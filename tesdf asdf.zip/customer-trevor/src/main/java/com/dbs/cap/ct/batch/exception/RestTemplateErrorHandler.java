package com.dbs.cap.ct.batch.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;

@Slf4j
public class RestTemplateErrorHandler implements ResponseErrorHandler {
    @Override
    public void handleError(ClientHttpResponse clientRes) {
        try {
            if(clientRes.getStatusCode() == HttpStatus.FORBIDDEN) {
                log.debug(HttpStatus.FORBIDDEN + " response");
            }
        } catch(IOException e) {
            log.error(e.getMessage(), e);
        }
    }

    @Override
    public boolean hasError(ClientHttpResponse clientRes) {
        try {
            if(clientRes.getStatusCode() != HttpStatus.OK) {
                log.debug("Status code " + clientRes.getStatusCode() + " Status Value "
                        + clientRes.getStatusText());
                log.debug(clientRes.getBody().toString());
                try {
                    if(clientRes.getStatusCode() == HttpStatus.FORBIDDEN) {
                        log.debug(" --- FORBIDDEN --- ");
                        return true;
                    }
                } catch(IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch(IOException e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }
}
