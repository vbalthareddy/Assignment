package com.dbs.cap.ct.batch.mapper;

import com.dbs.cap.ct.batch.model.CorpRelationship;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

@Slf4j
public class CorpRelationshipRowMapper implements RowMapper<CorpRelationship> {
    @Override
    public CorpRelationship mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        CorpRelationship cr = new CorpRelationship();
        cr.setChildCorpKey(resultSet.getString("CHILD_CORP_KEY"));
        cr.setLinkages(resultSet.getString("LINKAGES"));
        log.debug("RowMapper  : {}", cr);
        return cr;
    }
}
