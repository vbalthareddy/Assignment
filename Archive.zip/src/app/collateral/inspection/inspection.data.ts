export const InspectionFrequencyListResponse = [
    {
        'freq': 0,
        'freqDesc': 'CUSTOM'
    },
    {
        'freq': 1,
        'freqDesc': 'Monthly'
    },
    {
        'freq': 2,
        'freqDesc': '2 Months'
    },
    {
        'freq': 3,
        'freqDesc': '3 Months'
    },
    {
        'freq': 4,
        'freqDesc': '4 Months'
    }
];
export const InspectionTypeListResponse = [
    {
        'code': '16',
        'description': 'Market Value (Current) - Gross Development Value',
        'id': '01a029b2-2532-42b1-a572-c5e53600c652',
        'parentRefCode': null,
        'parentRefType': null,
        'scope': null,
        '_createdBy': 'cmsadmin',
        '_createdOn': '2017-08-16T07:22:27.575Z',
        '_isDeleted': false,
        '_modifiedBy': 'cmsadmin',
        '_modifiedOn': '2017-08-16T07:22:27.575Z',
        '_newVersion': null,
        '_oldVersion': null,
        '_requestId': null,
        '_type': 'InspectionAppraisalType',
        '_version': '89010428-fe57-4532-8a1c-ce46b183f18b'
    },
    {
        'code': '17',
        'description': 'Market Value (Current1) - Gross Development Value',
        'id': '01a029b2-2532-42b1-a572-c5e53600c652',
        'parentRefCode': null,
        'parentRefType': null,
        'scope': null,
        '_createdBy': 'cmsadmin',
        '_createdOn': '2017-08-16T07:22:27.575Z',
        '_isDeleted': false,
        '_modifiedBy': 'cmsadmin',
        '_modifiedOn': '2017-08-16T07:22:27.575Z',
        '_newVersion': null,
        '_oldVersion': null,
        '_requestId': null,
        '_type': 'InspectionAppraisalType',
        '_version': '89010428-fe57-4532-8a1c-ce46b183f18b'
    },
    {
        'code': '18',
        'description': 'Market Value (Current2) - Gross Development Value',
        'id': '01a029b2-2532-42b1-a572-c5e53600c652',
        'parentRefCode': null,
        'parentRefType': null,
        'scope': null,
        '_createdBy': 'cmsadmin',
        '_createdOn': '2017-08-16T07:22:27.575Z',
        '_isDeleted': false,
        '_modifiedBy': 'cmsadmin',
        '_modifiedOn': '2017-08-16T07:22:27.575Z',
        '_newVersion': null,
        '_oldVersion': null,
        '_requestId': null,
        '_type': 'InspectionAppraisalType',
        '_version': '89010428-fe57-4532-8a1c-ce46b183f18b'
    }
];
