import { CollateralComponent } from "app/collateral";
import { ComponentFixture } from "@angular/core/testing";
import { TestBed } from "@angular/core/testing";
import { async } from "@angular/core/testing";
import { OauthService } from "app/shared";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

class MockOauthService {

}


describe('CollateralComponent', () => {
    let component: CollateralComponent;
    let fixture: ComponentFixture<CollateralComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
             providers: [{provide: OauthService , useClass: MockOauthService}],
            declarations: [CollateralComponent],

            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            imports: [CommonModule, BrowserModule, BrowserAnimationsModule]
        })
            .compileComponents();
        fixture = TestBed.createComponent(CollateralComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    }));
    it('should create an instance of CollateralComponent',() => {
        expect(component).toBeTruthy();
    });
    it('should check canDeactive guard', () => {
        component.backBtnPress = false;
        expect(component.canDeactivate()).toBe(true);
        component.popUpShow = true;
        component.backBtnPress = true;
        expect(component.canDeactivate()).toBe(true);
        component.backBtnPress = true;
        component.popUpShow = false;
        expect(component.canDeactivate()).toBe(false);
    });
    it('should guard check popup message through event ',()=>{
       component.popUpshowEvent(false);
       expect(component.popUpShow).toBe(true);
    });
    it('should close popup dialog on click of close icon ',()=>{
        component.closeEventFromPopupDialog(false);
        expect(component.showPopupDialog).toBe(false);
    });
});

