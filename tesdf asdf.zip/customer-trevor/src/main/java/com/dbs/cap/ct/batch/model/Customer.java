package com.dbs.cap.ct.batch.model;

import lombok.Data;

@Data
public class Customer {
    private String entityId;
    private String entityType;
    private String entityName;
    private String countryOfIncorporation;
    private String countryOfOperation;
    private Boolean bankCustomer;
}
