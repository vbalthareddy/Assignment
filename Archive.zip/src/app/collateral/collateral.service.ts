import { AppSettings } from '../common/config/appsettings';
import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Observable, Observer } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { AutoSaveService } from '../common/autosave/auto-save.service';
import { SaveInProgress } from '../common/models/types';
import { ErrorResponse } from 'app/shared';
import { ChargeDetailList, DepositDetail, Collateral } from './model/collateral';
import { Subject } from 'rxjs/Subject';
import * as _ from 'underscore';
import { CustomFormControl } from '../common/custom-form-controls/custom-form-control';
import { TextboxValidator } from '../common/custom-validators/custom-textbox-validator';
import { OwnershipTotalPercentageValidator } from './ownership/ownership-total-percentage-validator';
import { GuarantorGridValidator, GuarantorGridValidatorForJOINT } from './collateral-guarantor/total-percentage-validator';
import { CollateralSummaryService } from './collateral-summary/collateral-summary.service';
import { CurrencyFormatPipe } from '../shared/currency-pipe/currency-pipe';
import { Subscription } from 'rxjs/Subscription';
import { JsonConvert } from 'json2typescript';
import { SessionService } from 'app/shared/auth/session.service';
@Injectable()
export class CollateralService {

    saveStateObservable: BehaviorSubject<SaveInProgress>;
    collateral: any;
    selectedCollateralType: string = null;
    tabSections: Array<String> = [];
    selectedTab: string;
    public limitDataBeneficiary: any = {};
    // error panel code
    backendErrors: any[] = [];
    private errorsModel: Subject<any> = new Subject<any>(); // the Object that would be used to control the error panel components
    formSubmitClicked: boolean = false; // check whether the Form was submitted or not
    errorTabs: any[] = []; // for controlling the tabs with errors, error icons for each tab
    // error panel code
    modifiedForm: string;
    errors: any[] = [];
    applicationDetailsSubmitted = false;
    dbsPercentageDetailsSubmitted = false;
    toggle = false;
    toggleDBSPercentage = false;
    dbsSharing: any[];
    maxCondition: any[];
    ratesLoaded = false;
    disableTab: boolean = false; // for disabling tab
    disabltButton: boolean = false; // for disabling button
    locationsForService: any[];
    collateralForm: FormGroup;
    chargeCompErrors: any[] = [];
    notIncludeValuationFormsFor: string[] = ['GUARN', 'DEPOS'];
    formCreated: boolean = false;
    checkPopupDialogBox:boolean = false;
    username: string = 'cls-user';
    collateralConfig: any = null;
    draftNeeded: boolean = false;
    lockStatus: boolean = false;
    agencyCodesSource: any[];

    lockedBy: string = null;
    private routeToHomePanel = new Subject<any>();

    sendMessage(message: string) {
        this.routeToHomePanel.next(message);
    }

    getMessage(): Observable<any> {
        return this.routeToHomePanel.asObservable();
    }

    constructor(private http: Http, private autoSaveService: AutoSaveService
        , private _fb: FormBuilder, public collateralSummaryService: CollateralSummaryService, private sessionService: SessionService) {
        this.saveStateObservable = new BehaviorSubject(false);

        // error panel code
        this.errorsModel.next({
            errorForm: {},
            entireForm: {},
            currentFormName: ''
        });
        // error panel code
        this.toggleDBSPercentage = false;
        this.toggle = false;

        this.loadCollateralConfig();
    }

    loadCollateralConfig() {
         this.getConfigurationsForCollaterals().subscribe(data => {
             this.collateralConfig = data;
         }, error => {
         });
    }

    // error panel code
    setErrorsModel(err?: any) {
        this.errorsModel.next(err);
    }

    // error panel code

    // error panel code
    getErrorsModel() {
        return this.errorsModel.asObservable();
    }

    // error panel code

    subscribeToSaveState(listner: Observer<SaveInProgress>) {
        this.saveStateObservable.subscribe(listner);
    }

    unSubscribeToSaveState() {
        this.saveStateObservable.unsubscribe();
        this.saveStateObservable = new BehaviorSubject(false);
    }

    setupAutoSave(form: FormGroup, listner: Observer<SaveInProgress>) {

        this.unSubscribeToSaveState();
        this.autoSaveService.unsubscribeToFormChanges();

        this.subscribeToSaveState(listner);
        this.autoSaveService.setup(form, this.saveStateObservable);
    }

    getCollateralFullForm(type: string, id: string): Observable<any> {
        return this.http.get('' + type + '/' + id)
            .map(
            res => res.json()
            );
    }

    getDraftCollateral(collateralId: string): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const filter = {
            where: { 'modelData.collateralId': collateralId },
            order: '_createdOn desc',
            limit: 1
        };

        if (filter) {
            params.set('filter', JSON.stringify(filter));
        }
        return this.http.get(AppSettings.apiBaseUrl + AppSettings.apiCollateralDraftApi, { search: params })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    public createCollateralForm() {
        this.collateralForm = this._fb.group({
            details: this.getDetailsForm(),
            beneficiary: this.getBeneficiaryForm(),
            charge: this.getChargeForm(),
            valuation: this.getApportionForm(),
            document: this.getDocumentForm(),
            ownership: this.getOwnershipForm(),
            particulars: this.getParticularsForm(),
            inspection: this.getInspectionForm(),
            insurance: this.getInsuranceForm()
        });
        this.formCreated = true;
        return this.collateralForm;
    }

    public getCollateralForm() {
        return this.collateralForm;
    }

    postCollateral(collateral: any): Observable<any> {

        this.toggleDBSPercentage = false;
        this.toggle = false;
        const collateralApi = this.collateralConfig[this.selectedCollateralType].apiToHit;
        const url = AppSettings.apiBaseUrl + collateralApi;
        return this.http.post(url, collateral)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    postELC(entitys?: any): Observable<any> {


        const url = AppSettings.apiBaseUrl + AppSettings.apiELC;
        return this.http.post(url, entitys)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    submitCollateral(): Observable<any> {

        const collateralApi = this.collateralConfig[this.selectedCollateralType].apiToHit;

        const url = AppSettings.apiBaseUrl + collateralApi;
        return this.http.put(url, this.collateral)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    getCollaterals(filter?: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();

        const collateralApi = this.collateralConfig[this.selectedCollateralType].apiToHit;

        if (filter) {
            params.set('filter', JSON.stringify(filter));
        }
        return this.http.get(AppSettings.apiBaseUrl + collateralApi, { search: params })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    getDetailsForm() {
        const tabForm = this._fb.group({
            collateralid: ['']
        });
        tabForm.valueChanges.subscribe(data => {
            this.modifiedForm = 'details';
        });
        return tabForm;
    }

    getDisabledTab(disableTab?: boolean) {
        return this.disableTab;
    }

    getDisabledButton(disabltButton?: boolean) {
        return this.disabltButton;
    }

    getParticularsForm() {
        const tabForm = this._fb.group({
            particularsList: ['']
        });
        tabForm.valueChanges.subscribe(data => {
            this.modifiedForm = 'Particular';
        });
        return tabForm;

    }

    getInsuranceForm() {
        const tabForm = this._fb.group({
            insuranceList: ['']
        });
        tabForm.valueChanges.subscribe(data => {
            this.modifiedForm = 'insurance';
        });
        return tabForm;

    }

    getBeneficiaryForm() {
        const tabForm = this._fb.group({
            beneficiaryList: []
        });
        tabForm.valueChanges.subscribe(data => {
            this.modifiedForm = 'Beneficiary';
        });
        return tabForm;
    }

    getInspectionForm() {
        const tabForm = this._fb.group({
            inspectionAppraisalList: []
        });
        tabForm.valueChanges.subscribe(data => {
            this.modifiedForm = 'Inspection';
        });
        return tabForm;
    }

    getCollateral() {
        return this.collateral;
    }

    getDocumentForm(document?: Document) {
        const tabForm = this._fb.group({
            documentidList: []
        });
        tabForm.valueChanges.subscribe(data => {
            this.modifiedForm = 'document';
        });
        return tabForm;
    }

    getChargeForm() {
        const tabForm = this._fb.group({
            chargeList: ['']
        });
        tabForm.valueChanges.subscribe(data => {
            this.modifiedForm = 'charge';
        });
        return tabForm;
    }

    getApportionForm() {
        const f: FormGroup = this._fb.group({});
        if (this.notIncludeValuationFormsFor.indexOf(this.selectedCollateralType) === -1) {
            const customControl = new CustomFormControl('', [TextboxValidator.required]);
            customControl.label = 'Valuation Report Required';
            f.addControl('valRepRequired', customControl);
            f.addControl('justificationRemark', new FormControl(''));
        }
        return f;
    }

    getOwnershipForm() {
        const tabForm = this._fb.group({
            ownershipid: []
        });

        // in case of DEPOS we have to make the Ownership mandatory
        this.addOwnershipVallidation(tabForm);
        this.guarantorGridLengthValidation(tabForm);


        tabForm.valueChanges.subscribe(data => {
            this.modifiedForm = 'ownership';
        });
        return tabForm;
    }

    addOwnershipVallidation(ownershipForm?: FormGroup) {
        if (this.selectedCollateralType !== 'GUARN') {
            ownershipForm.addControl('totalPercentageSum', new CustomFormControl('0.000', [OwnershipTotalPercentageValidator.required]));
            (<CustomFormControl>ownershipForm.controls['totalPercentageSum']).type = 'text';
            (<CustomFormControl>ownershipForm.controls['totalPercentageSum']).label = 'Total Ownership Percentage';
            if (this.getCollateral().ownershipDetails.length > 0) {
                (<FormControl>ownershipForm.controls['totalPercentageSum']).setValue(100);
            } else {
                (<FormControl>ownershipForm.controls['totalPercentageSum']).setValue(null);
            }
        }
    }

    validateOwnershipDetails(ownershipForm?: any) {
        if (this.selectedCollateralType === 'GUARN') {
            if (this.getCollateral().ownershipDetails && this.getCollateral().ownershipDetails.length > 0) {
                (<FormControl>ownershipForm.controls['minGridLengthCheck'])
                    .setValue(true);
            } else {
                (<FormControl>ownershipForm.controls['minGridLengthCheck'])
                    .setValue(false);
            }
            const colObj = this.getCollateral();
            ownershipForm.addControl('minGridLengthCheckForJOINT', new CustomFormControl('false', [GuarantorGridValidatorForJOINT.required]));
            (<CustomFormControl>ownershipForm.controls['minGridLengthCheckForJOINT']).type = 'boolean';
            (<CustomFormControl>ownershipForm.controls['minGridLengthCheckForJOINT']).label = 'Total Length';
            if (this.getCollateral().ownershipDetails && this.getCollateral().ownershipDetails.length > 0
                && ((colObj['LodgeCollateralTypeSpecificDetail']['guaranteeType'] === 'JOINT') || (colObj['LodgeCollateralTypeSpecificDetail']['guaranteeType'] === 'JOINT&SEVERAL'))
                && (this.getCollateral().ownershipDetails.length === 1)) {
                (<FormControl>ownershipForm.controls['minGridLengthCheckForJOINT'])
                    .setValue(false);
            } else {
                (<FormControl>ownershipForm.controls['minGridLengthCheckForJOINT'])
                    .setValue(true);
            }
        }

        if (this.selectedCollateralType !== 'GUARN') {
            (<CustomFormControl>ownershipForm.controls['totalPercentageSum']).type = 'text';
            (<CustomFormControl>ownershipForm.controls['totalPercentageSum']).label = 'Total Ownership Percentage';
            if (this.getCollateral().ownershipDetails.length > 0) {
                (<FormControl>ownershipForm.controls['totalPercentageSum']).setValue(100);
            } else {
                (<FormControl>ownershipForm.controls['totalPercentageSum']).setValue(null);
            }
        }
    }

    guarantorGridLengthValidation(ownershipForm?: FormGroup) {
        if (this.selectedCollateralType === 'GUARN') {
            ownershipForm.addControl('minGridLengthCheck', new CustomFormControl('false', [GuarantorGridValidator.required]));
            (<CustomFormControl>ownershipForm.controls['minGridLengthCheck']).type = 'boolean';
            (<CustomFormControl>ownershipForm.controls['minGridLengthCheck']).label = 'Total Length';
            if (this.getCollateral().ownershipDetails && this.getCollateral().ownershipDetails.length > 0) {
                (<FormControl>ownershipForm.controls['minGridLengthCheck'])
                    .setValue(true);
            } else {
                (<FormControl>ownershipForm.controls['minGridLengthCheck'])
                    .setValue(false);
            }
            const colObj = this.getCollateral();

            ownershipForm.addControl('minGridLengthCheckForJOINT', new CustomFormControl('false', [GuarantorGridValidatorForJOINT.required]));
            (<CustomFormControl>ownershipForm.controls['minGridLengthCheckForJOINT']).type = 'boolean';
            (<CustomFormControl>ownershipForm.controls['minGridLengthCheckForJOINT']).label = 'Total Length';
            if (this.getCollateral().ownershipDetails && this.getCollateral().ownershipDetails.length > 0
                && ((colObj['LodgeCollateralTypeSpecificDetail']['guaranteeType'] === 'JOINT') || (colObj['LodgeCollateralTypeSpecificDetail']['guaranteeType'] === 'JOINT&SEVERAL')) && (this.getCollateral().ownershipDetails.length === 1)) {
                (<FormControl>ownershipForm.controls['minGridLengthCheckForJOINT'])
                    .setValue(false);
            } else {
                (<FormControl>ownershipForm.controls['minGridLengthCheckForJOINT'])
                    .setValue(true);
            }

        }

    }

    getCollateralTypes(filter?: any): Observable<any> {
        // TODO: we need to use search filter
        const url = AppSettings.apiBaseUrl + AppSettings.apiGetcollateralTypes;
        const params: URLSearchParams = new URLSearchParams();
        if (filter) {
            params.set('filter', JSON.stringify(filter));
        } else {
            params.set('filter', '{"order":"collateralType"}');
        }
        return this.http.get(url, {
            'search': params
        })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }

    }

    getCollateralCodes(filter?: any, filterFlag?: boolean): Observable<any> {
        // TODO: we need to use search filter
        const url = AppSettings.apiBaseUrl + AppSettings.apiGetcollateralCodes;
        const params: URLSearchParams = new URLSearchParams();
        if (filter) {
            if (filterFlag) {
                filter = '{"where":{"collateralCode":{"regexp": "/' + filter + '/i"}},"order":"collateralCode"}';
            } else {
                filter = '{"where":{"collateralType": "' + filter + '"},"order":"collateralType"}';
            }

            params.set('filter', filter);
        }
        return this.http.get(url, { search: params })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }


    }


    searchOnTypeAndFilter(collateralType?: any, event?: any) {
        const url = AppSettings.apiBaseUrl + AppSettings.apiGetcollateralCodes;
        const params: URLSearchParams = new URLSearchParams();
        const filter = '{"where":{"collateralCode":{"regexp": "/' + event + '/i"}, "collateralType":"' + collateralType + '"},"order":"collateralCode"}';
        params.set('filter', filter);
        return this.http.get(url, { search: params })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    getLocations(filter?: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();

        const url = AppSettings.apiBaseUrl + AppSettings.apiToGetCountries;
        if (!filter) {
            filter = { 'fields': ['code', 'description'], 'order': 'description' };
        }
        params.set('filter', JSON.stringify(filter));
        return this.http.get(url, { search: params })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    getDbsSharingBasis(): Observable<any> {
        // TODO : Needs implemenatation
        const url = AppSettings.apiBaseUrl + AppSettings.apiToGetDBSSharingBasis;
        return this.http.get(url)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }

    }

    getMaxCondition(): Observable<any> {
        // TODO : Needs implemenatation
        const url = AppSettings.apiBaseUrl + AppSettings.apiToGetMaxCondition;
        return this.http.get(url)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }

    }

    getSolicitorAgencys(filter?: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const url = AppSettings.apiBaseUrl + AppSettings.apiToGetSolicitorAgencys;
        if (!filter) {
            filter = { 'fields': ['code', 'description'], 'order': 'description' };
        }
        params.set('filter', JSON.stringify(filter));
        return this.http.get(url, { search: params })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    errorResponseFunction(error: any) {
        const ErrorResponse = <ErrorResponse>error;
        return Observable.throw(<ErrorResponse>ErrorResponse);
    }

    getLimitsByLimitTypeId(filter?: any): Observable<any> {
        // return Observable.of(limitData);
        const url = AppSettings.apiBaseUrl + AppSettings.apiLimit;
        const params: URLSearchParams = new URLSearchParams();
        if (filter) {
            // filter = '{"where":{"limitTypeId": "' + filter + '"}}';
            params.set('filter', JSON.stringify(filter));
        }
        return this.http.get(url, { search: params })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    getLinkagesByCollateral(collateralId?: any): Observable<any> {
        // return Observable.of(linkageData);
        let url;
        if (this.selectedCollateralType === 'GUARN') {
            url = AppSettings.apiBaseUrl + AppSettings.apiGuarnCollaterals;
        } else if (this.selectedCollateralType === 'DEPOS') {
            url = AppSettings.apiBaseUrl + AppSettings.apiDeposCollaterals;
        } else {
            return Observable.throw('Invalid Collateral Type');
        }
        url += '/' + collateralId + '/linkage-detail';
        const params: URLSearchParams = new URLSearchParams();
        if (collateralId) {
            collateralId = '{"where":{"collateralId": "' + collateralId + '"}}';
            params.set('filter', collateralId);
        }
        return this.http.get(url, { search: params })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {

            return (resp.json());
        }
    }

    getLinkages(collateralId?: any) {

        const entityData = this.collateral.linkageDetails;

        const limits = _.map(this.collateral.linkageDetails, function (element, index, list) {
            return element.entityId;
        });

        const filter = { where: { limitId: { inq: limits } }, fields: ['limitId', 'limitTypeId'] };

        this.getLimitsByLimitTypeId(filter).subscribe(limitsResult => {
            this.limitDataBeneficiary = _.groupBy(_.map(entityData, function (element, index, list) {
                const linkage = _.where(limitsResult, { limitId: element.entityId });
                return {
                    limitId: element.entityId,
                    collateralId: element.collateralId,
                    gcin: linkage[0].limitTypeId
                };
            }), function (obj) {
                return obj.gcin;
            });
        },
            error => {
            }
        );
    }

    getLimitData() {
        return this.limitDataBeneficiary;
    }

    getData(path: string): Observable<any> {
        const url = AppSettings.apiBaseUrl + path;
        return this.http.get(url)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    setErrors(errors?: any[]) {
        this.errors = this.errors;
    }

    getConfigurationsForCollaterals(): Observable<any> {
        let configPath = '';
        configPath = '../assets/collaterals-config';
        return this.http.get(configPath)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    processCollateralValueForCollateralType(collateralCurrency: any, formField: FormControl | number | any) {
        this.ratesLoaded = false;
        const indexOfRate = this.collateralSummaryService.rateConversionArray.findIndex(item => item['toCurrency'] === collateralCurrency);
        if (indexOfRate === undefined || (indexOfRate === -1)) {
            this.collateralSummaryService.getRateValues('', collateralCurrency).subscribe(response => {
                this.collateralSummaryService.rateConversionArray = this.collateralSummaryService.rateConversionArray.concat(response);
                const index = this.collateralSummaryService.rateConversionArray.findIndex(data => data.toCurrency === collateralCurrency);
                this.checkForCollateralType(collateralCurrency, formField);
                this.ratesLoaded = true;
            }, error => {
                this.checkForCollateralType(collateralCurrency, formField);
                this.ratesLoaded = true;
            });
        } else {
            this.checkForCollateralType(collateralCurrency, formField);
            this.ratesLoaded = true;
        }
    }

    processSumValuesForGrid(collateralCurrency: string, formField: FormControl | number | any) {
        const gridDataObj: DepositDetail[] = this.getCollateral().LodgeCollateralTypeSpecificDetail.depositDetails;
        let earmarkAmountCounter = 0;
        let principalAmountCounter = 0;
        let availableBalanceCounter = 0;

        for (let i = 0; i < gridDataObj.length; i++) {

            const principleCcyRate = this.getRateForCurrency(collateralCurrency, gridDataObj[i].principal.ccy);
            const accountCcyRate = this.getRateForCurrency(collateralCurrency, gridDataObj[i].earmarkAmount.ccy);
            const availableCcyRate = this.getRateForCurrency(collateralCurrency, gridDataObj[i].avlblBalance.ccy);

            principalAmountCounter = principalAmountCounter + gridDataObj[i].principal.value * principleCcyRate;
            availableBalanceCounter = availableBalanceCounter + gridDataObj[i].avlblBalance.value * availableCcyRate;
            earmarkAmountCounter = earmarkAmountCounter + gridDataObj[i].earmarkAmount.value * accountCcyRate;
        }

        this.addSummaryRow(earmarkAmountCounter, collateralCurrency, formField);
        return [principalAmountCounter, availableBalanceCounter, earmarkAmountCounter];

    }

    addSummaryRow(earmarkAmountCounter: number, collateralCurrency: any, formField: CustomFormControl) {
        const collateralObj = this.getCollateral().CollateralValuationDetail;
        const exrenalChargeAmnt = collateralObj.externalChargeAmt.value;
        collateralObj.collateralValue.value = earmarkAmountCounter;
        collateralObj.collateralValue.ccy = collateralCurrency;
        collateralObj.finalCollateralValue.value = collateralObj.collateralValue.value - exrenalChargeAmnt;
        collateralObj.finalCollateralValue.ccy = collateralCurrency;
        formField.setValue(this.amountFormatter(collateralObj.finalCollateralValue.value));
    }

    getRateForCurrency(collateralCcy, amountCcy) {
        if (amountCcy === collateralCcy) {
            return 1;
        } else {
            if (this.collateralSummaryService.rateConversionArray.length > 0) {
                const indexOfRate = this.collateralSummaryService.rateConversionArray.findIndex(data => data.fromCurrency === amountCcy && data.toCurrency === collateralCcy);
                if (indexOfRate !== undefined && (indexOfRate !== -1)) {
                    return this.collateralSummaryService.rateConversionArray[indexOfRate]['rate'];
                } else {
                    return 0;
                }
            } else {
                return 0;
            }
        }
    }

    amountFormatter(amount: any): string {
        let value: number;
        if (!amount) {

            return '';
        }
        if (typeof (amount) !== 'string') {
            amount = amount.toString();
        }
        if (amount.endsWith('K') || amount.endsWith('k')) {
            amount = amount.substring(0, amount.length - 1);
            value = Number(amount) * 1000.00;
        } else if (amount.endsWith('M') || amount.endsWith('m')) {
            amount = amount.substring(0, amount.length - 1);
            value = Number(amount) * 1000000.00;
        } else if (amount.endsWith('B') || amount.endsWith('b')) {
            amount = amount.substring(0, amount.length - 1);
            value = Number(amount) * 1000000000.00;
        } else {
            value = Number(this.revertMinimumFractionDigits(amount));
        }
        if (!Number(value)) {
            value = 0.00;
        }
        value = Number(value.toFixed(3));

        return value.toLocaleString(undefined, {
            minimumFractionDigits: 2
        }).toString();
    }

    revertMinimumFractionDigits(amount: string): string {
        if (!amount) {
            return amount;
        }
        return amount.replace(/\,/g, '');
    }

    checkForCollateralType(collateralCurrency: any, formField: CustomFormControl) {
        if (this.selectedCollateralType === 'DEPOS') {
            this.processSumValuesForGrid(collateralCurrency, formField);
        } else if (this.selectedCollateralType === 'GUARN') {
            this.processCollateralValForGuarn(collateralCurrency, formField);
        } else {
            this.processChargeAmtSum(collateralCurrency, formField);
        }
    }

    processCollateralValForGuarn(collateralCurrency: string, formField?: FormControl | number | any) {
        const collateralObj = this.getCollateral().CollateralValuationDetail;
        collateralObj.collateralValue.value = CurrencyFormatPipe.transformAsNumberFromString(formField.value);
        collateralObj.collateralValue.ccy = collateralCurrency;
        collateralObj.finalCollateralValue.value = CurrencyFormatPipe.transformAsNumberFromString(formField.value);
        collateralObj.finalCollateralValue.ccy = collateralCurrency;
    }

    /* Currency change events for Charge Value */
    processChargeAmtSum(collateralCurrency: string, formField?: FormControl | number | any) {
        const gridDataObj: ChargeDetailList[] = this.getCollateral().LodgeChargeDetail.chargeDetailList;
        let counter = 0;
        let chargeAmountCounter = 0;
        for (let i = 0; i < gridDataObj.length; i++) {
            if (gridDataObj[i].externalCharge) {
                const externalChargeRate = this.getRateForCurrency(collateralCurrency, gridDataObj[i].chargeAmt.ccy);
                chargeAmountCounter = chargeAmountCounter + CurrencyFormatPipe.transformAsNumberFromString(gridDataObj[i].chargeAmt.value) * externalChargeRate;
                counter++;
            }
        }
        this.calculateFinalCollateralValueFromService(chargeAmountCounter, collateralCurrency, formField);

    }

    calculateFinalCollateralValueFromService(sumOfChargeAmt: number, collateralCurrency: any, formField: CustomFormControl) {
        const collateralObj = this.getCollateral().CollateralValuationDetail;
        collateralObj.collateralValue.value = CurrencyFormatPipe.transformAsNumberFromString(formField.value);
        collateralObj.collateralValue.ccy = collateralCurrency;
        collateralObj.externalChargeAmt.value = CurrencyFormatPipe.transformAsNumberFromString(sumOfChargeAmt);
        collateralObj.externalChargeAmt.ccy = collateralCurrency;
        collateralObj.finalCollateralValue.value = collateralObj.collateralValue.value - collateralObj.externalChargeAmt.value;
        collateralObj.finalCollateralValue.ccy = collateralCurrency;

        formField.setValue(this.amountFormatter(collateralObj.collateralValue.value));

        if (collateralObj.finalCollateralValue.value < 0.0) {
            this.chargeCompErrors = [];
            this.chargeCompErrors.push('Total External charge should not exceed the collateral value.');
        } else {
            this.chargeCompErrors = [];
        }

    }


    isCollateralLocked(collateralId: string, collateralType: string): Observable<any> {
        return this.getCollateralsAndCompareData(collateralId, collateralType).map(data => {
            return this.compareCollaterals(data[0], data[1]);
        });
    }

    getCollateralsAndCompareData(collateralId: string, collateralType: string): Observable<any> {
        const collateralIdFilter = {
            where: { collateralId: collateralId },
            include: this.collateralConfig[collateralType].include
        };

        return Observable.forkJoin(
            this.collateralSummaryService.getCollateralsList(collateralType, this.collateralConfig[collateralType].apiToHit, collateralIdFilter).map(data => {
                if (data.length > 0) {
                    return data[0];
                } else {
                    return null;
                }
            },
                error => {
                }),
            this.getDraftCollateral(collateralId).map(draftData => {
                if (draftData.length > 0) {
                    return draftData[0];
                } else {
                    return null;
                }
            })

        );
    }

    compareCollaterals(mainCollateral: any, draftCollateral: any): boolean {
        if (draftCollateral != null && mainCollateral != null && draftCollateral._modifiedOn > mainCollateral._modifiedOn) {
            this.collateral = JsonConvert.deserializeString(JSON.stringify(draftCollateral.modelData), Collateral);

            if (draftCollateral._modifiedBy === this.sessionService.getUsername()) {
                return false;
            } else if (this.getTimeDifference(draftCollateral._modifiedOn) > 30) {
                this.draftNeeded = true;
                return false;
            } else {
                this.lockStatus = true;
                this.lockedBy = draftCollateral._modifiedBy;
                return true;
            }
        } else {
            this.collateral = JsonConvert.deserializeString(JSON.stringify(mainCollateral), Collateral);
            this.draftNeeded = true;
            return false;
        }
    }

    getTimeDifference(modifiedOn: any)
    {
        const currentDate = (new Date()).toISOString();
        const minutes = Math.ceil((new Date(currentDate).getTime() - new Date(modifiedOn).getTime()) / 60000);
        return minutes;

    }

    clearCollateral() {
        this.collateral = undefined;
        this.toggle = false;
        this.toggleDBSPercentage = false;
        this.tabSections = [];
        this.limitDataBeneficiary = {};
        this.collateralForm = null;
        this.draftNeeded = false;
        this.lockStatus = false;
    }
}