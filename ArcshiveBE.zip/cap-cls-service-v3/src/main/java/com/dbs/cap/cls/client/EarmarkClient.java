package com.dbs.cap.cls.client;

import com.dbs.cap.cls.common.constants.ClsConstants;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;

@FeignClient(
        name = "EarmarkClient",
        url = "${ev.limit.host.v2}"
)
public interface EarmarkClient {
    @RequestMapping(
            path = "/api/Earmarks",
            method = RequestMethod.GET)
    List<HashMap<String, Object>> getEarmarks(
            @RequestParam(ClsConstants.FILTER) String filter);

    @RequestMapping(
            path = "/api/Earmarks",
            method = RequestMethod.PUT)
    HashMap<String, Object> updateEarmark(
            @RequestBody Object requestPayload);
}
