package com.dbs.cap.cls.common.configuration;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class CurrentUser {
    public String getOnebankId() {
        return (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }
}