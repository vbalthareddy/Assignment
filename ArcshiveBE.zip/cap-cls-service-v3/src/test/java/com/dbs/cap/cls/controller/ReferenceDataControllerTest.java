package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.oauth.OAuth2TestHelper;
import com.dbs.cap.cls.common.test.BaseMockMvcWiremockIntegrationTest;
import com.dbs.cap.cls.common.test.IntegrationTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.io.ByteArrayOutputStream;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Category(IntegrationTest.class)
@ActiveProfiles("test")
public class ReferenceDataControllerTest extends BaseMockMvcWiremockIntegrationTest {
    @Autowired
    private OAuth2TestHelper oauthHelper;
    @Autowired
    private WebApplicationContext webApplicationContext;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/BaseUsers/login.*")),
                "{\"id\":\"12345\"}");
        mockResponse(WireMock.post(WireMock.urlMatching("^/oauth/token.*")),
                "{\"access_token\":\"token1234\",\"expires_in\":28776}");
    }

    @Test
    public void create_referenceData_400_BAD_REQUEST() throws Exception {
        MockMultipartFile firstFile = new MockMultipartFile("file", "someExcelFile.xls",
                "application/vnd.ms-excel", new byte[0]);
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/LimitTypes.*")), null);
        mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mvc.perform(MockMvcRequestBuilders.fileUpload("/cls/api/v1/limit/bulk-upload/LimitTypes")
                .file(firstFile).with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value()));
    }

    @Test
    public void create_referenceData_collateral_400_BAD_REQUEST() throws Exception {
        MockMultipartFile firstFile = new MockMultipartFile("file", "someExcelFile.xls",
                "application/vnd.ms-excel", new byte[0]);
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/CollateralTypes.*")), null);
        mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mvc.perform(MockMvcRequestBuilders.fileUpload("/cls/api/v1/collateral/bulk-upload/CollateralTypes")
                .file(firstFile).with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value()));
    }

    @Test
    public void create_limit_reference_data_200_OK() throws Exception {
        MockMultipartFile firstFile = new MockMultipartFile("file", "someExcelFile.xls",
                "application/vnd.ms-excel",
                createExcel().toByteArray());
        mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/LimitTypes.*")), null);
        mvc.perform(MockMvcRequestBuilders.fileUpload("/cls/api/v1/limit/bulk-upload/LimitTypes")
                .file(firstFile).with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().is(200));
    }

    @Test
    public void create_collateral_reference_data_200_OK() throws Exception {
        MockMultipartFile firstFile = new MockMultipartFile("file", "someExcelFile.xls",
                "application/vnd.ms-excel",
                createExcel().toByteArray());
        mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/LimitTypes.*")), null);
        mvc.perform(MockMvcRequestBuilders.fileUpload("/cls/api/v1/collateral/bulk-upload/LimitTypes")
                .file(firstFile).with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().is(200));
    }

    @Test
    public void get_limit_reference_types_200_OK() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/ModelDefinitions.*")),
                "[{\"plural\":\"CategoryType\",\"name\":\"CategoryType\"}," +
                        "{\"plural\":\"RiskTakers\",\"name\":\"RiskTaker\"}]");
        mvc.perform(get("/cls/api/v1/limit/reference-type?filter=123")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[*].plural",
                        Matchers.hasItems(
                                Matchers.equalTo("CategoryType"),
                                Matchers.equalTo("RiskTakers"))));
    }

    @Test
    public void get_collateral_reference_types_200_OK() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/ModelDefinitions.*")),
                "[{\"plural\":\"CategoryType\",\"name\":\"CategoryType\"}," +
                        "{\"plural\":\"RiskTakers\",\"name\":\"RiskTaker\"}]");
        mvc.perform(get("/cls/api/v1/collateral/reference-type?filter=123")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[*].plural",
                        Matchers.hasItems(
                                Matchers.equalTo("CategoryType"),
                                Matchers.equalTo("RiskTakers"))));
    }

    @Test
    public void get_limit_reference_type_200_OK() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/RiskTakers.*")),
                "");
        mvc.perform(get("/cls/api/v1/limit/reference-type/RiskTakers")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void get_collateral_reference_type_200_OK() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/RiskTakers.*")),
                "");
        mvc.perform(get("/cls/api/v1/collateral/reference-type/RiskTakers")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    private ByteArrayOutputStream createExcel() throws Exception {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Test Sheet");
        Object[][] datatypes = {
                {"Datatype", "Type", "Size(in bytes)"},
                {"int", "Primitive", 2},
                {"float", "Primitive", 4},
                {"double", "Primitive", 8},
                {"char", "Primitive", 1},
                {"String", "Non-Primitive", "No fixed size"}
        };
        int rowNum = 0;
        for(Object[] datatype : datatypes) {
            Row row = sheet.createRow(rowNum++);
            int colNum = 0;
            for(Object field : datatype) {
                Cell cell = row.createCell(colNum++);
                if(field instanceof String) {
                    cell.setCellValue((String) field);
                } else if(field instanceof Integer) {
                    cell.setCellValue((Integer) field);
                }
            }
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            workbook.write(bos);
        } finally {
            bos.close();
        }
        return bos;
    }
}