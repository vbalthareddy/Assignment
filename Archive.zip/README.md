Will be better formatted soon........


Prerequisites
For starting with the project the system need to have
1.	Node.js – 4.x.x or above version (By running node –v command)
2.	Npm – 3.x.x or above version (By running npm –v command)

Angular CLI commands
As DBS does not support Angular CLI so this section may not be required.
Use Angular CLI commands to do the following:
•	ng serve to run NG Live Development Server is running on http://localhost:3030.
o	Default port is specified in .ember-cli
•	ng test to run unit tests
•	ng test-once to run unit tests once.
o	This will also produce code coverage report
•	ng e2e to run end to end test
•	ng build to uglify, minify, prune, transpile and bundle the source code (including scss!) into dist folder
Local and end to end testing
To be able to easily connect to the CAP-CLS backend we're assuming from the Angular side that the app is always accessible at /cls/api/v1. To handle this we need to have Nginx installed on our local dev machines, configured the same way as on the production environments.
To install and configure nginx run bin/configure-nginx. When running the app with npm start you can then access it on port 80 on localhost.

End-to-end (E2E) Tests
E2E tests are in the e2e directory, side by side with the app folder. Their filenames must end in .e2e-spec.ts.
Note: the first time you want to run e2e tests you need to install the correct web driver, do so by running: npm run e2e:setup
In order to run e2e tests locally:
•	Make sure nginx is up
•	Make sure your UI and API projects are up to date
•	Start wiremock app on port 9999  ./bin/run-wiremock 
•	Start API service on 8080
•	Start UI on 3030
•	Run e2e tests with ng e2e command
Connecting to Backend services
CAP-CLS UI only calls CAP-CLS backend services directly, via /cls/api/v1. Therefore we can avoid configuring CORS. By proxying the configuration can be dealt with by nginx. Which means the app can run in any environment.
We setup the /cls/api/v1 endpoint in nginx using the environment variable CAP_CLS_API_DOMAIN and provide it's value in Cloud Foundry. The value will be the service domain name.
For example:
CAP_CLS_API_DOMAIN= https://cap-cls-service.dev.apps.cs.sgp.dbs.com

	For login : /cls/api/v1/login (POST)
		For testing purpose below credentials can be used.
			Username: demouser
			Password : demouser
	The password cannot be entered wrong more than once or else it will be locked.
Install notes
While on the DBS network, npm will be using a network proxy. This can cause issues due to missed/timeout requests which return a HTML body instead of the package.
npm reports this as an invalid sha checksum.
To work around this, you'll need to rerun an install for the missed packages, one by one. Sadly, this will include dependent packages.

DBS internal npm server
There is also a DBS internal npm server available, which may provide a better installation experience.
Please note, the internal server is not updated automatically.
You can configure your local npm to use the DBS server with this command:
npm config set registry http://10.92.142.37:8081/artifactory/api/npm/dbs-npm
Known issues with using npm on DBS network / from Jenkins / thru Artifactory
node-sass
node-sass npm package requires native library to be downloaded from https://github.com/sass/node-sass-binaries
In case if proxy doesn't allow the download, download the file manually, upload to artifactory, and use it to install the package
// one time get of node-sass
sh "rm -f linux-x64-48_binding.node*"
sh "wget http://artifactory.dev.sys.cs.sgp.dbs.com/artifactory/libs-release-local/nodejs/utils/linux-x64-48_binding.node.zip-1 -O linux-x64-48_binding.node.zip"
sh "unzip linux-x64-48_binding.node.zip"

sh "npm uninstall node-sass"
sh "rm -fr node_modules/node-sass"

// install node-sass specifying a binary
sh "npm install node-sass --sass-binary-path=`pwd`/linux-x64-48_binding.node --verbose"

// create a folder and copy that binary into the node_sass module
sh "mkdir -p node_modules/node-sass/vendor/linux-x64-48"
sh "cp linux-x64-48_binding.node node_modules/node-sass/vendor/linux-x64-48/binding.node"
