import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';
import {Http, Response, URLSearchParams} from '@angular/http';
import {AppSettings} from './../../common/config/appsettings';
import {ErrorResponse} from '../../shared';

@Injectable()
export class InsuranceService {
    public params: any;

    constructor(private http: Http) {

    }
    getInsuranceTypesfromService(): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        params.set('access_token', null);

        const filter = {'fields': ['code', 'description'], 'order': 'description'};
        params.set('filter', JSON.stringify(filter));
        return this.http.get(AppSettings.apiBaseUrl + AppSettings.apiToGetInsuranceType, {search: params})
            .map(onSuccessSuccess.bind(this))
            .catch(error => error.message || error);

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }
}
