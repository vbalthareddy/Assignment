final APP_NAME = 'cap-cls-service-v3'
def GIT_BRANCH = "develop"
node {
    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'
    jenkins.downloadArtifactory(APP_NAME, BUILD_NUMBER, "${APP_NAME}.jar")
    jenkins.downloadManifest("https://gitlab.dev.apps.cs.sgp.dbs.com/cap/${APP_NAME}/raw/${GIT_BRANCH}/cloudfoundry/uat.yml")
    jenkins.loginWithCred('api.dev.sys.cs.sgp.dbs.com', 'ecb8efc3-6d07-4e55-bbe1-0a3b08636957')
    jenkins.target("-o dev-credit-risk -s cap-cls-service-v3-uat")
    jenkins.deploy(APP_NAME, "-p ${APP_NAME}.jar")
}