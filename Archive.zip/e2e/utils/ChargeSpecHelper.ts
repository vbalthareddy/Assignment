import {E2eSpecHelper} from './E2eSpecHelper';
import {$, protractor} from 'protractor';

const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const charge: any = {
    chargeIdOnTab: $('#charge_tab'),
    closeDialogIcon: $('.k-dialog-close'),
    natureOfChargesDropDown: $('#natureOfChargesDropDown'),
    natureOfChargesDropDownValue: (searchTerm: string): any => $('#natureOfChargesDropDown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
    chargeRankDropDown: $('#chargeRankDropDown'),
    chargeRankDropDownValue: (searchTerm: string): any => $('#chargeRankDropDown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
    chargeAmountInput: $('#chargeAmountInput'),
    chargeAmountInputValue: (chargeAmountInputVal: string): any => $('#chargeAmountInput input.cls-text').sendKeys(chargeAmountInputVal),
    registrationAuthorityInfo: $('#registrationAuthorityInfoId textarea'),
    registrationAuthorityInfoValue: (registrationAuthorityInfoInput: string): any => $('#registrationAuthorityInfoId textarea.commentTextArea__input').sendKeys(registrationAuthorityInfoInput, protractor.Key.ENTER),
    updateBtn: $('#update_charge_details_btn'),
    editIcon: $('#chargeEditIcon-0'),
    deleteIcon: $('#chargeDeleteIcon-0'),
    noRecordLink: $('#no-records-label-link'),
    filingDateIcon: $('#filingDateInput .input-group-addon'),
    filingDateSelect: $('.btn.active'),
    receiptDateIcon: $('#receiptDateInput .input-group-addon'),
    receiptDateSelect: $('.btn.active')
};

exports.ChargeTestSuite = function () {
    describe('Charge_Details_Page', function () {

        it('should have the title of tab as Charge', function () {
            e2eSpecHelper.sleepBrowser(3000);
            charge.chargeIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#charge_tab', 'Charge');
        });

        it('should display no-record-component when no data is shown in charge grid', function () {
            e2eSpecHelper.sleepBrowser(2000);
            charge.noRecordLink.click();
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Charge Details Found');
            e2eSpecHelper.sleepBrowser(2000);
            charge.closeDialogIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding charge details');
        });

        it('should display validation errors in charge dialog box when entering invalid value for Nature of Charge Data', function () {
            e2eSpecHelper.buttonClick('.clsBtnSecondary');
            e2eSpecHelper.sleepBrowser(1000);
            charge.natureOfChargesDropDown.click();
            charge.natureOfChargesDropDownValue('invalid');
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('.k-dialog-close');
            charge.closeDialogIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should display validation errors in charge dialog box when user clicks on save button without entering any details', function () {
            e2eSpecHelper.buttonClick('.clsBtnSecondary');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.buttonClick('#save_charge_details_btn');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should add charge data with valid values and show it on charge grid', function () {
            charge.natureOfChargesDropDown.click();
            charge.natureOfChargesDropDownValue('s');
            e2eSpecHelper.sleepBrowser(1000);
            charge.chargeRankDropDown.click();
            charge.chargeRankDropDownValue('1');
            e2eSpecHelper.sleepBrowser(1000);
            charge.chargeAmountInput.click();
            charge.chargeAmountInputValue('123k');
            e2eSpecHelper.sleepBrowser(1000);
            charge.filingDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            charge.filingDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            charge.receiptDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            charge.receiptDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.buttonClick('#save_charge_details_btn');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of charge details has been successfully added.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should click on edit icon from charge grid, update registration authority data and reflect updated data into charge grid', function () {
            charge.editIcon.click();
            e2eSpecHelper.verifyPresence('#chargeEditIcon-0');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#update_charge_details_btn', 'Update');
            e2eSpecHelper.sleepBrowser(3000);
            charge.registrationAuthorityInfo.clear();
            charge.registrationAuthorityInfoValue('Reg auth');
            charge.updateBtn.click();
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of charge details has been successfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should click on delete icon and remove data from charge grid', function () {
            e2eSpecHelper.verifyPresence('#chargeDeleteIcon-0');
            charge.deleteIcon.click();
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of charge details has been successfully deleted.');
            e2eSpecHelper.sleepBrowser(3000);
        });
    });
};

exports.ChargeTestSuiteForEditFlow = function () {
    describe('Charge_Details_Page for Edit Flow', function () {

        it('should have the title of tab as Charge', function () {
            e2eSpecHelper.sleepBrowser(3000);
            charge.chargeIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#charge_tab', 'Charge');
        });

        it('should display validation errors in charge dialog box when entering invalid value for Nature of Charge Data', function () {
            e2eSpecHelper.buttonClick('.clsBtnSecondary');
            e2eSpecHelper.sleepBrowser(1000);
            charge.natureOfChargesDropDown.click();
            charge.natureOfChargesDropDownValue('invalid');
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('.k-dialog-close');
            charge.closeDialogIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should display validation errors in charge dialog box when user clicks on save button without entering any details', function () {
            e2eSpecHelper.buttonClick('.clsBtnSecondary');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.buttonClick('#save_charge_details_btn');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should add charge data with valid values and show it on charge grid', function () {
            charge.natureOfChargesDropDown.click();
            charge.natureOfChargesDropDownValue('s');
            e2eSpecHelper.sleepBrowser(1000);
            charge.chargeRankDropDown.click();
            charge.chargeRankDropDownValue('1');
            e2eSpecHelper.sleepBrowser(1000);
            charge.chargeAmountInput.click();
            charge.chargeAmountInputValue('123k');
            e2eSpecHelper.sleepBrowser(1000);
            charge.filingDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            charge.filingDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            charge.receiptDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            charge.receiptDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.buttonClick('#save_charge_details_btn');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of charge details has been successfully added.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should click on edit icon from charge grid, update registration authority data and reflect updated data into charge grid', function () {
            charge.editIcon.click();
            e2eSpecHelper.verifyPresence('#chargeEditIcon-0');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#update_charge_details_btn', 'Update');
            e2eSpecHelper.sleepBrowser(3000);
            charge.registrationAuthorityInfo.clear();
            charge.registrationAuthorityInfoValue('edit flow reg auth');
            charge.updateBtn.click();
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of charge details has been successfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should click on delete icon and remove data from charge grid', function () {
            e2eSpecHelper.verifyPresence('#chargeDeleteIcon-0');
            charge.deleteIcon.click();
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of charge details has been successfully deleted.');
            e2eSpecHelper.sleepBrowser(3000);
        });
    });
};
