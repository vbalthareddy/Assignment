export const DocRefValues = [{
    'documentCode': 'Milestone - Launch Of Sale Date Of Property',
    'documentStatus': 'Doc Release (Pend Redemption)',
    'documentDate': '18 Apr 2017',
    'dueDate': '30 Apr 2017',
    'documentReceivedDate': '21 Apr 2017',
    'documentExpirationDate': '27 Apr 2017',
    'comments': '--'
},
    {
        'documentCode': 'Power of Attorney',
        'documentStatus': 'Document Not In',
        'documentDate': '18 Apr 2017',
        'dueDate': '30 Apr 2017',
        'documentReceivedDate': '21 Apr 2017',
        'documentExpirationDate': '27 Apr 2017',
        'comments': '--'
    }
];
export const documentCodes = [
    {code: '37', description: 'Milestone - Launch Of Sale Date Of Property'},
    {code: '050', description: 'Power of Attorney'}
];
export const documentStatus = [
    {code: '07', description: 'Doc Release (Pend Redemption)'},
    {code: '05', description: 'Document Not In'}
];
