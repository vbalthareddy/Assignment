describe('should complete add,edit,delete journey for collateral of vessel Type', () => {

    const createCollateralVesselTestSuite = require('./utils/CollateralsCreateVesselHelper');
    const editCollateralVesselTestSuite = require('./utils/CollateralsEditVesselHelper');
    const withdrawCollateralVesselTestSuite = require('./utils/CollateralsWithdrawVesselHelper');

    const processCreateCollateralVessel = () => {
        createCollateralVesselTestSuite.CreateCollateralVesselTestSuite();
    };

    const processEditCollateralVessel = () => {
        editCollateralVesselTestSuite.EditCollateralVesselTestSuite();
    };

    const processWithdrawCollateralVessel = () => {
        withdrawCollateralVesselTestSuite.WithdrawCollateralVesselTestSuite();
    };

    describe('should create a collateral of Vessel type', () => {
        processCreateCollateralVessel();
    });

    describe('should edit already created collateral of Vessel type', () => {
        processEditCollateralVessel();
    });

    describe('should withdraw existing collateral of Vessel type ', () => {
        processWithdrawCollateralVessel();
    });

});
