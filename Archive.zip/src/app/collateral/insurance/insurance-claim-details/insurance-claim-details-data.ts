export const insuranceClaimStatus = [
    {code: '1', description: 'Accepted'},
    {code: '2', description: 'Rejected'},
    {code: '3', description: 'Pending'}
]

export const collateralResData = {
    'collateralCode': 'code03',
    'collateralType': 'GUARN',
    'collateralId': 'COLL12500',
    'details': {
        'formNo': 'asd',
        'recievedDate': 'asd',
        'reviewDate': '',
        'signingDate': '',
        'executionDate': '',
        'applicationDetailsRemarks': '',
        'loanValuePcnt': '',
        'nextReviewDate': '',
        'expiryDate': '',
        'generalDetailsRemarks': '',

    },
    'generalDetail': {
        'currencyCode': 'SGD',
        'businessLocation': 'USA',
        'collateralCreationDate': '2017-07-04T10:02:15.068Z',
        'collateralExpiryDate': '2018-06-08T12:33:43.707Z'
    },
    'LodgeBeneficiaryDetail': {
        'beneficiaryList': [
            {
                'beneficiaryName': 'Personal Leadership Centre Pte.Ltd',
                'cifId': '',
                'beneficiaryIdType': '',
                'beneficiaryId': 'GCIN0000000',
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': '',
                'delete': false,
                'rank': '',
                'capAmount': 0,
                'capAmountType': ''
            }
        ]
    },
    'CollateralValuationDetail': {
        'externalChargeAmt': {
            'value': 0,
            'ccy': 'SGD'
        },
        'collateralValue': {
            'value': 0,
            'ccy': 'SGD'
        },
        'finalCollateralValue': {
            'value': 0,
            'ccy': 'SGD'
        },
        'totalApportionedValue': {
            'value': 0,
            'ccy': 'SGD'
        },
        'balanceApportionableAmt': {
            'value': 0,
            'ccy': 'SGD'
        },
        'apportioningMethod': 'P'
    },
    'document': {
        'documentidList': []
    },
    'beneficiary': {
        'beneficiaryList': []
    },
    'ownership': {
        'ownershipid': []
    },
    'LodgeOwnerShipDetail': {
        'ownerShipList': []
    },
    'LodgeCollateralTypeSpecificDetail': {
        'guaranteeAmt': {}
    },

    'insuranceDetails': [{
        'insuranceType': 'INSURANCE12',
        'insurancePurchaser': '',
        'policyDetails': {
            'policyHolderName': '',
            'policyNo': '1213',
            'policyAmt': {
                'value': 100,
                'ccy': 'SGD'
            },
            'riskCoverStartDate': '2017-06-02T12:33:43.722Z',
            'riskCoverEndDate': '2017-06-02T12:33:43.722Z',
            'itemsInsured': '',
            'bankId': '',
            'branchId': '',
            'accountId': '',
            'bankIdentifierCode': '',
            'premiumAmt': {
                'value': 0,
                'ccy': 'SGD'
            },
            'premiumStatus': '',
            'frequency': '',
            'paymentMethod': '',
            'lastPremiumPaidDate': '2017-06-02T12:33:43.722Z',
            'lastPremiumCollectionDate': '2017-06-02T12:33:43.722Z',
            'cancellationDate': '2017-06-02T12:33:43.722Z',
            'insuranceAction': ''
        },
        'claimDetails': {
            'claimFilingDate': '2017-06-02T12:33:43.722Z',
            'claimStatus': '',
            'claimedAmt': {
                'value': 0,
                'ccy': 'SGD'
            },
            'settledAmt': {
                'value': 0,
                'ccy': 'SGD'
            },
            'claimAckDate': '2017-06-02T12:33:43.722Z',
            'comments': 'Hello Incurance claims'
        },
        'insuranceCompanyDetails': {
            'agentName': '',
            'insuranceAgencyPhNo': '',
            'insuranceCompany': '',
            'addressLine1': '',
            'addressLine2': '',
            'addressLine3': '',
            'city': '',
            'state': '',
            'country': '',
            'postalCode': '',
            'phoneNo': '',
            'emailAddress': '',
            'telexNo': '',
            'faxNo': ''
        },
        'delete': false
    }]
    ,
};