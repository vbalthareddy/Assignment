import {GuarantorGridValidator, TotalPercentageValidator} from './total-percentage-validator';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {Observable} from 'rxjs/Rx';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {GridModule} from '@progress/kendo-angular-grid';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {IntlModule} from '@progress/kendo-angular-intl';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';
import {CommonUIModule} from '../../common/commonUI.module';
import {AutoCompleteModule, ComboBoxModule} from '@progress/kendo-angular-dropdowns';
import {CollateralGuarantorComponent} from './collateral-guarantor.component';
import {GcinData, GuarantorData} from './gcin-mock-data';
import {CollateralGuarantorService} from './collateral-guarantor.service';
import {Collateral} from '../model/collateral';
import {CollateralService} from '../collateral.service';
import {GuarantorGridValidatorForJOINT} from 'app/collateral/collateral-guarantor/total-percentage-validator';
import {AbstractControl} from '@angular/forms/src/model';
class MockGuaratorService {
    getGuarantorIdDataService(data) {
        if (data.searchKeyword.length > 3) {
            return Observable.of(GcinData);
        } else {
            return Observable.throw({status: 404});
        }
    }

    getGuarantorData(data: any) {
        return data;
    }

    addGuarantor(data: any) {
        const sampleObj = {};
        return Observable.of(sampleObj);
    }

    getGuaranteeType() {
        let listItems: any = ['SEVERAL', 'JOINT', 'JOINT&SEVERAL', 'SINGLE'];
        return Observable.of(listItems);
    }
}
class MockCollateralService {
    collateral: Collateral;

    getCollateral() {
        const Obj = new Collateral();
        return Obj;
    }
}
class MockFormBuilder extends FormBuilder {
    getBlankForm() {
        const formBuilder = new FormBuilder;
        const formGroup = formBuilder.group({
            guarantorId: [''],
            guarantorDescription: [''],
            guarantorType: [''],
            gurantorName: [''],
            guaranteePercentage: ['']
        });
        return formGroup;
    }

    getAddForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            guarantorId: ['GC0001045992'],
            guarantorDescription: ['16R2A GCIN4NF CN006 (GC0001045992)'],
            guarantorType: ['COUNTERPARTY'],
            gurantorName: ['Name'],
            guaranteePercentage: ['100']
        });
        return formGroup;
    }

    getMainForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            ownershipid: [''],
            minGridLengthCheck: [''],
            minGridLengthCheckForJOINT: ['']
        });
        return formGroup;
    }

    setMainForm(data: any) {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            ownershipid: [data]
        });
        return formGroup;
    }
}
describe('CollateralGuarantorComponent', () => {
    let component: CollateralGuarantorComponent;
    let fixture: ComponentFixture<CollateralGuarantorComponent>;
    const guarantorData = {
        'guarantorId': 'GC0001045992',
        'guarantorDescription': '16R2A GCIN4NF CN006 (GC0001045992)',
        'guarantorType': 'COUNTERPARTY',
        'gurantorName': '',
        'guaranteePercentage': '100'
    };
    const mockGuarantorData = GuarantorData;
    let mockCollateralService: MockCollateralService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                CommonModule,
                BrowserModule, FormsModule, ReactiveFormsModule,
                ButtonsModule, BrowserAnimationsModule,
                LoaderModule, GridModule, ClsSharedCommonModule, IntlModule, AutoCompleteModule
                , PopupDialogModule, CommonUIModule, ComboBoxModule
            ],
            declarations: [CollateralGuarantorComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [
                {provide: CollateralService, useClass: MockCollateralService},
                {provide: CollateralGuarantorService, useClass: MockGuaratorService},
                {provide: FormBuilder, useClass: MockFormBuilder}
            ]
        })
            .compileComponents().then(() => {
            fixture = TestBed.createComponent(CollateralGuarantorComponent);
            component = fixture.componentInstance;
            component.collateralGuarantorForm = new FormGroup({});
            component.collateralGuarantorForm.addControl('totalPercentageSum', new FormControl('', []));
            component.collateralGuarantorForm.addControl('minGridLengthCheck', new FormControl('', []));
            component.collateralGuarantorForm.addControl('minGridLengthCheckForJOINT', new FormControl('', []));
            mockCollateralService = TestBed.get(CollateralService);
        });
    }));

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('should show normalgrid on init', (async () => {
        component.divForNormalGrid = true;
        component.showSummaryGrid = false;
        expect(component.divForNormalGrid).toBe(true);
        component.customizeGuarantorGridForSummaryComp();
        if (component.showSummaryGrid) {
            expect(component.divForNormalGrid).toBe(false);
        } else {
            expect(component.divForNormalGrid).toBe(true);
        }
    }));
    it('PopDialog box should be close  onclick of Close button',
        async(() => {
            fixture.detectChanges();
            component.closeEventFromPopupDialog(true);
            expect(component.showPopupDialog).toBe(true);
        }));
    it('PopDialog box should be open  onclick of Add Guarantor button',
        async(() => {
            fixture.detectChanges();
            component.addGuarantor();
            expect(component.showPopupDialog).toBe(true);
            expect(component.saveData).toBe(true);
            expect(component.disableGCINCIF).toBe(false);
        }));
    it('should disable Add Guarantor button on init component',
        async(() => {
            fixture.detectChanges();
            expect(component.addGuarantorDisable).toBe(true);
        }));

    it('should Enable Add Guarantor button once select guarantor from dropdown ',
        async(() => {
            fixture.detectChanges();
            component.guarantorSelectedValueOld = '';
            component.guarantorSelectedValueNew = '';
            component.guarantorGridData = [];
            component.guarantorSelect('SEVERAL');
            fixture.detectChanges();
            expect(component.addGuarantorDisable).toBe(false);
            expect(component.configureChangeAlertToastEnable).toBe(false);
            expect(component.gridDisable).toBe(false);
            fixture.detectChanges();
            component.guarantorSelectedValueOld = '';
            component.guarantorSelectedValueNew = 'SINGLE';
            component.guarantorGridDataForHtml.length = 2;
            component.guarantorSelect('SEVERAL');
            expect(component.addGuarantorDisable).toBe(true);
            expect(component.configureChangeAlertToastEnable).toBe(true);
        }));
    it('should Disable Add Guarantor button if value undefined or empty from guarantor dropdown list ',
        async(() => {
            fixture.detectChanges();
            component.guarantorSelectedValueOld = '';
            component.guarantorSelectedValueNew = '';
            component.guarantorGridData = [guarantorData];
            component.addGuarantorDisable = false;
            component.guarantorSelect('');
            fixture.detectChanges();
            expect(component.addGuarantorDisable).toBe(true);
        }));
    it('should update selected values on selected guarantor values from dropdown ',
        async(() => {
            fixture.detectChanges();
            component.guarantorSelectedValueOld = '';
            component.guarantorSelectedValueNew = '';
            component.guarantorGridData = [];
            component.addGuarantorDisable = false;
            component.guarantorSelect('SEVERAL');
            fixture.detectChanges();
            expect(component.guarantorSelectedValueOld).toEqual('SEVERAL');
            expect(component.guarantorSelectedValueNew).toEqual('SEVERAL');
        }));
    it('should confirmation popdialog open on click of Guarantor Configuration Button if conditions true  ',
        async(() => {
            fixture.detectChanges();
            component.guarantorGridData = [guarantorData];
            component.validateSelectedChangeValue = true;
            component.configureChangeAlertToastEnable = true;
            component.guarantorConfigure();
            expect(component.showPopupDialogForConfirmation).toBe(true);
        }));
    it('should revert back selected value on click of revert back option  ',
        async(() => {
            fixture.detectChanges();
            component.guarantorSelectedValueOld = 'SEVERAL';
            component.revertBackChangesForSelected();
            expect(component.selectedGuarantorValue).toBe('SEVERAL');
        }));
    it('should alert toast message hide  on click of revert back option  ',
        async(() => {
            fixture.detectChanges();
            component.guarantorSelectedValueOld = 'SEVERAL';
            component.revertBackChangesForSelected();
            expect(component.configureChangeAlertToastEnable).toBe(false);
        }));
    it('Guarantor form should be defined onclick of ADD Guarantor button',
        async(() => {
            fixture.detectChanges();
            const mockForm = new MockFormBuilder();
            component.guarantorForm = mockForm.getBlankForm();
            component.showPopupDialog = false;
            component.addGuarantor();
            expect(component.guarantorForm).toBeDefined();
            component.selectedGuarantorValue = 'JOINT';
            component.addGuarantor();
            spyOn(component, 'percentageChange');
            expect(component.disablePercentageValue).toBe(true);
        }));
    it('Data should add to grid on click of save button from guarantor dialog box',
        async(() => {
            fixture.detectChanges();
            expect(component.guarantorGridData.length).toBe(0);
            component.showPopupDialog = false;
            component.guarantorForm = null;
            component.percentageValidationCheck = false;
            const mockForm = new MockFormBuilder();
            component.guarantorGridDataForHtml = [];
            component.idList =
                [{
                    'gcin': 'GC0001045992',
                    'description': '16R2A GCIN4NF CN006 (GC0001045992)',
                    'type': 'COUNTERPARTY',
                    'name': '16R2A GCIN4NF CN002 '
                }];
            component.guarantorForm = mockForm.getBlankForm();
            component.addGuarantor();
            expect(component.showPopupDialog).toBe(true);
            component.collateralGuarantorForm = mockForm.getMainForm();
            component.guarantorForm = mockForm.getAddForm();
            const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
            component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
            component.submitGuarantorForm(mockGuarantorData[0]);
            expect(component.guarantorGridData.length).toBeGreaterThan(0);
            expect(component.saveData).toBe(true);
            expect(component.showPopupDialog).toBe(false);
            expect(component.noDataFound).toBe(true);
        }));
    it('should Dalete guarantor data from Grid onClick of delete icon',
        async(() => {
            fixture.detectChanges();
            component.guarantorGridData = [];
            expect(component.guarantorGridData.length).toBe(0);
            component.showPopupDialog = false;
            component.guarantorForm = null;
            component.percentageValidationCheck = false;
            const mockForm = new MockFormBuilder();
            component.guarantorForm = mockForm.getBlankForm();
            component.addGuarantor();
            expect(component.showPopupDialog).toBe(true);
            component.collateralGuarantorForm = mockForm.getMainForm();
            component.guarantorForm = mockForm.getAddForm();
            const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
            component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
            component.submitGuarantorForm(mockGuarantorData[0]);
            expect(component.guarantorGridData.length).toBeGreaterThan(0);
            component.collateralGuarantorForm.addControl('totalPercentageSum', new FormControl('', []));
            expect(component.guarantorGridData.length).toBeGreaterThan(0);
        }));
    it('should Data Populate on Dialog box on click of Edit icon',
        () => {
            fixture.detectChanges();
            component.guarantorGridData = [];
            expect(component.guarantorGridData.length).toBe(0);
            component.showPopupDialog = false;
            component.guarantorForm = null;
            component.percentageValidationCheck = false;
            const mockForm = new MockFormBuilder();
            component.guarantorForm = mockForm.getBlankForm();
            component.addGuarantor();
            expect(component.showPopupDialog).toBe(true);
            component.collateralGuarantorForm = mockForm.getMainForm();
            component.guarantorForm = mockForm.getAddForm();
            const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
            component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
            component.submitGuarantorForm(mockGuarantorData[0]);
            expect(component.guarantorGridData.length).toBeGreaterThan(0);
            component.guarantorEditFunc(GcinData[0], 0);
            expect(component.saveData).toBe(false);
            expect(component.showPopupDialog).toBe(true);
            expect(component.disableGCINCIF).toBe(true);
            expect(component.dialogTitleName).toEqual('Update Guarantor');
            component.dataForEdit(GcinData[0]);
            fixture.detectChanges();
            expect(component.saveData).toBe(false);
        });
    it('should update data into grid  onclick of update button ',
        () => {
            fixture.detectChanges();
            const mockForm = new MockFormBuilder();
            component.collateralGuarantorForm = mockForm.getMainForm();
            component.guarantorForm = mockForm.getBlankForm();
            component.collateralGuarantorForm.addControl('totalPercentageSum', new FormControl('', []));
            component.collateralGuarantorForm.addControl('minGridLengthCheck', new FormControl('', []));
            component.collateralGuarantorForm.addControl('minGridLengthCheckForJOINT', new FormControl('', []));
            component.idList =
                [{
                    'gcin': 'GC0001045991',
                    'description': '16R2A GCIN4NF CN004 (GC0001045991)',
                    'type': 'COUNTERPARTY',
                    'name': '116R2A GCIN4NF CN004 '
                }];
            component.rowIndex = 0;
            component.dataForEdit(GcinData[0]);
            const updatedData = {
                'guarantorId': 'GC0001045991',
                'guarantorDescription': '16R2A GCIN4NF CN004 (GC0001045991)',
                'guarantorType': 'COUNTERPARTY',
                'gurantorName': 'myname',
                'guaranteePercentage': '25'
            };
            component.percentageValidationCheck = false;
            component.updateGuarantorValue(updatedData);
            expect(component.sumOfPercentage).toEqual(25);
        });
    it('should check validation on click of save button for invalid data ', async(() => {
        fixture.detectChanges();
        const mockForm = new MockFormBuilder();
        component.collateralGuarantorForm = mockForm.getMainForm();
        component.guarantorForm = mockForm.getAddForm();
        const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
        component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
        const invalidData = {
            'guarantorId': 'GC0001045991',
            'guarantorDescription': '',
            'guarantorType': 'COUNTERPARTY',
            'gurantorName': null,
            'guaranteePercentage': '1'
        };
        expect(component.validationCheck(invalidData)).toBe(false);
    }));
    it('should check validation for percentage if invalid entry ', async(() => {
        fixture.detectChanges();
        const mockForm = new MockFormBuilder();
        component.collateralGuarantorForm = mockForm.getMainForm();
        component.guarantorForm = mockForm.getAddForm();
        const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
        component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
        const invalidData = {
            'guarantorId': 'GC0001045991',
            'guarantorDescription': '',
            'guarantorType': 'COUNTERPARTY',
            'gurantorName': null,
            'guaranteePercentage': ''
        };
        expect(component.validationCheck(invalidData)).toBe(false);
    }));
    it('should validations reset on call of validation reset function ', async(() => {
        fixture.detectChanges();
        component.guarantorIdInvalid = true;
        component.validationReset();
        expect(component.guarantorIdInvalid).toBe(false);
    }));
    it('should not allowed to add sum of percentage greater than 100 if selected value severals ', async(() => {
        fixture.detectChanges();
        component.guarantorGridDataForHtml = GcinData;
        component.sumOfPercentage = 48;
        component.selectedGuarantorValue = 'SEVERAL';
        component.percentageChange('89');
        expect(component.guarantorPercentageValid).toBe(true);
        expect(component.errorValidatorMessageForPercentage).toEqual('Total Percentage should not be exceed 100');
    }));
    it('should not allowed to add /update data without entering percentage in dialogBox', async(() => {
        fixture.detectChanges();
        component.guarantorGridData = GcinData;
        component.sumOfPercentage = 48;
        component.selectedGuarantorValue = 'SEVERAL';
        component.percentageChange('');
        expect(component.guarantorPercentageValid).toBe(false);
        expect(component.percentageValidationCheck).toBe(false);
        fixture.detectChanges();
        component.guarantorGridData = [];
        component.sumOfPercentage = 48;
        component.selectedGuarantorValue = 'SEVERAL';
        component.percentageChange('34');
        expect(component.guarantorPercentageValid).toBe(false);
    }));
    it('should get sum of percentage of gridData', async(() => {
        fixture.detectChanges();
        component.guarantorGridDataForHtml = GcinData;
        expect(component.getGridPercentageSum()).toEqual(48);
    }));
    it('Error should get from backend when something wrong is entered in beneficiary id field',
        async(() => {
            fixture.detectChanges();
            component.idList = [];
            expect(component.idList.length).toBe(0);
            component.searchByGCINCIF('gfx');
            expect(component.errorMessage).toBe(true);
        }));
    it('should check percentage valid if selected guarantee is single', async(() => {
        fixture.detectChanges();
        component.guarantorGridDataForHtml = GcinData;
        component.selectedGuarantorValue = 'SINGLE';
        component.percentageChange('12');
        expect(component.guarantorPercentageValid).toBe(true);
        expect(component.percentageValidationCheck).toBe(true);
    }));
    it('should close confirmation dialog box onclick of cancel / close icon', async(() => {
        fixture.detectChanges();
        component.gaurantorRemoveItem('{}', 1);
        expect(component.rowIndex).toBe(1);
        expect(component.showYesNoPrompt).toBe(true);
        const dlgPayload = ['yes'];
        const mockForm = new MockFormBuilder();
        component.collateralGuarantorForm = mockForm.getMainForm();
        component.collateralGuarantorForm.addControl('totalPercentageSum', new FormControl('', []));
        component.collateralGuarantorForm.addControl('minGridLengthCheck', new FormControl('', []));
        component.collateralGuarantorForm.addControl('minGridLengthCheckForJOINT', new FormControl('', []));
        component.guarantorDataToDelete = {
            'cifId': 'GC0001045991',
            'idType': 'COUNTERPARTY',
            'idNo': '',
            'name': '   16R2A GCIN4NF CN004 ',
            'addressLine1': '',
            'addressLine2': '',
            'addressLine3': '',
            'city': '',
            'state': '',
            'country': '',
            'postalCode': '',
            'phoneNo': '',
            'emailAddress': '',
            'telexNo': '',
            'faxNo': '',
            'delete': false,
            'id': 'gurantor1ct2jqw104',
            '_version': '',
            '__row_status': 'added',
            'collateralOwnerShipPcnt': 100
        };
        component.guarantorGridData.push({
            'cifId': 'GC0001045991',
            'idType': 'COUNTERPARTY',
            'idNo': '',
            'name': '   16R2A GCIN4NF CN004 ',
            'addressLine1': '',
            'addressLine2': '',
            'addressLine3': '',
            'city': '',
            'state': '',
            'country': '',
            'postalCode': '',
            'phoneNo': '',
            'emailAddress': '',
            'telexNo': '',
            'faxNo': '',
            'delete': false,
            'id': 'gurantor1ct2jqw104',
            '_version': '',
            '__row_status': 'added',
            'collateralOwnerShipPcnt': 100
        });
        component.rowIndex = 0;
        component.confirmationFromYesNo(dlgPayload);
        expect(component.showYesNoPrompt).toBe(false);
    }));
    it('should return values after filter items on list', async(() => {
        fixture.detectChanges();
        component.listItems = ['Severel', 'Joint'];
        component.filterChangeGuaranteeType('s');
        expect(component.guaranteeList).toEqual(['Severel']);
        expect(component.getStringInSmall('SEVEREL')).toBe('Severel');
    }));
    it('should delete grid data on confirmation through dialog box', async(() => {
        fixture.detectChanges();
        const mockForm = new MockFormBuilder();
        component.collateralGuarantorForm = mockForm.getMainForm();
        component.collateralGuarantorForm.addControl('totalPercentageSum', new FormControl('', []));
        component.collateralGuarantorForm.addControl('minGridLengthCheck', new FormControl('', []));
        component.collateralGuarantorForm.addControl('minGridLengthCheckForJOINT', new FormControl('', []));
        component.guarantorDataToDelete = {
            'cifId': 'GC0001045991',
            'idType': 'COUNTERPARTY',
            'idNo': '',
            'name': '   16R2A GCIN4NF CN004 ',
            'addressLine1': '',
            'addressLine2': '',
            'addressLine3': '',
            'city': '',
            'state': '',
            'country': '',
            'postalCode': '',
            'phoneNo': '',
            'emailAddress': '',
            'telexNo': '',
            'faxNo': '',
            'delete': false,
            'id': 'gurantor1ct2jqw104',
            '_version': '',
            '__row_status': 'added',
            'collateralOwnerShipPcnt': 100
        };
        component.guarantorGridData.push({
            'cifId': 'GC0001045991',
            'idType': 'COUNTERPARTY',
            'idNo': '',
            'name': '   16R2A GCIN4NF CN004 ',
            'addressLine1': '',
            'addressLine2': '',
            'addressLine3': '',
            'city': '',
            'state': '',
            'country': '',
            'postalCode': '',
            'phoneNo': '',
            'emailAddress': '',
            'telexNo': '',
            'faxNo': '',
            'delete': false,
            'id': 'gurantor1ct2jqw104',
            '_version': '',
            '__row_status': 'added',
            'collateralOwnerShipPcnt': 100
        });
        component.confirmConfigureChanges();
        expect(component.showPopupDialogForConfirmation).toBe(false);
        expect(component.configureChangeAlertToastEnable).toBe(false);

    }));
    it('should revertBackChangesFromPopDialog', async(() => {
        fixture.detectChanges();
        component.guarantorSelectedValueOld = 'SINGLE';
        component.guarantorGridDataForHtml.length = 1;
        component.revertBackChangesFromPopDialog();
        expect(component.showPopupDialogForConfirmation).toBe(false);
        expect(component.addGuarantorDisable).toBe(true);
    }));
    it('should revertBackChangesFromPopDialog', async(() => {
        fixture.detectChanges();
        component.guarantorSelectedValueOld = 'SINGLE';
        component.guarantorGridDataForHtml.length = 1;
        component.revertBackChangesFromPopDialog();
        expect(component.showPopupDialogForConfirmation).toBe(false);
        expect(component.addGuarantorDisable).toBe(true);
    }));
    it('should closeEventFromPopupDialogForConfirmation', async(() => {
        fixture.detectChanges();
        component.closeEventFromPopupDialogForConfirmation();
        expect(component.showPopupDialogForConfirmation).toBe(false);
    }));
    it('should check error on search GCIN if its duplicate', async(() => {
        fixture.detectChanges();
        component.idList =
            [{
                'gcin': 'GC0001045990',
                'description': 'GC0001045990   16R2A GCIN4NF CN002',
                'type': 'COUNTERPARTY',
                'name': '16R2A GCIN4NF CN002 '
            }];
        component.onSearchGCIDCIFSelect('GC0001045990   16R2A GCIN4NF CN002');
        expect(component.showPopupDialogForConfirmation).toBe(false);
        component.onSearchGCIDCIFSelect(' ');
        expect(component.guarantorIdInvalid).toBe(true);
    }));
    it('should setdata to Grid on call of setData function', async(() => {
        fixture.detectChanges();
        const mockForm = new MockFormBuilder();
        component.collateralGuarantorForm = mockForm.getMainForm();
        component.collateralGuarantorForm.addControl('totalPercentageSum', new FormControl('', []));
        component.collateralGuarantorForm.addControl('minGridLengthCheck', new FormControl('', []));
        component.collateralGuarantorForm.addControl('minGridLengthCheckForJOINT', new FormControl('', []));
        component.guarantorGridDataForHtml.push({
            'cifId': 'GC0001045991',
            'idType': 'COUNTERPARTY',
            'idNo': '',
            'name': '   16R2A GCIN4NF CN004 ',
            'addressLine1': '',
            'addressLine2': '',
            'addressLine3': '',
            'city': '',
            'state': '',
            'country': '',
            'postalCode': '',
            'phoneNo': '',
            'emailAddress': '',
            'telexNo': '',
            'faxNo': '',
            'delete': false,
            'id': 'gurantor1ct2jqw104',
            '_version': '',
            '__row_status': 'added',
            'collateralOwnerShipPcnt': 100
        });
        const Obj = new Collateral();
        Obj.ownershipDetails = [{
            'cifId': 'GC0001045991',
            'idType': 'COUNTERPARTY',
            'idNo': '',
            'name': '   16R2A GCIN4NF CN004 ',
            'addressLine1': '',
            'addressLine2': '',
            'addressLine3': '',
            'city': '',
            'state': '',
            'country': '',
            'postalCode': '',
            'phoneNo': '',
            'emailAddress': '',
            'telexNo': '',
            'faxNo': '',
            'delete': false,
            'id': 'gurantor1ct2jqw104',
            '_version': '',
            '__row_status': 'added',
            'collateralOwnerShipPcnt': 100
        }];
        mockCollateralService.collateral = Obj;
        component.setGridData();
    }));
    it('Validators check', () => {
        const c: AbstractControl = new FormControl;
        expect(GuarantorGridValidatorForJOINT.getMessage(c)).toBe('Please add more than one  Guarantee record for JOINT & (JOINT&SEVERAL) types');
        expect(GuarantorGridValidatorForJOINT.checkValidation(false)).toBe(false);
        expect(GuarantorGridValidatorForJOINT.required(new FormControl('123456'), '')).toBe(null);
        expect(GuarantorGridValidator.getMessage(c)).toBe('Please add at least one Guarantee record');
        expect(GuarantorGridValidator.checkValidation(false)).toBe(false);
        expect(GuarantorGridValidator.required(new FormControl('123456'), '')).toBe(null);
        expect(TotalPercentageValidator.getMessage(c)).toBe('Make sure that total sum of guarantee percentage should be 100');
        expect(TotalPercentageValidator.checkTotal(100)).toBe(true);
        expect(TotalPercentageValidator.checkTotal(null)).toBe(true);
        expect(TotalPercentageValidator.checkTotal(1)).toBe(false);
        const expectResult = {
            required: 'Make sure that total sum of guarantee percentage should be 100'
        };
        expect(TotalPercentageValidator.required(new FormControl('123456'), '')).toEqual(expectResult);
    });
});
