import {$, by, element, protractor} from 'protractor';
import {E2eSpecHelper} from './E2eSpecHelper';

exports.ValuationAircradfTestSuite = function () {
    describe('Valuation_Page', function () {
        const sh = new E2eSpecHelper();
        const collateralSpecSuite = require('./CollateralSpecHelper');

        const valuation: any = {
            valuationIdOnTab: $('#valuation_tab'),
            // V5 changes
            valuationCard: $('#valuationCard'),
            valuationCardLabel: element(by.css('#valuationCard')).element(by.cssContainingText('span .panel-label', 'Valuation')),
            finalSubmitBtn: $('#final_submit_btn'),
            justificationRemarkError: $('.error-message-valuation-justification-remark'),
            justificationTextArea: $('.commentTextArea div textArea'),
            valRepRequiredError: $('.error-message-valRepRequired'),
            waivedButton: $('button[name="valRepReq.waived"]'),
            addValuationDetailsBtn: $('#addValuationDetailsBtn'),
            valuationPopUpDialog: $('#valuationPopUpDialog'),
            valuationType: $('#valuationType'),
            valitionTypeInputValue: (valuationTypeVal: string): any => $('#valuationType .k-searchbar > .k-input').sendKeys(valuationTypeVal, protractor.Key.ENTER),
            valitionTypeInputResult: $('#valuationType .k-animation-container .k-list .k-item:first-child'),
            employeeId: $('#employeeId'),
            employeeIdInputValue: (employeeIdVal: string): any => $('#employeeId').sendKeys(employeeIdVal, protractor.Key.ENTER),
            first_val_date: $('#first_val_date .k-select'),
            latest_val_date: $('#latest_val_date .k-select'),
            next_val_date: $('#next_val_date .k-select'),
            dateToday: $('.k-today '),
            dateWeekend: $('.k-weekend'),
            frequencyDropdown: $('.frequency-auto-complete'),
            frequencyDropdownResult: $('.k-list-container .k-list .k-item:nth-child(1)'),
            frequencyDropdownValue: (searchTerm: string): any => $('.frequency-auto-complete .k-searchbar > .k-input').sendKeys(searchTerm),
            addValuationSaveBtn: $('#save-form-btn'),
            valuationUpdateBtn: $('#update-form-btn'),
            valuationEditIcon_0: $('.k-grid table tr:nth-child(1) #valuationEditIcon-0'),
            valuationDeleteIcon_0: $('.k-grid table tr:nth-child(1) #valuationDeleteIcon-0')
        };

        const goToValuationTab = () => {
            const valuationTab = valuation.valuationIdOnTab;
            expect(valuationTab).toBeTruthy();
            valuationTab.click();
            expect(valuationTab.getText()).toEqual('Valuation');
            expect(valuation.valuationHeader).toBeTruthy();
        };

        // V5 changes Collateral Type AIRCF
        it('should contain the valuation Card for Add Valuation', () => {
            goToValuationTab();
            expect(valuation.valuationCard.isPresent()).toBeTruthy();
            expect(valuation.valuationCardLabel.isPresent()).toBeTruthy();
        });

        it('should show error justification Remarks Error messages on Submit', () => {
            valuation.finalSubmitBtn.click();
            expect(valuation.justificationRemarkError.isPresent()).toBeTruthy();
            expect(valuation.justificationRemarkError.getText()).toBe('Please enter a Value');
        });

        it('should remove error message on enter of a Valid justification value', () => {
            valuation.finalSubmitBtn.click();
            expect(valuation.justificationRemarkError.isPresent()).toBeTruthy();
            valuation.justificationTextArea.sendKeys('abcdef');
            expect(valuation.justificationRemarkError.isPresent()).toBeFalsy();
        });

        it('should show error ValuationReport required Error messages on Submit', () => {
            valuation.finalSubmitBtn.click();
            expect(valuation.valRepRequiredError.isPresent()).toBeTruthy();
            expect(valuation.valRepRequiredError.getText()).toBe('Please Select a Value');
        });

        it('should remove error message on click of Valid ValuationReport required value', () => {
            valuation.finalSubmitBtn.click();
            expect(valuation.valRepRequiredError.isPresent()).toBeTruthy();
            valuation.waivedButton.click();
            expect(valuation.valRepRequiredError.isPresent()).toBeFalsy();
        });

        it('should open pop up dialog for Add Valuation Details dialog', () => {
            valuation.addValuationDetailsBtn.click();
            expect(valuation.valuationPopUpDialog.isPresent()).toBeTruthy();
        });

        it('should enter values in valuationType', () => {
            valuation.valuationType.click();
            valuation.valitionTypeInputValue('a');
            valuation.valitionTypeInputResult.click();
            expect(element(valuation.valuationType).element('input').getText()).not.toBe('');
        });

        it('should enter values in employeeId', () => {
            valuation.employeeId.click();
            valuation.employeeIdInputValue('emp001');
            expect(element(valuation.employeeId).element('.k-input').getText()).not.toBe('');
        });

        it('should select the first valuation date', () => {
            valuation.first_val_date.click();
            sh.sleepBrowser(1000);
            valuation.dateWeekend.click();
        });

        it('should select the latest valuation date', () => {
            valuation.latest_val_date.click();
            sh.sleepBrowser(1000);
            valuation.dateToday.click();
        });

        it('should select frequency from Frew=quency dropndown', () => {
            valuation.frequencyDropdown.click();
            valuation.frequencyDropdownValue('CUS');
            sh.sleepBrowser(1000);
            valuation.frequencyDropdownResult.click();
            sh.sleepBrowser(1000);
        });

        it('should select the next valuation date', () => {
            valuation.next_val_date.click();
            sh.sleepBrowser(1000);
            valuation.dateToday.click();
        });

        it('should add valid Valuation data, display toast and reflect on grid on click of Add Valuation details button', () => {
            valuation.valuationType.click();
            valuation.valitionTypeInputValue('a');
            valuation.valitionTypeInputResult.click();
            valuation.employeeId.click();
            valuation.employeeIdInputValue('emp001');
            valuation.first_val_date.click();
            sh.sleepBrowser(1000);
            valuation.dateWeekend.click();
            valuation.latest_val_date.click();
            sh.sleepBrowser(1000);
            valuation.dateToday.click();
            valuation.frequencyDropdown.click();
            valuation.frequencyDropdownValue('CUS');
            sh.sleepBrowser(1000);
            valuation.frequencyDropdownResult.click();
            sh.sleepBrowser(1000);
            valuation.next_val_date.click();
            sh.sleepBrowser(1000);
            valuation.dateToday.click();
            valuation.addValuationSaveBtn.click();
            sh.sleepBrowser(1000);
            sh.verifyTextContains('.toast__msg', 'A record of Valuation details has been successfully Added.');
            sh.verifyPresence('.k-grid');
        });

        it('should update valid Valuation data, display toast and reflect on grid on click of Update Valuation Details button', function () {
            sh.verifyPresence('#valuationEditIcon-0');
            valuation.valuationEditIcon_0.click();
            sh.sleepBrowser(1000);
            valuation.next_val_date.click();
            sh.sleepBrowser(1000);
            valuation.dateToday.click();
            sh.sleepBrowser(1000);
            valuation.valuationUpdateBtn.click();
            sh.sleepBrowser(1000);
            sh.verifyTextContains('.toast__msg', 'A record of Valuation details has been successfully updated.');
            sh.verifyPresence('.k-grid');
        });

        it('should delete Valuation Details data from Grid, display toast and reflect on grid on click of delete icon', function () {
            sh.sleepBrowser(2000);
            sh.verifyPresence('#valuationDeleteIcon-0');
            sh.sleepBrowser(1000);
            valuation.valuationDeleteIcon_0.click();
            sh.sleepBrowser(2000);
            sh.verifyTextContains('.toast__msg', 'A record of Valuation details has been successfully deleted.');
        });

    });
};

exports.ValuationAircraftTestSuiteForEditFlow = function () {
    describe('Valuation_Page for Edit Flow', function () {
        /*TODO*/
    });
};

