import {inject, TestBed} from '@angular/core/testing';
import {MockBackend, MockConnection} from '@angular/http/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {InsuranceService} from './insurance.component.service';

describe('InsuranceService', () => {
    let insuranceService: InsuranceService;
    let mockBackend: MockBackend;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                }, InsuranceService
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([InsuranceService, MockBackend], (service: InsuranceService, backend: MockBackend) => {
            insuranceService = service;
            mockBackend = backend;
        })
    );
    it('Insurance service should be defined', () => {
        expect(insuranceService).toBeDefined();
    });
    it('getInsuranceTypes service should call endpoint and return it\'s result', (done) => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const options = new ResponseOptions({
                body: JSON.stringify({status: 'Ok'})
            });
            connection.mockRespond(new Response(options));
        });
        insuranceService.getInsuranceTypesfromService()
            .subscribe((response) => {
                expect(response).toEqual({status: 'Ok'});
                done();
            });
    });
    it('getInsuranceTypes service should call endpoint and return error', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        insuranceService.getInsuranceTypesfromService()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });
});
