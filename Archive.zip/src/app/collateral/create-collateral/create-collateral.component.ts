import {Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewEncapsulation} from '@angular/core';
import {CollateralService} from '../collateral.service';
import {CollateralCode, CollateralType} from '../model';
import * as _ from 'underscore';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {
    AircraftLodgeCollateralTypeSpecificDetail,
    BeneficiaryList,
    Collateral,
    DeposLodgeCollateralTypeSpecificDetail,
    VehicLodgeCollateralTypeSpecificDetail
} from '../model/collateral';

import {JsonConvert} from 'json2typescript';
import {CollateralSummaryService} from 'app/collateral/collateral-summary/collateral-summary.service';
import {ActivatedRoute, NavigationExtras, Params, Router} from '@angular/router';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';

@Component({
    selector: 'create-collateral',
    templateUrl: './create-collateral.html',
    encapsulation: ViewEncapsulation.Emulated,
    styleUrls: ['./create-collateral.scss']
})
export class CreateCollateralComponent implements OnInit, OnDestroy {

    @Input()
    showPopupDialog: boolean = true;

    @Output()
    cancelDailog: EventEmitter<boolean> = new EventEmitter<boolean>();

    currency: string = 'SGD';
    defaultValution = {value: 0, ccy: this.currency};

    selectedItem: CollateralType;
    selectedCode: CollateralCode;

    public counterPartyDetails: any;

    collateralTypes: Array<CollateralType> = [];
    collateralCodes: Array<CollateralCode> = [];
    tempCollateralTypes: Array<CollateralType> = [];
    tempCollateralCodes: Array<CollateralCode> = [];
    codeCollateralType: CollateralType;

    codePresent: boolean;
    typePresent: boolean;
    index: number;
    type: string;
    gcinCpValue: string;
    gcinDesc: string;
    createCollateralCustomForm: FormGroup;

    constructor(private collateralService: CollateralService, private router: Router, private route: ActivatedRoute,
                private counterPartyDetailsService: CounterPartyDetailsService, private collateralSummaryService: CollateralSummaryService, private _fb: FormBuilder) {
        this.route.queryParams.subscribe((params: Params) => {
            this.gcinCpValue = params['gcin'];
            this.gcinDesc = params['label'];
        });
    }

    ngOnInit() {
        this.codePresent = false;
        this.typePresent = false;
        this.initCustomForms();
        this.initTypes();
        this.initCodes();
        this.subscribeCounterPartyDetail();
    }

    subscribeCounterPartyDetail() {
        this.counterPartyDetailsService.subscribeToCPDetails({
            next: (value) => this.counterPartyDetails = value,
            error: (value) => console.log(value),
            complete: () => {
            }
        });

    }

    initCustomForms() {
        this.createCollateralCustomForm = this._fb.group({
            selectedItem: [<CollateralType>{}],
            selectedCode: [<CollateralCode>{}]
        });
    }

    initTypes() {
        this.collateralService.getCollateralTypes().subscribe(data => {
                this.tempCollateralTypes = this.formatCollateralType(data);
                this.collateralTypes = this.formatCollateralType(data);
            },
            error => {
            }
        );
    }

    initCodes() {
        this.collateralService.getCollateralCodes().subscribe(data => {
                this.collateralCodes = data;
                this.tempCollateralCodes = data;
            },
            error => {
            }
        );
    }

    formatCollateralType(data) {
        for (let i = 0; i < data.length; i++) {
            data[i]['customCollateralType'] = data[i].collateralTypeDesc.substr(0, data[i].collateralTypeDesc.indexOf(' '));
        }
        return data;
    }

    typeChange(event) {
        if (event === undefined) {
            return this.collateralService.getCollateralCodes().subscribe(data => {
                    this.collateralCodes = data;
                    this.typePresent = true;
                    this.collateralTypes = this.tempCollateralTypes;
                    this.selectedItem = <CollateralType>{};
                    this.selectedCode = <CollateralCode>{};
                    (<FormControl>this.createCollateralCustomForm.controls['selectedItem'])
                        .setValue(this.selectedItem);
                    (<FormControl>this.createCollateralCustomForm.controls['selectedCode'])
                        .setValue(this.selectedCode);
                },
                error => {
                }
            );
        }
        if (event.collateralType) {
            this.type = event.collateralType;
            this.collateralService.getCollateralCodes(this.type).subscribe(data => {
                    (<FormControl>this.createCollateralCustomForm.controls['selectedItem'])
                        .setValue(this.selectedItem);
                    this.selectedCode = <CollateralCode>{};
                    this.collateralCodes = data;
                    this.typePresent = false;
                    (<FormControl>this.createCollateralCustomForm.controls['selectedCode'])
                        .setValue(<CollateralCode>{});
                },
                error => {
                }
            );
            this.codeCollateralType = this.tempCollateralTypes.find(CollateralType => CollateralType.collateralType === event.collateralType);
            this.index = this.tempCollateralTypes.indexOf(this.codeCollateralType);
            this.selectedItem = this.tempCollateralTypes[this.index];
            (<FormControl>this.createCollateralCustomForm.controls['selectedItem'])
                .setValue(<CollateralType>{});
            (<FormControl>this.createCollateralCustomForm.controls['selectedItem'])
                .setValue(this.selectedItem);
            this.collateralTypes = this.tempCollateralTypes;
        }
    }

    codeChange(event) {
        if (event === undefined) {
            this.collateralService.getCollateralTypes().subscribe(data => {
                    this.collateralTypes = this.formatCollateralType(data);
                    this.codePresent = true;
                    this.collateralCodes = this.tempCollateralCodes;
                    this.selectedItem = <CollateralType>{};
                    this.selectedCode = <CollateralCode>{};
                    (<FormControl>this.createCollateralCustomForm.controls['selectedItem'])
                        .setValue(this.selectedItem);
                    (<FormControl>this.createCollateralCustomForm.controls['selectedCode'])
                        .setValue(this.selectedCode);
                },
                error => {
                }
            );
        }
        if (event) {
            this.codeCollateralType = this.tempCollateralTypes.find(CollateralType => CollateralType.collateralType === event.collateralType);
            this.index = this.tempCollateralTypes.indexOf(this.codeCollateralType);
            // this.collateralTypes.push(this.codeCollateralType);
            this.selectedItem = this.tempCollateralTypes[this.index];
            (<FormControl>this.createCollateralCustomForm.controls['selectedItem'])
                .setValue(<CollateralType>{});
            (<FormControl>this.createCollateralCustomForm.controls['selectedItem'])
                .setValue(this.selectedItem);
            this.codePresent = false;
            this.typePresent = false;
        }
    }

    onProceed(type: any, code: any) {
        const request = '';
        code.value = code.custom_ngModel;
        type.value = type.custom_ngModel;
        if (code.value !== undefined && code.value.hasOwnProperty('collateralCode')) {
            this.codePresent = false;
        } else {
            this.codePresent = true;
        }

        if (code.value !== undefined && type.value !== undefined) {
             this.collateralService.selectedCollateralType = type.value.collateralType;
            const data = new BeneficiaryList();
            const beneficiaryTempArray = [];
            data.beneficiaryId = this.counterPartyDetails.value;
            let tempName = this.counterPartyDetails.label.replace(this.counterPartyDetails.value, '');
            tempName = tempName.replace('()', '');
            data.beneficiaryName = tempName;
            data.id = 'benefiary' + Math.random().toString(36).substr(2, 5) + Math.random().toString(36).substr(2, 5);
            data.__row_status = 'added';
            beneficiaryTempArray.push(data);

            const collateral = this.populateDefaultRequestData(code.value);
            collateral.beneficiaryDetails = beneficiaryTempArray;
            this.createCollateral(collateral);
        }
    }

    populateDefaultRequestData(code): Collateral {
        const collateral = new Collateral();
        collateral.collateralCode = code.collateralCode;
        collateral.generalDetail.currencyCode = this.currency;
        // collateral.generalDetail.country = 'USA';
        collateral.generalDetail.collateralCreationDate = (new Date()).toISOString();

        if (this.collateralService.selectedCollateralType === 'DEPOS') {
            collateral.LodgeCollateralTypeSpecificDetail = new DeposLodgeCollateralTypeSpecificDetail();
        } else if (this.collateralService.selectedCollateralType === 'AIRCF') {
            collateral.LodgeCollateralTypeSpecificDetail = new AircraftLodgeCollateralTypeSpecificDetail();
        } else if (this.collateralService.selectedCollateralType === 'VEHIC') {
            collateral.LodgeCollateralTypeSpecificDetail = new VehicLodgeCollateralTypeSpecificDetail();
        }
        // collateral.generalDetail.collateralExpiryDate = '2018-06-08T12:33:43.707Z';
        collateral.CollateralValuationDetail.externalChargeAmt = this.defaultValution;
        collateral.CollateralValuationDetail.collateralValue = this.defaultValution;
        collateral.CollateralValuationDetail.finalCollateralValue = this.defaultValution;
        collateral.CollateralValuationDetail.totalApportionedValue = this.defaultValution;
        collateral.CollateralValuationDetail.balanceApportionableAmt = this.defaultValution;
        collateral.CollateralValuationDetail.apportioningMethod = 'P';
        return collateral;
    }

    createCollateral(collateral: any) {

        if (!this.collateralSummaryService.collateralConfigListFromService || !this.collateralSummaryService.collateralConfigListFromService[this.collateralService.selectedCollateralType]) {
            this.collateralSummaryService.getConfig().subscribe(data => {
                this.collateralSummaryService.collateralConfigListFromService = data;
            });
        }

        this.collateralService.postCollateral(collateral).subscribe(data => {
                this.collateralService.collateral = JsonConvert.deserializeString(JSON.stringify(data), Collateral);
                let navigationExtras: NavigationExtras;
                this.collateralService.disableTab = false;
                this.collateralService.collateralForm = null;
                this.collateralSummaryService.collateralOperation = 'ADD';
                navigationExtras = {
                    queryParams: {
                        'cid': this.collateralService.collateral.collateralId,
                        'ctype': this.collateralService.selectedCollateralType,
                        'gcin': this.gcinCpValue,
                        'label': this.gcinDesc
                    }
                };
                this.collateralService.clearCollateral();
                this.router.navigate(['./collateral'], navigationExtras);


               /*  const config = this.collateralSummaryService.collateralConfigListFromService[this.collateralService.selectedCollateralType];

                const filter = {
                    where: {
                        'withdrawalDetail.withdraw': false,
                        collateralId: this.collateralService.collateral.collateralId
                    }, include: config.include
                };
                this.collateralSummaryService.getCollateralsList(this.collateralService.selectedCollateralType, config.apiToHit, filter).subscribe(getDataRes => {

                    this.collateralService.collateral = JsonConvert.deserializeString(JSON.stringify(getDataRes[0]), Collateral);
                    this.collateralService.limitDataBeneficiary = {};
                    this.collateralSummaryService.collateralOperation = 'ADD';
                    let navigationExtras: NavigationExtras;
                    this.collateralService.disableTab = false;
                    this.collateralService.collateralForm = null;
                    // this.collateralService.saveDraftCollateral();
                    navigationExtras = {
                        queryParams: {
                            'cid': this.collateralService.collateral.collateralId,
                            'ctype': this.collateralService.selectedCollateralType,
                            'gcin': this.gcinCpValue,
                            'label': this.gcinDesc
                        }
                    };
                    this.router.navigate(['./collateral'], navigationExtras);
                }, error => {
                }); */
            },
            error => {
            }
        );
    }

    onCancel() {
        this.codePresent = false;
        this.selectedItem = <CollateralType>{};
        this.selectedCode = <CollateralCode>{};
        (<FormControl>this.createCollateralCustomForm.controls['selectedItem'])
            .setValue(<CollateralType>{});
        (<FormControl>this.createCollateralCustomForm.controls['selectedCode'])
            .setValue(<CollateralCode>{});
        this.collateralCodes = this.tempCollateralCodes;
        this.cancelDailog.emit(false);
    }

    ngOnDestroy() {

    }

    keyInType(event) {
        const filter = {'where': {'collateralType': {'regexp': '/' + event + '/i'}}, 'order': 'collateralType'};
        this.collateralService.getCollateralTypes(filter).subscribe(data => {
                this.collateralTypes = this.formatCollateralType(data);
            },
            error => {
                console.log(error);
            }
        );
    }

    keyInCode(event) {
        if (this.selectedItem !== undefined && this.selectedItem.hasOwnProperty('collateralType')) {
            if (this.selectedItem.collateralType) {
                this.collateralService.searchOnTypeAndFilter(this.selectedItem.collateralType, event).subscribe(data => {
                    this.collateralCodes = data;
                });
            } else {
                this.collateralService.getCollateralCodes(event, true).subscribe(data => {
                    this.collateralCodes = data;
                });
            }
        } else {
            this.collateralService.getCollateralCodes(event, true).subscribe(data => {
                    this.collateralCodes = data;
                },
                error => {
                    console.log(error);
                });
        }
    }
}