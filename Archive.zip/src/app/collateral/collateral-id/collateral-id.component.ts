import {Component} from '@angular/core';
import {CollateralService} from '../collateral.service';
@Component({
    selector: 'collateral-id',
    templateUrl: './collateral-id.component.html',
    styleUrls: ['./collateral-id.component.scss']
})
export class CollateralIDComponent {
    collapsible: boolean = true;
    today: number = Date.now();
    id: string;
    collateral: any;
    constructor(public collateralService: CollateralService) {}
}
