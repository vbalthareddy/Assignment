describe('should complete add,edit,delete journey for collateral of Guarantee Type', () => {

    const createCollateralGaurnTestSuite = require('./utils/CollateralsCreateGaurnHelper');
    const editCollateralGaurnTestSuite = require('./utils/CollateralsEditGaurnHelper');
    const viewAndEditCollateralGaurnTestSuite = require('./utils/CollateralViewAndEditGaurnHelper');
    const withdrawCollateralGaurnTestSuite = require('./utils/CollateralsWithdrawGaurnHelper');
    const processCreateCollateralGaurn = () => {
        createCollateralGaurnTestSuite.CreateCollateralGaurnTestSuite();
    };

    const processEditCollateralGaurn = () => {
        editCollateralGaurnTestSuite.EditCollateralGaurnTestSuite();
    };

    const processWithdrawCollateralGaurn = () => {
        withdrawCollateralGaurnTestSuite.WithdrawCollateralGaurnTestSuite();
    };

    const processViewAndEditCollateralGaurnTestSuite = () => {
        viewAndEditCollateralGaurnTestSuite.ViewAndEditCollateralGaurnTestSuite();
    }

    xdescribe('should create a collateral of guarantee type', () => {
        processCreateCollateralGaurn();
    });

    xdescribe('should edit already created collateral of guarantee type', () => {
        processEditCollateralGaurn();
    });

    //process collateral id flow
    describe('should view and edit already created collateral of guarantee type', () => {
        processViewAndEditCollateralGaurnTestSuite();
    });

    describe('should withdraw existing collateral of guarantee type ', () => {
        processWithdrawCollateralGaurn();
    });

});
