import {E2eSpecHelper} from './E2eSpecHelper';

const collateralSpecSuite = require('./CollateralSpecHelper');
const summarySpecSuite = require('./SummarySpecHelper');
const valuationSpecSuite = require('./ValuationSpecHelper');
const documentSpecSuite = require('./DocumentSpecHelper');
const beneficiarySpecSuite = require('./BeneficiarySpecHelper');
const collateralDetailSpecSuite = require('./CollateralDetailSpecHelper');
const specificDetailSpecSuite = require('./SpecificDetailsVehicleSpecHelper');
const subHirerDetailsSpecSuite = require('./SubHirerDetailsSpecHelper');
const hpDetailsSpecSuite = require('./HPDetailsSpecHelper');
const garagingDetailsSpecSuite = require('./GaragingDetailsSpecHelper');
const ownershipSpecSuite = require('./OwnershipSpecHelper');
const chargeSpecSuite = require('./ChargeSpecHelper');
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

exports.CreateCollateralVehicleTestSuite = function () {
    describe('should create collateral of vehicle type', () => {
        /*E2E for setting up add collateral Page*/
        const processCollateralPage = () => {
            collateralSpecSuite.CollateralTestSuite('Vehicle');
        };

        /*E2E for Collateral Details Page*/
        const processCollateralDetailsPage = () => {
            collateralDetailSpecSuite.CollateralDetailsTestSuite();
        };

        /*E2E for Specific Details Page*/
        const processSpecificDetailsPage = () => {
            specificDetailSpecSuite.SpecificDetailsTestSuiteForVehicleCreateFlow();
        };

        /*E2E for Sub Hirer Details Page*/
        const processSubHirerDetailsPage = () => {
            subHirerDetailsSpecSuite.SubHirerDetailsSpecSuite();
        };

        /*E2E for HP Details Page*/
        const processHPDetailsSpecSuite = () => {
            hpDetailsSpecSuite.HPDetailsSpecSuite();
        };

        /*E2E for Garaging Details Page*/
        const processGaragingDetailsSpecSuite = () => {
            garagingDetailsSpecSuite.GaragingDetailsSpecSuite();
        };

        /*E2E for Beneficiary Page*/
        const processBeneficiaryDetailsPage = () => {
            beneficiarySpecSuite.BeneficiaryTestSuite();
        };

        /*E2E for Ownership Page*/
        const processOwnershipDetailsPage = () => {
            ownershipSpecSuite.OwnershipTestSuite();
        };

        /*E2E for Document Page*/
        const processDocumentDetailsPage = () => {
            documentSpecSuite.DocumentTestSuite();
        };

        /*E2E for Valuation Page*/
        const processValuationDetailsPage = () => {
            valuationSpecSuite.ValuationTestSuite();
        };

        /*E2E for Summary Page*/
        const processSummaryPage = () => {
            summarySpecSuite.SummaryTestSuite('Vehicle');
        };

        describe('should set up add collateral page', () => {
            processCollateralPage();
        });

        describe('should verify details on collateral-details page', () => {
            processCollateralDetailsPage();
        });

        describe('should verify details on specific-details page', () => {
            processSpecificDetailsPage();
        });

        describe('should verify details on Sub Hirer Details page', () => {
            processSubHirerDetailsPage();
        });

        describe('should verify details on HP  page', () => {
            processHPDetailsSpecSuite();
        });

        describe('should verify details on garaging page', () => {
            processGaragingDetailsSpecSuite();
        });

        describe('should verify details on beneficiary-details page', () => {
            processBeneficiaryDetailsPage();
        });

        xdescribe('should verify details on ownership-details page', () => {
            processOwnershipDetailsPage();
        });

        describe('should verify details on document-details page', () => {
            processDocumentDetailsPage();
        });

        describe('should verify details on valuation tab page', () => {
            processValuationDetailsPage();
        });

        describe('should verify data from summary page', () => {
            processSummaryPage();
        });

        it('should click on Submit button to submit vehicle type collateral', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.buttonClick('#final_submit_btn');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('#gblMsgId');
        });
    });
};
