package com.dbs.cap.cls.client;

import com.dbs.cap.cls.common.constants.ClsConstants;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;

@FeignClient(
        name = "CustomerClient",
        url = "${ev.limit.host}")
public interface CustomerClient {
    @RequestMapping(
            path = "/api/Customers",
            method = RequestMethod.POST)
    HashMap<String, Object> createCustomer(
            @RequestBody Object customer);

    @RequestMapping(
            path = "/api/Customers",
            method = RequestMethod.PUT)
    HashMap<String, Object> updateCustomer(
            @RequestBody Object customer);

    @RequestMapping(
            path = "/api/Customers",
            method = RequestMethod.GET)
    List<HashMap<String, Object>> getCustomer(
            @RequestParam(ClsConstants.FILTER) String filter);
}
