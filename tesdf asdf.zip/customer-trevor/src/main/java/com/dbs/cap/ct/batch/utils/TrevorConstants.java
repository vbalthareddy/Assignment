package com.dbs.cap.ct.batch.utils;

public class TrevorConstants {
    public static final String CUSTOMER_API = "/cls/api/v1/customer";
    public static final String CUSTOMER_RELATION_API = "/cls/api/v1/customer/relationship";
}
