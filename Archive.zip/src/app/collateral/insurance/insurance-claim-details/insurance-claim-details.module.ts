import { PopupDialogOnleaveModule } from '../../../common/popupdialog-onleave/popupdialog-onleave.module';
import {CommonModule} from '@angular/common';
import {CUSTOM_ELEMENTS_SCHEMA, ModuleWithProviders, NgModule} from '@angular/core';
import {InsuranceClaimDetailsComponent} from './insurance-claim-details.component';
import {CommonUIModule} from '../../../common/commonUI.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../../shared/shared-common.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {GridModule} from '@progress/kendo-angular-grid';

import {CounterpartyDetailsModule} from '../../../shared/counterparty-details/counterparty-details.module';
import {CustomPanelModule} from '../../../common/custom-panel/custom-panel.module';
import {InsuranceClaimsDetailsService} from './insurance-claim-details.service';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {ComboBoxModule} from '@progress/kendo-angular-dropdowns';


@NgModule({
    imports: [CommonModule, BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
        BrowserAnimationsModule, CounterpartyDetailsModule,
        GridModule, ClsSharedCommonModule, CommonUIModule, CustomPanelModule, DateInputsModule, ComboBoxModule,PopupDialogOnleaveModule],
    declarations: [InsuranceClaimDetailsComponent],
    exports: [InsuranceClaimDetailsComponent],
    providers: [InsuranceClaimsDetailsService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]

})

export class InsuranceClaimDetailsModule {
    // public static forRoot(): ModuleWithProviders {
    //     return {ngModule: InsuranceClaimDetailsModule, providers: []};
    // }
}
