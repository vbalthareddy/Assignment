import {ChargeComponent} from './charge.component';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {AutoCompleteModule, ComboBoxModule} from '@progress/kendo-angular-dropdowns';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {InputsModule} from '@progress/kendo-angular-inputs';
import {BrowserModule} from '@angular/platform-browser';
import {CommonModule} from '@angular/common';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {GridModule} from '@progress/kendo-angular-grid';
import {DialogModule} from '@progress/kendo-angular-dialog';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {IntlModule} from '@progress/kendo-angular-intl';
import {ToggleButtonModule} from '../../common/toggle-button/toggle-button.module';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';
import {CommonUIModule} from '../../common/commonUI.module';
import {Collateral, CollateralValuationDetail} from '../model/collateral';
import {CollateralService} from '../collateral.service';
import {Observable} from 'rxjs/Observable';
import {ChargeService} from './charge.component.service';
import {
    ChargeRankJSON,
    ChargeRankList,
    MOCK_CHARGE_DATA,
    MOCK_COLLATERAL_VALUATION_DATA,
    MOCK_LODGE_CHARGE_DETAIL,
    MOCK_NATURE_OF_CHARGES,
    MOCK_REGISTRATION_AUTHOURITY
} from './charge.data';
import {ChargeDataModel} from './charge.model';
import {CurrencyDropdownService} from '../../common/currency-dropdown/currency-dropdown.service';
import {CollateralSummaryService} from '../collateral-summary/collateral-summary.service';

class MockChargeService {
    getNatureOfCharges() {
        return Observable.of(MOCK_NATURE_OF_CHARGES);
    }

    getBlankChargeData() {
        return Observable.of([]);
    }

    getOneChargeData(data: any) {
        return data;
    }

    getChargeRank() {
        return Observable.of(ChargeRankJSON);
    }

    getRegistrationAuthorityDetails() {
        return Observable.of(MOCK_REGISTRATION_AUTHOURITY);
    }
}

class MockCollateralService {
    getCollateral() {
        return new Collateral();
    }
}

class MockFormBuilder extends FormBuilder {

    getBlankForm() {
        const formBuilder = new FormBuilder;
        const formGroup = formBuilder.group({
            natureOfCharge: ['', [Validators.required]],
            chargeRankToSubmit: ['', [Validators.required]],
            chargeRankToShow: ['', [Validators.required]],
            chargeAmount: ['', [Validators.required]],
            filingDate: [null, [Validators.required]],
            receiptDate: [null, [Validators.required]],
            registrationAuthInfo: [],
            currencyType: ['', [Validators.required]]
        });
        return formGroup;
    }

    getAddChargeForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            natureOfCharge: ['Nature of charge code1', [Validators.required]],
            chargeRankToSubmit: [1, [Validators.required]],
            chargeRankToShow: ['1ST', [Validators.required]],
            chargeAmount: [100000.00, [Validators.required]],
            filingDate: ['2017-05-12T07:06:17.255Z', [Validators.required]],
            receiptDate: ['2017-05-12T07:06:17.255Z', [Validators.required]],
            registrationAuthInfo: ['ACRA'],
            currencyType: ['SGD', [Validators.required]]
        });
        return formGroup;
    }

    setMainForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            chargeList: ['', [Validators.required]]
        });
        return formGroup;
    }

    setMainFormWithChargeListVal(data: any) {
        const mockChargeService: MockChargeService = new MockChargeService();
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            chargeList: [data, [Validators.required]]
        });
        return formGroup;
    }

}

class MockCurrencyService {
    getCurrencies(filter?: any) {
        return {
            body: [
                {
                    'code': 'SGD',
                    'description': 'SGD Currency',
                    'id': '5f30e506-a276-4865-95aa-210667ded1a8'
                },
                {
                    'code': 'EUR',
                    'description': 'EUR Currency',
                    'id': '6acc19da-6c8a-441d-ba8b-7d41efbe9ab9'
                }],
            subscribe: function (data?: any) {
            }
        };
    }
}

class MockCollateralSummaryService {
    rateConversionArray: any = [
        {
            fromCurrency: 'SGD',
            toCurrency: 'INR',
            rate: 10
        }, {
            fromCurrency: 'SGD',
            toCurrency: 'SGD',
            rate: 1
        }
    ];

    getCurrency() {
        const data = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        return Observable.of(data);
    }

    getRateValues(from: string, to: string) {
        const data = [{
            fromCurrency: 'SGD',
            toCurrency: 'INR',
            rate: 10
        }, {
            fromCurrency: 'SGD',
            toCurrency: 'SGD',
            rate: 1
        }];
        return Observable.of(data);
    }

    getRateForCurrency(collateralCcy, amountCcy) {
        if (amountCcy === collateralCcy) {
            return 1;
        } else {
            if (this.rateConversionArray.length > 0) {
                const indexOfRate = this.rateConversionArray.findIndex(data => data.fromCurrency === amountCcy && data.toCurrency === collateralCcy);
                if (indexOfRate !== undefined && (indexOfRate !== -1)) {
                    return this.rateConversionArray[indexOfRate]['rate'];
                } else {
                    return 0;
                }
            } else {
                return 0;
            }
        }
    }
}

describe('Component : ChargeComponent', () => {

    let chargeComponent: ChargeComponent;
    let fixture: ComponentFixture<ChargeComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, BrowserModule, LoaderModule, GridModule, DialogModule,
                ButtonsModule, InputsModule, ReactiveFormsModule, AutoCompleteModule,
                DateInputsModule, CommonUIModule, PopupDialogModule, ToggleButtonModule,
                IntlModule, ClsSharedCommonModule, ComboBoxModule],
            declarations: [ChargeComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [
                {provide: CollateralService, useClass: MockCollateralService},
                {provide: FormBuilder, useClass: MockFormBuilder},
                {provide: ChargeService, useClass: MockChargeService},
                {provide: CurrencyDropdownService, useClass: MockCurrencyService},
                {provide: CollateralSummaryService, useClass: MockCollateralSummaryService}
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ChargeComponent);
        chargeComponent = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(chargeComponent).toBeTruthy();
    });

    it('should show no-record-component-found when no data from service', () => {
        let collateralService: CollateralService;
        collateralService = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral;
        collateral.LodgeChargeDetail = undefined;
        spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
        chargeComponent.setUpChargeComponent();
        expect(chargeComponent.divForNoData).toBe(true);
    });

    it('should not show no-record-component-found', () => {
        let collateralService: CollateralService;
        collateralService = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral;
        collateral.LodgeChargeDetail = MOCK_LODGE_CHARGE_DETAIL;
        chargeComponent.regAuthorityObj = MOCK_REGISTRATION_AUTHOURITY;
        spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
        chargeComponent.setUpChargeComponent();
        expect(chargeComponent.divForNoData).toBe(false);
    });

    it('Charge data should get added to grid on click of save button', async(() => {
        fixture.detectChanges();
        const mockFormBuilder = new MockFormBuilder();
        chargeComponent.chargeRankList = ChargeRankJSON;
        chargeComponent.chargeRankResponse = ChargeRankList;
        chargeComponent.addChargeForm = mockFormBuilder.getAddChargeForm();
        chargeComponent.natureOfCharges = MOCK_NATURE_OF_CHARGES;
        chargeComponent.regAuthorityObj = MOCK_REGISTRATION_AUTHOURITY;
        chargeComponent.addChargeData(MOCK_CHARGE_DATA);
        expect(chargeComponent.chargeGridDataForHTML.length).toBeGreaterThan(0);
    }));

    it('should show summary grid', async(() => {
        const mockFormBuilder = new MockFormBuilder();
        chargeComponent.chargeForm = mockFormBuilder.setMainFormWithChargeListVal(MOCK_CHARGE_DATA);
        const mockChargeService: MockChargeService = new MockChargeService();
        chargeComponent.chargeGridDataForHTML = mockChargeService.getOneChargeData(MOCK_CHARGE_DATA);
        chargeComponent.showSummaryGrid = true;
        chargeComponent.setUpChargeComponent();
        expect(chargeComponent.showSummaryGrid).toBe(true);
    }));

    it('should show normal grid', async(() => {
        const mockFormBuilder = new MockFormBuilder();
        chargeComponent.chargeForm = mockFormBuilder.setMainFormWithChargeListVal(MOCK_CHARGE_DATA);
        const mockChargeService: MockChargeService = new MockChargeService();
        chargeComponent.chargeGridDataForHTML = mockChargeService.getOneChargeData(MOCK_CHARGE_DATA);
        chargeComponent.showSummaryGrid = false;
        chargeComponent.setUpChargeComponent();
        expect(chargeComponent.showSummaryGrid).toBe(false);
    }));

    it('Charge dialog box should get opened on click of Add Charge button', async(() => {
        fixture.detectChanges();
        chargeComponent.showAddChargeDialog();
        expect(chargeComponent.addChargeDetailsDialogBox).toBe(true);
        expect(chargeComponent.chargeDialogTitleName).toEqual('Add Charge Details');
        // chargeComponent.chargeGridDataForHTML = [{}];
        // chargeComponent.chargeGridDataForHTML.length = 2;
        // chargeComponent.natureOfChargeVal = 'xyz';
        // chargeComponent.showAddChargeDialog();
        // fixture.detectChanges();
        // expect(chargeComponent.addChargeForm.get('natureOfCharge').value).toEqual('xyz');

    }));

    it('Charge dialog box should get closed on click of Cancel button', async(() => {
        fixture.detectChanges();
        chargeComponent.closeAddChargeDetailsDialogBox();
        expect(chargeComponent.addChargeDetailsDialogBox).toBe(false);
    }));

    it('toggle button event should be emitted', async(() => {
        fixture.detectChanges();
        const valueFromSelectedButton = 'Yes';
        chargeComponent.eventFromToggleButton(valueFromSelectedButton);
        expect(chargeComponent.valueFromSelectedButton).toBe('Yes');
    }));

    it('should validate charge amount', async(() => {
        fixture.detectChanges();
        const $event = {amount: 100000.00};
        chargeComponent.validateChargeAmount($event);
        expect(chargeComponent.chargeAmountValidate).toBe(false);
    }));

    it('should throw error on charge amount ', async(() => {
        fixture.detectChanges();
        const $event = {};
        chargeComponent.validateChargeAmount($event);
        expect(chargeComponent.chargeAmountValidate).toBe(true);
    }));

    it('should return "-" when checkForRegAuthValue is null', async(() => {
        fixture.detectChanges();
        const $value = '';
        expect(chargeComponent.checkForRegAuthValue($value)).toBe('');
    }));

    it('should return "abc" when checkForRegAuthValue is "abc"', async(() => {
        fixture.detectChanges();
        const $value = 'abc';
        expect(chargeComponent.checkForRegAuthValue($value)).toBe('abc');
    }));

    it('should return error when nature of charge value is not in service response', async(() => {
        fixture.detectChanges();
        chargeComponent.natureOfCharges = MOCK_NATURE_OF_CHARGES;
        const $value = 'abc';
        chargeComponent.validationCheckForNatureOfCharge($value);
        expect(chargeComponent.natureOfChargeDivError).toBe(true);
        expect(chargeComponent.validationCheckForNatureOfCharge($value)).toBe(false);
    }));

    it('should not return error when nature of charge value is not in service response', async(() => {
        fixture.detectChanges();
        chargeComponent.natureOfCharges = MOCK_NATURE_OF_CHARGES;
        const $value = 'Nature of charge code1';
        chargeComponent.validationCheckForNatureOfCharge($value);
        expect(chargeComponent.natureOfChargeDivError).toBe(false);
        expect(chargeComponent.validationCheckForNatureOfCharge($value)).toBe(true);
    }));

    it('should return error when charge rank value is not in service response', async(() => {
        fixture.detectChanges();
        chargeComponent.chargeRankList = ChargeRankJSON;
        chargeComponent.chargeRankResponse = ChargeRankList;
        const $value = 'xyz';
        chargeComponent.validationCheckForChargeRank($value);
        expect(chargeComponent.chargeRankDivError).toBe(true);
        expect(chargeComponent.validationCheckForChargeRank($value)).toBe(false);
    }));

    it('should not return error when charge rank value is not in service response', async(() => {
        fixture.detectChanges();
        chargeComponent.chargeRankList = ChargeRankJSON;
        chargeComponent.chargeRankResponse = ChargeRankList;
        const $value = '1DBS';
        chargeComponent.validationCheckForChargeRank($value);
        expect(chargeComponent.chargeRankDivError).toBe(false);
        expect(chargeComponent.validationCheckForChargeRank($value)).toBe(true);
    }));

    it('Data should get displayed in Update Charge Dialog Box fields onclick of edit icon', async(() => {
        fixture.detectChanges();
        const mockUpdatedChargeData = {};
        mockUpdatedChargeData['natureOfCharge'] = 'Nature of charge code1';
        mockUpdatedChargeData['chargeRank'] = '1ST';
        mockUpdatedChargeData['chargeAmount'] = 200000.08;
        mockUpdatedChargeData['filingDate'] = new Date('2017-05-12T07:06:17.255Z');
        mockUpdatedChargeData['receiptDate'] = new Date('2017-05-12T07:06:17.255Z');
        mockUpdatedChargeData['registrationAuthority'] = '-';
        const mockFormBuilder = new MockFormBuilder();
        chargeComponent.addChargeForm = mockFormBuilder.getAddChargeForm();
        const mockChargeService: MockChargeService = new MockChargeService();
        chargeComponent.natureOfCharges = MOCK_NATURE_OF_CHARGES;
        chargeComponent.chargeGridDataForHTML.push(mockUpdatedChargeData);
        const rowIndex = 1;
        chargeComponent.chargeEditFunc(mockUpdatedChargeData, rowIndex);
        expect(chargeComponent.addChargeForm.controls['natureOfCharge'].value).toBe('Nature of charge code1');
        expect(chargeComponent.chargeDialogTitleName).toBe('Update Charge Details');
    }));

    it('Data should get updated in Grid  onclick of update button', async(() => {
        fixture.detectChanges();
        chargeComponent.chargeRankList = ChargeRankJSON;
        chargeComponent.chargeRankResponse = ChargeRankList;
        chargeComponent.natureOfCharges = MOCK_NATURE_OF_CHARGES;
        chargeComponent.regAuthorityObj = MOCK_REGISTRATION_AUTHOURITY;
        chargeComponent.chargeGridDataForHTML.push(MOCK_CHARGE_DATA);
        const mockUpdatedChargeData = new ChargeDataModel();
        const mockFormBuilder = new MockFormBuilder();
        chargeComponent.addChargeForm = mockFormBuilder.getAddChargeForm();
        mockUpdatedChargeData.natureOfCharge = mockFormBuilder.getAddChargeForm().controls['natureOfCharge'].value;
        mockUpdatedChargeData['chargeRankToShow'] = mockFormBuilder.getAddChargeForm().controls['chargeRankToShow'].value;
        mockUpdatedChargeData.chargeAmount = mockFormBuilder.getAddChargeForm().controls['chargeAmount'].value;
        mockUpdatedChargeData.filingDate = mockFormBuilder.getAddChargeForm().controls['filingDate'].value;
        mockUpdatedChargeData.receiptDate = mockFormBuilder.getAddChargeForm().controls['receiptDate'].value;
        mockUpdatedChargeData.registrationAuthInfo = mockFormBuilder.getAddChargeForm().controls['registrationAuthInfo'].value;
        chargeComponent.rowIndex = 0;
        chargeComponent.updateChargeData(mockUpdatedChargeData);
        expect(chargeComponent.chargeGridDataForHTML[0].registrationAuthority).toBe(mockUpdatedChargeData.registrationAuthInfo);
    }));

    it('Data should get deleted from Grid onclick of delete icon', async(() => {
        fixture.detectChanges();
        chargeComponent.chargeGridDataForHTML.push(MOCK_CHARGE_DATA);
        const rowIndex = 0;
        chargeComponent.deleteChargeData(rowIndex);
        chargeComponent.confirmationFromYesNo(['yes']);
        expect(chargeComponent.chargeGridDataForHTML.length).toBe(0);
        chargeComponent.chargeGridDataForHTML.push(MOCK_CHARGE_DATA);
        chargeComponent.chargeGridDataForHTML.push(MOCK_CHARGE_DATA);
        chargeComponent.deleteChargeData(rowIndex);
        chargeComponent.confirmationFromYesNo(['yes']);
        expect(chargeComponent.divForNoData).toBe(false);

    }));

    it('validation check for total charge amount when amount is greater than to Collateral value', async(() => {
        fixture.detectChanges();
        chargeComponent.valueFromSelectedButton = 'Yes';
        chargeComponent.collateralCurrency = 'SGD';
        chargeComponent.maxChargeAmount = 9000.00;
        const mockFormBuilder = new MockFormBuilder();
        chargeComponent.addChargeForm = mockFormBuilder.getAddChargeForm();
        chargeComponent.validateChargeAmountWithValuationDetail();
        expect(chargeComponent.maxChargeAmountReachedDivError).toBe(true);
        chargeComponent.valueFromSelectedButton = 'No';
        chargeComponent.validateChargeAmountWithValuationDetail();
        expect(chargeComponent.maxChargeAmountReachedDivError).toBe(false);
    }));

    it('validation check for total charge amount when amount is smaller than or equal to Collateral value', async(() => {
        fixture.detectChanges();
        chargeComponent.valueFromSelectedButton = 'Yes';
        chargeComponent.collateralCurrency = 'SGD';
        chargeComponent.maxChargeAmount = 110000.00;
        const mockFormBuilder = new MockFormBuilder();
        chargeComponent.addChargeForm = mockFormBuilder.getAddChargeForm();
        chargeComponent.validateChargeAmountWithValuationDetail();
        expect(chargeComponent.maxChargeAmountReachedDivError).toBe(false);
    }));

    it('should validate charge component', async(() => {
        fixture.detectChanges();
        const data = {
            'chargeAmount': null
        };
        chargeComponent.addChargeData(data);
        expect(chargeComponent.chargeAmountValidate).toBe(true);
        expect(chargeComponent.maxChargeAmountReachedDivError).toBe(false);

        const chargeData: ChargeDataModel = new ChargeDataModel();
        chargeData.chargeAmount = null;
        chargeComponent.updateChargeData(chargeData);
        expect(chargeComponent.chargeAmountValidate).toBe(true);
        expect(chargeComponent.maxChargeAmountReachedDivError).toBe(false);

    }));

    it('should get filtered value from nature of charge array when user types in combobox', async(() => {
        fixture.detectChanges();
        chargeComponent.natureOfCharges = MOCK_NATURE_OF_CHARGES;
        chargeComponent.filterNatureOfCharge('xyz');
        expect(chargeComponent.natureOfDataToShow).toEqual([]);
    }));

    it('should test for error handler method', async(() => {
        const error = {
            status: 500
        };
        expect(chargeComponent.handleErrorResponse(error)).toEqual(Observable.throw(new Error('500')));
        error['status'] = 404;
        expect(chargeComponent.handleErrorResponse(error)).toEqual(Observable.throw(new Error('404')));
        error['status'] = 400;
        expect(chargeComponent.handleErrorResponse(error)).toEqual(Observable.throw(new Error('400')));
        error['status'] = 409;
        expect(chargeComponent.handleErrorResponse(error)).toEqual(Observable.throw(new Error('409')));

    }));

    it('should calculate final collateral, collateral and external charge vals when currency is not present in rate conversion array', async(() => {

        chargeComponent.collateralCurrency = 'SGD';
        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        collateralService_1.chargeCompErrors = [];
        const collateral: Collateral = new Collateral();
        const collateralValuationDetails = new CollateralValuationDetail();
        collateral.CollateralValuationDetail = MOCK_COLLATERAL_VALUATION_DATA;
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);

        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'INR',
                toCurrency: 'INR',
                rate: 10
            }
        ];
        chargeComponent.chargeGridDataForHTML = [{
            currencyType: 'SGD',
            chargeAmount: 50000,
            externalCharge: 'Yes'
        }];
        chargeComponent.getRateValues();
        expect(collateralService_1.chargeCompErrors[0]).toEqual('Total External charge should not exceed the collateral value.');

    }));

    it('should calculate final collateral, collateral and external charge vals when currency is present in rate conversion array', async(() => {

        chargeComponent.collateralCurrency = 'SGD';
        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        collateralService_1.chargeCompErrors = [];
        const collateral: Collateral = new Collateral();
        const collateralValuationDetails = new CollateralValuationDetail();
        collateral.CollateralValuationDetail = MOCK_COLLATERAL_VALUATION_DATA;
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);

        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'SGD',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            }
        ];
        chargeComponent.chargeGridDataForHTML = [{
            currencyType: 'SGD',
            chargeAmount: 50000,
            externalCharge: 'Yes'
        }];
        chargeComponent.getRateValues();
        expect(collateralService_1.chargeCompErrors[0]).toEqual('Total External charge should not exceed the collateral value.');

    }));

    it('should test get currency api when rate conversion array has values', () => {
        const collateralCcy = 'INR';
        const amountCcy = 'SGD';
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'SGD',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            }
        ];
        expect(chargeComponent.getRateForCurrency(collateralCcy, amountCcy)).toEqual(10);
    });

    it('should test get currency api when rate conversion array has values but dont have specified currencies', () => {
        const collateralCcy = 'INR';
        const amountCcy = 'SGD';
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'USD',
                toCurrency: 'PSD',
                rate: 10
            }
        ];
        expect(chargeComponent.getRateForCurrency(collateralCcy, amountCcy)).toEqual(0);
    });

    it('should test get currency api when rate conversion array has no values', () => {
        const collateralCcy = 'INR';
        const amountCcy = 'SGD';
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [];
        expect(chargeComponent.getRateForCurrency(collateralCcy, amountCcy)).toEqual(0);
    });
    it('should filter filterChangeRegAuthority object on search ', () => {
        chargeComponent.regAuthorityObj = MOCK_REGISTRATION_AUTHOURITY;
        chargeComponent.filterChangeRegAuthority('ACRA');
        expect(chargeComponent.regAuthorityDataForFilter).toEqual(['ACRA']);
    });
    it('should filter validationCheckForRegistrationAuth object on search ', () => {
        chargeComponent.regAuthorityObj = MOCK_REGISTRATION_AUTHOURITY;
        chargeComponent.validationCheckForRegistrationAuth('ACRA');
        expect(chargeComponent.regAuthDivError).toBe(false);
        chargeComponent.validationCheckForRegistrationAuth('noValue');
        expect(chargeComponent.regAuthDivError).toBe(true);
    });

});
