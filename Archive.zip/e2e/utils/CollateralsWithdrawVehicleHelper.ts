import {E2eSpecHelper} from './E2eSpecHelper';
import {browser} from 'protractor';

const collateralSpecSuite = require('./CollateralSpecHelper');
const viewCollateralsSpecSuite = require('./ViewCollateralsSpecHelper');
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

exports.WithdrawCollateralVehicleTestSuite = function () {
    describe('should withdraw collateral of vehicle type', () => {
        browser.ignoreSynchronization = true;

        /*E2E for setting up add collateral Page*/
        const processCollateralPageForViewCollaterals = () => {
            collateralSpecSuite.CollateralTestSuiteForViewCollaterals();
        };

        /*E2E for verifying view collaterals Page*/
        const processViewCollateralsPage = () => {
            viewCollateralsSpecSuite.ViewCollateralsTestSuite();
        };

        describe('should verify details on add/update collaterals page', () => {
            processCollateralPageForViewCollaterals();
        });

        describe('should verify details on view collaterals page', () => {
            processViewCollateralsPage();
        });
// TODO : Implementation required accordingly
        describe('Withdraw collateral of vehicle type', () => {
            it('should click on Delete button from vehicle grid and withdraw selected collateral', () => {
                /*e2eSpecHelper.sleepBrowser(2000);
                 e2eSpecHelper.buttonClick('#VEHICLE-DeleteIcon-0');*/
            });
// TODO : Implementation required accordingly
            it('should verify the confirmation box and click on confirm button', () => {
                /*e2eSpecHelper.sleepBrowser(2000);
                 e2eSpecHelper.verifyTextContains('.k-window-title.k-dialog-title', 'Confirm Collateral Withdrawal');
                 e2eSpecHelper.buttonClick('#confirmation_btn');
                 e2eSpecHelper.sleepBrowser(2000);
                 e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of vehicle Collateral has been successfully withdrawn.');
                 e2eSpecHelper.sleepBrowser(2000);*/
            });
        });

    });
};
