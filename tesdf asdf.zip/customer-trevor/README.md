# Customer Trevor

Trevor is the name of the donkey, which carries information from one place to another place.

## Description

This batch is used to read from cap limit database and will send processed data to EV through cls-gateway service.

Batch will run every 3 hours and is configurable via spring profiles.

## Running the batch

building jar

```
mvn clean package
```
running the jar

```
java -jar -Dspring.profiles.active=dev customer-trevor.jar
```

## Deployment Info:

* [SIT](https://jenkins-oc-0.dev.sys.cs.sgp.dbs.com/job/cap/job/customer-trevor/job/build/) - Jenkins
* org:  dev-credit-risk, space: customer-trevor-sit  - PCF
* [coverage](https://sonar.dev.sys.cs.sgp.dbs.com/dashboard?id=com.dbs.cap%3Acustomer-trevor) - Sonar