import {BehaviorSubject} from 'rxjs/Rx';
import {DraftRecordService} from '../../draftrecord/draft-record.service';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FacilityLinkageDataComponent} from './facility-linkage-data.component';
import {BrowserModule} from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, ElementRef, NO_ERRORS_SCHEMA} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CommonUIModule} from '../../common/commonUI.module';
import {ActivatedRoute, Router} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {GridModule} from '@progress/kendo-angular-grid';
import {CounterpartyDetailsModule} from '../../shared/counterparty-details/counterparty-details.module';
import {CustomPanelModule} from '../../common/custom-panel/custom-panel.module';
import {FacilityLinkageDataService} from './facility-linkage-data.service';
import {CollateralService} from 'app/collateral/collateral.service';
import {CollateralSummaryService} from 'app/collateral/collateral-summary/collateral-summary.service';
import {Observable} from 'rxjs/Observable';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {beneficiaryLimitData, limitData} from './limits.data';
import {collateralData} from './../new-collateral/new-collateral.data';

class MockElementRef implements ElementRef {
    nativeElement = {};
}
class MockCollateralSummaryService {
    collateralOperation = 'FACILITY LINKAGE';
    breadcrumbvalue = false;
}
class MockCollateralService {
    limitDataBeneficiary = beneficiaryLimitData;
    collateral = collateralData;

    getLimitsByLimitTypeId() {
        return Observable.of(limitData);
    }

    postELC(entitys?: any): Observable<any> {
        return Observable.of({});
    }

    submitCollateral(): Observable<any> {
        return Observable.of(collateralData);
    }

    getDraftCollateral() {
        return Observable.of(null);
    }
}
class MockFacilityLinkageDataService {
    setLinkages(data: any) {
        return data;
    }

    // getLinkages(): any {
    // 	return '';
    // }
}
class MockCounterPartyDetailsService {
    selectedCollateralType = 'TYPE_A';
    collateral = this.getCounterpartyInfo('GC0000181706');

    cpDetailsObservable: BehaviorSubject<any>;
    temp = new Observable(observer => {
        observer.next({'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'});
    });

    subscribeToCPDetails(temp) {
        return Observable.of({label: 'Personal Leadership Centre Pte.Ltd', value: 'GCIN0000000'});
    }

    getCounterpartyInfo(gcin) {
        return Observable.of(null);
    }

    getExternalRatings(gcin) {
        return Observable.of(null);
    }

    updateReviewDates() {
        const updateInfo: any = {
            gcin: '',
            lastReviewDate: '2017-03-07T12:40:36.355Z',
            nextReviewDate: '2017-07-07T12:40:36.355Z',
            reviewFrequency: 'Weekly'
        };
        return true;
    }
}
class MockDraftRecordService {
    putDraftRecord() {
        return Observable.of(null);
    }

    postDraftRecord() {
        return Observable.of(null);
    }

    saveCollateralAsDraft() {
        return null;
    }

}

describe('Facility Linkage Component Test Cases', () => {
    let component: FacilityLinkageDataComponent;
    let fixture: ComponentFixture<FacilityLinkageDataComponent>;
    const router = {
        navigate: jasmine.createSpy('navigate')
    };
    const MockActivatedRoute = {
        queryParams: Observable.of({
            'gcinLabel': '16R2A GCIN4NF CN002 ',
            'gcinValue': 'GC0001045990',
            'functionFlag': 'EDIT'
        })
    };
    const tempEventForSelect = {'target': {'checked': true}};
    const tempEventForDeselect = {'target': {'checked': false}};
    const linkageData = {
        'activated': 24000000,
        'approved': 15050000,
        'facilityRiskRating': '4A',
        'limitId': 'LIM14103',
        'limitName': 'EXPORT BILLS UNDER LC - BANK (EBLC)',
        'limitTypeId': 'GC0000190330',
        'remarks': 'US$6.5mil to be re-aligned back to MM lending-DBS HK LTD on 4th Jan 2013',
        'riskTaker': '102000',
        'riskType': 'LLE',
        'tenor': 1,
        'totalExposure': 0
    };
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
                BrowserAnimationsModule, CounterpartyDetailsModule,
                GridModule, ClsSharedCommonModule, CommonUIModule, CustomPanelModule],
            declarations: [FacilityLinkageDataComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [
                {provide: CounterPartyDetailsService, useClass: MockCounterPartyDetailsService},
                {provide: ElementRef, useValue: new MockElementRef()},
                {provide: Router, useValue: router},
                {provide: ActivatedRoute, useValue: MockActivatedRoute},
                {provide: CollateralService, useClass: MockCollateralService},
                {provide: FacilityLinkageDataService, useClass: MockFacilityLinkageDataService},
                {provide: CollateralSummaryService, useClass: MockCollateralSummaryService},
                {provide: DraftRecordService, useClass: MockDraftRecordService}
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(FacilityLinkageDataComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create',
        async(() => {
            fixture.detectChanges();
            expect(component).toBeTruthy();
        }));
    it('should navigate to collateral List page on click of back button',
        async(() => {
            fixture.detectChanges();
            component.source = 'CollateralList';
            component.navigateBack();
            expect(router.navigate).toHaveBeenCalledWith(['./collateralList'], Object({
                queryParams: Object({
                    gcin: undefined,
                    label: undefined
                })
            }));
        }));
    it('should navigate to Collateral page on click of back button',
        async(() => {
            fixture.detectChanges();
            component.source = 'Collateral';
            component.navigateBack();
            expect(router.navigate).toHaveBeenCalledWith(['./collateral'], Object({
                queryParams: Object({
                    cid: 'COLL903',
                    ctype: undefined,
                    gcin: undefined,
                    label: undefined
                })
            }));
        }));
    it('should set limit data in service and navigate to collateral page',
        async(() => {
            component.selectedData = [];
            fixture.detectChanges();
            component.source = 'CollateralList';
            component.selectedData.push(linkageData);
            component.linkCollateral();
            expect(router.navigate).toHaveBeenCalledWith(['./collateral'], Object({
                queryParams: Object({
                    cid: 'COLL903',
                    ctype: undefined,
                    gcin: undefined,
                    label: undefined
                })
            }));
        }));

    it('should submit limit data and navigate to Collateral List page',
        async(() => {
            component.selectedData = [];
            fixture.detectChanges();
            component.selectedData.push(linkageData);
            component.linkCollateral();
            expect(router.navigate).toHaveBeenCalledWith(['./collateralList'], Object({
                queryParams: Object({
                    gcin: undefined,
                    label: undefined
                })
            }));
        }));
    it('should select of all the check box and the data of all limit underthat risk type should add to service',
        async(() => {
            fixture.detectChanges();
            component.selectedData = [];
            component.toggleCheckBox(0, tempEventForSelect);
            expect(component.selectedData.length).toBeGreaterThan(1);
        }));
    it('should deselect of all the check box and the data of all limit underthat risk type should add to service',
        async(() => {
            fixture.detectChanges();
            component.selectedData = [];
            component.toggleCheckBox(0, tempEventForSelect);
            component.toggleCheckBox(0, tempEventForDeselect);
            expect(component.selectedData.length).toEqual(0);
        }));
    it('should toggle select the check box and the data of particular limit should add to service',
        async(() => {
            fixture.detectChanges();
            const tempEvent = {'target': {'checked': true}};
            component.selectedData = [];
            component.getData(0, linkageData, tempEvent, 0);
            expect(component.selectedData.length).toBeGreaterThan(0);
        }));
    it('should toggle deselect the check box and the data of particular limit should add to service',
        async(() => {
            fixture.detectChanges();
            component.selectedData = [];
            component.getData(0, linkageData, tempEventForSelect, 0);
            component.getData(0, linkageData, tempEventForDeselect, 0);
            expect(component.selectedData.length).toEqual(0);
        }));
    it('should close popup dialog on click of close icon', () => {
        component.closeEventFromPopupDialog(false);
        expect(component.showPopupDialog).toBe(false);
    });
    it('should check canDeactive guard', () => {
        component.popUpShow = false;
        expect(component.canDeactivate()).toBe(false);
        component.popUpShow = true;
        component.backBtnPress = true;
        expect(component.canDeactivate()).toBe(true);
        component.backBtnPress = true;
        component.popUpShow = false;
        expect(component.canDeactivate()).toBe(false);
    });
    it('should save data in draft service and navigate to collateral page', () => {
        component.navigateToColl('save');
        expect(component.popUpShow).toBe(true);
        let mockCollateralSummary: CollateralSummaryService;
        mockCollateralSummary = TestBed.get(CollateralSummaryService);
        mockCollateralSummary.breadcrumbvalue = true;
        component.navigateToColl('save');
        expect(component.popUpShow).toBe(true);
    });
});
