package com.dbs.cap.cls.utility;

import org.apache.commons.lang3.StringUtils;

public final class ClsUtils {
    public static final String extractToken(String token) {
        if (StringUtils.isNotEmpty(token) && token.length() > 0) {
            return token.substring(7);
        }
        return token;
    }
}
