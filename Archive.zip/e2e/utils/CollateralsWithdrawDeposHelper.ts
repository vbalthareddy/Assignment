import {E2eSpecHelper} from './E2eSpecHelper';
import {browser} from 'protractor';

const collateralSpecSuite = require('./CollateralSpecHelper');
const viewCollateralsSpecSuite = require('./ViewCollateralsSpecHelper');
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

exports.WithdrawCollateralDeposTestSuite = function () {
    describe('should withdraw collateral of deposit type', () => {
        browser.ignoreSynchronization = true;

        /*E2E for setting up add collateral Page*/
        const processCollateralPageForViewCollaterals = () => {
            collateralSpecSuite.CollateralTestSuiteForViewCollaterals();
        };

        /*E2E for verifying view collaterals Page*/
        const processViewCollateralsPage = () => {
            viewCollateralsSpecSuite.ViewCollateralsTestSuite();
        };

        describe('should verify details on add/update collaterals page', () => {
            processCollateralPageForViewCollaterals();
        });

        describe('should verify details on view collaterals page', () => {
            processViewCollateralsPage();
        });

        describe('Withdraw collateral of deposit type', () => {
            it('should click on Delete button from deposit grid and withdraw selected collateral', () => {
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.buttonClick('#DEPOS-DeleteIcon-0');
            });

            it('should verify the confirmation box and click on confirm button', () => {
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyTextContains('.k-window-title.k-dialog-title', 'Confirm Collateral Withdrawal');
                e2eSpecHelper.buttonClick('#confirmation_btn');
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Deposit Collateral has been successfully withdrawn.');
                e2eSpecHelper.sleepBrowser(2000);
            });
        });

    });
};
