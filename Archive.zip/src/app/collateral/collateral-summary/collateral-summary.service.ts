import {Injectable} from '@angular/core';
import {Http, Response, URLSearchParams} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import {Observable} from 'rxjs/Observable';
import {AppSettings} from './../../common/config/appsettings';
import {_} from 'underscore';


@Injectable()
export class CollateralSummaryService {
    public ratesUrl = AppSettings.apiBaseUrl + AppSettings.apiToGetRates;
    public currencyUrl = AppSettings.apiBaseUrl + AppSettings.apiToGetCurrencyList;
    /*TODO Change the service name*/
    guarnCollateralDataFromService: any;
    deposCollateralDataFromService: any;
    selectedCollateral: any;
    selectedCollateralType: any;
    collateralTypes: any;
    collateralOperation: string = '';
    public rateConversionArray: any = [];
    public collateralConfigListFromService: any;
    public masterCollateralListFromService: any;
    public breadcrumbvalue: boolean = false;
    public breadCrumbDashboardValue: boolean = false;
    breadCrumbClickFlag: boolean = false;


    public messageToken: any;

    constructor(private http: Http) {
        this.rateConversionArray = [];
        this.resetMessageToken();
    }

    public getCurrency(): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const filter = {'fields': ['code', 'description'], 'order': 'code'};
        params.set('filter', JSON.stringify(filter));
        return this.http.get(this.currencyUrl, {search: params})
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    public getConfig(): Observable<any> {
        const config = '../assets/collaterals-config';
        return this.http.get(config)
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    getRateValues(fromCurreny?: any, toCurrency?: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const filter = {where: {toCurrency: toCurrency}};
        params.set('filter', JSON.stringify(filter));
        return this.http.get(this.ratesUrl, {search: params})
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    getCollateralsList(collateralType: string, collateralApi?: string, filter?: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        if (filter) {
            params.set('filter', JSON.stringify(filter));
        }
        return this.http.get(AppSettings.apiBaseUrl + collateralApi, {search: params})
            .map(onSuccessSuccess.bind(this))
            .catch(error => error.message || error);
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    getCollateralInqRes(beneficiaryId?: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        if (beneficiaryId) {
            params.set('beneficiaryId', beneficiaryId);
        }
        return this.http.get(AppSettings.apiBaseUrl + AppSettings.apiToCollateralInq, {search: params})
            .map(onSuccessSuccess.bind(this))
            .catch(error => error.message || error);
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    private extractData(res: Response) {
        const body = res.json();
        return body;
    }

    public resetMessageToken() {
        this.messageToken = null;
    }

    public setMessageToken(raisedBy: string, raisedFor: string, actionCode: string, message: string, timestamp?: string) {
        this.messageToken = {
            'raisedBy': raisedBy,
            'raisedFor': raisedFor,
            'actionCode': actionCode,
            'message': message,
            'timestamp': timestamp
        };
    }

    public getMessageToken(): any {
        if (this.messageToken) {
            return this.messageToken;
        } else {
            return null;
        }
    }


}
