import { PopupDialogOnleaveModule } from '../common/popupdialog-onleave/popupdialog-onleave.module';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {ComboBoxModule, DropDownsModule} from '@progress/kendo-angular-dropdowns';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {InputsModule} from '@progress/kendo-angular-inputs';
import {DialogModule} from '@progress/kendo-angular-dialog';
import {GridModule} from '@progress/kendo-angular-grid';
import {ClsSharedCommonModule} from '../shared/';
import {CounterpartyDetailsModule} from '../shared/counterparty-details/counterparty-details.module';
import {SpecificDetailsModule} from './specific-details/deposit/specific-details.module';
import {PopupDialogModule} from '../common/popup-dialog/popup-dialog.module';
import {CommonUIModule} from '../common/commonUI.module';
import {BeneficiaryModule} from './beneficiary/beneficiary.module';
import {CustomPanelModule} from '../common/custom-panel/custom-panel.module';
import {TabbedWizardModule} from '../common/tabbed-wizard/tabbed-wizard.module';
import {CollateralService} from './collateral.service';
import {AutoSaveService} from '../common/autosave/auto-save.service';
import {ChargeModule} from './charge/charge.module';
import {SummaryModule} from './summary/summary.module';
import {OwnershipModule} from './ownership/ownership.module';
import {DocumentModule} from './document/document.module';
import {NewCollateralModule} from './new-collateral/new-collateral.module';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {FacilityLinkageDataService} from './facility-linkage-data/facility-linkage-data.service';
import {CollateralGuarantorModule} from './collateral-guarantor/collateral-guarantor.module';
import {CollateralSummaryService} from './collateral-summary/collateral-summary.service';
import {InspectionModule} from './inspection/inspection.module';
import {SpecificDetailsAircraftModule} from './specific-details/aircraft/specific-details-aircraft.module';
import {SpecificDetailsVehicleModule} from './specific-details/vehicle/specific-details-vehicle.module';
@NgModule({
    imports: [
        CommonModule, ButtonsModule, DialogModule, GridModule, FormsModule, BrowserModule,
        DropDownsModule, ReactiveFormsModule, InputsModule, ComboBoxModule,
        ClsSharedCommonModule, CounterpartyDetailsModule, CommonUIModule, PopupDialogModule, SpecificDetailsModule,
        BeneficiaryModule, CustomPanelModule, TabbedWizardModule, ChargeModule, SummaryModule,
        OwnershipModule, DocumentModule, NewCollateralModule, DateInputsModule, CollateralGuarantorModule, InspectionModule, SpecificDetailsAircraftModule, SpecificDetailsVehicleModule,PopupDialogOnleaveModule

    ],
    declarations: [],
    entryComponents: [],
    providers: [CollateralService, AutoSaveService, CounterPartyDetailsService, FacilityLinkageDataService, CollateralSummaryService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CollateralModule {
}
