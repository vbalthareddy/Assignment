import {Http, Response, URLSearchParams} from '@angular/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {AppSettings} from './../../common/config/appsettings';

@Injectable()
export class ChargeService {

    public urlToGetNatureOfCharges = AppSettings.apiBaseUrl + AppSettings.apiToGetNatureOfCharges;
    public urlToGetChargeRank = AppSettings.apiBaseUrl + AppSettings.apiToGetChargeRank;

    constructor(private http: Http) {

    }

    public getNatureOfCharges(filter?: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        if (!filter) {
            filter = {'fields': ['code', 'description'], 'order': 'description'};
        }
        params.set('filter', JSON.stringify(filter));
        return this.http.get(this.urlToGetNatureOfCharges, {search: params})
            .map(
                res => res.json()
            ).catch(error => error.message || error);
    }

    public getChargeRank(): Observable<any> {
        return this.http.get(this.urlToGetChargeRank)
            .map(
                res => res.json()
            ).catch(error => error.message || error);
    }

    public getRegistrationAuthorityDetails(): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        params.set('access_token', null);
        const filter = {'order': 'code'};
        params.set('filter', JSON.stringify(filter));
        const urlToGetRegAuthorityDetails = AppSettings.apiBaseUrl + AppSettings.apiToGetRegAuthority;
        return this.http.get(urlToGetRegAuthorityDetails, {search: params})
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    private extractData(res: Response) {
        const body = res.json();
        return body;
    }
}
