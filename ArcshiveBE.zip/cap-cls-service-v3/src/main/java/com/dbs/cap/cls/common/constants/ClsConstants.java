package com.dbs.cap.cls.common.constants;

public class ClsConstants {
    public static final String ID = "id";
    public static final String FILTER = "filter";
    public static final String X_JWT_ASSERTION = "x-jwt-assertion";
    public static final String CLIENT_ID = "client1";
    public static final String AUTHORIZATION = "Authorization";
    public static final String X_REQUEST_ID = "x-request-id";
    public static final String USER_NAME = "username";
    public static final String EMAIL = "email";
    public static final String ROLES = "roles";
    public static final String CHANNEL_ID = "channel_id";
    public static final String TIMESTAMP = "timestamp";
    public static final String CLS_USER = "cls-user";
    public static final String CLS_USER_EMAIL = "cls-user@dbs.com";
    public static final String ADMIN = "[\"admin\"]";
    public static final String CLS_SERVICE = "cls-service";
    public static final String TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.SSSz";
    public static final String BEARER = "Bearer ";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String PATH_PARAM = "{PATH_PARAM}";
    public static final String EQUAL_DELIMITER = "=";
}
