// Required Parameters
// BUILD_NUMBER
// DEPLOY_TO
final APP_NAME = "cap-cls-service-v3"
final MANIFEST_URL = "https://gitlab.dev.apps.cs.sgp.dbs.com/cap/cap-cls-service-v3/raw/develop/cloudfoundry/${DEPLOY_TO}.yml"
final CLOUDFOUNDRY_API_URL = 'api.dev.sys.cs.sgp.dbs.com'
final CF_CREDENTIAL = 'ecb8efc3-6d07-4e55-bbe1-0a3b08636957'
node {
    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'
    jenkins.downloadArtifactory(APP_NAME, BUILD_NUMBER, "${APP_NAME}.jar")
    jenkins.downloadManifest(MANIFEST_URL)
    jenkins.loginWithCred(CLOUDFOUNDRY_API_URL, CF_CREDENTIAL)
    jenkins.target("-o dev-credit-risk -s cap-cls-service-v3-${DEPLOY_TO}")
    jenkins.deploy(APP_NAME, "-p ${APP_NAME}.jar")
}