import {CommonModule} from '@angular/common';
import {CUSTOM_ELEMENTS_SCHEMA, ModuleWithProviders, NgModule} from '@angular/core';
import {CommonUIModule} from '../../common/commonUI.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {GridModule} from '@progress/kendo-angular-grid';
import {CounterpartyDetailsModule} from '../../shared/counterparty-details/counterparty-details.module';
import {CustomPanelModule} from '../../common/custom-panel/custom-panel.module';
import {CreateCollateralComponent} from 'app/collateral/create-collateral/create-collateral.component';
import {ComboBoxModule, DropDownsModule} from '@progress/kendo-angular-dropdowns';

@NgModule({
    imports: [CommonModule, BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
        BrowserAnimationsModule, CounterpartyDetailsModule,
        GridModule, ClsSharedCommonModule, CommonUIModule, CustomPanelModule, DropDownsModule, ComboBoxModule],
    declarations: [CreateCollateralComponent],
    exports: [CreateCollateralComponent],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]

})

export class CreateCollateralModule {
    public static forRoot(): ModuleWithProviders {
        return {ngModule: CreateCollateralModule, providers: []};
    }
}