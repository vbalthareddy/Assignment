import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {PopupDialogOnleaveModule} from '../../common/popupdialog-onleave/popupdialog-onleave.module';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {FormBuilder, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ComboBoxModule, DropDownsModule} from '@progress/kendo-angular-dropdowns';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {InputsModule} from '@progress/kendo-angular-inputs';
import {DialogModule} from '@progress/kendo-angular-dialog';
import {GridModule} from '@progress/kendo-angular-grid';
import {CustomPanelModule} from '../../common/custom-panel/custom-panel.module';
import {CommonUIModule} from '../../common/commonUI.module';
import {CollateralSummaryComponent} from './collateral-summary.component';
import {CollateralSummaryService} from './collateral-summary.service';
import {RouterTestingModule} from '@angular/router/testing';
import {Observable} from 'rxjs/Rx';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {MockCollateralData, MockCollateralsMasterInqData} from './collateral-summary-mock-data';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {CounterpartyDetailsModule} from '../../shared/counterparty-details/counterparty-details.module';
import {CreateCollateralComponent} from 'app/collateral/create-collateral/create-collateral.component';
import {CollateralService} from 'app/collateral/collateral.service';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {
    collateralCodesData,
    collateralCodesDataFilter,
    collateralData
} from 'app/collateral/new-collateral/new-collateral.data';
import {COLLATERAL_CODES_TYPES_DATA} from '../collaterals-list/collaterals-list.data';
import {Collateral} from 'app/collateral/model/collateral';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
class MockCollateralSummaryService {
    rateConversionArray: any = [
        {
            fromCurrency: 'SGD',
            toCurrency: 'INR',
            rate: 10
        }
    ];
    collateralOperation = 'Add';
    masterCollateralListFromService = {};
    collateralConfigListFromService = {};

    getCurrency() {
        const data = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        return Observable.of(data);
    }

    getCollateralSummaryData() {
        return Observable.of(MockCollateralData);
    }

    getRateValues(from: string, to: string) {
        if (to === '') {
            return Observable.throw({status: 404});

        } else {
            const data = [{
                fromCurrency: 'SGD',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            }];
            return Observable.of(data);
        }
    }

    getCollateralDataFromMasters(gcin: string) {
        return Observable.of(null);
    }

    getCollateralInqRes(id?: any) {
        return Observable.of(MockCollateralsMasterInqData);
    }

    getCollateralsList(collateralType: string, collateralApi?: string, filter?: any) {
        const objTemp = [
            {
                'CollateralValuationDetail': {
                    'finalCollateralValue': {
                        'value': 10.00,
                        'ccy': 'SGD'
                    }
                }
            }];
        if (collateralType === '' && filter === '' && collateralApi === '') {
            return Observable.throw({status: 404});
        } else {
            return Observable.of(objTemp);
        }
    }

    getConfig() {
        const tempObj = {
            'GUARN': {
                'sequencePos': 1,
                'label': 'Guarantee',
                'description': 'Guarantee Description',
                'apiToHit': ''
            },
            'DEPOS': {
                'sequencePos': 2,
                'label': 'Guarantee',
                'description': 'Guarantee Description',
                'apiToHit': ''
            }
        };
        return Observable.of(tempObj);
    }
}
class MockCollateralService {
    _fb: FormBuilder = new FormBuilder();
    collateral: Collateral = new Collateral();
    tabSections: Array<String> = [];
    disableTab = false;

    getCollateralTypes() {
        return Observable.of(COLLATERAL_CODES_TYPES_DATA);
    }

    getCollateralCodes(filter: any) {
        if (filter === undefined) {
            return Observable.of(collateralCodesData);
        } else {
            return Observable.of(collateralCodesDataFilter);
        }
    }

    getDetailsForm() {
        return this._fb.group({
            collateralid: ['']
        });
    }

    getParticularsForm() {
        return this._fb.group({
            particularsList: ['']
        });
    }

    getBeneficiaryForm() {
        return this._fb.group({
            beneficiaryList: [this.collateral.beneficiaryDetails]
        });
    }

    getCollateral() {
        return this.collateral;
    }

    getDocumentForm(document?: Document) {
        return this._fb.group({
            documentidList: []
        });
    }

    getChargeForm() {
        return this._fb.group({
            chargeList: ['']
        });
    }

    getApportionForm() {
        return this._fb.group({});
    }

    getOwnershipForm() {
        return this._fb.group({
            ownershipid: []
        });
    }

    postCollateral(collateral) {
        return Observable.of(collateralData);
    }

    getCollateralForm() {
        return this._fb.group({
            details: this.getDetailsForm(),
            beneficiary: this.getBeneficiaryForm(),
            charge: this.getChargeForm(),
            valuation: this.getApportionForm(),
            document: this.getDocumentForm(),
            ownership: this.getOwnershipForm(),
            particulars: this.getParticularsForm()
        });
    }
}

class MockPartyDetailsService {
    temp = new Observable(observer => {
        observer.next({'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'});
    });

    subscribeToCPDetails(temp) {

        return Observable.of([{'collateralId': 'COLL12406', 'collateralCode': 'code16', 'collateralType': 'VEHIC'},
            {
                'collateralId': 'COLL12436',
                'collateralCode': 'code16',
                'collateralType': 'VEHIC'
            }, {
                'collateralId': 'COLL12454',
                'collateralCode': 'GAUCODE',
                'collateralType': 'GUARN'
            }, {
                'collateralId': 'COLL12455',
                'collateralCode': 'air04',
                'collateralType': 'AIRCF'
            }, {
                'collateralId': 'COLL12456',
                'collateralCode': 'air04',
                'collateralType': 'AIRCF'
            }, {'collateralId': 'COLL12460', 'collateralCode': 'code02', 'collateralType': 'DEPOS'}]);

    }

}
class MockActivatedRoute {
    queryParams = {
        subscribe: jasmine.createSpy('subscribe')
            .and
            .returnValue(Observable.of({
                gcin: undefined,
                label: undefined,
                gcinCpValue: undefined,
                gcinDesc: undefined
            }))
    };
}

describe('CollateralSummaryComponent', () => {
    let component: CollateralSummaryComponent;
    let fixture: ComponentFixture<CollateralSummaryComponent>;
    const router = {
        navigate: jasmine.createSpy('navigate')
    };
    const mockArray = [
        {totalAmount: 40000},
        {totalAmount: 100000},
        {totalAmount: 120000},
        {totalAmount: 890000}
    ];
    beforeEach(async(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
        TestBed.configureTestingModule({
            imports: [CommonModule,
                ButtonsModule, DialogModule, GridModule, FormsModule, BrowserModule,
                DropDownsModule, ReactiveFormsModule, InputsModule, ComboBoxModule, BrowserAnimationsModule,
                CustomPanelModule, CommonUIModule, RouterTestingModule, CounterpartyDetailsModule, ClsSharedCommonModule, LoaderModule, PopupDialogOnleaveModule],
            declarations: [CollateralSummaryComponent, CreateCollateralComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
        });
        TestBed.overrideComponent(CollateralSummaryComponent, {
            set: {
                providers: [
                    {provide: CollateralSummaryService, useClass: MockCollateralSummaryService},
                    {provide: Router, useValue: router},
                    {provide: CounterPartyDetailsService, useClass: MockPartyDetailsService},
                    {provide: CollateralService, useClass: MockCollateralService},
                    {provide: ActivatedRoute, useClass: MockActivatedRoute}, FormBuilder
                ]
            }
        })
            .compileComponents();
        fixture = TestBed.createComponent(CollateralSummaryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    }));
    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('should currencyChangeFormatter work', () => {
        const resultArray = component.currencyChangeFormatter(mockArray, 1.0e+6);
        const expectedArray = [Object({totalAmount: 0.04}), Object({totalAmount: 0.1}), Object({totalAmount: 0.12}), Object({totalAmount: 0.89})];
        expect(resultArray).toEqual(expectedArray);
    });
    it('Should redirect url onclick of Add /Update Collateral', () => {
        component.redirectToNewCollateral();
        expect(component.createCollateral).toBe(true);
    });
    it('Should redirect url onclick of view Collateral', () => {
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {'gcin': undefined, 'label': undefined}
        };
        component.redirectToViewCollaterals();
        expect(router.navigate).toHaveBeenCalledWith(['/collateralList'], navigationExtras);
    });
    it('get currency list dropdown from API', () => {
        component.getCurrencyList();
        expect(component.currencyFormatValues).toEqual([Object({code: 'INR'}), Object({code: 'SGD'}), Object({code: 'USD'})]);
    });
    it('get collateral details from service and sum the values', () => {
        component.tableHeaderList = [{
            type: 'GUARN',
            description: 'Guarantor Description',
            label: 'Guarantor Description',
            apiToHit: '',
            totalAmount: 0.00
        }];
        component.mainAmountValues = JSON.parse(JSON.stringify(component.tableHeaderList));
        component.convertedRateValues = [{
            fromCurrency: 'SGD',
            toCurrency: 'INR',
            rate: 10
        }, {
            fromCurrency: 'SGD',
            toCurrency: 'SGD',
            rate: 1
        }];
        component.fetchCollateralDetails(MockCollateralsMasterInqData);
        const temp = {
            type: 'DEPOS',
            totalAmount: 10
        };
        expect((component.tableHeaderList[0]['totalAmount'])).toEqual(temp.totalAmount);
        component.presentCurrencyFormat = 'INR';
        component.fetchCollateralDetails(MockCollateralsMasterInqData);
        const temp1 = {
            totalAmount: 110
        };
        expect((component.tableHeaderList[0]['totalAmount'])).toEqual(temp1['totalAmount']);
    });
    it('should setup collateral summary page summay values', () => {
        component.tableHeaderList = [{
            type: 'GUARN',
            description: 'Guarantor Description',
            label: 'Guarantor Description',
            apiToHit: '',
            totalAmount: 0.00
        }];
        component.mainAmountValues = JSON.parse(JSON.stringify(component.tableHeaderList));
        component.convertedRateValues = [{
            fromCurrency: 'SGD',
            toCurrency: 'INR',
            rate: 10
        }, {
            fromCurrency: 'SGD',
            toCurrency: 'SGD',
            rate: 1
        }];
        component.setUpCollateralSumamryComponent();
        expect((component.tableHeaderList[0].totalAmount)).toBe(0);
    });
    it('should amount values convert based on format change', () => {
        component.getConfiguarationFile();
        component.selectionCurrencyChange('INR');
        expect((component.tableHeaderList[0].totalAmount)).toBe(100);
    });
    it('should amount values convert based on unit format change', () => {
        component.tableHeaderList = [{
            type: 'GUARN',
            description: 'Guarantor Description',
            label: 'Guarantor Description',
            apiToHit: '',
            totalAmount: 100
        }];
        component.mainAmountValues = JSON.parse(JSON.stringify(component.tableHeaderList));
        component.selectionChangeFormat('Thousand');
        expect((component.tableHeaderList[0].totalAmount)).toBe(0.1);
        component.selectionChangeFormat('Unit');
        expect((component.tableHeaderList[0].totalAmount)).toBe(100);
        component.selectionChangeFormat('Million');
        expect((component.tableHeaderList[0].totalAmount)).toBe(0.0001);
        const objTemp = [
            {
                'CollateralValuationDetail': {
                    'finalCollateralValue': {
                        'value': 10.00,
                        'ccy': 'SGD'
                    }
                }
            }];
    });
    it('should currencyChangeFormatter', () => {
        const temp = [{
            totalAmount: 100
        }];
        const currencyDivider = 1;
        expect(component.currencyChangeFormatter(temp, currencyDivider)).toEqual(temp);
    });
    it('should get data from config file', () => {
        const tmpObj = [
            {type: 'GUARN', description: 'Guarantee Description', label: 'Guarantee', apiToHit: '', totalAmount: 10},
            {type: 'DEPOS', description: 'Guarantee Description', label: 'Guarantee', apiToHit: '', totalAmount: 10}

        ];
        component.getConfiguarationFile();
        expect(component.tableHeaderList[0]['type']).toBe(tmpObj[0]['type']);
    });
    it('should error message display for rates error from service', () => {
        const errorObj = {
            _body: 'ErrorMsg'
        };
        component.errorMsgShow(errorObj);
        expect(component.errorMsgText).toEqual('Service not available');
        expect(component.ratesErrorMsgsList.length).toBeGreaterThan(0);
    });
    it('should return true if data available from service ', () => {
        const tmpObj = [
            {
                type: 'GUARN',
                description: 'Guarantee Description',
                label: 'Guarantee',
                apiToHit: '',
                totalAmount: 10,
                dataPresent: true
            },
            {
                type: 'DEPOS',
                description: 'Guarantee Description',
                label: 'Guarantee',
                apiToHit: '',
                totalAmount: 10,
                dataPresent: true
            }

        ];
        component.tableHeaderList = tmpObj;
        const result = component.checkData('GUARN');
        expect(result).toBe(true);
    });
    it('check on cancel for create collateral popup dialog box close ', () => {
        component.onCancel(false);
        expect(component.createCollateral).toBe(false);
    });
    it('should error message display if rates are not available form service ', () => {
        component.presentCurrencyFormat = 'SGD';
        component.ratesErrorMsgsList = [];
        component.errorMsgShow('');
        expect(component.showHeadErrorPanel).toBe(true);
    });
    it('should handle error message ', () => {
        const error = {
            status: 500
        };
        expect(component.returnError(error)).toEqual(Observable.throw(new Error('500')));
    });
    it('should getRateValuesForAllCcyTypes for change ', () => {
        component.selectedCurrencyListItem = ['SGD', 'INR', 'RUB'];
        component.presentCurrencyFormat = 'SGD';
        const objTemp = [
            {
                'CollateralValuationDetail': {
                    'finalCollateralValue': {
                        'value': 10.00,
                        'ccy': 'SGD'
                    }
                }
            }];
        component.finalCollateralData = [];
        component.finalCollateralData.push({'type': 'GUARN', data: objTemp});
        component.getRateValuesForAllCcyTypes('change');
        expect(component.showHeadErrorPanel).toBe(true);
    });

    it('should close popup dialog on click of close icon', () => {
        component.closeEventFromPopupDialog(false);
        expect(component.showPopupDialog).toBe(false);
    })
});
