package com.dbs.cap.ct.batch.mapper;

import com.dbs.cap.ct.batch.model.Corporate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

@Slf4j
public class CorporateRowMapper implements RowMapper<Corporate> {
    @Override
    public Corporate mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        Corporate corp = new Corporate();
        corp.setCorpKey(resultSet.getString("CORP_KEY"));
        corp.setName(resultSet.getString("CORP_NAME"));
        corp.setBankBorrowerFlag(resultSet.getString("BANK_BORROWER_FLAG"));
        corp.setCountryOfIncorporation(resultSet.getString("COUNTRY_OF_INCORPORATION"));
        log.debug("RowMapper record : {}", corp);
        return corp;
    }
}
