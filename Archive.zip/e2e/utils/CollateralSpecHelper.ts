import {$, browser, by, element, protractor} from 'protractor';
import {E2eSpecHelper} from './E2eSpecHelper';

const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const collateral: any = {
    addUpdateCollateral: $('#add-update-collateral'),
    collateralTypeDropDown: $('#coll-type-dropdown'),
    collateralTypeSearch: (searchTerm: string): any => e2eSpecHelper.dropDownSearchKeys(searchTerm, '#coll-type-dropdown .k-searchbar > .k-input'),
    collateralCodeDropDown: $('#coll-code-dropdown'),
    collateralCodeDropDownArrow: $('#coll-code-dropdown .k-select'),
    collateralCodeDropDownValueSelect: $('.k-animation-container .k-list .k-item:nth-child(1)'),
    collateralCodeDropDownValueSelectForAircraft: $('.k-animation-container .k-list .k-item:nth-child(2)'),
    collateralCodeSearch: (searchTerm: string): any => e2eSpecHelper.dropDownSearchKeys(searchTerm, '#coll-code-dropdown .k-searchbar > .k-input'),
    proceedAddUpdate: $('.proceed'),
    isSelectedTab: $('.tab-buttons .tab-element-underline'),
    collateralSummary: {
        collateralCurrencyFormatter: $('.currencyFormatter .k-select'),
        collateralCurrencyFormatterValueSelect: $('.k-animation-container .k-list .k-item:nth-child(3)'),
        collateralamountFormatter: $('.amountFormatter .k-select'),
        collateralamountFormatterValueSelect: $('.k-animation-container .k-list .k-item:first-child'),
        collateralSummaryLableId: $('#collateralSummaryPanel'),
        summaryTooltip1: $('th:nth-child(1) .imageName'),
        summaryTooltip2: $('th:nth-child(2) .imageName'),
        summaryTooltip3: $('th:nth-child(3) .imageName'),
        collateralCurrencyFormatValue: $('.currencyFormatter .k-input')
    },
    viewCollateral: $('#view-collaterals'),
    counterPartySearch: $('.serach-text'),
    counterPartySearchInputValue: (counterPartySearchVal: string): any => $('input.serach-text').sendKeys(counterPartySearchVal)
};

exports.CollateralTestSuite = function (collateralType: string) {

    describe('Add/Update_Collateral_Page', function () {
        it('should search for counter-party and land on collateral page', function () {
            e2eSpecHelper.sleepBrowser(2000);
            collateral.counterPartySearch.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateral.counterPartySearchInputValue('AIR');
            e2eSpecHelper.sleepBrowser(4000);
            element(by.xpath('//*[@id="cp-id"]/li[1]')).click();
        });

        it('should verify collateral summary section', function () {
            e2eSpecHelper.sleepBrowser(10000);
            e2eSpecHelper.verifyTextContains('#collateralSummaryPanel', 'Collaterals');
            e2eSpecHelper.verifyPresence('.imageName');
            collateral.collateralSummary.summaryTooltip1.click();
            e2eSpecHelper.sleepBrowser(1000);
            collateral.collateralSummary.summaryTooltip2.click();
            e2eSpecHelper.sleepBrowser(1000);
            collateral.collateralSummary.summaryTooltip3.click();
            e2eSpecHelper.sleepBrowser(1000);
            collateral.collateralSummary.collateralCurrencyFormatter.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateral.collateralSummary.collateralCurrencyFormatterValueSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            collateral.collateralSummary.collateralamountFormatter.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateral.collateralSummary.collateralamountFormatterValueSelect.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.imageName');
        });

        it('should verify Add/Update collateral page', function () {
            e2eSpecHelper.verifyTextContains('#add-update-collateral', 'Add New Collaterals');
            collateral.addUpdateCollateral.click();
        });

        switch (collateralType) {
            case 'GUARANTEE':
                it('should click on proceed button when collateral type and collateral code for guarantee is selected', function () {
                    e2eSpecHelper.verifyTextContains('.k-window-title.k-dialog-title', 'Add New Collateral');
                    e2eSpecHelper.sleepBrowser(3000);
                    collateral.collateralTypeDropDown.click();
                    element(by.css('[placeholder="Search Collateral Type"]')).sendKeys('Guar');
                    e2eSpecHelper.sleepBrowser(3000);
                    browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
                    browser.actions().sendKeys(protractor.Key.ENTER).perform();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.collateralCodeDropDownArrow.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    collateral.collateralCodeDropDownValueSelect.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.proceedAddUpdate.click();
                });
                break;

            case 'DEPOSIT':
                it('should click on proceed button when collateral type and collateral code for Deposit is selected', function () {
                    e2eSpecHelper.verifyTextContains('.k-window-title.k-dialog-title', 'Add New Collateral');
                    e2eSpecHelper.sleepBrowser(3000);
                    collateral.collateralTypeDropDown.click();
                    element(by.css('[placeholder="Search Collateral Type"]')).sendKeys('Depos');
                    e2eSpecHelper.sleepBrowser(3000);
                    browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
                    browser.actions().sendKeys(protractor.Key.ENTER).perform();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.collateralCodeDropDownArrow.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    collateral.collateralCodeDropDownValueSelect.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.proceedAddUpdate.click();
                });
                break;

            case 'Aircraft':
                it('should click on proceed button when collateral type and collateral code for Aircraft is selected', function () {
                    e2eSpecHelper.verifyTextContains('.k-window-title.k-dialog-title', 'Add New Collateral');
                    e2eSpecHelper.sleepBrowser(3000);
                    collateral.collateralTypeDropDown.click();
                    element(by.css('[placeholder="Search Collateral Type"]')).sendKeys('Airc');
                    e2eSpecHelper.sleepBrowser(3000);
                    browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
                    browser.actions().sendKeys(protractor.Key.ENTER).perform();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.collateralCodeDropDownArrow.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    collateral.collateralCodeDropDownValueSelect.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.proceedAddUpdate.click();
                });
                break;

            case 'Vehicle':
                it('should click on proceed button when collateral type and collateral code for Vehicle is selected', function () {
                    e2eSpecHelper.verifyTextContains('.k-window-title.k-dialog-title', 'Add New Collateral');
                    e2eSpecHelper.sleepBrowser(3000);
                    collateral.collateralTypeDropDown.click();
                    element(by.css('[placeholder="Search Collateral Type"]')).sendKeys('Vehi');
                    e2eSpecHelper.sleepBrowser(3000);
                    browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
                    browser.actions().sendKeys(protractor.Key.ENTER).perform();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.collateralCodeDropDownArrow.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    collateral.collateralCodeDropDownValueSelect.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.proceedAddUpdate.click();
                });
                break;

            case 'Vessel':
                it('should click on proceed button when collateral type and collateral code for Vessel is selected', function () {
                    e2eSpecHelper.verifyTextContains('.k-window-title.k-dialog-title', 'Add New Collateral');
                    e2eSpecHelper.sleepBrowser(3000);
                    collateral.collateralTypeDropDown.click();
                    element(by.css('[placeholder="Search Collateral Type"]')).sendKeys('Boat');
                    e2eSpecHelper.sleepBrowser(3000);
                    browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
                    browser.actions().sendKeys(protractor.Key.ENTER).perform();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.collateralCodeDropDownArrow.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    collateral.collateralCodeDropDownValueSelect.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    collateral.proceedAddUpdate.click();
                });
                break;
        }
    });

};

exports.CollateralTestSuiteForViewCollaterals = function () {
    describe('Add/Update_Collateral_Page', function () {
        it('should load collateral landing page', function () {
            browser.get('/collateral');
            browser.sleep(2000);
        });

        it('should search for counter-party and land on collateral page', function () {
            e2eSpecHelper.sleepBrowser(2000);
            collateral.counterPartySearch.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateral.counterPartySearchInputValue('WER');
            e2eSpecHelper.sleepBrowser(2000);
            element(by.xpath('//*[@id="cp-id"]/li[1]')).click();
        });

        it('should load collateral page', function () {
            const kl = e2eSpecHelper.sideNav.getCssValue('width');
            expect(e2eSpecHelper.sideNav.getCssValue('width')).toEqual('0px');
            e2eSpecHelper.hamburgerIcon.click();
            browser.sleep(2000);
            e2eSpecHelper.collateralLink.click();
        });

        it('should verify View collaterals page', function () {
            browser.sleep(3000);
            e2eSpecHelper.verifyTextContains('#view-collaterals', 'View Collaterals');
            collateral.viewCollateral.click();
        });
    });
};