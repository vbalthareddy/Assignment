import {ChangeDetectorRef, Component, EventEmitter, HostListener, Input, OnInit, Output} from '@angular/core';
import {CollateralSummaryService} from './collateral-summary.service';
import {ActivatedRoute, NavigationExtras, Params, Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {CounterPartyDetailsService} from '../../common/counterparty-details/counterparty.service';
import {_} from 'underscore';
import {ToastsComponent} from '../../shared/toasts/toasts.component';
import {CollateralService} from 'app/collateral/collateral.service';
import {PlatformLocation} from '@angular/common';
import {FormBuilder, FormGroup} from '@angular/forms';
@Component({
    selector: 'collateral-summary-component',
    templateUrl: './collateral-summary.component.html',
    styleUrls: ['./collateral-summary.component.scss']
})
export class CollateralSummaryComponent implements OnInit {
    backBtnPress: boolean;
    popUpShow: boolean = false;
    showPopupDialog: boolean;
    public listItems: any[] = ['Thousand', 'Million', 'Unit'];
    public currencyFormatValues: any = [];
    public mainAmountValues: any = [];
    public currencyDividerValue: number = 1;
    // TODO get presentCurrencyFormat value from service Based on User login
    public setPresentCurrencyFormat: any = {
        code: 'SGD'
    };
    public presentCurrencyFormat: any = 'SGD';
    public oldCurrencyFormat: string = 'SGD';
    public presentCurrencyFormatIn: string = 'Unit';
    public errorMsg: boolean = false;
    public retesErrorFlag: boolean = false;
    public ratesErrorMsgsList: any = [];
    counterparty: any;
    collateralDataFromMastersInq: any;
    public noCollateralFound: boolean = true;
    public tableHeaderList: any = [];
    public configList: any;
    public argToastMessageObject: any;
    collateralSummaryData: any = [];
    createCollateral: boolean = false;
    toastsComponent: ToastsComponent = new ToastsComponent();
    convertedRateValues: any = [];
    finalCollateralData: any = [];
    currencyFormatValue: number = 2;
    showHeadErrorPanel: boolean = false;
    showLoader: boolean = false;
    selectedCurrencyListItem: any = [];
    collateralObjData: any = [];
    gcinCpValue: string;
    gcinDesc: string;
    counterForAPICompletion: number = 0;
    initializeData: boolean = false;
    checkLengthCounter: number = 0;
    @Input() popupdialogFlag: boolean = false;
    @Output() closePopup: EventEmitter<any> = new EventEmitter<any>();
    @Output() popUpshowEvent: EventEmitter<any> = new EventEmitter<any>();
    errorMsgText: string = 'Errors found while converting Rate values (The collaterals with below currencies as collateral currency are  excluding from total Amount)';
    collateralSummaryForm: FormGroup;

    constructor(private collateralService: CollateralService,
                private collateralSummaryService: CollateralSummaryService,
                private router: Router,
                private counterPartyDetailsService: CounterPartyDetailsService,
                private route: ActivatedRoute, private cdRef: ChangeDetectorRef, location: PlatformLocation, private _fb: FormBuilder) {
        this.getCpValue();
        location.onPopState(() => {
            this.backBtnPress = true;
            location.pushState(null, null, window.location.pathname);
        });
    }

    ngOnInit() {
        this.getCpValue();
        this.initCustomForms();
        this.getRateValuesForAllCcyTypes();
        this.setUpCollateralSumamryComponent();
    }

    @HostListener('window:onbeforeunload')
    getValues() {
        console.log('window reloading here');
    }

    getCpValue() {
        this.route.queryParams.subscribe((params: Params) => {
            this.gcinCpValue = params['gcin'];
            this.gcinDesc = params['label'];
        });
    }

    initCustomForms() {
        this.collateralSummaryForm = this._fb.group({
            currencyFormat: [this.setPresentCurrencyFormat],
            amountFormat: [this.presentCurrencyFormatIn]
        });
    }

    setUpCollateralSumamryComponent() {
        this.showLoader = true;

        this.counterPartyDetailsService.subscribeToCPDetails({
            next: (value) => {
                this.counterparty = value;
                this.collateralSummaryService.getCollateralInqRes(value.value).subscribe(data => {
                        this.collateralDataFromMastersInq = data;
                        this.getConfiguarationFile();
                    },
                    error => {
                        this.showLoader = false;
                    });
            },
            error: (value) => {
                this.showLoader = false;
                this.returnError(value);
            },
            complete: () => {

            }
        });
        this.ratesErrorMsgsList['message'] = [];
        this.selectedCurrencyListItem.push(this.presentCurrencyFormat);
        this.getCurrencyList();
    }

    getCurrencyList() {
        this.collateralSummaryService.getCurrency().subscribe(data => {
            this.currencyFormatValues = data;
        }, error => {
            this.errorMsg = true;
            this.returnError(error);
        });
    }

    getConfiguarationFile() {
        this.collateralSummaryService.getConfig().subscribe(data => {
            this.configList = data;
            this.collateralSummaryService.collateralConfigListFromService = {};
            this.collateralSummaryService.collateralConfigListFromService = data;
            const configList = data;
            for (const key in configList) {
                this.tableHeaderList[(configList[key].sequencePos) - 1] = {
                    type: key,
                    description: (configList[key].description),
                    label: (configList[key].label),
                    apiToHit: (configList[key].apiToHit),
                    totalAmount: 0.00,
                    dataPresent: true,
                    include: (configList[key].include)
                };
            }
            this.mainAmountValues = JSON.parse(JSON.stringify(this.tableHeaderList));
            this.fetchCollateralDetails(this.collateralDataFromMastersInq);
        }, error => {
            this.errorMsg = true;
            this.showLoader = false;
            this.returnError(error);
        });
    }

    fetchCollateralDetails(collateralsMasterData) {
        this.collateralObjData = [];
        this.finalCollateralData = [];
        this.counterForAPICompletion = 0;
        this.checkLengthCounter = 0;
        let errorCount = 0;
        this.showLoader = true;
        collateralsMasterData = _.groupBy(collateralsMasterData, function (obj) {
            return obj.collateralType;
        });
        const collateralIds = _.map(collateralsMasterData['GUARN'], function (element, index, list) {
            return element.collateralId;
        });
        this.collateralSummaryService.masterCollateralListFromService = {};
        this.tableHeaderList.forEach((element, idx, array) => {
            const collateralIds_ = _.map(collateralsMasterData[element.type], function (value, index, list) {
                return value.collateralId;
            });
            const filter = {
                where: {'withdrawalDetail.withdraw': false, collateralId: {inq: collateralIds_}},
                order: '_createdOn desc',
                include: element.include
            };
            this.collateralSummaryService.getCollateralsList(element.type, element.apiToHit, filter).subscribe(data => {
                this.collateralObjData.push({'type': element.type, data: data});
                this.counterForAPICompletion++;
                this.collateralSummaryService.masterCollateralListFromService[element.type] = [];
                this.collateralSummaryService.masterCollateralListFromService[element.type] = data;
                this.noCollateralFound = false;
            }, error => {
                this.errorMsg = true;
                errorCount++;
                if (errorCount === this.tableHeaderList.length) {
                    this.showLoader = false;
                }
                this.collateralSummaryService.masterCollateralListFromService[element.type] = [];
                this.counterForAPICompletion++;
                this.returnError(error);
            }, () => {
                if (this.counterForAPICompletion === this.tableHeaderList.length) {
                    let counter = 0;
                    this.tableHeaderList.map((item,index)=>{
                        const indexFind=this.collateralObjData.findIndex(data=>data.type===item.type);
                        if(indexFind===-1){
                            this.tableHeaderList[index]['dataPresent'] = false;
                            counter++;
                        }
                    });
                    this.collateralObjData.map(item => {
                        const findIndexValue = this.tableHeaderList.findIndex(data => data.type === item.type);
                        if (findIndexValue !== -1) {
                            this.checkLengthCounter++;
                            if (item.data.length === 0) {
                                this.tableHeaderList[findIndexValue]['dataPresent'] = false;
                                this.mainAmountValues[findIndexValue]['dataPresent'] = false;
                                counter++;
                                if (counter === this.tableHeaderList.length) {
                                    this.noCollateralFound = true;
                                }
                                this.showLoader = false;
                            } else {
                                this.getCollateralArrayData(item.type, item.data);
                            }
                        }
                    });
                  
                }
            });

        });
    }

    getCollateralArrayData(type: any, collateralArray: any) {
        const modifyData = [];
        if (collateralArray.length > 0) {
            collateralArray.forEach(element => {
                const calculateAmountValuesForDepos = element['CollateralValuationDetail']['finalCollateralValue'];
                modifyData.push({
                    amount: calculateAmountValuesForDepos['value'],
                    ccyType: calculateAmountValuesForDepos['ccy']
                });
            });
            this.finalCollateralData.push({'type': type, data: modifyData});
            if (this.checkLengthCounter === this.collateralObjData.length) {
                this.initializeData = true;
                this.showLoader = false;
                this.finalCollateralData.map(item => {
                    this.calculateSumValues(item.type, item.data);
                });

            }
        }
    }

    getRateValuesForAllCcyTypes(changeFlag?: any) {
        const currencyValues = this.selectedCurrencyListItem;
        this.showHeadErrorPanel = false;
        this.errorMsgText = 'Errors found while converting Rate values (The collaterals with below currencies as collateral currency are  excluding from total Amount)';
        const findIndexForCurrency = currencyValues.findIndex(item => item === this.presentCurrencyFormat);
        if (findIndexForCurrency !== undefined && findIndexForCurrency !== -1) {
            if (changeFlag === 'change') {
                this.finalCollateralData.forEach(element => {
                    this.calculateSumValues(element['type'], element['data']);
                });
                this.showLoader = false;
            }
        } else {
            this.getRateValuesFromService(changeFlag);
        }

    }

    getRateValuesFromService(changeFlag?: any) {
        this.showLoader = true;
        this.collateralSummaryService.getRateValues('', this.presentCurrencyFormat).subscribe(response => {
            this.convertedRateValues = this.convertedRateValues.concat(response);
            this.collateralSummaryService.rateConversionArray = this.convertedRateValues;
            if (changeFlag === 'change') {
                this.finalCollateralData.forEach(element => {
                    this.calculateSumValues(element['type'], element['data']);
                });
            }
            this.selectedCurrencyListItem.push(this.presentCurrencyFormat);
            if (response.length === 0) {
                this.errorMsgShow();
            }
        }, error => {
            this.showLoader = false;
            this.errorMsgShow(error);
            this.returnError(error);
        });
    }

    errorMsgShow(error?: any) {
        if (error) {
            this.errorMsgText = 'Service not available';
            this.ratesErrorMsgsList.push(error._body);

        } else {
            const msg = 'Rates are not available from service for ' + this.presentCurrencyFormat;
            const findIndexValue = this.ratesErrorMsgsList.findIndex(item => item === msg);
            if (findIndexValue === undefined || findIndexValue === -1) {
                this.ratesErrorMsgsList.push(msg);
                this.showHeadErrorPanel = true;
            }
        }
    }

    calculateSumValues(type?: any, data?: any) {
        if (this.convertedRateValues.length > 0) {
            const findIndex = this.tableHeaderList.findIndex(item => item.type === type);
            data.forEach(element => {
                const indexOfRate = this.convertedRateValues.findIndex(item => item['fromCurrency'] === element['ccyType'] && item['toCurrency'] === this.presentCurrencyFormat);
                if (indexOfRate !== undefined && (indexOfRate !== -1)) {
                    const amount = element['amount'] * this.convertedRateValues[indexOfRate]['rate'];
                    this.tableHeaderList[findIndex]['totalAmount'] += amount / (this.currencyDividerValue);
                    this.mainAmountValues[findIndex]['totalAmount'] += amount;
                    this.showLoader = !this.initializeData;
                } else {
                    const msg = 'Rate Values for ' + element['ccyType'] + ' currency to ' + this.presentCurrencyFormat + ' not available form service';
                    this.showLoader = !this.initializeData;
                    const findIndexValue = this.ratesErrorMsgsList.findIndex(item => item === msg);
                    if (findIndexValue === undefined || findIndexValue === -1) {
                        this.ratesErrorMsgsList.push(msg);
                        this.showHeadErrorPanel = true;
                    }
                }
            });
        }
    }

    currencyChangeFormatter(currencyArray: any[], currencyDivider: any) {
        if (currencyArray !== undefined) {
            const currencyValueArray = currencyArray.map(item => {
                item['totalAmount'] = (Math.abs(Number(item.totalAmount)) / (currencyDivider));
                return item;
            });
            return currencyValueArray;
        }
    }

    selectionChangeFormat(amountFormat: any) {
        this.currencyFormatValue = 3;
        this.initializeData = true;
        this.showLoader = false;
        const duplicateArray = JSON.parse(JSON.stringify(this.mainAmountValues));
        this.presentCurrencyFormatIn = amountFormat;
        if (this.presentCurrencyFormatIn === 'Million') {
            this.currencyDividerValue = 1.0e+6;
            this.tableHeaderList = this.currencyChangeFormatter(duplicateArray, 1.0e+6);
        } else if (this.presentCurrencyFormatIn === 'Unit') {
            this.currencyFormatValue = 2;
            this.currencyDividerValue = 1;
            this.tableHeaderList = this.currencyChangeFormatter(duplicateArray, 1);
        } else if (this.presentCurrencyFormatIn === 'Thousand') {
            this.currencyDividerValue = 1.0e+3;
            this.tableHeaderList = this.currencyChangeFormatter(duplicateArray, 1.0e+3);
        }
    }

    selectionCurrencyChange(currencyForamt: any) {
        this.initializeData = true;
        this.showLoader = false;
        if (currencyForamt) {
            this.oldCurrencyFormat = this.presentCurrencyFormat;
            this.presentCurrencyFormat = currencyForamt;
            this.retesErrorFlag = false;
            this.showHeadErrorPanel = false;
            this.ratesErrorMsgsList = [];
            this.collateralSummaryData = JSON.parse(JSON.stringify(this.tableHeaderList));
            const configList = this.configList;
            for (const key in configList) {
                this.tableHeaderList[(configList[key].sequencePos) - 1]['totalAmount'] = 0.00;
            }
            this.mainAmountValues = JSON.parse(JSON.stringify(this.tableHeaderList));
            this.getRateValuesForAllCcyTypes('change');
        }
    }

    redirectToNewCollateral() {
        this.popUpshowEvent.emit(true);
        this.collateralService.disableTab = false;
        this.createCollateral = true;
    }

    onCancel(createCollateral: boolean) {
        this.createCollateral = createCollateral;
    }

    redirectToViewCollaterals() {
        this.popUpshowEvent.emit(true);
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {'gcin': this.gcinCpValue, 'label': this.gcinDesc}
        };
        this.router.navigate(['/collateralList'], navigationExtras);
    }

    public returnError(error: any) {
        return Observable.throw(new Error(error.status));
    }

    checkData(key: any) {
        const findIndexValue = this.tableHeaderList.findIndex(data => data.type === key);
        return this.tableHeaderList[findIndexValue].dataPresent;
    }

    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.showPopupDialog = showPopupDialog;
        this.closePopup.emit(showPopupDialog);

    }
}
