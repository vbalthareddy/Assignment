package com.dbs.cap.ct.batch.config;

import com.dbs.cap.ct.batch.model.CorpRelationship;
import com.dbs.cap.ct.batch.model.Corporate;
import com.dbs.cap.ct.batch.model.Customer;
import com.dbs.cap.ct.batch.model.RelationCustomer;
import com.dbs.cap.ct.batch.processor.ClsProcessor;
import com.dbs.cap.ct.batch.processor.ClsRelationProcessor;
import com.dbs.cap.ct.batch.service.ClsReaderService;
import com.dbs.cap.ct.batch.writer.CustomerRelationWriter;
import com.dbs.cap.ct.batch.writer.CustomerWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.sql.DataSource;

@Configuration
@EnableBatchProcessing
@EnableOAuth2Client
@Slf4j
public class BatchConfiguration {
    private static final String CHUNK_SIZE = "ct.batch.chunk.size";
    @Autowired
    public JobBuilderFactory jobBuilderFactory;
    @Autowired
    public StepBuilderFactory stepBuilderFactory;
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    UAA3Configuration authConfig;
    @Autowired
    DataSource dataSource;
    @Autowired
    JobExecutionListener listener;
    @Value("${cap.cls.host}")
    private String clsServiceUrl;
    @Resource
    private Environment env;
    @Autowired
    private SimpleJobLauncher jobLauncher;

    @Scheduled(cron = "${cron.value}")
    public void perform() throws Exception {
        JobParameters param = new JobParametersBuilder()
                .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();
        JobExecution execution = jobLauncher.run(importUserJob(), param);
        log.info("Job finished with status :" + execution.getStatus());
    }

    @Bean
    public ItemReader<Corporate> corpReader() {
        return ClsReaderService.getCorpReader(dataSource);
    }

    @Bean
    public ItemProcessor<Corporate, Customer> corpProcessor() {
        return new ClsProcessor();
    }

    @Bean
    public ItemWriter<Customer> corpWrite() {
        return new CustomerWriter(restTemplate, clsServiceUrl, authConfig);
    }

    @Bean
    public ItemReader<CorpRelationship> corpRelationReader() {
        return ClsReaderService.getCorpRelationReader(dataSource);
    }

    @Bean
    public ItemProcessor<CorpRelationship, RelationCustomer> corpRelationProcessor() {
        return new ClsRelationProcessor();
    }

    @Bean
    public ItemWriter<RelationCustomer> corpRelationWrite() {
        return new CustomerRelationWriter(restTemplate, clsServiceUrl, authConfig);
    }

    @Bean
    public Job importUserJob() {
        return jobBuilderFactory.get("importUserJob").incrementer(new RunIdIncrementer())
                .listener(listener).flow(step1()).next(step2()).end().build();
    }

    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1")
                .<Corporate, Customer>chunk(Integer.valueOf(env.getRequiredProperty(CHUNK_SIZE)))
                .reader(corpReader()).processor(corpProcessor()).writer(corpWrite()).build();
    }

    @Bean
    public Step step2() {
        return stepBuilderFactory.get("step2")
                .<CorpRelationship, RelationCustomer>chunk(
                        Integer.valueOf(env.getRequiredProperty(CHUNK_SIZE)))
                .reader(corpRelationReader()).processor(corpRelationProcessor()).writer(corpRelationWrite())
                .build();
    }

    @Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
