import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {ChangeDetectorRef, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, SimpleChanges} from '@angular/core';
import {GeneralDetailsComponent} from './general-details.component';
import {CollateralService} from '../../collateral.service';
import {ApplicationDetail, Collateral, GeneralDetail, LinkageDetails} from '../../../collateral/model/collateral';
import {CustomFormControl} from '../../../common/custom-form-controls/custom-form-control';
import {Observable} from 'rxjs/Observable';

import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {Location} from '../../../collateral/model/locations';
import createSpy = jasmine.createSpy;
import createSpyObj = jasmine.createSpyObj;
import {DateCompareValidator, ExpiryDateCompareValidator} from '../../../common/custom-validators/custom-date-validator';
import { AbstractControl } from '@angular/forms/src/model';

class MockCollateralService {
    selectedCollateralType: string = 'GUARN';
    collateral: Collateral = new Collateral();
    applicationDetailsSubmitted = false;
    dbsPercentageDetailsSubmitted = false;
    toggle = false;
    toggleDBSPercentage = false;

    getCollateral() {
        return new Collateral();
    }

    getLocations() {
        return Observable.of(null);
    }

    getSolicitorAgencys() {
        return Observable.of(null);
    }

    getDbsSharingBasis() {
        return Observable.of(null);
    }

    getMaxCondition() {
        return Observable.of(null);
    }

}

class MockCollateralServiceWithApplicationData {
    selectedCollateralType: string = 'GUARN';
    collateral: Collateral = new Collateral();
    applicationDetailsSubmitted = true;
    dbsPercentageDetailsSubmitted = false;
    toggle = false;
    toggleDBSPercentage = false;
    formSubmitClicked = true;

    getCollateral() {
        this.collateral = new Collateral();
        this.collateral.generalDetail = new GeneralDetail();
        this.collateral.generalDetail.applicationDetail = new ApplicationDetail();
        this.collateral.generalDetail.applicationDetail.formNo = 'testFormNumber';
        this.collateral.generalDetail.dbsCollateralPercentage = 11;
        this.collateral.CollateralValuationDetail.collateralValue.value = 199;
        this.collateral.CollateralValuationDetail.collateralValue.ccy = 'SGD';
        this.collateral.CollateralValuationDetail.loanToValuePcnt = 11;
        this.collateral.generalDetail.dbsSharingBasis = 'test';
        this.collateral.generalDetail.maxCondition = 'test';
        this.collateral.linkageDetails = [];
        this.collateral.linkageDetails.push(<LinkageDetails>{
            loanToValuePcnt: 1
        });
        return this.collateral;
    }

    getLocations() {
        return Observable.of(null);
    }

    getSolicitorAgencys() {
        return Observable.of(null);
    }

    getDbsSharingBasis() {
        return Observable.of(null);
    }

    getMaxCondition() {
        return Observable.of(null);
    }

}

class MockFormBuilder extends FormBuilder {
    getAddTestForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            executionDate: ['2017-06-12T07:06:17.255Z'],
            signingDate: ['2017-05-12T07:06:17.255Z'],
        });
        return formGroup;
    }
}

class MockChangeDetectorRef {

}

describe('GeneralDetailsComponent', () => {
    let component: GeneralDetailsComponent;
    let fixture: ComponentFixture<GeneralDetailsComponent>;

    describe('GeneralDetailsComponent OnInit possible case', () => {
        beforeEach(async(() => {
            TestBed.configureTestingModule({
                declarations: [GeneralDetailsComponent],
                schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
                providers: [{provide: CollateralService, useClass: MockCollateralService},
                    {provide: ChangeDetectorRef, useClass: MockChangeDetectorRef}
                ]
            }).compileComponents();

        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(GeneralDetailsComponent);
            component = fixture.componentInstance;
            component.collateralDetailsForm = new FormGroup({});
        });

        it('should create GeneralDetailsComponent', () => {
            expect(component).toBeTruthy();
        });

        it('should call ngOnInit GeneralDetailsComponent without loading collateral', () => {
            spyOn(component, 'addFormControls');
            spyOn(component, 'populateData');
            component.ngOnInit();
            expect(component.addFormControls).toHaveBeenCalledTimes(1);
            expect(component.populateData).toHaveBeenCalledTimes(0);
        });

        it('should call ngOnInit GeneralDetailsComponent after loading collateral', () => {
            spyOn(component, 'addFormControls');
            spyOn(component, 'populateData');
            component.collateralLoaded = true;
            component.ngOnInit();
            expect(component.addFormControls).toHaveBeenCalledTimes(1);
            expect(component.populateData).toHaveBeenCalledTimes(1);
            expect(component.selectedCollateralType).toEqual('GUARN');
        });
    });

    describe('GeneralDetailsComponent - ngOnChanges possible case', () => {

        it('collateral loaded status changes from undefined to defined value in change state and having false in initialization', () => {
            component.collateralLoaded = false;
            const changes: SimpleChanges | any = {
                collateralLoaded: {
                    currentValue: true
                }
            };
            spyOn(component, 'addFormControls');
            spyOn(component, 'populateData');
            component.ngOnChanges(changes);
            expect(component.addFormControls).toHaveBeenCalledTimes(0);
            expect(component.populateData).toHaveBeenCalledTimes(0);
        });

        it('if collateral loaded status changes from undefined to defined value in change state', () => {
            component.collateralLoaded = true;
            const changes: SimpleChanges | any = {
                collateralLoaded: {
                    currentValue: true
                }
            };
            spyOn(component, 'addFormControls');
            spyOn(component, 'populateData');
            component.ngOnChanges(changes);
            expect(component.addFormControls).toHaveBeenCalledTimes(1);
            expect(component.populateData).toHaveBeenCalledTimes(1);
            expect(component.selectedCollateralType).toEqual('GUARN');
        });
    });

    describe('GeneralDetailsComponent - populateData With Application details and DBS % details', () => {

        beforeEach(async(() => {
            TestBed.configureTestingModule({
                declarations: [GeneralDetailsComponent],
                schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
                providers: [{provide: CollateralService, useClass: MockCollateralServiceWithApplicationData},
                    {provide: ChangeDetectorRef, useClass: MockChangeDetectorRef}
                ]
            }).compileComponents();

        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(GeneralDetailsComponent);
            component = fixture.componentInstance;
            component.collateralDetailsForm = new FormGroup({});
        });
        it('populate collateral data with application details except DEPOS', () => {
            component.collateralLoaded = false;

            component.ngOnInit();
            component.populateData();

            expect(component.getCollateralService().toggle).toBeTruthy();
        });

        it('populate collateral data with application details for DEPOS', () => {
            component.collateralLoaded = false;
            const collateralService = TestBed.get(CollateralService);
            collateralService.selectedCollateralType = 'DEPOS';

            component.ngOnInit();
            component.populateData();


            expect(component.getCollateralService().toggle).toBeTruthy();
        });

        it('should call onApplicationDataFocusHasError onApplicationDataFocusHasError', () => {
            const collateralService = TestBed.get(CollateralService);
            collateralService.selectedCollateralType = 'DEPOS';
            collateralService.formSubmitClicked = true;
            const collateral = new Collateral();
            collateral.generalDetail = new GeneralDetail();
            collateral.generalDetail.applicationDetail = new ApplicationDetail();
            collateral.generalDetail.applicationDetail.formNo = '';

            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            component.ngOnInit();
            expect(component.onApplicationDataFocusHasError('currencyType')).toBeFalsy();
        });
        it('validate isApplicationDetailsAvailable truthy if one of the fields presents-receivedDate', () => {

            const collateral = new Collateral();
            collateral.generalDetail = new GeneralDetail();
            collateral.generalDetail.applicationDetail = new ApplicationDetail();
            collateral.generalDetail.applicationDetail.receivedDate = new Date();
            const collateralService = TestBed.get(CollateralService);

            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            expect(component.isApplicationDetailsAvailable()).toBeTruthy();
        });

        it('validate isApplicationDetailsAvailable truthy if one of the fields presents-signingDate', () => {

            const collateral = new Collateral();
            collateral.generalDetail = new GeneralDetail();
            collateral.generalDetail.applicationDetail = new ApplicationDetail();
            collateral.generalDetail.applicationDetail.signingDate = new Date();
            const collateralService = TestBed.get(CollateralService);

            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            expect(component.isApplicationDetailsAvailable()).toBeTruthy();
        });

        it('validate isApplicationDetailsAvailable truthy if one of the fields-executionDate presents', () => {
            const collateral = new Collateral();
            collateral.generalDetail = new GeneralDetail();
            collateral.generalDetail.applicationDetail = new ApplicationDetail();
            collateral.generalDetail.applicationDetail.executionDate = new Date();
            const collateralService = TestBed.get(CollateralService);

            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            expect(component.isApplicationDetailsAvailable()).toBeTruthy();
        });

        it('validate isApplicationDetailsAvailable truthy if one of the fields-reviewDate presents', () => {
            const collateral = new Collateral();
            collateral.generalDetail = new GeneralDetail();
            collateral.generalDetail.applicationDetail = new ApplicationDetail();
            collateral.generalDetail.applicationDetail.reviewDate = new Date();
            const collateralService = TestBed.get(CollateralService);

            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            expect(component.isApplicationDetailsAvailable()).toBeTruthy();
        });

        it('validate isApplicationDetailsAvailable truthy if one of the fields -nextReviewDate presents', () => {
            const collateral = new Collateral();
            collateral.generalDetail = new GeneralDetail();
            collateral.generalDetail.applicationDetail = new ApplicationDetail();
            collateral.generalDetail.applicationDetail.nextReviewDate = new Date();
            const collateralService = TestBed.get(CollateralService);

            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            expect(component.isApplicationDetailsAvailable()).toBeTruthy();
        });

        it('validate isApplicationDetailsAvailable truthy if one of the fields -comments presents', () => {
            const collateral = new Collateral();
            collateral.generalDetail = new GeneralDetail();
            collateral.generalDetail.applicationDetail = new ApplicationDetail();
            collateral.generalDetail.applicationDetail.comments = 'asdf';
            const collateralService = TestBed.get(CollateralService);

            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            expect(component.isApplicationDetailsAvailable()).toBeTruthy();

        });

        it('DateCompareValidator should return true if Collateral Execution date is greater than Signing Date', async(() => {
        fixture.detectChanges();
        const tempForm = new FormGroup({
            executionDate: new FormControl(new Date('2017-07-08')),
            signingDate: new FormControl(new Date('2017-07-05'))
        });
        (<CustomFormControl>tempForm.controls['signingDate']).type = 'date';
        (<CustomFormControl>tempForm.controls['signingDate']).label = 'Signing Date';
        (<CustomFormControl>tempForm.controls['executionDate']).type = 'date';
        (<CustomFormControl>tempForm.controls['executionDate']).label = 'Execution Date';

       tempForm.get('executionDate').setValidators(DateCompareValidator(tempForm.get('executionDate'), 'Signing Date', 'Execution Date'));
       tempForm.controls['signingDate'].setValue('1999-07-08');
       tempForm.controls['executionDate'].setValue('2000-07-08');
       expect(tempForm.controls['executionDate'].setValue('2000-07-08')).toBe(undefined);
    }));


    it('ExpiryDateCompareValidator should return true if Collateral Expiry date is greater than Created Date', (() => {
      fixture.detectChanges();
         const tempForm = new FormGroup({
            expiryDate: new FormControl(new Date('2001-07-08')),
            createdDate: new FormControl(new Date('2000-07-05'))
        });
        (<CustomFormControl>tempForm.controls['createdDate']).type = 'date';
        (<CustomFormControl>tempForm.controls['createdDate']).label = 'Created Date';
        (<CustomFormControl>tempForm.controls['expiryDate']).type = 'date';
        (<CustomFormControl>tempForm.controls['expiryDate']).label = 'Expiry Date';

       tempForm.get('createdDate').setValidators(ExpiryDateCompareValidator(tempForm.get('expiryDate').value, 'Created Date', 'Expiry Date'));
       tempForm.controls['expiryDate'].setValue('2001-07-08');
       tempForm.controls['createdDate'].setValue('2000-07-08');
       expect(tempForm.controls['expiryDate'].setValue('2001-07-08')).toBe(undefined);
    }));

    it('validate isApplicationDetailsAvailable falsy if non of the fields presents', () => {
        const collateral = new Collateral();
        collateral.generalDetail = new GeneralDetail();
        collateral.generalDetail.applicationDetail = new ApplicationDetail();
        const collateralService = TestBed.get(CollateralService);

        spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
        component.isApplicationDetailsAvailable();

    });


    });

    it('validate ngAfterViewInit', () => {
        component.validationMessages = {'currencyType': 'testmsg'};
        component.onValueChanged();
    });

    it('should call addFormControls GeneralDetailsComponent', () => {
        component.addFormControls();
    });

    it('should call checkValue GeneralDetailsComponent', () => {
        expect(component.checkValue('test')).toBe('test');
    });
    it('should call checkValue GeneralDetailsComponent', () => {
        expect(component.checkValue(null)).toBeFalsy();
    });

    it('should call onTouched GeneralDetailsComponent', () => {
        component.onTouched('currencyType');
        expect(component.formTouched['currencyType']).toBeTruthy();
    });


    it('should call validateLoan GeneralDetailsComponent', () => {
        component.validateLoan({_textvalue: undefined});
        expect(component.inputLoanValidate).toBe(true);
        component.validateLoan({_textvalue: 2});
        expect(component.inputLoanValidate).toBe(false);
    });

    it('should call validateCollateralPercentage GeneralDetailsComponent', () => {
        component.validateCollateralPercentage({_textvalue: undefined});
        expect(component.collatarelPercentValidate).toBe(true);
        component.validateCollateralPercentage({_textvalue: 2});
        expect(component.collatarelPercentValidate).toBe(false);
    });

    it('should call validateCCYAmount GeneralDetailsComponent', () => {
        component.validateCCYAmount({amount: undefined, currency: undefined});
        expect(component.ccyAmountValidate).toBe(true);
        component.validateCCYAmount({amount: 2, currency: 'SGD'});
        expect(component.ccyAmountValidate).toBe(false);
    });

    it('should call validateMaxAmount GeneralDetailsComponent', () => {
        component.validateMaxAmount({amount: undefined, currency: undefined});
        expect(component.maxAmountValidate).toBe(true);
        component.validateMaxAmount({amount: 2, currency: 'SGD'});
        expect(component.maxAmountValidate).toBe(false);
    });
    it('should call validateRecDate GeneralDetailsComponent', () => {
        component.validateRecDate({value: null});
        expect(component.recDateValidate).toBe(true);
        component.validateRecDate({value: 2});
        expect(component.recDateValidate).toBe(false);
    });

    it('should call validateFormNo GeneralDetailsComponent', () => {
        component.validateFormNo({value: undefined});
        expect(component.formNoValidate).toBe(true);
        component.validateFormNo({value: 2});
        expect(component.formNoValidate).toBe(false);
    });

    it('showDBSPercentageOfCollateralValues will update the toggle for enabling DBS% fields', () => {
        component.ngOnInit();
        component.getCollateralService().toggleDBSPercentage = true;
        component.showDBSPercentageOfCollateralValues();
        expect(component.percentageCollateralHeading).toBe('Add DBS % of Collateral Value Details');
    });
    it('showDBSPercentageOfCollateralValues will update the toggle for disable DBS% fields', () => {
        component.showDBSPercentageOfCollateralValues();
        expect(component.percentageCollateralHeading).toBe('Remove DBS % of Collateral Value Details');
    });

    it('showApplicationDetails will update the toggle for disable application fields', () => {
        component.getCollateralService().toggle = false;
        component.addFormControls();
        component.collateralDetailsForm = new FormGroup({
            executionDate: new FormControl(new Date('2017-07-04')),
            signingDate: new FormControl(new Date('2017-07-05')),
            recievedDate: new FormControl(new Date('2017-07-05')),
            reviewDate: new FormControl(new Date('2017-07-05')),
            formNo: new FormControl('')
        });
        component.showApplicationDetails();
        expect(component.heading).toBe('Remove Application Details');
    });

    it('showApplicationDetails will update the toggle for enabling DBS% fields', () => {
        component.getCollateralService().toggle = true;
        component.addFormControls();
        component.showApplicationDetails();
        expect(component.heading).toBe('Add Application Details');
    });
    it('reviewExeDateValidator should return true if signing date is greater than execute date', () => {
        component.collateralDetailsForm = new FormGroup({
            executionDate: new FormControl(new Date('2017-07-04')),
            signingDate: new FormControl(new Date('2017-07-05'))
        });
        component.reviewExeDateValidator();
        expect(component.executionDateValidate).toBe(true);
    });
    it('reviewExeDateValidator should return false if signing date is less than execute date', () => {
        component.collateralDetailsForm = new FormGroup({
            executionDate: new FormControl(new Date('2017-07-06')),
            signingDate: new FormControl(new Date('2017-07-05'))
        });
        component.reviewExeDateValidator();
        expect(component.executionDateValidate).toBe(false);
    });
    it('reviewValidator should return true if signing date is greater than execute date', () => {
        component.collateralDetailsForm = new FormGroup({
            nextReviewDate: new FormControl(new Date('2017-07-04')),
            reviewDate: new FormControl(new Date('2017-07-05'))
        });
        component.reviewValidator();
        expect(component.nextReviewDateValidate).toBe(true);
    });
    it('reviewValidator should return false if signing date is less than execute date', () => {
        component.collateralDetailsForm = new FormGroup({
            nextReviewDate: new FormControl(new Date('2017-07-06')),
            reviewDate: new FormControl(new Date('2017-07-05'))
        });
        component.reviewValidator();
        expect(component.nextReviewDateValidate).toBe(false);
    });
    it('validateExpDate should return true if Collateral create date is greater than Expiry Date', () => {
        const expDate = new Date();
        expDate.setDate(expDate.getDate() - 1);
        component.collateralDetailsForm = new FormGroup({expiryDate: new FormControl(expDate)});
        component.validateExpDate({});
        expect(component.expiryDateValidate).toBe(false);
    });
    it('validateExpDate should return false if Collateral create date is less than Expiry Date', () => {
        const expDate = new Date();
        expDate.setDate(expDate.getDate() + 1);
        component.collateralDetailsForm = new FormGroup({expiryDate: new CustomFormControl(expDate)});
        component.validateExpDate({});
        expect(component.expiryDateValidate).toBe(false);
    });

  
    

    it('addFormControls should add controls to formgroup', () => {
        component.collateralDetailsForm = new FormGroup({});
        component.addFormControls();
        expect(component.collateralDetailsForm.get('currencyType')).not.toBe(undefined);
        expect(component.collateralDetailsForm.get('recievedDate')).not.toBe(undefined);
    });
    it('eventFromToggleButton should assign values on change on toggle componemt', () => {
        component.collateralDetailsForm = new FormGroup({baselEligible: new FormControl()});
        component.eventFromToggleButton('Yes');
        expect(component.collateralDetailsForm.get('baselEligible').value).toBe(true);
        component.eventFromToggleButton('No');
        expect(component.collateralDetailsForm.get('baselEligible').value).toBe(false);
    });
    it('methodEvent should assign values on change on toggle componemt', () => {
        component.collateralDetailsForm = new FormGroup({method: new FormControl()});
        component.methodEvent('Fixed Amount');
        expect(component.collateralDetailsForm.get('method').value).toBe('Fixed Amount');
        component.methodEvent('All Monies');
        expect(component.collateralDetailsForm.get('method').value).toBe('All Monies');
    });
    it('should call validateSolicitor GeneralDetailsComponent', () => {
        component.validateSolicitorName({value: undefined});
        expect(component.validateSolicitor).toBe(true);
        component.validateSolicitorName({value: 2});
        expect(component.validateSolicitor).toBe(false);
    });

    it('showApplicationDetails should populate applicatio  values', () => {
        component.collateralDetailsForm = new FormGroup({
            formNo: new FormControl(), recievedDate: new FormControl(),
            signingDate: new FormControl(), applicationDetailsRemarks: new FormControl(),
            executionDate: new FormControl(), reviewDate: new FormControl(), nextReviewDate: new FormControl()
        });
        component.showApplicationDetails();
        expect(component.collateralDetailsForm.get('nextReviewDate')).not.toBe(undefined);
    });

    it('should check if all monies are allowed based on collateral type', () => {
        component.selectedCollateralType = 'GUARN';
        expect(component.isMethodAllowed()).toBe(true);
        component.selectedCollateralType = 'DEPOS';
        expect(component.isMethodAllowed()).toBe(true);
    });

    it('validate checkRecievedDateInput', () => {
        component.checkRecievedDateInput(false);
        expect((<CustomFormControl>component.collateralDetailsForm.controls['recievedDate']).type).toBe('date');
    });

    /*it('validate checkExpiryDateInput', () => {
     component.checkExpiryDateInput(false);
     expect((<CustomFormControl>component.collateralDetailsForm.controls['expiryDate']).type).toBe('date');
     });*/

    it('validate checkNextReviewDateInput', () => {
        component.checkNextReviewDateInput(false);
        expect((<CustomFormControl>component.collateralDetailsForm.controls['nextReviewDate']).type).toBe('date');
    });

    it('validate checkReviewDateInput', () => {
        component.checkReviewDateInput(false);
        expect((<CustomFormControl>component.collateralDetailsForm.controls['reviewDate']).type).toBe('date');
    });

    it('validate checkSigningDateInput', () => {
        component.checkSigningDateInput(false);
        expect((<CustomFormControl>component.collateralDetailsForm.controls['signingDate']).type).toBe('date');
    });

    it('validate checkExecutionDateInput', () => {
        component.checkExecutionDateInput(false);
        expect((<CustomFormControl>component.collateralDetailsForm.controls['executionDate']).type).toBe('date');
    });

    it('validate testHandleFilterLocation', () => {

        const location = <Location>{};
        location.code = 'testcode1';
        location.description = 'testDescription1';

        const location1 = <Location>{};
        location1.code = 'testcode1';
        location1.description = 'testDescription1';

        const location2 = <Location>{};
        location2.code = 'testcode2';
        location2.description = 'testDescription2';

        const locationsSource: Array<Location> = [];
        locationsSource.push(location1);
        locationsSource.push(location1);
        locationsSource.push(location2);


        component.locationsSource = locationsSource;
        component.handleFilterLocation('testDescription1');
        expect(component.locations.length).toBe(2);
    });

    it('validate handleFilterDbsSharing', () => {

        const location = <Location>{};
        location.code = 'testcode1';
        location.description = 'testDescription1';

        const location1 = <Location>{};
        location1.code = 'testcode1';
        location1.description = 'testDescription1';

        const location2 = <Location>{};
        location2.code = 'testcode2';
        location2.description = 'testDescription2';

        const locationsSource: Array<Location> = [];
        locationsSource.push(location1);
        locationsSource.push(location1);
        locationsSource.push(location2);


        component.dbsSharingBasisSource = locationsSource;
        component.handleFilterDbsSharing('testDescription1');
        expect(component.dbsSharingBasis.length).toBe(2);
    });

    it('validate handleFilterMaxCondition', () => {

        const location = <Location>{};
        location.code = 'testcode1';
        location.description = 'testDescription1';

        const location1 = <Location>{};
        location1.code = 'testcode1';
        location1.description = 'testDescription1';

        const location2 = <Location>{};
        location2.code = 'testcode2';
        location2.description = 'testDescription2';

        const locationsSource: Array<Location> = [];
        locationsSource.push(location1);
        locationsSource.push(location1);
        locationsSource.push(location2);


        component.maxConditionSource = locationsSource;
        component.handleFilterMaxCondition('testDescription1');
        expect(component.maxCondition.length).toBe(2);
    });

    it('validate handleFilterSolicitorName', () => {

        const location = <Location>{};
        location.code = 'testcode1';
        location.description = 'testDescription1';

        const location1 = <Location>{};
        location1.code = 'testcode1';
        location1.description = 'testDescription1';

        const location2 = <Location>{};
        location2.code = 'testcode2';
        location2.description = 'testDescription2';

        const locationsSource: Array<Location> = [];
        locationsSource.push(location1);
        locationsSource.push(location1);
        locationsSource.push(location2);


        component.agencyCodesSource = locationsSource;
        component.handleFilterSolicitorName('testDescription1');
        expect(component.agencyCodes.length).toBe(2);
    });
});
