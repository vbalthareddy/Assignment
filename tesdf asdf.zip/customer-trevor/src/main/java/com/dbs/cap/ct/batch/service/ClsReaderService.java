package com.dbs.cap.ct.batch.service;

import com.dbs.cap.ct.batch.mapper.CorpRelationshipRowMapper;
import com.dbs.cap.ct.batch.mapper.CorporateRowMapper;
import com.dbs.cap.ct.batch.model.CorpRelationship;
import com.dbs.cap.ct.batch.model.Corporate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

@Service
@Slf4j
public class ClsReaderService {
    public static ItemReader<Corporate> getCorpReader(DataSource dataSource) {
        JdbcCursorItemReader<Corporate> reader = new JdbcCursorItemReader<Corporate>();
        reader.setSql(getCorpQuery());
        reader.setDataSource(dataSource);
        reader.setRowMapper(new CorporateRowMapper());
        return reader;
    }

    private static String getCorpQuery() {
        Calendar calendar = Calendar.getInstance();
        TimeZone sgt = TimeZone.getTimeZone("Singapore");
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setTimeZone(sgt);
        Date date = calendar.getTime();
        final String query = "select * from CORPORATE where update_on ='" + dateFormat.format(date)
                + "' and customer_segment not like 'WM%' and (corp_key like '%DOA' or corp_type = 'CUST' or corp_type = '02')";
        log.debug(query);
        return query;
    }

    public static ItemReader<CorpRelationship> getCorpRelationReader(DataSource dataSource) {
        JdbcCursorItemReader<CorpRelationship> reader = new JdbcCursorItemReader<CorpRelationship>();
        reader.setSql(getCorpRelationQuery());
        reader.setDataSource(dataSource);
        reader.setRowMapper(new CorpRelationshipRowMapper());
        return reader;
    }

    private static String getCorpRelationQuery() {
        Calendar calendar = Calendar.getInstance();
        TimeZone sgt = TimeZone.getTimeZone("Singapore");
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setTimeZone(sgt);
        Date date = calendar.getTime();
        final String query =
                "select CHILD_CORP_KEY, GROUP_CONCAT(PARENT_CORP_KEY SEPARATOR ', ') as LINKAGES "
                        + "from CORP_RELATIONSHIP where update_on = '" + dateFormat.format(date)
                        + "' and child_corp_key like 'GC%' and relationship = 'DOA' group by child_corp_key";
        log.debug(query);
        return query;
    }
}