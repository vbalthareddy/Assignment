import {fakeAsync, inject, TestBed} from '@angular/core/testing';
import {MockBackend, MockConnection} from '@angular/http/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {CollateralGuarantorService} from './collateral-guarantor.service';
import {GcinData} from './gcin-mock-data';
import {AppSettings} from './../../common/config/appsettings';
import {AppConfigData} from './../../common/config/app-config.data';

class MockGuaratorService {
    getGuarantorIdDataService(data) {
        if (data.searchKeyword.length > 3) {
            return Observable.of(GcinData);
        } else {
            return Observable.throw({status: 404});
        }
    }

    getGuarantorData(data: any) {
        return data;
    }

    addGuarantor(data: any) {
        const sampleObj = {};
        return Observable.of(sampleObj);
    }

    getGuaranteeType() {
        const listItems: any = ['SEVERAL', 'JOINT', 'JOINT&SEVERAL', 'SINGLE'];
        return Observable.of(listItems);
    }
}
describe('CollateralGuarantorService', () => {
    let collateralGuarantorService: CollateralGuarantorService;
    let mockBackend: MockBackend;
    const urlToGetGuarantorID = AppConfigData.apiBaseUrl + AppSettings.apiToGetCifId;
    const urlToGuarantor = AppConfigData.apiBaseUrl + 'collaterals/customers';
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                CollateralGuarantorService
            ],
            imports: [HttpModule]
        });
    });
    beforeEach(
        inject([CollateralGuarantorService, MockBackend], (service: CollateralGuarantorService, backend: MockBackend) => {
            collateralGuarantorService = service;
            mockBackend = backend;
        })
    );

    it('should ...', inject([CollateralGuarantorService], (service: CollateralGuarantorService) => {
        expect(service).toBeTruthy();
    }));
    it('Should get response for currency list ', fakeAsync(() => {
        const dataValues = [{}];
        const mockResponseBody = dataValues;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        const searchObj = {'searchKeyword': 'GCIN'};
        collateralGuarantorService.getGuarantorIdDataService(searchObj).subscribe((response: Response) => {
            expect(response).toEqual(dataValues);
        });
    }));
    it('Should get response for getGuarantorIdDataService', fakeAsync(() => {
        const mockResponseBody = {};
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralGuarantorService.addGuarantor('GUARN').subscribe((response: Response) => {
            expect(response).toEqual({});
        });
    }));
    it('Should get response for getGuaranteeType', fakeAsync(() => {
        const mockResponseBody = {};
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralGuarantorService.getGuaranteeType().subscribe((response: Response) => {
            expect(response).toEqual({});
        });
    }));
    it('getGuaranteeType service should call endpoint and return error', (() => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        collateralGuarantorService.getGuaranteeType('GUARN')
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
    }));
    it('getGuarantorIdDataService service should call endpoint and return error', (() => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        collateralGuarantorService.getGuarantorIdDataService('GUARN')
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
    }));
    it('getGuarantorIdDataService service should call endpoint and return error', (() => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        collateralGuarantorService.addGuarantor('GUARN')
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
    }));

});
