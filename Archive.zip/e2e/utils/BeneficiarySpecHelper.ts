import {E2eSpecHelper} from './E2eSpecHelper';
import {$, protractor} from 'protractor';

const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const beneficiary: any = {
    beneficiaryIdOnTab: $('#beneficiary_tab'),
    beneficiaryIdDropdown: $('.beneficiary_id'),
    beneficiaryIdDropdownResult: $('.k-list-container .k-list .k-item:nth-child(1)'),
    beneficiaryIdDropdownValue: (searchTerm: string): any => $('.beneficiary_id .k-searchbar > .k-input').sendKeys(searchTerm),
    beneficiaryRankDropdown: $('.beneficiary_rank'),
    beneficiaryRankDropdownResult: $('.k-list-container .k-list .k-item:first-child'),
    beneficiaryRankDropdownValue: (searchTerm: string): any => $('.beneficiary_rank .k-searchbar > .k-input').sendKeys(searchTerm),
    beneficiaryRankDropdownValueEnter: (searchTerm: string): any => $('.beneficiary_rank .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
    beneficiaryCapAmount: $('#BeneficiaryCapAmountInput'),
    beneficiaryCapAmountValue: (beneficiaryCapAmountVal: string): any => $('#BeneficiaryCapAmountInput input.cls-text').sendKeys(beneficiaryCapAmountVal),
    // disableEditIcon: $('.k-grid table tr:first-child #beneficiaryEditIcon'),
    // disableDeleteIcon: $('.k-grid table tr:first-child #beneficiaryDeleteIcon'),
    beneficiaryEditIcon: $('.k-grid table tr:nth-child(2) #beneficiaryEditIcon'),
    beneficiaryDeleteIcon: $('.k-grid table tr:nth-child(1) #beneficiaryDeleteIcon'),
    closeButton: $('.k-dialog-close'),
    addBeneficiaryBtnForPopDialog: $('.clsBtnSecondary'),
    beneficiarySaveBtn: $('#beneficiary_save'),
    beneficiaryUpdateBtn: $('#beneficiary_update'),
    beneficiaryAddLinkageLink: $('.k-grid table tr:nth-child(1) #beneficiaryAddLinkageLink'),
    beneficiaryEditLinkageLink: $('.k-grid table tr:nth-child(1) #beneficiaryEditLinkageLink'),
    facilityBackBtn: $('#facilityBackButton'),
    facilitySubmitBtn: $('#facilitySubmitButton'),
    facilityLinkageCheckBox: $('label.limitId00'),
    facilityLinkageCheckBoxForEdit: $('label.limitId01')
};

exports.BeneficiaryTestSuite = function () {
    describe('Beneficiary_Page', function () {
        it('should have the title of tab as Beneficiary', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#beneficiary_tab', 'Beneficiary & Facility Linkage');
        });
        it('should have a counterparty record in grid', function () {
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-grid table tr:first-child #beneficiaryName', 'BANK_14OCT1 (GC0001011953)');
            e2eSpecHelper.sleepBrowser(1000);
            // e2eSpecHelper.verifyPresence('.not-editable');
            // browser.actions().mouseMove(element(by.css(beneficiary.disableEditIcon))).perform();
        });
        it('should display validation errors in beneficiary dialog box when entering invalid value for Beneficiary Data', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.addBeneficiaryBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiarySaveBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(2000);
            beneficiary.closeButton.click();
        });
        it('should add valid beneficiary data, display toast and reflect on grid on click of add beneficiary button', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.addBeneficiaryBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdDropdown.click();
            beneficiary.beneficiaryIdDropdownValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdDropdownResult.click();
            beneficiary.beneficiarySaveBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of beneficiary details has been successfully added.');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-grid table tr:nth-child(2) #beneficiaryName', '16R2A GCIN4NF CN002');
        });
        it('should update beneficiary data, display toast and reflect on grid on click of edit icon', function () {
            e2eSpecHelper.verifyPresence('#beneficiaryEditIcon');
            beneficiary.beneficiaryEditIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryRankDropdown.click();
            beneficiary.beneficiaryRankDropdownValue('1DBS');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdDropdownResult.click();
            beneficiary.beneficiaryUpdateBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of beneficiary details has been successfully updated.');
        });
        it('should delete beneficiary data, display toast and reflect on grid on click of delete icon', function () {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('#beneficiaryDeleteIcon');
            e2eSpecHelper.sleepBrowser(2000);
            beneficiary.beneficiaryDeleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of beneficiary details has been successfully deleted.');
        });
        xit('should validate rank optional field with invalid data entry in beneficiary form', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.addBeneficiaryBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            beneficiary.beneficiaryIdDropdown.click();
            beneficiary.beneficiaryIdDropdownValue('GCIN');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdDropdownResult.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryRankDropdown.click();
            beneficiary.beneficiaryRankDropdownValueEnter('ABC');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.closeButton.click();
        });
        xit('should validate cap amount optional field with valid data entry in beneficiary form', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.addBeneficiaryBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            beneficiary.beneficiaryIdDropdown.click();
            beneficiary.beneficiaryIdDropdownValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdDropdownResult.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryCapAmount.click();
            beneficiary.beneficiaryCapAmountValue('10k');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiarySaveBtn.click();
        });
        it('should validate duplicate value entry in beneficiary details page', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.addBeneficiaryBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdDropdown.click();
            beneficiary.beneficiaryIdDropdownValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdDropdownResult.click();
            beneficiary.beneficiarySaveBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('.duplicateValueDiv');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.closeButton.click();
        });
        it('should navigate to facility linkage page with no limit data', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryAddLinkageLink.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Limit Data Found');
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.facilityBackBtn.click();
        });
        it('should navigate to facility linkage page with limit data', function () {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('#beneficiaryDeleteIcon');
            e2eSpecHelper.sleepBrowser(2000);
            beneficiary.beneficiaryDeleteIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.addBeneficiaryBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryIdDropdown.click();
            beneficiary.beneficiaryIdDropdownValue('GC0000190330');
            e2eSpecHelper.sleepBrowser(4000);
            beneficiary.beneficiaryIdDropdownResult.click();
            beneficiary.beneficiarySaveBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryAddLinkageLink.click();
            e2eSpecHelper.sleepBrowser(1000);
        });
        it('should add a limit data to that particular gcin ', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.facilityLinkageCheckBox.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.facilitySubmitBtn.click();
        });
        it('should navigate to facility linkage page with linked limit data highlighted', function () {
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.beneficiaryEditLinkageLink.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.facilityLinkageCheckBox.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.facilityLinkageCheckBoxForEdit.click();
            e2eSpecHelper.sleepBrowser(1000);
            beneficiary.facilitySubmitBtn.click();
        });

    });
};

exports.BeneficiaryTestSuiteForEditFlow = function () {
    describe('Beneficiary_Page for Edit Flow', function () {
        describe('Beneficiary_Page', function () {
            it('should have the title of tab as Beneficiary', function () {
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryIdOnTab.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('#beneficiary_tab', 'Beneficiary & Facility Linkage');
            });
            it('should have a counterparty record in grid', function () {
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('.k-grid table tr:first-child #beneficiaryName', 'BANK_14OCT1 (GC0001011953)');
                e2eSpecHelper.sleepBrowser(1000);
                // e2eSpecHelper.verifyPresence('.not-editable');
                // browser.actions().mouseMove(element(by.css(beneficiary.disableEditIcon))).perform();
            });
            it('should display validation errors in beneficiary dialog box when entering invalid value for Beneficiary Data', function () {
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.addBeneficiaryBtnForPopDialog.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiarySaveBtn.click();
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyPresence('.has-error');
                e2eSpecHelper.sleepBrowser(2000);
                beneficiary.closeButton.click();
            });
            it('should add valid beneficiary data, display toast and reflect on grid on click of add beneficiary button', function () {
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.addBeneficiaryBtnForPopDialog.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryIdDropdown.click();
                beneficiary.beneficiaryIdDropdownValue('gcin');
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryIdDropdownResult.click();
                beneficiary.beneficiarySaveBtn.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of beneficiary details has been successfully added.');
            });
            it('should update beneficiary data, display toast and reflect on grid on click of edit icon', function () {
                e2eSpecHelper.verifyPresence('#beneficiaryEditIcon');
                beneficiary.beneficiaryEditIcon.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryRankDropdown.click();
                beneficiary.beneficiaryRankDropdownValue('1DBS');
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryIdDropdownResult.click();
                beneficiary.beneficiaryUpdateBtn.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of beneficiary details has been successfully updated.');
            });
            it('should delete beneficiary data, display toast and reflect on grid on click of delete icon', function () {
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyPresence('#beneficiaryDeleteIcon');
                e2eSpecHelper.sleepBrowser(2000);
                beneficiary.beneficiaryDeleteIcon.click();
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of beneficiary details has been successfully deleted.');
            });
            it('should validate duplicate value entry in beneficiary details page', function () {
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.addBeneficiaryBtnForPopDialog.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryIdDropdown.click();
                beneficiary.beneficiaryIdDropdownValue('gcin');
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryIdDropdownResult.click();
                beneficiary.beneficiarySaveBtn.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyPresence('.duplicateValueDiv');
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.closeButton.click();
            });
            it('should navigate to facility linkage page with no limit data', function () {
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryAddLinkageLink.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('#no-records-header', 'No Limit Data Found');
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.facilityBackBtn.click();
            });
            it('should navigate to facility linkage page with limit data', function () {
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyPresence('#beneficiaryDeleteIcon');
                e2eSpecHelper.sleepBrowser(2000);
                beneficiary.beneficiaryDeleteIcon.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.addBeneficiaryBtnForPopDialog.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryIdDropdown.click();
                beneficiary.beneficiaryIdDropdownValue('GC0000190330');
                e2eSpecHelper.sleepBrowser(4000);
                beneficiary.beneficiaryIdDropdownResult.click();
                beneficiary.beneficiarySaveBtn.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryAddLinkageLink.click();
                e2eSpecHelper.sleepBrowser(1000);
            });
            it('should add a limit data to that particular gcin ', function () {
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.facilityLinkageCheckBox.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.facilitySubmitBtn.click();
            });
            it('should navigate to facility linkage page with linked limit data highlighted', function () {
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.beneficiaryEditLinkageLink.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.facilityLinkageCheckBox.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.facilityLinkageCheckBoxForEdit.click();
                e2eSpecHelper.sleepBrowser(1000);
                beneficiary.facilitySubmitBtn.click();
            });
        });
    });
};
exports.BeneficiaryTestForAircraftEditSuite = function () {
};


