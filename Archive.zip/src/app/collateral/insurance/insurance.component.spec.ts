import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, DebugElement, NO_ERRORS_SCHEMA} from '@angular/core';
import {InsuranceComponent} from './insurance.component';
import {CollateralService} from '../collateral.service';
import {InsuranceDetails} from '../model/collateral';
import {InsuranceService} from '../insurance/insurance.component.service';
import {By} from '@angular/platform-browser';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import {Collateral} from '../../collateral/model/collateral';
import {Observable} from 'rxjs/Rx';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {GridModule} from '@progress/kendo-angular-grid';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {IntlModule} from '@progress/kendo-angular-intl';
import {AutoCompleteModule, ComboBoxModule} from '@progress/kendo-angular-dropdowns';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';
import {CommonUIModule} from '../../common/commonUI.module';
import {RouterTestingModule} from '@angular/router/testing';
import {ToggleButtonModule} from '../../common/toggle-button/toggle-button.module';
import {InsuranceClaimDetailsModule} from '../insurance/insurance-claim-details/insurance-claim-details.module';
import {CollateralSummaryService} from 'app/collateral/collateral-summary/collateral-summary.service';

import {Router, ActivatedRoute, Params, NavigationExtras} from '@angular/router';
import {InsuranceTypeResponse} from './insurance.component.data';

class MockInsuranceService {
    getData() {
        return [];
    }

    getInsuranceDataService() {
        return Observable.of('');
    }

    getInsuranceTypesfromService() {
        return Observable.of({});
    }

    insuranceData(data: any) {
        const mockInsuranceList = new InsuranceDetails();
        mockInsuranceList.insuranceTypeNew = data.insuranceType;
        mockInsuranceList.insurancePurchaser = data.insurancePurchaser;
        mockInsuranceList.policyDetails = data.policyDetails;
        mockInsuranceList.claimDetails = data.claimDetails;
        mockInsuranceList.insuranceCompanyDetails = data.insuranceCompanyDetails;

        return mockInsuranceList;
    }

}

class MockCollateralService {
    checkPopupDialogBox:boolean = false;
    getCollateral() {
        return new Collateral();
    }
}

class MockFormBuilder extends FormBuilder {
    getBlankForm() {
        const formBuilder = new FormBuilder;
        const formGroup = formBuilder.group({
            insuranceTypeNew: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            insurancePurchaser: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            policyNumber: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            policyDetails: [],
            claimDetails: [],
            insuranceCompanyDetails: []

        });
        return formGroup;
    }

    getAddForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            insuranceTypeNew: ['Blanket Cover', [<any>Validators.required, <any>Validators.minLength(0)]],
            insurancePurchaser: ['Customer', [<any>Validators.required, <any>Validators.minLength(0)]],
            policyNumber: ['12345', [<any>Validators.required, <any>Validators.minLength(0)]],
            policyDetails: [],
            claimDetails: [],
            insuranceCompanyDetails: []
        });
        return formGroup;
    }

}

class MockCollateralSummaryService {
    getMessageToken() {
        return null;
    }

}

describe('InsuranceComponent', () => {
    let component: InsuranceComponent;
    let fixture: ComponentFixture<InsuranceComponent>;

    const router = {
        navigate: jasmine.createSpy('navigate')
    };
    const MockActivatedRoute = {
        queryParams: Observable.of({'gcin': '1234567', 'label': 'ABC', 'ctype': 'COUNTERPATY'})
    };

    beforeEach(async(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
        TestBed.configureTestingModule({
            imports: [
                CommonModule, ComboBoxModule,
                BrowserModule, FormsModule, ReactiveFormsModule,
                ButtonsModule, BrowserAnimationsModule,
                LoaderModule, GridModule, ClsSharedCommonModule, DateInputsModule, IntlModule, AutoCompleteModule
                , PopupDialogModule, CommonUIModule, ToggleButtonModule, InsuranceClaimDetailsModule, RouterTestingModule
            ],
            declarations: [InsuranceComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [
                {provide: CollateralService, useClass: MockCollateralService},
                {provide: InsuranceService, useClass: MockInsuranceService},
                {provide: FormBuilder, useClass: MockFormBuilder},
                {provide: ActivatedRoute, useValue: MockActivatedRoute},
                {provide: Router, useValue: router},
                {provide: CollateralSummaryService, useClass: MockCollateralSummaryService}
            ]

        }).compileComponents().then(() => {
            fixture = TestBed.createComponent(InsuranceComponent);
            component = fixture.componentInstance;

            fixture.detectChanges();
        });
    }));

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('PopDialog should be disabled',
        async(() => {
            expect(component.showPopupDialog).toBe(false);
        }));

    it('PopDialog box should open onclick of add insurance button',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = false;
            component.openPopDialog();
            expect(component.showPopupDialog).toBe(true);
        }));

    it('PopDialog box should be close  onclick of close  button',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = true;
            component.closeEventFromPopupDialog(false);
            expect(component.showPopupDialog).toBe(false);
        }));

    it('should show no-record component when no data available in grid', () => {
        const mockService = new MockInsuranceService();
        component.gridData = mockService.getData();
        component.intializeGridData();
        expect(component.gridData.length).toBe(0);
    });

    it('should not show no-record-component-found when data from service',
        async(() => {
            const mockFormBuilder = new MockFormBuilder();
            let collateralService: CollateralService;
            collateralService = TestBed.get(CollateralService);
            const collateral: Collateral = new Collateral;
            const insuranceDetails: InsuranceDetails[] = [];
            const mockInsuranceService = new MockInsuranceService();
            collateral.insuranceDetails = insuranceDetails;
            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            component.ngOnInit();
            expect(component.gridData.length).toBe(0);
        }));

    it('On onInsuranceTypeSelect function check for selecting insurance type',
        async(() => {
            fixture.detectChanges();
            component.refDepositObj = [{insuranceType: 'Blanket Policy'}];
            component.onInsuranceTypeSelect('Blanket Policy');
            expect(component.insuranceTypeInvalid).toBeTruthy();
        }));

    it('Data should get from backend when something is entered in insurance type field',
        async(() => {
            fixture.detectChanges();
            component.refDepositObj = [];

            component.filterType('Fire Policy');
        }));

    it('Data should add to grid on click of save button',
        async(() => {
            fixture.detectChanges();
            expect(component.gridData.length).toBe(0);
            component.showPopupDialog = false;
            component.refDepositObj = [];
            component.addInsuranceDetailsForm = null;
            const mockForm = new MockFormBuilder();
            const mockService = new MockInsuranceService();
            const data = {
                'insuranceTypeNew': 'Blank coverage',
                'insurancePurchaser': 'Bank',
                'policyNumber': '12345'
            };
            component.initializeFormGroup();
            component.insuranceForm = new FormGroup({});
            component.insuranceForm.addControl('insuranceList', new FormControl(''));
            component.addInsuranceDetailsData(data);
            expect(component.gridData.length).toBeGreaterThan(0);
        }));

    it('Data should get updated in Grid  onclick of update button', () => {
        fixture.detectChanges();
        const mockFormBuilder = new MockFormBuilder();
        const mockForm = new MockFormBuilder();
        component.insuranceForm = new FormGroup({});
        component.insuranceForm.addControl('insuranceList', new FormControl(''));
        component.addInsuranceDetailsForm = mockFormBuilder.getAddForm();
        const mockInsuranceData = new InsuranceDetails();
        mockInsuranceData.insuranceTypeNew = 'Blanket policy';
        mockInsuranceData.insurancePurchaser = 'Bank';
        mockInsuranceData.policyDetails.policyNo = '123';
        component.gridData.push(mockInsuranceData);
        component.rowIndex = 1;
        component.refDepositObj = InsuranceTypeResponse;
        const mockUpdatedInsuranceData = {'policyNumber': '123'};
        component.addInsuranceDetailsForm = mockForm.getAddForm();
        component.updateInsuranceDetailsData(mockUpdatedInsuranceData);
        expect(component.gridData[0].insuranceTypeNew).toBe('Blanket Cover');
    });
    it('Promt box should appear on click of delete icon', () => {
        fixture.detectChanges();
        const insurancedetails = new InsuranceDetails();
        insurancedetails.insuranceTypeNew = 'Blank coverage';
        insurancedetails.insurancePurchaser = 'Bank';
        insurancedetails.policyDetails.policyNo = '12345';
        component.dataItemDelete = insurancedetails;
        component.insuranceRemoveItemFunc(insurancedetails, 0);
        expect(component.showYesNoPrompt).toBe(true);
    });
    it('Data should delete from gridData on click of yes button of promt box', () => {
        fixture.detectChanges();
        const data = {
            'insuranceTypeNew': 'Blank coverage',
            'insurancePurchaser': 'Bank',
            'policyDetails': {
                'policyNo': '12345'
            },
            '__row_status': 'added'
        };
        component.gridData.push(data);
        const mockForm = new MockFormBuilder();
        component.insuranceForm = mockForm.getAddForm();
        const insurancedetails = new InsuranceDetails();
        insurancedetails.insuranceTypeNew = 'Blank coverage';
        insurancedetails.insurancePurchaser = 'Bank';
        insurancedetails.policyDetails.policyNo = '12345';
        component.dataItemDelete = insurancedetails;
        const rowIndex = 0;
        component.insuranceForm = new FormGroup({});
        component.insuranceForm.addControl('insuranceList', new FormControl(''));
        component.confirmationFromYesNo(['yes']);
        expect(component.gridData.length).toBe(0);
    });

    it('methodEvent should assign values on change on toggle component', () => {
        component.addInsuranceDetailsForm = new FormGroup({});
        component.addInsuranceDetailsForm.addControl('insuranceCharge', new FormControl(''));
        component.methodEvent('Customer');
        component.methodEvent('Bank');
    });
    it('should check the validation for all fields', () => {
        const data = {
            'insuranceTypeNew': '',
            'insurancePurchaser': '',
            'policyDetails': {
                'policyNo': ''
            },
            '__row_status': 'added'
        };
        component.validationCheck(data);
        expect(component.insuranceTypeInvalid).toBe(true);
        expect(component.policyNumberInvalid).toBe(true);
    });
    it('on click of Add policy details link it should navigate back to policy details page',
        async(() => {
            fixture.detectChanges();
            const data = {policyDetails: {policyNo: '123'}};
            component.getPolicyDetails(data, 'ADD');
            expect(router.navigate).toHaveBeenCalledWith(['./insurance/policyDetails'], Object({
                queryParams: Object({
                    policyNo: '123',
                    functionFlag: 'ADD',
                    ctype: 'COUNTERPATY',
                    gcin: '1234567',
                    label: 'ABC'
                })
            }));
        }));
    it('on click of Add claim details link it should navigate back to claim details page',
        async(() => {
            fixture.detectChanges();
            const data = {policyDetails: {policyNo: '123'}};
            component.getClaimDetails(data, 'ADD');
            expect(router.navigate).toHaveBeenCalledWith(['./insurance/claimDetails'], Object({
                queryParams: Object({
                    policyNumber: '123',
                    functionFlag: 'ADD',
                    ctype: 'COUNTERPATY',
                    gcin: '1234567',
                    label: 'ABC'
                })
            }));
        }));
    it('on click of edit icon the values should display in form',
        async(() => {
            fixture.detectChanges();
            const data = new InsuranceDetails();
            data.insuranceTypeNew = 'Blank coverage';
            data.insurancePurchaser = 'Customer';
            data.policyDetails.policyNo = '123';
            component.refDepositObj = InsuranceTypeResponse;
            component.insuranceEditFunc(data, 0);
            expect(component.addInsuranceDetailsForm.controls['policyNumber'].value).toBe('123');
        }));
    it('get Insurance type description',
        async(() => {
            fixture.detectChanges();
            component.refDepositObj = InsuranceTypeResponse;
            component.getInsuranceTypeDescription('013');
        }));
    it('get InsurancePurchaser for view of value customer',
        async(() => {
            fixture.detectChanges();
            component.getInsurancePurchaserForView('C');
        }));
    it('get InsurancePurchaser for view of value bank',
        async(() => {
            fixture.detectChanges();
            component.getInsurancePurchaserForView('B');
        }));
    it('get InsurancePurchaser for view of value null',
        async(() => {
            fixture.detectChanges();
            component.getInsurancePurchaserForView(null);
        }));
    it('get InsurancePurchaser for model of value customer',
        async(() => {
            fixture.detectChanges();
            component.getInsurancePurchaserForView('Customer');
        }));
    it('get InsurancePurchaser for model of value bank',
        async(() => {
            fixture.detectChanges();
            component.getInsurancePurchaserForView('B');
        }));
    it('get InsurancePurchaser for model of value null',
        async(() => {
            fixture.detectChanges();
            component.getInsurancePurchaserForView(null);
        }));
    it('Open add popup on click of link in norecord component',
        async(() => {
            fixture.detectChanges();
            component.onLabelClicked('');
            expect(component.showPopupDialog).toBe(true);
        }));
    xit('On onInsuranceTypeSelect function check for selecting insurance type',
        async(() => {
            fixture.detectChanges();
            component.refDepositObj = [{insuranceType: 'Blanket Policy'}];
            component.onInsuranceTypeSelect('Marine Cargo Insurance');
            expect(component.insuranceTypeInvalid).toBe(false);
        }));

});

