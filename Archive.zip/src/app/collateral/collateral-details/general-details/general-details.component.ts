import {
    AfterViewInit,
    ChangeDetectorRef,
    Component,
    Input,
    OnChanges,
    OnInit,
    SimpleChanges,
    ViewEncapsulation
} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {CollateralService} from '../../collateral.service';
import {CustomFormControl} from '../../../common/custom-form-controls/custom-form-control';
import {TextboxValidator} from '../../../common/custom-validators/custom-textbox-validator';

import {PercentageValidator} from '../../../common/custom-validators/custom-percentage-validator';

import {
    DateCompareValidator,
    ExpiryDateCompareValidator
} from '../../../common/custom-validators/custom-date-validator';
import {ErrorResponse} from '../../../shared';
import {Location} from '../../model/';
import * as _ from 'underscore';

@Component({
    selector: 'general-details',
    templateUrl: './general-details.html',
    encapsulation: ViewEncapsulation.Emulated,
    styleUrls: ['./general-details.scss']
})
export class GeneralDetailsComponent implements OnInit, AfterViewInit, OnChanges {
    heading: string;
    percentageCollateralHeading: string;
    valid: boolean;
    recDateValidate: boolean;
    errorResponse: ErrorResponse = null;
    ccyAmountValidate: boolean;
    ccyCurrencyValidate: boolean;
    formNoValidate: boolean;
    validateSolicitor: boolean;
    nextReviewDateValidate: boolean;
    expiryDateValidate: boolean;
    maxAmountValidate: boolean;
    collatarelPercentValidate: boolean;
    executionDateValidate: boolean;
    inputLoanValidate: boolean;
    valueFromSelectedButton: string = 'No';
    public selectedBtn: string = 'value2';
    selectedCollateralType: string = '';
    selectedValueMethod: string = 'Fixed Method';
    private selectedMethod: string = 'value1';
    locationsSource: Array<Location> = [];

    locations: Array<Location> = [];
    dbsSharingBasisSource: Array<{code: string, description: string}> = [];
    dbsSharingBasis: Array<{code: string, description: string}> = [];

    maxConditionSource: Array<{code: string, description: string}> = [];
    maxCondition: Array<{code: string, description: string}> = [];

    agencyCodes: Array<{code: string, description: string}> = [];
    agencyCodesSource: Array<{code: string, description: string}> = [];
    loanToValuePercentage: number;
    currency: string = 'SGD';
    applicationDetailsFormOpen = false;
    dbsPercentageDetailsFormOpen = false;
    public data: any[];

    expiryDateValid: boolean = true;
    recievedDateValid: boolean = true;
    signingDateValid: boolean = true;
    executionDateValid: boolean = true;
    reviewDateValid: boolean = true;
    nextReviewDateValid: boolean = true;

    @Input()
    collateralDetailsForm: FormGroup;

    @Input()
    collateralLoaded: boolean = false;

    formErrors = {
        'currencyType': '',
        'amount': '',
        'expiryDate': null,
        'generalDetailsRemarks': '',
        'loanValuePcnt': '',
        'locationControl': '',
        'collateralValuePcnt': '',
        'sharingBasis': '',
        'maxCondition': '',
        'maxAmountCurrencyType': '',
        'maxAmount': '',
        'fixedAmountCurrencyType': '',
        'fixedAmount': '',
        'proportionateValuePcnt': '',
        'formNo': '',
        'recievedDate': null,
        'reviewDate': null,
        'nextReviewDate': null,
        'signingDate': null,
        'executionDate': null,
        'applicationDetailsRemarks': '',
        'method': '',
        'solicitorName': ''
    };

    formTouched = {
        'currencyType': false,
        'amount': false,
        'expiryDate': false,
        'generalDetailsRemarks': false,
        'loanValuePcnt': false,
        'locationControl': false,
        'collateralValuePcnt': false,
        'sharingBasis': false,
        'maxCondition': false,
        'maxAmountCurrencyType': false,
        'maxAmount': false,
        'fixedAmountCurrencyType': false,
        'fixedAmount': false,
        'proportionateValuePcnt': false,
        'formNo': false,
        'recievedDate': false,
        'reviewDate': false,
        'nextReviewDate': false,
        'signingDate': false,
        'executionDate': false,
        'applicationDetailsRemarks': false,
        'baselEligible': false,
        'method': false,
        'solicitorName': false
    };

    validationMessages = {};

    constructor(private collateralService: CollateralService, private _changeDetectionRef: ChangeDetectorRef) {
        this.heading = 'Add Application Details';
        this.percentageCollateralHeading = 'Add DBS % of Collateral Value Details';
        this.valid = false;
        this.ccyAmountValidate = false;
        this.ccyCurrencyValidate = false;
        this.maxAmountValidate = false;
        this.inputLoanValidate = false;
        this.collatarelPercentValidate = false;
        this.nextReviewDateValidate = false;
        this.recDateValidate = false;
        this.formNoValidate = false;
        this.expiryDateValidate = false;
        this.executionDateValidate = false;
        this.validateSolicitor = false;

    }

    ngOnInit() {
        this.addFormControls();
        if (this.collateralLoaded) {
            this.selectedCollateralType = this.collateralService.selectedCollateralType;
            this.populateData();
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes['collateralLoaded'] && this.collateralLoaded) {
            if (changes['collateralLoaded'].currentValue && changes['collateralLoaded'].previousValue === undefined) {
                this.addFormControls();
            }
            this.selectedCollateralType = this.collateralService.selectedCollateralType;
            this.populateData();
        }
    }

    populateData() {
        this.setGeneralDetails();
        if (this.collateralService.getCollateral().generalDetail.applicationDetail) {
            if (this.isApplicationDetailsAvailable() || this.collateralService.toggle) {
                this.collateralService.toggle = true;
                this.heading = 'Remove Application Details';
            }
            this.setApplicationDetails();
        }
        this.initLocations();
        this.initSolicitorAgencys();

        this.initDBSSharingBasis();
        this.initMaxCondition();
        if (this.collateralService.getCollateral()) {
            if (this.isShowDBSPercentageOfCollateralValuesAvailable() || this.collateralService.toggleDBSPercentage) {
                this.collateralService.toggleDBSPercentage = true;
                this.percentageCollateralHeading = 'Remove DBS % of Collateral Value Details';

            }
            this.setDBSPercentageOfCollateralValues();
        }
        this.currency = 'SGD';
    }

    ngAfterViewInit(): void {
        this.collateralDetailsForm.valueChanges.subscribe(data => {
            if (data.loanValuePcnt && this.collateralService.collateral.linkageDetails) {
                this.collateralService.collateral.linkageDetails.forEach(element => {
                    element.loanToValuePcnt = data.loanValuePcnt;
                });
            }
            this.onValueChanged(data);
        });

        this._changeDetectionRef.detectChanges();
    }

    setGeneralDetails() {
        if (this.collateralService.selectedCollateralType === 'DEPOS') {
            if (this.getCollateralValue() >= 0) {
                this.setAmount();
            }
        } else {
            if (this.getCollateralValue() > 0) {
                this.setAmount();
            }
        }

        if (this.collateralService.getCollateral().CollateralValuationDetail.loanToValuePcnt) {
            this.loanToValuePercentage = this.collateralService.getCollateral().CollateralValuationDetail.loanToValuePcnt;
        }
        this.collateralDetailsForm.get('loanValuePcnt').setValue(this.loanToValuePercentage);
        this.collateralDetailsForm.get('expiryDate').setValue(this.collateralService.getCollateral().generalDetail.collateralExpiryDate);
        this.collateralDetailsForm.get('generalDetailsRemarks').setValue(this.collateralService.getCollateral().generalDetail.remarks);
        this.collateralDetailsForm.get('currencyType').setValue(this.collateralService.getCollateral().generalDetail.currencyCode);
        this.collateralDetailsForm.get('solicitorName').setValue(this.collateralService.getCollateral().generalDetail.solicitorDetails ? this.collateralService.getCollateral().generalDetail.solicitorDetails.solicitorName : '');
        this.collateralService.getCollateral().generalDetail.BASELEligible ? this.selectedBtn = 'value1' : this.selectedBtn = 'value2';
        if (this.collateralService.getCollateral().generalDetail.allMoniesFixedAmount === 'M') {
            this.selectedMethod = 'value2';
        } else {
            this.selectedMethod = 'value1';
        }
    }

    private getCollateralValue() {
        return this.collateralService.getCollateral().CollateralValuationDetail.collateralValue.value;
    }

    private setAmount() {
        this.collateralDetailsForm.get('amount').setValue(this.collateralService.getCollateral().CollateralValuationDetail.collateralValue.value.toString());
    }

    private initLocations() {
        this.collateralService.getLocations().subscribe(data => {
                this.locationsSource = data;
                if (this.locationsSource) {
                    this.locations = this.locationsSource.slice();
                    this.collateralService.locationsForService = this.locations;
                }
                if (this.collateralService.getCollateral() && this.collateralService.getCollateral().generalDetail.country) {
                    const country = this.collateralService.getCollateral().generalDetail.country;
                    const location = _.find(data, function (o) {
                        return o.code === country;
                    });
                    this.collateralDetailsForm.get('locationControl').setValue(location.code);
                }
            }, error => {
            }
        );
    }

    private initDBSSharingBasis() {
        this.collateralService.getDbsSharingBasis().subscribe(data => {
                this.dbsSharingBasisSource = data;
                this.collateralService.dbsSharing = data;
                if (this.dbsSharingBasisSource) {
                    this.dbsSharingBasis = this.dbsSharingBasisSource.slice();
                }
            }, error => {
            }
        );

    }

    private initMaxCondition() {
        this.collateralService.getMaxCondition().subscribe(data => {
                this.maxConditionSource = data;
                this.collateralService.maxCondition = data;
                if (this.maxConditionSource) {
                    this.maxCondition = this.maxConditionSource.slice();
                }
            }, error => {
            }
        );
    }

    private initSolicitorAgencys() {
        this.collateralService.getSolicitorAgencys().subscribe(data => {
                this.agencyCodesSource = data;
                this.collateralService.agencyCodesSource = data;
                if (this.agencyCodesSource) {
                    this.agencyCodes = this.agencyCodesSource.slice();
                }
            }, error => {
            }
        );
    }

    setApplicationDetails() {
        this.collateralDetailsForm.get('formNo').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.formNo);
        this.collateralDetailsForm.get('recievedDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.receivedDate);
        this.collateralDetailsForm.get('signingDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.signingDate);
        this.collateralDetailsForm.get('executionDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.executionDate);
        this.collateralDetailsForm.get('applicationDetailsRemarks').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.comments);
        this.collateralDetailsForm.get('reviewDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.reviewDate);
        this.collateralDetailsForm.get('nextReviewDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.nextReviewDate);
        if (this.collateralService.toggle) {
            this.collateralDetailsForm.get('reviewDate').setValidators(DateCompareValidator(this.collateralDetailsForm.get('nextReviewDate'), 'Review Date', 'Next Review Date'));
            this.collateralDetailsForm.get('signingDate').setValidators(DateCompareValidator(this.collateralDetailsForm.get('executionDate'), 'Signing Date', 'Execution Date'));
        }

    }

    public isApplicationDetailsAvailable() {
        return this.collateralService.getCollateral().generalDetail.applicationDetail.formNo ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.receivedDate ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.signingDate ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.executionDate ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.comments ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.reviewDate ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.nextReviewDate;
    }

    public setDBSPercentageOfCollateralValues() {

        if (this.collateralService.getCollateral().generalDetail.dbsCollateralPercentage) {
            this.collateralDetailsForm.get('collateralValuePcnt').setValue(this.collateralService.getCollateral().generalDetail.dbsCollateralPercentage);
        }
        if (this.collateralService.getCollateral().generalDetail.dbsSharingBasis) {
            this.collateralDetailsForm.get('sharingBasis').setValue(this.collateralService.getCollateral().generalDetail.dbsSharingBasis);
        }
        if (this.collateralService.getCollateral().generalDetail.maxCondition) {
            this.collateralDetailsForm.get('maxCondition').setValue(this.collateralService.getCollateral().generalDetail.maxCondition);
        }
        if (this.collateralService.getCollateral().generalDetail.maxFixedAmount) {
            this.collateralDetailsForm.get('maxAmountCurrencyType').setValue(this.collateralService.collateral.generalDetail.maxFixedAmount.ccy);
            this.collateralDetailsForm.get('maxAmount').setValue(this.collateralService.collateral.generalDetail.maxFixedAmount.value);
        }
        if (this.collateralService.toggleDBSPercentage) {
            this.collateralDetailsForm.get('collateralValuePcnt').setValidators(TextboxValidator.required);
            (<CustomFormControl>this.collateralDetailsForm.controls['collateralValuePcnt']).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls['collateralValuePcnt']).label = 'Collateral Value Percentage';

            this.collateralDetailsForm.get('maxAmount').setValidators(TextboxValidator.required);
            (<CustomFormControl>this.collateralDetailsForm.controls['maxAmount']).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls['maxAmount']).label = 'Max Amount';

            this.collateralDetailsForm.get('sharingBasis').setValidators(TextboxValidator.required);
            (<CustomFormControl>this.collateralDetailsForm.controls['sharingBasis']).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls['sharingBasis']).label = 'Sharing Basis';

            this.collateralDetailsForm.get('maxCondition').setValidators(TextboxValidator.required);
            (<CustomFormControl>this.collateralDetailsForm.controls['maxCondition']).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls['maxCondition']).label = 'Max Condition';
        }

    }

    private isShowDBSPercentageOfCollateralValuesAvailable() {
        return this.checkValueAvailable(this.collateralService.getCollateral().generalDetail.dbsCollateralPercentage) ||
            (this.collateralService.getCollateral().generalDetail.maxFixedAmount && this.checkValue(this.collateralService.getCollateral().generalDetail.maxFixedAmount.value)) ||
            this.checkValue(this.collateralService.getCollateral().generalDetail.dbsSharingBasis) || this.checkValue(this.collateralService.getCollateral().generalDetail.maxCondition);
    }

    checkValue(value) {
        if (value) {
            return value.toString();
        } else {
            return;
        }
    }

    checkValueAvailable(value) {
        if (value && value > 0) {
            return true;
        } else {
            return;
        }
    }

    checkRecievedDateInput(valueFromSelectedDate: any) {
        this.recievedDateValid = valueFromSelectedDate;

        if (!this.recievedDateValid &&
            this.collateralDetailsForm.get('recievedDate')
            || (this.collateralDetailsForm.get('recievedDate') !== null)
            && (this.collateralDetailsForm.get('recievedDate').dirty)) {
            this.collateralDetailsForm.get('recievedDate').setValidators(TextboxValidator.invalidDateText);
            (<CustomFormControl>this.collateralDetailsForm.controls['recievedDate']).type = 'date';
            (<CustomFormControl>this.collateralDetailsForm.controls['recievedDate']).label = 'Recieved Date';
        }
    }

    checkExpiryDateInput(valueFromSelectedDate: any) {
        this.expiryDateValid = valueFromSelectedDate;

        if (!this.expiryDateValid && this.collateralDetailsForm.get('expiryDate') || (this.collateralDetailsForm.get('expiryDate') !== null)
            && (this.collateralDetailsForm.get('expiryDate').dirty)) {
            this.collateralDetailsForm.get('expiryDate').setValidators(TextboxValidator.invalidDateText);
            (<CustomFormControl>this.collateralDetailsForm.controls['expiryDate']).type = 'date';
            (<CustomFormControl>this.collateralDetailsForm.controls['expiryDate']).label = 'Expiry Date';
        }
    }

    checkNextReviewDateInput(valueFromSelectedDate: any) {
        this.nextReviewDateValid = valueFromSelectedDate;
        if (!this.nextReviewDateValid && this.collateralDetailsForm.get('nextReviewDate') || (this.collateralDetailsForm.get('nextReviewDate') !== null)
            && (this.collateralDetailsForm.get('nextReviewDate').dirty)) {
            this.collateralDetailsForm.get('nextReviewDate').setValidators(TextboxValidator.invalidDateText);
            (<CustomFormControl>this.collateralDetailsForm.controls['nextReviewDate']).type = 'date';
            (<CustomFormControl>this.collateralDetailsForm.controls['nextReviewDate']).label = 'Next Review Date';
        }
    }

    checkReviewDateInput(valueFromSelectedDate: any) {
        this.reviewDateValid = valueFromSelectedDate;
        if (!this.reviewDateValid && this.collateralDetailsForm.get('reviewDate') || (this.collateralDetailsForm.get('reviewDate') !== null)
            && (this.collateralDetailsForm.get('reviewDate').dirty)) {
            this.collateralDetailsForm.get('reviewDate').setValidators(TextboxValidator.invalidDateText);
            (<CustomFormControl>this.collateralDetailsForm.controls['reviewDate']).type = 'date';
            (<CustomFormControl>this.collateralDetailsForm.controls['reviewDate']).label = 'Review Date';
        }
    }

    checkSigningDateInput(valueFromSelectedDate: any) {
        this.signingDateValid = valueFromSelectedDate;
        if (!this.signingDateValid && this.collateralDetailsForm.get('signingDate') || (this.collateralDetailsForm.get('signingDate') !== null)
            && (this.collateralDetailsForm.get('signingDate').dirty)) {
            this.collateralDetailsForm.get('signingDate').setValidators(TextboxValidator.invalidDateText);
            (<CustomFormControl>this.collateralDetailsForm.controls['signingDate']).type = 'date';
            (<CustomFormControl>this.collateralDetailsForm.controls['signingDate']).label = 'Signing Date';
        }
    }

    checkExecutionDateInput(valueFromSelectedDate: any) {
        this.executionDateValid = valueFromSelectedDate;
        if (!this.executionDateValid && this.collateralDetailsForm.get('executionDate') || (this.collateralDetailsForm.get('executionDate') !== null)
            && (this.collateralDetailsForm.get('executionDate').dirty)) {
            this.collateralDetailsForm.get('executionDate').setValidators(TextboxValidator.invalidDateText);
            (<CustomFormControl>this.collateralDetailsForm.controls['executionDate']).type = 'date';
            (<CustomFormControl>this.collateralDetailsForm.controls['executionDate']).label = 'Execution Date';
        }
    }

    addFormControls() {

        const customControls = ['currencyType', 'amount', 'applicationDetailsRemarks', 'loanValuePcnt', 'locationControl', 'baselEligible',
            'collateralValuePcnt', 'sharingBasis', 'maxCondition', 'maxAmountCurrencyType', 'maxAmount',
            'fixedAmountCurrencyType', 'fixedAmount', 'formNo', 'method', 'solicitorName', 'expiryDate', 'generalDetailsRemarks', 'proportionateValuePcnt'

        ];
        for (const customControl of customControls) {
            this.addCustomControls(customControl);
        }

        const nullControls = ['recievedDate', 'reviewDate', 'nextReviewDate', 'signingDate', 'executionDate'
        ];

        const emptyControls = ['formNo', 'generalDetailsRemarks', 'applicationDetailsRemarks'];

        for (const emptyControl of emptyControls) {
            this.addEmptyControls(emptyControl);
        }

        for (const nullControl of nullControls) {
            this.addNullControls(nullControl);
        }
    }

    private addCustomControls(control: string) {
        if (this.isMethodAllowed() && control === 'amount') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null, [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'CCY Amount';
        }
        if (!this.isMethodAllowed() && control === 'amount') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null));
        }
        if (control === 'loanValuePcnt') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null, [PercentageValidator.percentageRequired]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Loan to Value';
        }

        if (control === 'solicitorName') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(/* {
             code: '',
             description: ''
             } */'', [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Solicitor Name';

        }

        if (control === 'sharingBasis') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(/* {
             code: '',
             value: ''
             } */''));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'sharing Basis';
        }

        if (control === 'maxCondition') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(/* {
             code: '',
             value: ''
             } */''));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Max Condition';
        }

        if (control === 'locationControl') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(/* {
             code: '',
             value: ''
             } */ '', [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Location';
        }

        if (control === 'currencyType') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl({
                code: '',
                description: ''
            }, [TextboxValidator.requiredDropDownValue]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Currency Type';
        }

        if (control === 'maxAmount') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null));
        }

        if (control === 'maxAmountCurrencyType') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null));
        }

        if (control === 'collateralValuePcnt') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null));
        }
        if (control === 'method') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null));
        }

        if (control === 'expiryDate') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null,
                [ExpiryDateCompareValidator(this.collateralService.collateral.generalDetail.collateralCreationDate, 'Collateral Created Date', 'Expiry Date')]));
        }
        this.collateralDetailsForm.addControl(control, new CustomFormControl({}));
    }

    private addNullControls(control: string) {
        // error panel code
        this.collateralDetailsForm.addControl(control, new CustomFormControl(null));
    }

    private addEmptyControls(control: string) {
        this.collateralDetailsForm.addControl(control, new FormControl(''));
    }

    onValueChanged(data?: any) {
        if (!this.collateralDetailsForm) {
            return;
        }
        const form = this.collateralDetailsForm;
        for (const field in this.formErrors) {
            this.formErrors[field] = '';
            const control = form.get(field);
            if (control) {
                this.formTouched[field] = control.touched;
                if (control && control.dirty && !control.valid) {
                    const messages = this.validationMessages[field];
                    if (messages) {
                        for (const key in control.errors) {
                            this.formErrors[field] += messages[key] + ' ';
                        }
                    }
                }
            }
        }
    }

    onCurrencyChange(event: any) {
        this.collateralService.processCollateralValueForCollateralType(this.collateralDetailsForm.get('currencyType').value, this.collateralDetailsForm.get('amount'));
    }

    onAmountChange(event: any) {
        this.collateralService.processCollateralValueForCollateralType(this.collateralDetailsForm.get('currencyType').value, this.collateralDetailsForm.get('amount'));
    }

    eventFromToggleButton(valueFromSelectedButton: any) {
        this.valueFromSelectedButton = valueFromSelectedButton;
        this.collateralDetailsForm.get('baselEligible').setValue(valueFromSelectedButton === 'Yes');
    }

    methodEvent(selectedValueMethod: any) {
        this.selectedValueMethod = selectedValueMethod;
        this.collateralDetailsForm.get('method').setValue(selectedValueMethod);
    }

    validateLoan(pst) {
        this.inputLoanValidate = !(pst._textvalue);
    }

    validateCollateralPercentage(cvp) {
        this.collatarelPercentValidate = !(cvp._textvalue);
    }

    showDBSPercentageOfCollateralValues() {
        this.collateralService.dbsPercentageDetailsSubmitted = false;
        if (!this.collateralService.toggleDBSPercentage) {
            this.collateralService.toggleDBSPercentage = true;
            this.percentageCollateralHeading = 'Remove DBS % of Collateral Value Details';
            const controls = ['collateralValuePcnt', 'sharingBasis', 'proportionateValuePcnt', 'maxAmount', 'fixedAmount', 'maxCondition'];
            for (const control of controls) {
                this.updateControl(control);
            }
            if (this.collateralDetailsForm.get('sharingBasis')) {
                this.collateralDetailsForm.get('sharingBasis').setValidators(TextboxValidator.required);
                (<CustomFormControl>this.collateralDetailsForm.controls['sharingBasis']).type = 'dropdown';
                (<CustomFormControl>this.collateralDetailsForm.controls['sharingBasis']).label = 'Sharing Basis';
            }

            if (this.collateralDetailsForm.get('maxCondition')) {
                this.collateralDetailsForm.get('maxCondition').setValidators(TextboxValidator.required);
                (<CustomFormControl>this.collateralDetailsForm.controls['maxCondition']).type = 'dropdown';
                (<CustomFormControl>this.collateralDetailsForm.controls['maxCondition']).label = 'Max Condition';
            }

            if (this.collateralDetailsForm.get('maxAmount')) {
                this.collateralDetailsForm.get('maxAmount').setValidators(TextboxValidator.required);
                (<CustomFormControl>this.collateralDetailsForm.controls['maxAmount']).type = 'text';
                (<CustomFormControl>this.collateralDetailsForm.controls['maxAmount']).label = 'Max Amount';
            }

            if (this.collateralDetailsForm.get('collateralValuePcnt')) {
                this.collateralDetailsForm.get('collateralValuePcnt').setValidators((PercentageValidator.percentageRequired));
                (<CustomFormControl>this.collateralDetailsForm.controls['collateralValuePcnt']).type = 'text';
                (<CustomFormControl>this.collateralDetailsForm.controls['collateralValuePcnt']).label = 'Collateral Value Percentage';
            }

        } else {
            this.collateralService.toggleDBSPercentage = false;
            this.percentageCollateralHeading = 'Add DBS % of Collateral Value Details';
            this.maxAmountValidate = false;
            this.collatarelPercentValidate = false;

            if (this.collateralDetailsForm.get('sharingBasis')) {
                this.collateralDetailsForm.removeControl('sharingBasis');
                this.collateralDetailsForm.addControl('sharingBasis', new CustomFormControl(/* {
                 code: '',
                 description: ''
                 } */''));
            }

            if (this.collateralDetailsForm.get('maxCondition')) {
                this.collateralDetailsForm.removeControl('maxCondition');
                this.collateralDetailsForm.addControl('maxCondition', new CustomFormControl(/* {
                 code: '',
                 description: ''
                 } */''));
            }
            if (this.collateralDetailsForm.get('maxAmountCurrencyType')) {
                this.collateralDetailsForm.removeControl('maxAmountCurrencyType');
                this.collateralDetailsForm.addControl('maxAmountCurrencyType', new CustomFormControl(null));
            }
            if (this.collateralDetailsForm.get('maxAmount')) {
                this.collateralDetailsForm.removeControl('maxAmount');
                this.collateralDetailsForm.addControl('maxAmount', new CustomFormControl(null));
            }
            if (this.collateralDetailsForm.get('collateralValuePcnt')) {
                this.collateralDetailsForm.removeControl('collateralValuePcnt');
                this.collateralDetailsForm.addControl('collateralValuePcnt', new CustomFormControl(null));
            }
        }

    }

    showApplicationDetails() {
        this.collateralService.applicationDetailsSubmitted = false;
        if (!this.collateralService.toggle) {
            this.collateralService.toggle = true;
            this.heading = 'Remove Application Details';
            const controls = ['recievedDate', 'reviewDate', 'nextReviewDate', 'signingDate', 'executionDate',
                'applicationDetailsRemarks'];
            for (const control of controls) {
                this.updateControl(control);
            }

            if (this.collateralDetailsForm.get('applicationDetailsRemarks')) {
                this.collateralDetailsForm.get('applicationDetailsRemarks').setValue('');
            }

            if (this.collateralDetailsForm.get('formNo')) {
                this.collateralDetailsForm.get('formNo').setValidators(TextboxValidator.required);
                (<CustomFormControl>this.collateralDetailsForm.controls['formNo']).type = 'text';
                (<CustomFormControl>this.collateralDetailsForm.controls['formNo']).label = 'Form No';

            }
            if (this.collateralDetailsForm.get('recievedDate') || (this.collateralDetailsForm.get('recievedDate') !== null)) {
                this.collateralDetailsForm.get('recievedDate').setValidators(TextboxValidator.required);
                (<CustomFormControl>this.collateralDetailsForm.controls['recievedDate']).type = 'text';
                (<CustomFormControl>this.collateralDetailsForm.controls['recievedDate']).label = 'Recieved Date';
            }

            this.collateralDetailsForm.get('reviewDate').setValidators(DateCompareValidator(this.collateralDetailsForm.get('nextReviewDate'), 'Review Date', 'Next Review Date'));
            this.collateralDetailsForm.get('signingDate').setValidators(DateCompareValidator(this.collateralDetailsForm.get('executionDate'), 'Signing Date', 'Execution Date'));

        } else {
            if (this.collateralDetailsForm.get('formNo')) {
                this.collateralDetailsForm.removeControl('formNo');
                this.collateralDetailsForm.addControl('formNo', new CustomFormControl(''));
            }

            if (this.collateralDetailsForm.get('recievedDate')) {
                this.collateralDetailsForm.removeControl('recievedDate');
                this.collateralDetailsForm.addControl('recievedDate', new CustomFormControl(null));
            }
            if (this.collateralDetailsForm.get('reviewDate')) {
                this.collateralDetailsForm.removeControl('reviewDate');
                this.collateralDetailsForm.addControl('reviewDate', new CustomFormControl(null));
            }
            if (this.collateralDetailsForm.get('signingDate')) {
                this.collateralDetailsForm.removeControl('signingDate');
                this.collateralDetailsForm.addControl('signingDate', new CustomFormControl(null));
            }
            if (this.collateralDetailsForm.get('nextReviewDate')) {
                this.collateralDetailsForm.removeControl('nextReviewDate');
                this.collateralDetailsForm.addControl('nextReviewDate', new CustomFormControl(null));
            }
            if (this.collateralDetailsForm.get('executionDate')) {
                this.collateralDetailsForm.removeControl('executionDate');
                this.collateralDetailsForm.addControl('executionDate', new CustomFormControl(null));
            }
            if (this.collateralDetailsForm.get('applicationDetailsRemarks')) {
                this.collateralDetailsForm.removeControl('applicationDetailsRemarks');
                this.collateralDetailsForm.addControl('applicationDetailsRemarks', new CustomFormControl(null));
            }

            this.collateralService.toggle = false;
            this.heading = 'Add Application Details';
            this.nextReviewDateValidate = false;
            this.executionDateValidate = false;
            this.recDateValidate = false;
            this.formNoValidate = false;
        }
    }

    updateControl(formControl: string) {
        const control = this.collateralDetailsForm.get(formControl);
        if (control) {
            control.setValue(null);
        }
    }

    onTouched(element) {
        if (!this.collateralDetailsForm) {
            return;
        }
        this.formTouched[element] = true;
    }

    onFocusHasError(element: string) {
        if (this.collateralService.formSubmitClicked && this.collateralDetailsForm.controls[element] && this.collateralDetailsForm.controls[element]['invalid']) {
            return true;
        }
        return false;
    }

    onFocusHasErrorDBSPercentageDetails(element: string) {
        if (this.collateralService.dbsPercentageDetailsSubmitted) {
            if (this.collateralDetailsForm.controls[element] && this.collateralDetailsForm.controls[element]['invalid']) {
                return true;
            }
        }
        return false;
    }

    onFocusHasErrorApplicationDetails(element: string) {
        if (this.collateralService.applicationDetailsSubmitted) {
            if (this.collateralDetailsForm.controls[element] && this.collateralDetailsForm.controls[element]['invalid']) {
                return true;
            }
        }
        return false;
    }

    onApplicationDataFocusHasError(element: string) {
        if (this.collateralService.formSubmitClicked && this.isApplicationDetailsAvailable()) {
            this.collateralDetailsForm.get('formNo').setValidators(TextboxValidator.required);
            this.collateralDetailsForm.get('formNo').updateValueAndValidity(true);
            if (this.collateralDetailsForm.controls[element] && this.collateralDetailsForm.controls[element]['invalid']) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    reviewValidator() {
        const nextReviewDate = this.collateralDetailsForm.controls['nextReviewDate'].value !== null ? new Date(this.collateralDetailsForm.get('nextReviewDate').value) : this.collateralDetailsForm.get('nextReviewDate').value;
        const reviewDate = this.collateralDetailsForm.controls['reviewDate'].value !== null ? new Date(this.collateralDetailsForm.controls['reviewDate'].value) : this.collateralDetailsForm.controls['reviewDate'].value;
        this.collateralDetailsForm.get('reviewDate').updateValueAndValidity();
        if (reviewDate && nextReviewDate) {
            if (reviewDate > nextReviewDate) {
                this.nextReviewDateValidate = true;
            } else {
                this.nextReviewDateValidate = false;
            }
        } else {
            this.nextReviewDateValidate = false;
        }
    }

    reviewExeDateValidator() {
        const executionDate = this.collateralDetailsForm.controls['executionDate'].value !== null ? new Date(this.collateralDetailsForm.get('executionDate').value) : this.collateralDetailsForm.get('executionDate').value;
        const signingDate = this.collateralDetailsForm.controls['signingDate'].value !== null ? new Date(this.collateralDetailsForm.get('signingDate').value) : this.collateralDetailsForm.get('signingDate').value;
        this.collateralDetailsForm.get('signingDate').updateValueAndValidity();
        if (executionDate && signingDate) {
            if (signingDate > executionDate) {
                this.executionDateValidate = true;
            } else {
                this.executionDateValidate = false;
            }
        } else {
            this.executionDateValidate = false;
        }
    }

    validateCCYAmount(ccy) {
        this.ccyAmountValidate = !(ccy.amount) || !(ccy.currency);
    }

    validateCCYCurrency(ccy) {
        this.ccyCurrencyValidate = !(ccy.currency);
    }

    validateMaxAmount(mc) {
        this.maxAmountValidate = !(mc.amount) || !(mc.currency);
    }

    validateRecDate(event) {
        if (event !== null) {
            const val = event.value;
            if (val === null) {
                this.recDateValidate = true;
            } else {
                this.recDateValidate = false;
            }
        }
    }

    validateFormNo(formNo) {
        this.formNoValidate = !(formNo.value);
    }

    validateSolicitorName(solicitorName) {
        this.validateSolicitor = !(solicitorName.value);
    }

    validateExpDate(expd) {
        const collateralCreatedDate = new Date(this.collateralService.collateral.generalDetail.collateralCreationDate);
        const expiryDate = this.collateralDetailsForm.get('expiryDate').value;
        this.collateralDetailsForm.get('expiryDate').updateValueAndValidity();
        if (expiryDate === '' || expiryDate === null) {
            this.expiryDateValidate = false;
            return;
        }
        if (collateralCreatedDate > expiryDate) {
            this.expiryDateValidate = true;
        } else {
            this.expiryDateValidate = false;
        }
    }

    isMethodAllowed() {
        return (this.collateralService.selectedCollateralType !== 'DEPOS');
    }

    public handleFilterLocation(filter: any): void {
        if (this.locationsSource) {
            const tempArray = JSON.parse(JSON.stringify(this.locationsSource));
            this.locations = tempArray.filter((s) => s.description.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
        }
    }

    public handleFilterDbsSharing(filter: any): void {
        if (this.dbsSharingBasisSource) {
            this.dbsSharingBasis = this.dbsSharingBasisSource.filter((s) => s.description.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
        }
    }

    public handleFilterMaxCondition(filter: any): void {
        if (this.maxConditionSource) {
            this.maxCondition = this.maxConditionSource.filter((s) => s.description.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
        }
    }

    public handleFilterSolicitorName(filter: any): void {
        if (this.agencyCodesSource) {
            this.agencyCodes = this.agencyCodesSource.filter((s) => s.description.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
        }
    }

    getCollateralService() {
        return this.collateralService;
    }
}
