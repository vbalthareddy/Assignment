package com.dbs.cap.cls.common.io;

import com.dbs.cap.cls.common.test.UnitTest;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.io.IOException;

import static org.junit.Assert.assertNotNull;

@Category(UnitTest.class)
public class ResourceFileReaderTest {
	@Test
	public void readResourceFileToString() throws Exception {
		String fileContent = ResourceFileReader.readResourceFileToString("fixtures/bank_id.json");
		assertNotNull(fileContent);
	}

	@Test(expected = IOException.class)
	public void test_IOException() throws Exception {
		ResourceFileReader.readResourceFileToString("fixtures/no_file_exist.json");
	}
}