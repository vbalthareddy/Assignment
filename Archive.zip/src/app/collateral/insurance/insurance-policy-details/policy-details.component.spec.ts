import {DraftRecordService} from '../../../draftrecord/draft-record.service';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {ChangeDetectorRef, CUSTOM_ELEMENTS_SCHEMA, ElementRef, NO_ERRORS_SCHEMA} from '@angular/core';
import {PolicyDetailsComponent} from './policy-details.component';
import {CollateralService} from '../../collateral.service';
import {Collateral, InsuranceDetails} from '../../../collateral/model/collateral';
import {Observable} from 'rxjs/Observable';
import {FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {CommonModule} from '@angular/common';
import {CommonUIModule} from '../../../common/commonUI.module';
import {BrowserModule} from '@angular/platform-browser';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../../shared/shared-common.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {GridModule} from '@progress/kendo-angular-grid';
import {CustomPanelModule} from '../../../common/custom-panel/custom-panel.module';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {ComboBoxModule, DropDownsModule} from '@progress/kendo-angular-dropdowns';
import {InputsModule} from '@progress/kendo-angular-inputs';
import {DialogModule} from '@progress/kendo-angular-dialog';
import {CounterpartyDetailsModule} from '../../../shared/counterparty-details/counterparty-details.module';
import {ToggleButtonModule} from 'app/common/toggle-button/toggle-button.module';
import {CollateralSummaryService} from '../../collateral-summary/collateral-summary.service';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {CurrencyDropdownService} from '../../../common/currency-dropdown/currency-dropdown.service';
import {
    BankIdResponse,
    BranchIdResponse,
    CoverTypeResponse,
    FrequencyResponse,
    InsuranceActionResponse,
    InsuredTypesResponse,
    MOCK_INSURANCE_DATA,
    PaymentMethodResponse
} from './policy-details.component.data';

class MockCollateralService {
    collateral: Collateral;
    checkPopupDialogBox: boolean = false;

    getCollateral() {
        const collateral = new Collateral();
        const insuranceList = new InsuranceDetails();
        collateral.insuranceDetails.push(insuranceList);
        return Observable.of(collateral);
    }

    getData() {
        return Observable.of({});
    }
}

class MockElementRef implements ElementRef {
    nativeElement = {};
}

class MockCollateralSummaryService {
    collateralOperation = 'ADD_INSURANCE_CLAIM';
    rateConversionArray: any = [
        {
            fromCurrency: 'SGD',
            toCurrency: 'INR',
            rate: 10
        }
    ];
    masterCollateralListFromService = {};
    collateralConfigListFromService = {};

    setMessageToken(raisedBy: string, raisedFor: string, actionCode: string, message: string, timestamp?: string) {
        return true;
    }

    getCurrency() {
        const data = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        return Observable.of(data);
    }

}

class MockPartyDetailsService {
    temp = new Observable(observer => {
        observer.next({'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'});
    });

    subscribeToCPDetails(temp) {
        return Observable.of({label: 'Personal Leadership Centre Pte.Ltd', value: 'GCIN0000000'});
    }

}

class MyRouter {

}
class MockChangeDetectorRef {

}
class MockCurrencyService {
    getCurrencies(filter?: any) {
        return {
            body: [
                {
                    'code': 'SGD',
                    'description': 'SGD Currency',
                    'id': '5f30e506-a276-4865-95aa-210667ded1a8'
                },
                {
                    'code': 'EUR',
                    'description': 'EUR Currency',
                    'id': '6acc19da-6c8a-441d-ba8b-7d41efbe9ab9'
                }],
            subscribe: function (data?: any) {
            }
        };
    }
}
class MockDraftRecordService {
    putDraftRecord() {
        return Observable.of(null);
    }

    postDraftRecord() {
        return Observable.of(null);
    }

    saveCollateralAsDraft() {
        return null;
    }

}

describe('PolicyDetailsComponent', () => {
    let component: PolicyDetailsComponent;
    let fixture: ComponentFixture<PolicyDetailsComponent>;
    const router = {
        navigate: jasmine.createSpy('navigate')
    };
    const MockActivatedRoute = {
        queryParams: Observable.of({
            'policyNo': '1213',
            'functionFlag': 'ADD',
            'gcin': '',
            'label': 'Label',
            'ctype': ''
        })
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [PolicyDetailsComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            imports: [CommonModule, BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
                BrowserAnimationsModule, DateInputsModule, DropDownsModule, ComboBoxModule, InputsModule, DialogModule,
                GridModule, ClsSharedCommonModule, CommonUIModule, CustomPanelModule, CounterpartyDetailsModule, ToggleButtonModule],
            providers: [
                {provide: CollateralService, useClass: MockCollateralService},
                {provide: ChangeDetectorRef, useClass: MockChangeDetectorRef},
                {provide: Router, useValue: router},
                {provide: CurrencyDropdownService, useClass: MockCurrencyService},
                {provide: CounterPartyDetailsService, useClass: MockPartyDetailsService},
                {provide: ActivatedRoute, useValue: MockActivatedRoute},
                {provide: CollateralSummaryService, useClass: MockCollateralSummaryService},
                {provide: DraftRecordService, useClass: MockDraftRecordService}
            ]
        })
            .compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(PolicyDetailsComponent);
        component = fixture.componentInstance;
        component.policyDetailsForm = new FormGroup({});
        spyOn(component, 'getParameterisedData');

    });

    it('should create PolicyDetailsComponent', () => {
        expect(component).toBeTruthy();
    });

    it('should call ngOnInit PolicyDetailsComponent', () => {
        component.ngOnInit();
    });

    it('should call addFormControls PolicyDetailsComponent', () => {
        component.addFormControls();
    });

    it('should call setHeading PolicyDetailsComponent', () => {
        component.functionType = 'EDIT';
        component.setHeading();
        expect(component.heading).toBe('Edit Policy Details');
    });

    it('should call validateAmount PolicyDetailsComponent', () => {
        component.validateAmount({amount: undefined});
        expect(component.ccyAmountValidate).toBe(true);
        component.validateAmount({amount: 2});
        expect(component.ccyAmountValidate).toBe(false);
    });

    it('should call validatePremiumAmount PolicyDetailsComponent', () => {
        component.validatePremiumAmount({amount: undefined});
        expect(component.premiumAmountValidate).toBe(true);
        component.validatePremiumAmount({amount: 2});
        expect(component.premiumAmountValidate).toBe(false);
    });

    it('should call setPolicyDetails PolicyDetailsComponent', () => {
        component.functionType = 'EDIT';
        component.insuranceDetails = new InsuranceDetails();
        component.insuranceDetails.policyDetails.bankId = 'BNKID2';
        component.insuranceDetails.policyDetails.branchId = 'BRNCHID2';
        component.insuranceDetails.policyDetails.frequency = '3YEARS';
        component.insuranceDetails.policyDetails.insuranceAction = '06';
        component.insuranceDetails.policyDetails.itemsInsured = '0';
        component.insuranceDetails.policyDetails.paymentMethod = 'PAYMETHOD1';
        component.insuranceDetails.policyDetails.typeOfCover = 'COVER1';
        component.addFormControls();
        component.bankIdList = BankIdResponse;
        component.branchId = BranchIdResponse;
        component.paymentMethod = PaymentMethodResponse;
        component.insuranceAction = InsuranceActionResponse;
        component.insuredItems = InsuredTypesResponse;
        component.frequency = FrequencyResponse;
        component.typeOfCover = CoverTypeResponse;
        component.setPolicyDetails();
    });

    it('should call setBasicDetails PolicyDetailsComponent', () => {
        const mockPolicyDetailsForm: FormGroup = new FormGroup({
            policyNumber: new FormControl()
        });

        let collateralService: CollateralService;
        collateralService = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral;
        collateral.insuranceDetails = MOCK_INSURANCE_DATA;
        spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
        component.policyDetailsForm = mockPolicyDetailsForm;
        component.setBasicDetails();
        expect(component.policyNumber).toBeDefined();
    });

    it('should call validatePolicyNumber PolicyDetailsComponent', () => {
        component.validatePolicyNumber({value: undefined});
        expect(component.policyNumberValidate).toBe(true);
        component.validatePolicyNumber({value: 2});
        expect(component.policyNumberValidate).toBe(false);
    });

    it('should call validateCollectionID PolicyDetailsComponent', () => {
        component.validateCollectionID({value: undefined});
        expect(component.collectionIDValidate).toBe(true);
        component.validateCollectionID({value: 2});
        expect(component.collectionIDValidate).toBe(false);
    });

    it('riskCoverDateValidator should return true if cover start date is greater than cover end date', () => {
        component.policyDetailsForm = new FormGroup({
            coverEndDate: new FormControl(new Date('2017-07-04')),
            coverStartDate: new FormControl(new Date('2017-07-05'))
        });
        component.riskCoverDateValidator();
        expect(component.riskEndDateValidate).toBe(true);
    });
    it('riskCoverDateValidator should return false if cover start date is less than cover end date', () => {
        component.policyDetailsForm = new FormGroup({
            coverEndDate: new FormControl(new Date('2017-07-06')),
            coverStartDate: new FormControl(new Date('2017-07-05'))
        });
        component.riskCoverDateValidator();
        expect(component.riskEndDateValidate).toBe(false);
    });

    it('premiumPaidDateValidator should return true if premiumPaidDate is greater than premium Collection Date', () => {
        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-04')),
            premiumPaidDate: new FormControl(new Date('2017-07-05'))
        });
        component.premiumPaidDateValidator();
        expect(component.premiumCollectionDateValidate).toBe(false);
    });
    it('premiumPaidDateValidator should return false if premiumPaidDate is less than premium Collection Date', () => {
        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-06')),
            premiumPaidDate: new FormControl(new Date('2017-07-05'))
        });
        component.premiumPaidDateValidator();
        expect(component.premiumCollectionDateValidate).toBe(false);
    });

    it('premiumPaidDateValidator should return false if premiumPaidDate is less than premium Collection Date', () => {
        component.policyDetailsForm = new FormGroup({
            premiumPaidDate: new FormControl()
        });
        component.premiumPaidDateValidator();
        expect(component.premiumPaidValidate).toBe(true);
    });

    it('should call premiumCollectionDateValidator PolicyDetailsComponent', () => {
        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-06')),
            premiumPaidDate: new FormControl(new Date('2017-07-05'))
        });

        component.premiumCollectionDateValidator();
        expect(component.premiumCollectionValidate).toBe(false);
        expect(component.premiumCollectionValidateRange).toBe(false);
    });

    it('should call premiumCollectionDateValidator PolicyDetailsComponent', () => {
        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(),
            premiumPaidDate: new FormControl()
        });

        component.premiumCollectionDateValidator();
        expect(component.premiumCollectionValidate).toBe(true);
        expect(component.premiumCollectionValidateRange).toBe(false);
    });

    it('should call premiumCollectionDateValidator PolicyDetailsComponent', () => {
        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-06')),
            premiumPaidDate: new FormControl(new Date('2017-07-07'))
        });

        component.premiumCollectionDateValidator();
        expect(component.premiumCollectionValidateRange).toBe(true);
    });

    it('should call riskCoverStartDateValidator PolicyDetailsComponent', () => {
        component.policyDetailsForm = new FormGroup({
            coverStartDate: new FormControl(new Date('2017-06-02T12:33:43.707Z')),
            coverEndDate: new FormControl(new Date('2020-06-02T12:33:43.707Z'))
        });

        component.riskCoverStartDateValidator();
        expect(component.coverStartDateValidate).toBe(false);
        expect(component.riskCoverValidateRange).toBe(false);
    });

    it('should call riskCoverEndDateValidator2 PolicyDetailsComponent', () => {

        component.policyDetailsForm = new FormGroup({
            coverStartDate: new FormControl(new Date('2017-07-07')),
            coverEndDate: new FormControl(new Date('2017-07-06'))
        });

        component.riskCoverEndDateValidator();
        expect(component.riskCoverValidateRange).toBe(true);
    });

    it('should call riskCoverEndDateValidator4 PolicyDetailsComponent', () => {
        component.policyDetailsForm = new FormGroup({
            coverStartDate: new FormControl(),
            coverEndDate: new FormControl()
        });

        component.riskCoverEndDateValidator();
        expect(component.riskCoverEndValidate).toBe(true);
        expect(component.riskCoverValidateRange).toBe(false);
    });

    it('Should redirect url onclick of Back Button', () => {
        let collateralSummaryService: CollateralSummaryService;
        collateralSummaryService = TestBed.get(CollateralSummaryService);
        const mockCollateralOperation = collateralSummaryService.collateralOperation;

        let collateralService: CollateralService;
        collateralService = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral;
        collateral.collateralId = 'collat123';
        collateralService.collateral = collateral;
        component.navigateBack();
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {'cid': 'collat123', 'ctype': '', 'gcin': '', 'label': 'Label'}
        };
        expect(router.navigate).toHaveBeenCalledWith(['./collateral'], navigationExtras);
    });

    it('should call isPremiumDatesValid PolicyDetailsComponent', () => {
        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-07')),
            premiumPaidDate: new FormControl(new Date('2017-07-08'))
        });

        // component.isPremiumDatesValid();
        expect(component.isPremiumDatesValid()).toBe(false);

        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-07')),
            premiumPaidDate: new FormControl(new Date('2017-07-06'))
        });

        // component.isPremiumDatesValid();
        expect(component.isPremiumDatesValid()).toBe(true);
    });

    it('should call isCoverDatesValid PolicyDetailsComponent', () => {
        component.policyDetailsForm = new FormGroup({
            coverStartDate: new FormControl(new Date('2017-07-09')),
            coverEndDate: new FormControl(new Date('2017-07-08'))
        });

        component.isCoverDatesValid();
        expect(component.isCoverDatesValid()).toBe(false);

        component.policyDetailsForm = new FormGroup({
            coverStartDate: new FormControl(new Date('2017-07-07')),
            coverEndDate: new FormControl(new Date('2017-07-08'))
        });

        component.isCoverDatesValid();
        expect(component.isCoverDatesValid()).toBe(true);
    });

    it('should call savePolicyDetails PolicyDetailsComponent', () => {
        component.insuranceDetails = new InsuranceDetails();
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            bankID: [{code: 'xyz'}, [<any>Validators.required]],
            branchID: [{code: 'abc'}, [<any>Validators.required]],
            frequency: [{code: 'ICAR'}, [<any>Validators.required]],
            insuranceAction: [{code: 'ENGINEMK01'}, [<any>Validators.required]],
            itemsInsured: [{code: 'ENGINEMD01'}, [<any>Validators.required]],
            collectionID: ['abc1', [<any>Validators.required]],
            paymentMethod: [{code: 'xyz'}, [<any>Validators.required]],
            cancellationDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            premiumCollectionDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            premiumPaidDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            premiumCurrencyType: ['INR', [<any>Validators.required]],
            premiumAmount: [5000],
            policyHolderName: ['Marrisa', [<any>Validators.required]],
            coverEndDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            coverStartDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            policyCurrencyType: ['INR', [<any>Validators.required]],
            policyAmount: [100000, [<any>Validators.required]],
            coverType: [{code: 'COVER1'}, [<any>Validators.required]]
        });

        let collateralService: CollateralService;
        collateralService = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral;
        collateral.collateralId = 'collat123';
        collateralService.collateral = collateral;

        collateral.insuranceDetails = MOCK_INSURANCE_DATA;
        spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
        component.policyDetailsForm = formGroup;

        component.savePolicyDetails();
    });

    it('should call validateAllFormFields1 PolicyDetailsComponent', () => {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            premiumCollectionDate: [null, [Validators.required]],
            premiumPaidDate: [null, [Validators.required]],
            coverStartDate: [null, [Validators.required]],
            coverEndDate: [null, [Validators.required]],
            policyHolderName: [null, [Validators.required]],
            policyNumber: [null, [Validators.required]],
            collectionID: [null, [Validators.required]],
            policyAmount: [null, [Validators.required]],
            premiumAmount: [null, [Validators.required]]
        });

        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-07')),
            premiumPaidDate: new FormControl(new Date('2017-07-08')),
            coverStartDate: new FormControl(new Date('2017-07-09')),
            coverEndDate: new FormControl(new Date('2017-07-08'))
        });

        component.validateAllFormFields(formGroup);
        expect(component.policyHolderNameValidate).toBe(true);
        expect(component.policyNumberValidate).toBe(true);
        expect(component.collectionIDValidate).toBe(true);
        expect(component.ccyAmountValidate).toBe(true);
        expect(component.premiumAmountValidate).toBe(true);
        expect(component.premiumPaidValidate).toBe(true);
        expect(component.premiumCollectionValidate).toBe(true);
        expect(component.coverStartDateValidate).toBe(true);
        expect(component.riskCoverEndValidate).toBe(true);

    });

    it('should call validateAllFormFields2 PolicyDetailsComponent', () => {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            premiumCollectionDate: ['2017-07-08', [Validators.required]],
            premiumPaidDate: ['2017-07-08', [Validators.required]],
            coverStartDate: ['2017-07-08', [Validators.required]],
            coverEndDate: ['2017-07-08', [Validators.required]],
            policyHolderName: [null, [Validators.required]],
            policyNumber: [null, [Validators.required]],
            collectionID: [null, [Validators.required]],
            policyAmount: [null, [Validators.required]],
            premiumAmount: [null, [Validators.required]]
        });

        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-07')),
            premiumPaidDate: new FormControl(new Date('2017-07-08')),
            coverStartDate: new FormControl(new Date('2017-07-09')),
            coverEndDate: new FormControl(new Date('2017-07-08'))
        });

        component.validateAllFormFields(formGroup);
        expect(component.premiumCollectionValidateRange).toBe(true);
        expect(component.riskCoverValidateRange).toBe(true);

        component.policyDetailsForm = new FormGroup({
            premiumCollectionDate: new FormControl(new Date('2017-07-08')),
            premiumPaidDate: new FormControl(new Date('2017-07-07')),
            coverStartDate: new FormControl(new Date('2017-07-08')),
            coverEndDate: new FormControl(new Date('2017-07-09'))
        });

        component.validateAllFormFields(formGroup);
        expect(component.premiumCollectionValidateRange).toBe(false);
        expect(component.riskCoverValidateRange).toBe(false);

    });

    it('should call validatePolicyHolder PolicyDetailsComponent', () => {
        component.validatePolicyHolder({value: undefined});
        expect(component.policyHolderNameValidate).toBe(true);
        component.validatePolicyHolder({value: 2});
        expect(component.collectionIDValidate).toBe(false);
    });
    it('should hide error message if there in cancellation date change', () => {
        component.onDateChange('date');
        expect(component.cancellationDateValidate).toBe(false);
    });
    it('cancel date error should hide if InsuranceAction value is not "Cancel Policy & Eff Under BK MSTR"', () => {
        const insuranceActionObj = {code: '06', description: 'Cancel Policy'};
        component.insuranceAction = InsuranceActionResponse;
        component.onInsuranceActionSelect(insuranceActionObj);
        expect(component.cancellationDateValidate).toBe(false);
    });
    it('cancel date should be mandatory if InsuranceAction value is "Cancel Policy & Eff Under BK MSTR"', () => {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            bankID: [{code: 'xyz'}, [<any>Validators.required]],
            branchID: [{code: 'abc'}, [<any>Validators.required]],
            frequency: [{code: 'ICAR'}, [<any>Validators.required]],
            insuranceAction: [{code: 'ENGINEMK01', description: 'Cancel Policy & Eff Under BK MSTR'}],
            itemsInsured: [{code: 'ENGINEMD01'}, [<any>Validators.required]],
            collectionID: ['abc1', [<any>Validators.required]],
            paymentMethod: [{code: 'xyz'}, [<any>Validators.required]],
            cancellationDate: [null],
            premiumCollectionDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            premiumPaidDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            premiumCurrencyType: ['INR', [<any>Validators.required]],
            premiumAmount: [5000],
            policyHolderName: ['Marrisa', [<any>Validators.required]],
            coverEndDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            coverStartDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            policyCurrencyType: ['INR', [<any>Validators.required]],
            policyAmount: [100000, [<any>Validators.required]]
        });
        component.policyDetailsForm = formGroup;
        component.submitPolicyDetails();
        expect(component.cancellationDateValidate).toBe(true);
    });
    it('should close popup dialog on click of close icon', () => {
        component.closeEventFromPopupDialog(false);
        expect(component.showPopupDialog).toBe(false);
    });
    it('should check canDeactive guard', () => {
        component.popUpShow = false;
        expect(component.canDeactivate()).toBe(false);
        component.popUpShow = true;
        component.backBtnPress = true;
        expect(component.canDeactivate()).toBe(true);
        component.backBtnPress = true;
        component.popUpShow = false;
        expect(component.canDeactivate()).toBe(false);
    });
    it('should save data in draft service and navigate to collateral page', () => {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            bankID: [{code: 'xyz'}, [<any>Validators.required]],
            branchID: [{code: 'abc'}, [<any>Validators.required]],
            frequency: [{code: 'ICAR'}, [<any>Validators.required]],
            insuranceAction: [{code: 'ENGINEMK01', description: 'Cancel Policy & Eff Under BK MSTR'}],
            itemsInsured: [{code: 'ENGINEMD01'}, [<any>Validators.required]],
            collectionID: ['abc1', [<any>Validators.required]],
            paymentMethod: [{code: 'xyz'}, [<any>Validators.required]],
            cancellationDate: [null],
            premiumCollectionDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            premiumPaidDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            premiumCurrencyType: ['INR', [<any>Validators.required]],
            premiumAmount: [5000],
            policyHolderName: ['Marrisa', [<any>Validators.required]],
            coverEndDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            coverStartDate: [new Date('2017-06-02T12:33:43.707Z'), [<any>Validators.required]],
            policyCurrencyType: ['INR', [<any>Validators.required]],
            policyAmount: [100000, [<any>Validators.required]]
        });
        component.policyDetailsForm = formGroup;
        spyOn(component, 'savePolicyDetails');
        component.navigateToColl('save');
        expect(component.popUpShow).toBe(true);
        let mockCollateralSummary: CollateralSummaryService;
        mockCollateralSummary = TestBed.get(CollateralSummaryService);
        mockCollateralSummary.breadcrumbvalue = true;
        component.navigateToColl('save');
        expect(component.popUpShow).toBe(true);
    });
});
