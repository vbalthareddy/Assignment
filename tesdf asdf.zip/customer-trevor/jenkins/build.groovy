final APP_NAME = "cap-cls-service-v3"
final GIT_REPO = "https://gitlab.dev.apps.cs.sgp.dbs.com/cap/customer-trevor.git"
node {
    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'
    stage 'Checkout'
    git branch: 'basic-draft', url: GIT_REPO
    jenkins.maven()
    jenkins.uploadArtifact(APP_NAME, "${APP_NAME}.jar", "target/${APP_NAME}.jar")
    jenkins.tag()
    jenkins.runDeployJob()
}