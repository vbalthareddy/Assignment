import {E2eSpecHelper} from './E2eSpecHelper';
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

exports.HPDetailsSpecSuite = function () {
};

exports.HPDetailsTestSuiteForEditFlow = function () {
};
