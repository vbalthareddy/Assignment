final APP_NAME = "cap-cls-service-v3"
final GIT_REPO = "https://gitlab.dev.apps.cs.sgp.dbs.com/cap/cap-cls-service-v3.git"
node {
    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'
    stage 'Checkout'
    git branch: 'develop', url: GIT_REPO

    jenkins.maven()
    jenkins.checkSonar("com.dbs.cap:$APP_NAME") // you may need to check what is the sonar key
    jenkins.fortify("CST_CAP", "cap-cls-service-v3")
    jenkins.uploadArtifact(APP_NAME, "${APP_NAME}.jar", "target/${APP_NAME}.jar")
//    def reportsFileName = "jacoco-report-api-${env.BUILD_NUMBER}.zip"
//    sh "zip -r -9 ${reportsFileName} target/site/jacoco-ut"
//    jenkins.uploadArtifact(APP_NAME, "${reportsFileName}", "${reportsFileName}")
//    sh "rm -f ${reportsFileName}"
    jenkins.tag()
    jenkins.runDeployJob()
}