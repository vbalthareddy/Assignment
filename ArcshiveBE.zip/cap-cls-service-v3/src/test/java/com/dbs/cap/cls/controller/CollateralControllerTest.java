package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.oauth.OAuth2TestHelper;
import com.dbs.cap.cls.common.test.BaseMockMvcWiremockIntegrationTest;
import com.dbs.cap.cls.common.test.IntegrationTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Category(IntegrationTest.class)
@ActiveProfiles("test")
public class CollateralControllerTest extends BaseMockMvcWiremockIntegrationTest {
    @Autowired
    private OAuth2TestHelper oauthHelper;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        mockResponse(WireMock.post(WireMock.urlMatching("^/oauth/token.*")),
                "{\"access_token\":\"token1234\",\"expires_in\":28776}");
    }

    @Test
    public void get_bank_id_returns_200OK() throws Exception {
        MockHttpServletRequestBuilder getBankId = get("/cls/api/v1/collateral/bank-id")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getBankId.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void get_valuation_frequency_returns_200OK() throws Exception {
        MockHttpServletRequestBuilder getBankId = get("/cls/api/v1/collateral/valuation-frequency")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getBankId.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void get_bank_details_returns_200OK() throws Exception {
        MockHttpServletRequestBuilder getBankId =
                get("/cls/api/v1/collateral/bank-detail?bankId=B123&accountNum=acc123")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getBankId.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void get_bank_details_bankid_accid_null_returns_200OK() throws Exception {
        MockHttpServletRequestBuilder getBankId =
                get("/cls/api/v1/collateral/bank-detail")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getBankId.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void get_charge_rank() throws Exception {
        mvc.perform(get("/cls/api/v1/collateral/charge-rank")
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].rank").value(0))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[*].rank",
                        Matchers.hasItems(Matchers.equalTo(0), Matchers.equalTo(1))))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[*].rankDesc",
                        Matchers.hasItems(Matchers.equalTo("1DBS"), Matchers.equalTo("1ST"))));
    }

    @Test
    public void get_bank_id() throws Exception {
        mvc.perform(get("/cls/api/v1/collateral/bank-id")
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].bankId").value("bank1"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[*].bankId",
                        Matchers.hasItems(Matchers.equalTo("bank2"), Matchers.equalTo("bank3"))))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[*].bankName",
                        Matchers.hasItems(Matchers.equalTo("DBS Bank 1 Singapore"),
                                Matchers.equalTo("DBS Bank 3 Singapore"))));
    }

    @Test
    public void get_deposit_collateral_linkage_by_id_200() throws Exception {
        mockResponse(WireMock.get(
                WireMock.urlMatching("^/api/DEPOSCollaterals/DEPOSIT12345/linkageDetails.*"))
                        .withQueryParam("filter",
                                WireMock.equalTo("filter123")),
                "[{\"entityId\": \"COLL7\"," +
                        "\"collateralId\": \"DEPOSIT12345\"," +
                        "\"sourceSystem\": \"\"," +
                        "\"apportionedPercentage\": 10," +
                        "\"apportionedValue\": {" +
                        "\"value\": 4000," +
                        "\"ccy\": \"SGD\"," +
                        "\"_isDeleted\": false}}]");
        MockHttpServletRequestBuilder getDepositCollateralLinkage =
                get("/cls/api/v1/collateral/deposit/DEPOSIT12345/linkage-detail?filter=filter123")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getDepositCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void get_deposit_collateral_linkage_by_id_404() throws Exception {
        wireMockRule.stubFor(
                WireMock.get(WireMock.urlMatching("^/api/DEPOSCollaterals/DEPOSITXXXX/linkageDetails.*"))
                        .withQueryParam("filter", WireMock.equalTo("filter123"))
                        .willReturn(aResponse().withStatus(HttpStatus.NOT_FOUND.value())));
        MockHttpServletRequestBuilder getDepositCollateralLinkage =
                get("/cls/api/v1/collateral/DEPOSCollaterals/DEPOSITXXXX/linkage-detail?filter=filter123")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getDepositCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isNotFound());
    }

    @Test
    public void put_deposit_collateral_linkage_200() throws Exception {
        wireMockRule.stubFor(
                WireMock.put(WireMock.urlMatching("^/api/DEPOSCollaterals/DEPOSIT12345/linkageDetails.*"))
                        .withRequestBody(
                                WireMock.equalTo(
                                        "{\"LodgeReceiptAndPayment\": {\"receiptAndPayment\": [{ }]}," +
                                                "\"collateralCode\": \"DEPOSIT12345\"}"))
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withBody("{\"LodgeReceiptAndPayment\": {\"receiptAndPayment\": [{ }]}," +
                                        "\"collateralCode\": \"DEPOSIT12345\"" +
                                        "}")
                                .withHeader("Accept", "application/json")
                                .withHeader("Content-Type", "application/json")));
        MockHttpServletRequestBuilder putDepositCollateralLinkage =
                put("/cls/api/v1/collateral/deposit/DEPOSIT12345/linkage-detail")
                        .content("{\"LodgeReceiptAndPayment\": {\"receiptAndPayment\": [{ }]}," +
                                "\"collateralCode\": \"DEPOSIT12345\"}")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(putDepositCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void put_deposit_collateral_linkage_400() throws Exception {
        MockHttpServletRequestBuilder putDepositCollateralLinkage =
                put("/cls/api/v1/collateral/deposit/DEPOSIT12345/linkage-detail")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(putDepositCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void get_gurantee_collateral_linkage_by_id_200() throws Exception {
        wireMockRule.stubFor(
                WireMock.get(
                        WireMock.urlMatching("^/api/GUARNCollaterals/GUARN12345/linkageDetails.*"))
                        .withQueryParam("filter",
                                WireMock.equalTo("filter123")).willReturn(aResponse().withStatus(HttpStatus.OK.value())
                        .withBody("[\r\n"
                                + "\t{\r\n"
                                + "\t\t\"entityId\": \"COLL3154\",\r\n"
                                + "\t\t\"collateralId\": \"aaaaaaa\",\r\n"
                                + "\t\t\"sourceSystem\": \"\",\r\n"
                                + "\t\t\"nature\": \"Primary\",\r\n"
                                + "\t\t\"method\": \"L\",\r\n"
                                + "\t\t\"unlinkReasonCode\": \"\"\r\n"
                                + "\t}\r\n"
                                + "]")
                        .withHeader("Content-Type", "application/json").withHeader("Accept", "application/json")));
        MockHttpServletRequestBuilder getGuranteeCollateralLinkage =
                get("/cls/api/v1/collateral/guarantee/GUARN12345/linkage-detail?filter=filter123")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getGuranteeCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void get_gurantee_collateral_linkage_by_id_404() throws Exception {
        wireMockRule.stubFor(
                WireMock.get(WireMock.urlMatching("^/api/GUARNCollaterals/GUARNXXXX/linkageDetails.*"))
                        .withQueryParam("filter", WireMock.equalTo("filter123"))
                        .willReturn(aResponse().withStatus(HttpStatus.NOT_FOUND.value())));
        MockHttpServletRequestBuilder getGuranteeCollateralLinkage =
                get("/cls/api/v1/collateral/GUARNCollaterals/GUARNXXXX/linkage-detail?filter=filter123")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getGuranteeCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isNotFound());
    }

    @Test
    public void put_gurantee_collateral_linkage_200() throws Exception {
        wireMockRule.stubFor(
                WireMock.put(WireMock.urlMatching("^/api/GUARNCollaterals/GUARN12345/linkageDetails.*"))
                        .withRequestBody(
                                WireMock.equalTo(
                                        "{\r\n"
                                                + "\t\"LodgeReceiptAndPayment\": {\r\n"
                                                + "\t\t\"receiptAndPayment\": [{ }]\r\n"
                                                + "\t},\r\n"
                                                + "\t\"collateralCode\": \"GUARN12345\"\r\n"
                                                + "}"))
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withBody("{\r\n"
                                        + "\t\"LodgeReceiptAndPayment\": {\r\n"
                                        + "\t\t\"receiptAndPayment\": [{ }]\r\n"
                                        + "\t},\r\n"
                                        + "\t\"collateralCode\": \"GUARN12345\"\r\n"
                                        + "}")
                                .withHeader("Accept", "application/json")
                                .withHeader("Content-Type", "application/json")));
        MockHttpServletRequestBuilder putGuranteeCollateralLinkage =
                put("/cls/api/v1/collateral/guarantee/GUARN12345/linkage-detail")
                        .content("{\r\n"
                                + "\t\"LodgeReceiptAndPayment\": {\r\n"
                                + "\t\t\"receiptAndPayment\": [{ }]\r\n"
                                + "\t},\r\n"
                                + "\t\"collateralCode\": \"GUARN12345\"\r\n"
                                + "}")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(putGuranteeCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void put_gurantee_collateral_linkage_400() throws Exception {
        MockHttpServletRequestBuilder putGuranteeCollateralLinkage =
                put("/cls/api/v1/collateral/guarantee/GUARN12345/linkage-detail")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(putGuranteeCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void put_gurantee_collateral_withdraw_200() throws Exception {
        wireMockRule.stubFor(
                WireMock.put(WireMock.urlMatching("^/api/GUARNCollaterals/GUARN12345/withdraw.*"))
                        .withRequestBody(
                                WireMock.equalTo(
                                        "{\r\n"
                                                + "\t\"withdraw\": true,\r\n"
                                                + "\t\"reasonCode\": \"some reason\",\r\n"
                                                + "\t\"withdrawalDate\": \"2017-08-01T07:25:01.275Z\",\r\n"
                                                + "\t\"id\": \"aaaaaaa\"\r\n"
                                                + "}"))
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withBody("{\r\n"
                                        + "\t\"withdraw\": true,\r\n"
                                        + "\t\"reasonCode\": \"some reason\",\r\n"
                                        + "\t\"withdrawalDate\": \"2017-08-01T07:25:01.275Z\",\r\n"
                                        + "\t\"id\": \"aaaaaaa\"\r\n"
                                        + "}")
                                .withHeader("Accept", "application/json")
                                .withHeader("Content-Type", "application/json")));
        MockHttpServletRequestBuilder putGuranteeCollateralWithdraw =
                put("/cls/api/v1/collateral/guarantee/GUARN12345/withdraw")
                        .content("{\r\n"
                                + "\t\"withdraw\": true,\r\n"
                                + "\t\"reasonCode\": \"some reason\",\r\n"
                                + "\t\"withdrawalDate\": \"2017-08-01T07:25:01.275Z\",\r\n"
                                + "\t\"id\": \"aaaaaaa\"\r\n"
                                + "}")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(putGuranteeCollateralWithdraw
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void put_gurantee_collateral_withdraw_400() throws Exception {
        MockHttpServletRequestBuilder putGuranteeCollateralWithdraw =
                put("/cls/api/v1/collateral/guarantee/GUARN12345/withdraw")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(putGuranteeCollateralWithdraw
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void put_deposit_collateral_withdraw_200() throws Exception {
        wireMockRule.stubFor(
                WireMock.put(WireMock.urlMatching("^/api/DEPOSCollaterals/DEPOSIT12345/withdraw.*"))
                        .withRequestBody(
                                WireMock.equalTo(
                                        "{\r\n"
                                                + "\t\"withdraw\": true,\r\n"
                                                + "\t\"reasonCode\": \"some reason\",\r\n"
                                                + "\t\"withdrawalDate\": \"2017-08-01T07:25:01.275Z\",\r\n"
                                                + "\t\"id\": \"abcdef\"\r\n"
                                                + "}"))
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withBody("{\r\n"
                                        + "\t\"withdraw\": true,\r\n"
                                        + "\t\"reasonCode\": \"some reason\",\r\n"
                                        + "\t\"withdrawalDate\": \"2017-08-01T07:25:01.275Z\",\r\n"
                                        + "\t\"id\": \"abcdef\"\r\n"
                                        + "}")
                                .withHeader("Accept", "application/json")
                                .withHeader("Content-Type", "application/json")));
        MockHttpServletRequestBuilder putGuranteeCollateralWithdraw =
                put("/cls/api/v1/collateral/deposit/DEPOSIT12345/withdraw")
                        .content("{\r\n"
                                + "\t\"withdraw\": true,\r\n"
                                + "\t\"reasonCode\": \"some reason\",\r\n"
                                + "\t\"withdrawalDate\": \"2017-08-01T07:25:01.275Z\",\r\n"
                                + "\t\"id\": \"abcdef\"\r\n"
                                + "}")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(putGuranteeCollateralWithdraw
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void put_deposit_collateral_withdraw_400() throws Exception {
        MockHttpServletRequestBuilder putGuranteeCollateralWithdraw =
                put("/cls/api/v1/collateral/deposit/DEPOSIT12345/withdraw")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(putGuranteeCollateralWithdraw
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void get_items_insured_id_success() throws Exception {
        MockHttpServletRequestBuilder getGuranteeCollateralLinkage =
                get("/cls/api/v1/collateral/items-insured?filter=filter123")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getGuranteeCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].code", is("0")));
    }

    @Test
    public void get_items_insured_notnull() throws Exception {
        MockHttpServletRequestBuilder getGuranteeCollateralLinkage =
                get("/cls/api/v1/collateral/items-insured?filter=filter123")
                        .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getGuranteeCollateralLinkage
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(jsonPath("$[101].code").doesNotExist());
    }
}
