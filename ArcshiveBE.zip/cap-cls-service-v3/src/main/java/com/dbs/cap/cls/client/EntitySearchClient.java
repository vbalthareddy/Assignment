package com.dbs.cap.cls.client;

import com.dbs.cap.cls.common.configuration.ClientConfiguration;
import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.utility.EntitySearchResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.HashMap;

@FeignClient(
        name = "EntitySearchClient",
        url = "${entitySearch.host}",
        configuration = ClientConfiguration.class
)
public interface EntitySearchClient {
    @RequestMapping(
            path = "/entitySearch",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    EntitySearchResponse searchByKeyword(@RequestBody String requestBody,
                                         @RequestHeader(ClsConstants.AUTHORIZATION) String token);

    @RequestMapping(
            path = "/entitySearch",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    HashMap<String, Object> searchByKeyword(HashMap<String, Object> search,
                                            @RequestHeader(ClsConstants.AUTHORIZATION) String token);
}