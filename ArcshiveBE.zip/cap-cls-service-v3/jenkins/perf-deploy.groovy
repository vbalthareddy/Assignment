// Required Parameters
// APP_NAME = 'cap-cls-service' or 'cap-cls-service-v3'
// BUILD_NUMBER
// CF_USERNAME
// CF_PASSWORD
final MANIFEST_URL = "https://gitlab.dev.apps.cs.sgp.dbs.com/cap/${APP_NAME}/raw/develop/cloudfoundry/perf.yml"
node {
    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'
    jenkins.downloadArtifactory(APP_NAME, BUILD_NUMBER, "${APP_NAME}.jar")
    jenkins.downloadManifest(MANIFEST_URL)
    jenkins.login('api.dev.sys.cs.sgp.dbs.com', CF_USERNAME, CF_PASSWORD, 'CLS', 'perf' )
    jenkins.deploy(APP_NAME, "-p ${APP_NAME}.jar")
}