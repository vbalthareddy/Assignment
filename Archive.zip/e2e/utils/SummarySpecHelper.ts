import {E2eSpecHelper} from './E2eSpecHelper';
import {$, browser, by, element, protractor} from 'protractor';

exports.SummaryTestSuite = function (collateralType?: string) {
    describe('Summary_Details_Page', function () {
        const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

        const summary: any = {
            summaryTabId: $('#summary_tab'),
            chargeTabId: $('#charge_tab'),
            beneficiaryTabId: $('#beneficiary_tab'),
            specificDetailsTab: $('#specific_details_tab'),
            generalDetailsPanelId: '#general-details-section',
            beneficiaryDetailsPanelId: '#beneficiary-details-section',
            valuationDetailsPanelId: '#valuation-details-section',
            spanLabel: 'span.panel-label',
            spanKArrowIcon: 'span.k-icon-arrow',
            collDetailsTabId: $('#collDetails_tab'),
            ownershipTabId: $('#ownership_tab'),
            documentTabId: $('#document_tab'),
            inspectionTabId: $('#inspection_tab'),
            insuranceTabId: $('#insurance_tab'),
            tabNavPrevId: element(by.xpath('//*[@id="tab-navigation-prev"]')),
            collateralDetailsPage: {
                basic_details: {
                    ccy_amount: element(by.xpath('//*[@id="amount"]')),
                    gen_remarks_textarea: element(by.css('[name=generalDetailsRemarks]')).element(by.className('commentTextArea')).element(by.tagName('textarea')),
                    loan_to_value_pcnt: element(by.css('[formcontrolname="loanValuePcnt"]')).element(by.className('prefixSuffix-box')).element(by.tagName('input')),
                    location_control: $('#locationControl'),
                    location_control_select: $('#locationControl .k-searchbar > .k-input'),
                    solicitor_selection: element(by.xpath('//*[@id="solicitorName"]/span/kendo-searchbar/input')),
                    solicitor_dropdown_selection: $('.k-animation-container .k-list .k-item:nth-child(1)')
                },
                dbs_pcnt_details: {
                    link: element.all(by.id('toggleDBSPercentagelink')),
                    max_amount: element.all(by.id('maxAmount')),
                    collateral_value_pcnt: element(by.css('[formcontrolname="collateralValuePcnt"]')).element(by.className('prefixSuffix-box')).element(by.tagName('input'))
                },
                application_details: {
                    link: element.all(by.id('toggleApplicationLink')),
                    form_no: element.all(by.id('formNo')),
                    receivedDateInputIcon: $('#recievedDate .input-group-addon'),
                    reviewDateInputIcon: $('#reviewDate .input-group-addon'),
                    nextReviewDateInputIcon: $('#nextReviewDate .input-group-addon'),
                    signingDateInputIcon: $('#signingDate .input-group-addon'),
                    executionDateInputIcon: $('#executionDate .input-group-addon'),
                    active_btn: $('.btn.active'),
                    app_remarks: element(by.css('[name=applicationDetailsRemarks]')).element(by.className('commentTextArea')).element(by.tagName('textarea'))
                }
            },
            specificDetails: {
                addSpecificDetailsBtn: $('.add-specific-details-btn'),
                deposit: {
                    fcfdDropdown: $('#fcfd-dropdwon'),
                    fcfdSearch: (searchTerm: string): any => $('#fcfd-dropdwon .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    depositAcDropdown: $('#depositAc-Dropdown'),
                    depositAcSearch: (searchTerm: string): any => $('#depositAc-Dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    depositNoInputBox: $('#depositNo'),
                    depositNoInputValue: (inputTerm: string): any => $('#depositNo').sendKeys(inputTerm),
                    earmarkAmount: $('#earmark-amount input.cls-text'),
                    earmarkAmountInput: (earmarkAmountInput: string): any => $('#earmark-amount input.cls-text').sendKeys(earmarkAmountInput),
                    earmarkReasonTextarea: $('#earmark-reason textarea.commentTextArea__input'),
                    earmarkReasonInput: (earmarkReasonInput: string): any =>
                        summary.specificDetails.deposit.earmarkReasonTextarea.sendKeys(earmarkReasonInput),
                    earmarkReasonUpdateInput: (earmarkReasonInput: string) => summary.specificDetails.deposit.earmarkReasonTextarea.clear()
                        .then(() => summary.specificDetails.deposit.earmarkReasonTextarea.sendKeys(earmarkReasonInput)),
                    remarksTextarea: $('#remarks textarea.commentTextArea__input'),
                    remarksTextareaInput: (remarksTextareaInput: string): any => summary.specificDetails.deposit.remarksTextarea.sendKeys(remarksTextareaInput),
                    saveFormBtn: $('#save-form-btn'),
                    depositAcInputBox: $('#depositAc-Dropdown .k-searchbar > .k-input'),
                    addDetailsBtn: $('#add-details-btn')
                },
                aircraft: {
                    saveFormBtn: $('#save-form-btn'),
                    addDetailsBtn: $('#add-details-btn'),
                    airframeMakeDropdown: $('#airframe-make-dropdown'),
                    airframeMakeSearch: (searchTerm: string): any => $('#airframe-make-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    airframeModelDropdown: $('#airframe-model-dropdown'),
                    airframeModelSearch: (searchTerm: string): any => $('#airframe-model-dropdown .k-searchbar > .k-input').sendKeys(searchTerm),
                    selectDropdownList: $('.k-animation-container .k-list .k-item:last-child'),
                    airframeSerialInputBox: $('#airframe-serial'),
                    airframeSerialInput: (inputTerm: string): any => $('#airframe-serial').sendKeys(inputTerm),
                    engineMake: $('#engine-make'),
                    engineMakeInput: (inputTerm: string): any => $('#engine-make').sendKeys(inputTerm),
                    engineModel: $('#engine-model'),
                    engineModelInput: (inputTerm: string): any => $('#engine-model').sendKeys(inputTerm),
                    engineSno: $('#engine-sno'),
                    engineSnoInput: (inputTerm: string): any => $('#engineSno').sendKeys(inputTerm),
                    fusulageNo: $('#fusulage-no'),
                    fusulageNoInput: (inputTerm: string): any => $('#fusulageNo').sendKeys(inputTerm),
                    tailNo: $('#tail-no'),
                    tailNoInput: (inputTerm: string): any => $('#tailNo').sendKeys(inputTerm),
                    mfdYear: $('#mfd-year'),
                    mfdYearInput: (inputTerm: string): any => $('#mfd-year').sendKeys(inputTerm),
                    purchasedDateIcon: $('#purchased-date .input-group-addon'),
                    purchasedDateSelect: $('.btn.active'),
                    engineRemarksTextarea: $('#engine-remarks.commentTextArea__input'),
                    engineRemarksInput: (engineRemarksTextarea: string): any =>
                        summary.specificDetails.aircraft.engineRemarksTextarea.sendKeys(engineRemarksTextarea),
                    manufacturerName: $('#manufacturer-name'),
                    manufacturerNameInput: (inputTerm: string): any => $('#manufacturer-name').sendKeys(inputTerm),
                    operatorName: $('#operator-name'),
                    operatorNameInput: (inputTerm: string): any => $('#operator-name').sendKeys(inputTerm),
                    addSubHirerLink: $('#addSubHirerLink')
                },
                vehicle: {
                    specificDetailsIdOnTab: $('#specific_details_tab'),
                    saveFormBtn: $('#save-form-btn'),
                    addDetailsBtn: $('#add-details-btn'),
                    selectDropdownList: $('.k-animation-container .k-list .k-item:last-child'),
                    vehicleMakeDropdown: $('#vehicle-make-dropdown'),
                    vehicleMakeSearch: (searchTerm: string): any => $('#vehicle-make-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    vehicleTypeDropdown: $('#vehicle-type-dropdown'),
                    vehicleTypeSearch: (searchTerm: string): any => $('#vehicle-type-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    vehicleModelDropdown: $('#vehicle-model-dropdown'),
                    vehicleModelSearch: (searchTerm: string): any => $('#vehicle-model-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    vehicleRegistrationNumberInputBox: $('#registration-no'),
                    vehicleRegistrationNumberInput: (inputTerm: string): any => $('#registration-no').sendKeys(inputTerm),
                    chassisNumberInputBox: $('#chassis-no'),
                    chassisNumberInput: (inputTerm: string): any => $('#chassis-no').sendKeys(inputTerm),
                    vehicleRemarksTextarea: $('#vehicle-remarks.commentTextArea__input'),
                    vehicleRemarksInput: (vehicleRemarksTextarea: string): any =>
                        summary.specificDetails.vehicle.vehicleRemarksTextarea.sendKeys(vehicleRemarksTextarea),
                    engineMakeInputBox: $('#engine-make'),
                    engineMakeInput: (inputTerm: string): any => $('#engine-make').sendKeys(inputTerm),
                    engineSnoInputBox: $('#engine-serial-no'),
                    engineSnoInput: (inputTerm: string): any => $('#engine-serial-no').sendKeys(inputTerm),
                    oldRegistrationInputBox: $('#old-registration-no'),
                    oldRegistrationInput: (inputTerm: string): any => $('#old-registration-no').sendKeys(inputTerm),
                    yearInputBox: $('#year-input'),
                    yearInput: (inputTerm: string): any => $('#year-input').sendKeys(inputTerm),
                    regAuthority: $('#reg-authority-dropdown'),
                    regAuthoritySearch: (searchTerm: string): any => $('#reg-authority-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    regState: $('#registration-state-dropdown'),
                    regStateSearch: (searchTerm: string): any => $('#reg-authority-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    regCountry: $('#reg-authority-dropdown'),
                    regCountrySearch: (searchTerm: string): any => $('#country-reg-dropdown > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    trackStatusDropdown: $('#tracking-status-dropdown'),
                    trackStatusSearch: (searchTerm: string): any => $('#tracking-status-dropdown > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                    mfdYear: $('#mfd-year .input-group-addon'),
                    mfdYearSelect: $('.btn.active'),
                    purchaseDate: $('#purchase-date .input-group-addon'),
                    purchaseDateSelect: $('.btn.active'),
                    disposalDate: $('#disposal-date .input-group-addon'),
                    disposalDateSelect: $('.btn.active'),
                    trackStatusDate: $('#disposal-date .input-group-addon'),
                    trackStatusDateSelect: $('.btn.active'),
                    addSubHirerLink: $('#addSubHirerLink')
                }
            },
            beneficiaryDetailsPage: {
                addBeneficiaryBtnForPopDialog: $('.clsBtnSecondary'),
                beneficiaryIdDropdown: $('.beneficiary_id'),
                beneficiaryIdDropdownResult: $('.k-list-container .k-list .k-item:nth-child(1)'),
                beneficiaryIdDropdownValue: (searchTerm: string): any => $('.beneficiary_id .k-searchbar > .k-input').sendKeys(searchTerm),
                beneficiarySaveBtn: $('#beneficiary_save')
            },
            ownershipDetailsPage: {
                openOwnershipDetailsDialog: $('#btn_showAddOwnershipDialog'),
                ownershipName: $('.autocomplete-dropdown'),
                ownershipNameDropdownValue: (searchTerm: string): any => $('.autocomplete-dropdown .k-searchbar > .k-input').sendKeys(searchTerm),
                ownershipNameDropdownResult: $('.k-list-container .k-list .k-item:first-child'),
                ownershipNameDropdownResultLastValue: $('.k-list-container .k-list .k-item:last-child'),
                ownershipPercentage: $('.prefix_percentage_class input'),
                ownershipPercentageInput: (searchTerm: string): any => $('#id_OwnershipPercentage > div > input').sendKeys(searchTerm),
                saveOwnershipDetails: $('#btn_OwnershipDetailSave')
            },
            chargeDetailsPage: {
                natureOfChargesDropDown: $('#natureOfChargesDropDown'),
                natureOfChargesDropDownValue: (searchTerm: string): any => $('#natureOfChargesDropDown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                chargeRankDropDown: $('#chargeRankDropDown'),
                chargeRankDropDownValue: (searchTerm: string): any => $('#chargeRankDropDown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
                chargeAmountInput: $('#chargeAmountInput'),
                chargeAmountInputValue: (chargeAmountInputVal: string): any => $('#chargeAmountInput input.cls-text').sendKeys(chargeAmountInputVal),
                registrationAuthorityInfo: $('#registrationAuthorityInfoId textarea'),
                registrationAuthorityInfoValue: (registrationAuthorityInfoInput: string): any => $('#registrationAuthorityInfoId textarea.commentTextArea__input').sendKeys(registrationAuthorityInfoInput, protractor.Key.ENTER),
                filingDateIcon: $('#filingDateInput .input-group-addon'),
                filingDateSelect: $('.btn.active'),
                receiptDateIcon: $('#receiptDateInput .input-group-addon'),
                receiptDateSelect: $('.btn.active')
            },
            inspectionDetailsPage: {
                addIInspectionBtnForPopDialog: $('.clsBtnSecondary'),
                inspectionSaveBtn: $('#inspection_save'),
                inspectionUpdateBtn: $('#inspection_update'),
                inspectionTypeDropdown: $('.inspection_type'),
                inspectionTypeDropdownResult: $('.k-list-container .k-list .k-item:nth-child(1)'),
                inspectionTypeDropdownValue: (searchTerm: string): any => $('.inspection_type .k-searchbar > .k-input').sendKeys(searchTerm),
                inspectionEmployeeId: $('.employee_id'),
                inspectionEmployeeIdValue: (searchTerm: string): any => $('.employee_id > input').sendKeys(searchTerm),
                firstInspectionDate: $('#firstInspectionAppraisalDate .k-select'),
                latestInspectionDate: $('#latestInspectionAppraisalDate .k-select'),
                nextInspectionDate: $('#nextInspectionAppraisalDate .k-select'),
                dateToday: $('.k-today '),
                dateWeekend: $('.k-weekend'),
                inspectionFrequencyDropdown: $('.frequency'),
                inspectionFrequencyDropdownResult: $('.k-list-container .k-list .k-item:nth-child(4)'),
                inspectionFrequencyDropdownValue: (searchTerm: string): any => $('.frequency .k-searchbar > .k-input').sendKeys(searchTerm)
            },
            documentDetailsPage: {
                documentBtnForPopDialog: $('.clsBtnSecondary'),
                documentCodeId: $('#doccumentCodeId'),
                documentDateIcon: $('#documentDate .input-group-addon'),
                dateToday: $('.btn.active '),
                documentDueDate: $('#documentDueDate .input-group-addon'),
                documentExpirationDate: $('#documentExpirationDate .input-group-addon'),
                dateWeekend: $('.btn.active'),
                documentCodeSearch: (searchTerm: string): any => $('#doccumentCodeId .k-searchbar .k-input').sendKeys(searchTerm),
                documentDropDownResult: $('.k-animation-container .k-list .k-item:first-child'),
                documentCustodianSearch: (searchTerm: string): any => $('#documentSearchId .k-searchbar .k-input').sendKeys(searchTerm),
                saveFormBtn: $('#save-form-btn')
            },
            insuranceDetailsPage: {
                insuranceBtnForPopDialog: $('.clsBtnSecondary'),
                insuranceTypeId: $('#fcfd-dropdwon'),
                insuranceCodeSearch: (searchTerm: string): any => $('#fcfd-dropdwon .k-searchbar .k-input').sendKeys(searchTerm),
                selectDropdownList: $('.k-animation-container .k-list .k-item:first-child'),
                insurancePolicyNoInputValue: (inputTerm: string): any => $('#policyNumber').sendKeys(inputTerm),
                saveFormBtn: $('#save-form-btn')
            }
        };

        it('should have the title of tab as Summary', function () {
            e2eSpecHelper.sleepBrowser(2000);
            if (collateralType === 'Aircraft') {
                summary.chargeTabId.click();
                e2eSpecHelper.sleepBrowser(2000);
            }
            summary.summaryTabId.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#summary_tab', 'Summary');
        });

        it('should show default panels on Summary Tab', function () {
            e2eSpecHelper.verifyTextContains(summary.generalDetailsPanelId + ' ' + summary.spanLabel, 'General Details');
            e2eSpecHelper.verifyTextContains(summary.valuationDetailsPanelId + ' ' + summary.spanLabel, 'Collateral Value');
        });

        it('should open-close default panels on Summary Tab', function () {
            e2eSpecHelper.scrollToElement(summary.valuationDetailsPanelId);
            browser.sleep(3000);
            /*Close the default panels one at a time*/
            e2eSpecHelper.buttonClick(summary.generalDetailsPanelId + ' ' + summary.spanKArrowIcon);
            e2eSpecHelper.buttonClick(summary.valuationDetailsPanelId + ' ' + summary.spanKArrowIcon);
            browser.sleep(3000);
            /*Open the default panels one at a time*/
            e2eSpecHelper.buttonClick(summary.valuationDetailsPanelId + ' ' + summary.spanKArrowIcon);
            e2eSpecHelper.buttonClick(summary.generalDetailsPanelId + ' ' + summary.spanKArrowIcon);
            e2eSpecHelper.scrollToTheTop();
        });

        /*Go to Collateral Details Page, add data and verify on summary page*/

        it('should have the title of tab as Collateral Details', function () {
            e2eSpecHelper.sleepBrowser(2000);
            if (collateralType === 'Guarantee' || collateralType === 'Deposit') {
                summary.collDetailsTabId.click();
            } else {
                summary.chargeTabId.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.tabNavPrevId.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.tabNavPrevId.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.tabNavPrevId.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.tabNavPrevId.click();
            }
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#collDetails_tab', 'Collateral Details');
        });

        describe('should verify collateral details data on summary page', function () {
            it('should add collateral details on collateral details page for summary page', function () {
                e2eSpecHelper.sleepBrowser(3000);

                if (collateralType !== 'DEPOSIT') {
                    /*Enter amount*/
                    summary.collateralDetailsPage.basic_details.ccy_amount.clear();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.collateralDetailsPage.basic_details.ccy_amount.sendKeys('1234');
                }

                /*Enter general remarks*/
                summary.collateralDetailsPage.basic_details.gen_remarks_textarea.clear();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.basic_details.gen_remarks_textarea.sendKeys('gen details remarks test');
                /*Enter loan to value pcnt*/
                summary.collateralDetailsPage.basic_details.loan_to_value_pcnt.clear();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.basic_details.loan_to_value_pcnt.sendKeys('11');
                /*Enter location of collateral*/
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.basic_details.location_control.click();
                // summary.collateralDetailsPage.basic_details.location_control.clear();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.basic_details.location_control_select.sendKeys('Singapore', protractor.Key.ENTER);
                summary.collateralDetailsPage.basic_details.solicitor_selection.click();

                e2eSpecHelper.scrollToTheBottom('1000');

                /*Enter DBS % Value Section*/
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.dbs_pcnt_details.link.click();
                summary.collateralDetailsPage.dbs_pcnt_details.collateral_value_pcnt.clear();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.dbs_pcnt_details.collateral_value_pcnt.sendKeys('22');
                e2eSpecHelper.sleepBrowser(2000);
                summary.collateralDetailsPage.dbs_pcnt_details.max_amount.clear();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.dbs_pcnt_details.max_amount.sendKeys('333');

                /*Enter application details section*/
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.application_details.link.click();
                summary.collateralDetailsPage.application_details.form_no.clear();
                summary.collateralDetailsPage.application_details.form_no.sendKeys('abc123');
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.application_details.receivedDateInputIcon.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.collateralDetailsPage.application_details.active_btn.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.application_details.reviewDateInputIcon.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.collateralDetailsPage.application_details.active_btn.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.application_details.nextReviewDateInputIcon.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.collateralDetailsPage.application_details.active_btn.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.application_details.signingDateInputIcon.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.collateralDetailsPage.application_details.active_btn.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.collateralDetailsPage.application_details.executionDateInputIcon.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.collateralDetailsPage.application_details.active_btn.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.collateralDetailsPage.application_details.app_remarks.sendKeys('app details remarks test');
                e2eSpecHelper.scrollToTheTop();

            });

            it('should verify collateral details on summary page', function () {
                e2eSpecHelper.sleepBrowser(3000);
                if (collateralType !== 'DEPOSIT') {
                    /*Verify basic details*/
                    e2eSpecHelper.verifyTextContains('#basic_details_div > summary-subsection > div > div.section-subtext > div:nth-child(2) > span', 'SGD 1,234.00');
                }
                /*Verify basic details*/
                e2eSpecHelper.verifyTextContains('#basic_details_div > summary-subsection > div > div.section-subtext > div:nth-child(4) > span', 'gen details remarks test');
                e2eSpecHelper.verifyTextContains('#basic_details_div > summary-subsection > div > div.section-subtext > div:nth-child(5) > span', '11%');
                e2eSpecHelper.verifyTextContains('#basic_details_div > summary-subsection > div > div.section-subtext > div:nth-child(7) > span', 'Singapore');

                /*Verify dbs % details*/
                e2eSpecHelper.verifyTextContains('#dbs_per_details_div > summary-subsection > div > div.section-subtext > div:nth-child(2) > span', '22%');
                e2eSpecHelper.verifyTextContains('#dbs_per_details_div > summary-subsection > div > div.section-subtext > div:nth-child(5) > span', 'SGD 333.00');

                /*Verify Application Details*/
                e2eSpecHelper.verifyTextContains('#application_details_div > summary-subsection > div > div.section-subtext > div:nth-child(2) > span', 'abc123');
                e2eSpecHelper.verifyTextContains('#application_details_div > summary-subsection > div > div.section-subtext > div:nth-child(8) > span', 'app details remarks test');
            });
        });

        if (collateralType !== 'Guarantee') {
            describe('should verify specific details data on summary page', function () {
                it('should enter specific details data to be verified on Summary tab', function () {
                    e2eSpecHelper.scrollToTheTop();
                    e2eSpecHelper.sleepBrowser(2000);
                    if (collateralType === 'Deposit') {
                        summary.specificDetailsTab.click();
                        /*/!*Enter deposit specific Details data to view on Summary Page*!/*/
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.addSpecificDetailsBtn.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.deposit.fcfdDropdown.click();
                        summary.specificDetails.deposit.fcfdSearch('bank1');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.deposit.depositAcDropdown.click();
                        summary.specificDetails.deposit.depositAcSearch('123');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.deposit.depositNoInputBox.click();
                        summary.specificDetails.deposit.depositNoInputValue('DN1');
                        e2eSpecHelper.verifyPresence('#show-specific-details-fields');
                        e2eSpecHelper.verifyPresence('.disabled-container');
                        summary.specificDetails.deposit.earmarkAmount.click();
                        summary.specificDetails.deposit.earmarkAmountInput('10k');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.deposit.earmarkReasonTextarea.click();
                        summary.specificDetails.deposit.earmarkReasonInput('Earmark Test');
                        summary.specificDetails.deposit.remarksTextarea.click();
                        summary.specificDetails.deposit.remarksTextareaInput('Test Remarks');
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.specificDetails.deposit.saveFormBtn.click();
                        browser.waitForAngular('wait for toast message');
                        e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully Added.');
                        e2eSpecHelper.verifyPresence('.k-grid');
                        e2eSpecHelper.verifyPresence('.warning-box');
                        e2eSpecHelper.sleepBrowser(3000);
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.summaryTabId.click();
                        e2eSpecHelper.sleepBrowser(2000);
                    }
                    if (collateralType === 'Aircraft') {
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.chargeTabId.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.tabNavPrevId.click();
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.tabNavPrevId.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetailsTab.click();
                        /*/!*Enter aircraft specific Details data to view on Summary Page*!/*/
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.addSpecificDetailsBtn.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.aircraft.airframeMakeDropdown.click();
                        summary.specificDetails.aircraft.airframeMakeSearch('AIRFRAME001');
                        e2eSpecHelper.sleepBrowser(1000);
                        e2eSpecHelper.verifyPresence('.form-group-sub-fields');
                        summary.specificDetails.aircraft.airframeModelDropdown.click();
                        summary.specificDetails.aircraft.airframeModelSearch('AIRFRMODEL002');
                        summary.specificDetails.aircraft.selectDropdownList.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.aircraft.airframeSerialInputBox.click();
                        summary.specificDetails.aircraft.airframeSerialInput('ARFSN001');
                        summary.specificDetails.aircraft.engineMake.click();
                        summary.specificDetails.aircraft.engineMakeInput('ENGINEMK01');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.aircraft.engineModel.click();
                        summary.specificDetails.aircraft.engineModelInput('ENGINEMD01');
                        summary.specificDetails.aircraft.engineSno.click();
                        summary.specificDetails.aircraft.engineSnoInput('ENGINESN01');
                        summary.specificDetails.aircraft.fusulageNo.click();
                        summary.specificDetails.aircraft.fusulageNoInput('FUSN01');
                        summary.specificDetails.aircraft.tailNo.click();
                        summary.specificDetails.aircraft.tailNoInput('TN01');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.aircraft.engineRemarksInput.click();
                        summary.specificDetails.aircraft.engineRemarksTextarea('Text Remarks');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.aircraft.mfdYear.click();
                        summary.specificDetails.aircraft.mfdYearInput('1920');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.aircraft.purchasedDateIcon.click();
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.specificDetails.aircraft.purchasedDateSelect.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.aircraft.manufacturerName.click();
                        summary.specificDetails.aircraft.manufacturerNameInput('Marissa');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.aircraft.operatorName.click();
                        summary.specificDetails.aircraft.operatorNameInput('Marissa');
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.specificDetails.aircraft.saveFormBtn.click();
                        browser.waitForAngular('wait for toast message');
                        e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully Added.');
                        e2eSpecHelper.verifyPresence('.k-grid');
                        e2eSpecHelper.sleepBrowser(3000);
                        summary.chargeTabId.click();
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.summaryTabId.click();
                    }
                    if (collateralType === 'Vehicle') {
                        summary.specificDetailsTab.click();
                        /*/!*Enter vehicle specific Details data to view on Summary Page*!/*/
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.addSpecificDetailsBtn.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.vehicleMakeDropdown.click();
                        summary.specificDetails.vehicle.vehicleMakeSearch('Vehicle Make 001');
                        e2eSpecHelper.sleepBrowser(2000);
                        e2eSpecHelper.verifyPresence('.form-group-sub-fields');
                        summary.specificDetails.vehicle.vehicleTypeDropdown.click();
                        summary.specificDetails.vehicle.vehicleTypeSearch('Vehicle Type 001');
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.specificDetails.vehicle.vehicleModelDropdown.click();
                        summary.specificDetails.vehicle.vehicleModelSearch('Vehicle Model 001');
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.specificDetails.vehicle.vehicleRegistrationNumberInputBox.click();
                        summary.specificDetails.vehicle.vehicleRegistrationNumberInput('0123');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.chassisNumberInputBox.click();
                        summary.specificDetails.vehicle.chassisNumberInput('CHS123');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.engineMakeInputBox.click();
                        summary.specificDetails.vehicle.engineMakeInput('EM045');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.engineMakeInputBox.click();
                        summary.specificDetails.vehicle.engineMakeInput('ENSN567');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.mfdYear.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.mfdYearSelect.click();
                        summary.specificDetails.vehicle.purchaseDate.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.purchaseDateSelect.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.regAuthority.click();
                        summary.specificDetails.vehicle.regAuthoritySearch('i');
                        summary.specificDetails.vehicle.selectDropdownList.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.regState.click();
                        summary.specificDetails.vehicle.regStateSearch('a');
                        summary.specificDetails.vehicle.selectDropdownList.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.oldRegistrationInputBox.click();
                        summary.specificDetails.vehicle.oldRegistrationInput('678');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.regCountry.click();
                        summary.specificDetails.vehicle.regCountrySearch('ACRA');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.disposalDate.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.disposalDateSelect.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.trackStatusDropdown.click();
                        summary.specificDetails.vehicle.trackStatusSearch('TRS001');
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.trackStatusDate.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.trackStatusDateSelect.click();
                        e2eSpecHelper.sleepBrowser(1000);
                        summary.specificDetails.vehicle.saveFormBtn.click();
                        browser.waitForAngular('wait for toast message');
                        e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully Added.');
                        e2eSpecHelper.verifyPresence('.k-grid');
                        e2eSpecHelper.sleepBrowser(3000);
                        summary.chargeTabId.click();
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.summaryTabId.click();
                    }
                    if (collateralType === 'Vessel') {
                        summary.specificDetailsTab.click();
                        /*/!*Enter vessel specific Details data to view on Summary Page*!/*/
                        /*TODO*/
                        summary.chargeTabId.click();
                        e2eSpecHelper.sleepBrowser(2000);
                        summary.summaryTabId.click();
                    }
                });

                it('should verify specific details on summary page', function () {
                    e2eSpecHelper.sleepBrowser(3000);
                    e2eSpecHelper.verifyPresence('#specific-details-section');
                });
            });
        }

        describe('should verify beneficiary data on summary page', function () {
            it('should add beneficiary data to be verified on Summary tab', () => {
                e2eSpecHelper.scrollToTheTop();
                e2eSpecHelper.sleepBrowser(2000);
                if (collateralType === 'Guarantee' || collateralType === 'Deposit') {
                    summary.beneficiaryTabId.click();
                } else {
                    summary.chargeTabId.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.tabNavPrevId.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.tabNavPrevId.click();
                }
                e2eSpecHelper.sleepBrowser(1000);
                summary.beneficiaryDetailsPage.addBeneficiaryBtnForPopDialog.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.beneficiaryDetailsPage.beneficiaryIdDropdown.click();
                summary.beneficiaryDetailsPage.beneficiaryIdDropdownValue('gcin');
                e2eSpecHelper.sleepBrowser(1000);
                summary.beneficiaryDetailsPage.beneficiaryIdDropdownResult.click();
                summary.beneficiaryDetailsPage.beneficiarySaveBtn.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of beneficiary details has been successfully added.');
                e2eSpecHelper.sleepBrowser(1000);
                summary.chargeTabId.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.summaryTabId.click();
            });

            it('should verify beneficiary details on summary page', function () {
                e2eSpecHelper.sleepBrowser(3000);
                if (collateralType !== 'Guarantee' && collateralType !== 'Deposit') {
                    /*Verify charge details*/
                    e2eSpecHelper.verifyPresence('#beneficiary-details-section');
                }
            });
        });

        describe('should verify ownership data on summary page', function () {
            it('should add ownership data to be verified on Summary tab', () => {
                e2eSpecHelper.scrollToTheTop();
                e2eSpecHelper.sleepBrowser(2000);
                if (collateralType === 'Guarantee' || collateralType === 'Deposit') {
                    summary.ownershipTabId.click();
                } else {
                    summary.chargeTabId.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.tabNavPrevId.click();
                }
                e2eSpecHelper.sleepBrowser(1000);
                summary.ownershipDetailsPage.openOwnershipDetailsDialog.click();
                summary.ownershipDetailsPage.ownershipName.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.ownershipDetailsPage.ownershipNameDropdownValue('GCIN');
                e2eSpecHelper.sleepBrowser(2000);       // the interval very much needed - DONOT DELETE
                summary.ownershipDetailsPage.ownershipNameDropdownResult.click();
                summary.ownershipDetailsPage.ownershipPercentage.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.ownershipDetailsPage.ownershipPercentageInput('23.547');
                summary.ownershipDetailsPage.saveOwnershipDetails.click();
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of ownership details has been successfully added.');
                summary.summaryTabId.click();
            });

            it('should verify ownership details on summary page', function () {
                e2eSpecHelper.sleepBrowser(3000);
                if (collateralType !== 'Guarantee' && collateralType !== 'Deposit') {
                    /*Verify charge details*/
                    e2eSpecHelper.verifyPresence('#ownership-details-section');
                }
            });
        });

        describe('should verify charge data on summary page', function () {
            it('should add charge data to be verified on Summary tab', () => {
                e2eSpecHelper.scrollToTheTop();
                e2eSpecHelper.sleepBrowser(2000);
                if (collateralType !== 'Guarantee' && collateralType !== 'Deposit') {
                    summary.chargeTabId.click();
                    e2eSpecHelper.buttonClick('.clsBtnSecondary');
                    summary.chargeDetailsPage.natureOfChargesDropDown.click();
                    summary.chargeDetailsPage.natureOfChargesDropDownValue('s');
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.chargeDetailsPage.chargeRankDropDown.click();
                    summary.chargeDetailsPage.chargeRankDropDownValue('1');
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.chargeDetailsPage.chargeAmountInput.click();
                    summary.chargeDetailsPage.chargeAmountInputValue('123k');
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.chargeDetailsPage.filingDateIcon.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.chargeDetailsPage.filingDateSelect.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.chargeDetailsPage.receiptDateIcon.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.chargeDetailsPage.receiptDateSelect.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    e2eSpecHelper.buttonClick('#save_charge_details_btn');
                    e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of charge details has been successfully added.');
                    e2eSpecHelper.sleepBrowser(3000);
                }
                summary.summaryTabId.click();
            });

            it('should verify charge details on summary page', function () {
                e2eSpecHelper.sleepBrowser(3000);
                if (collateralType !== 'Guarantee' && collateralType !== 'Deposit') {
                    /*Verify charge details*/
                    e2eSpecHelper.verifyPresence('#charge-details-section');
                }
            });
        });

        if (collateralType !== 'Guarantee' && collateralType !== 'Deposit') {
            describe('should verify inspection data on summary page', function () {
                it('should add inspection data to be verified on Summary tab', () => {
                    e2eSpecHelper.scrollToTheTop();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.inspectionTabId.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.addIInspectionBtnForPopDialog.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.inspectionTypeDropdown.click();
                    summary.inspectionDetailsPage.inspectionTypeDropdownValue('Market');
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.inspectionTypeDropdownResult.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.inspectionEmployeeId.click();
                    summary.inspectionDetailsPage.inspectionEmployeeIdValue('TestEmployee123');
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.firstInspectionDate.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.dateWeekend.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.latestInspectionDate.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.dateToday.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.inspectionFrequencyDropdown.click();
                    summary.inspectionDetailsPage.inspectionFrequencyDropdownValue('CUS');
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.inspectionFrequencyDropdownResult.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    summary.inspectionDetailsPage.inspectionSaveBtn.click();
                    e2eSpecHelper.sleepBrowser(1000);
                    e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of inspection details has been successfully added.');
                    summary.summaryTabId.click();
                });

                it('should verify inspection details on summary page', function () {
                    e2eSpecHelper.sleepBrowser(3000);
                    if (collateralType !== 'Guarantee' && collateralType !== 'Deposit') {
                        /*Verify charge details*/
                        e2eSpecHelper.verifyPresence('#inspection-details-section');
                    }
                });
            });
        }

        describe('should verify document data on summary page', function () {
            it('should add document data to be verified on Summary tab', () => {
                e2eSpecHelper.scrollToTheTop();
                e2eSpecHelper.sleepBrowser(2000);
                summary.documentIdOnTab.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.documentDetailsPage.documentBtnForPopDialog.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.documentDetailsPage.documentCodeId.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.documentDetailsPage.documentDateIcon.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.documentDetailsPage.dateToday.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.documentDetailsPage.documentDueDate.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.documentDetailsPage.dateToday.click();
                summary.documentDetailsPage.documentExpirationDate.click();
                e2eSpecHelper.sleepBrowser(2000);
                summary.documentDetailsPage.dateWeekend.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.documentDetailsPage.documentCodeId.click();
                summary.documentDetailsPage.documentCodeSearch('d');
                summary.documentDetailsPage.documentDropDownResult.click();
                e2eSpecHelper.sleepBrowser(1000);
                summary.documentDetailsPage.documentCustodianSearch('s');
                summary.documentDetailsPage.documentDropDownResult.click();
                summary.documentDetailsPage.saveFormBtn.click();
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyPresence('.k-grid');
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully Added.');
                summary.summaryTabId.click();
            });

            it('should verify document details on summary page', function () {
                e2eSpecHelper.sleepBrowser(3000);
                e2eSpecHelper.verifyPresence('#document-details-section');
            });
        });

        if (collateralType !== 'Guarantee' && collateralType !== 'Deposit') {
            describe('should verify insurance data on summary page', function () {
                it('should add insurance data to be verified on Summary tab', () => {
                    e2eSpecHelper.scrollToTheTop();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.insuranceTabId.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.insuranceDetailsPage.insuranceBtnForPopDialog.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.insuranceDetailsPage.insuranceTypeId.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.insuranceDetailsPage.insuranceCodeSearch('M');
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.insuranceDetailsPage.selectDropdownList.click();
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.insuranceDetailsPage.insurancePolicyNoInputValue('XYZ1');
                    e2eSpecHelper.sleepBrowser(2000);
                    summary.insuranceDetailsPage.saveFormBtn.click();
                    e2eSpecHelper.sleepBrowser(5000);
                    summary.summaryTabId.click();
                });

                it('should verify insurance details on summary page', function () {
                    e2eSpecHelper.sleepBrowser(3000);
                    if (collateralType !== 'Guarantee' && collateralType !== 'Deposit') {
                        /*Verify charge details*/
                        e2eSpecHelper.verifyPresence('#insurance-details-section');
                    }
                });
            });
        }
    });
};
