import {ElementRef} from '@angular/core';
// import { MockElementRef } from '../../common/multi-select-component/multi-select.component.spec';
import {CommonModule} from '@angular/common';
import {PopupDialogOnleaveModule} from '../../common/popupdialog-onleave/popupdialog-onleave.module';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserModule} from '@angular/platform-browser';
import {CollateralsListService} from './collaterals-list.component.service';
import {GridModule} from '@progress/kendo-angular-grid';
import {DialogModule} from '@progress/kendo-angular-dialog';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {InputsModule} from '@progress/kendo-angular-inputs';
import {FormBuilder, ReactiveFormsModule} from '@angular/forms';
import {AutoCompleteModule, DropDownsModule} from '@progress/kendo-angular-dropdowns';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {CommonUIModule} from '../../common/commonUI.module';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';
import {ToggleButtonModule} from '../../common/toggle-button/toggle-button.module';
import {IntlModule} from '@progress/kendo-angular-intl';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {CollateralsListComponent} from './collaterals-list.component';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {CounterpartyDetailsModule} from '../../shared/counterparty-details/counterparty-details.module';
import {CustomPanelModule} from '../../common/custom-panel/custom-panel.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {Observable} from 'rxjs/Rx';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {CollateralSummaryService} from '../collateral-summary/collateral-summary.service';
import {CollateralService} from '../collateral.service';
import {MockCollateralData} from '../collateral-summary/collateral-summary-mock-data';
import {
    COLLATERAL_CODES_TYPES_DATA,
    DEPOS_TYPE_COLLATERALS,
    GUARN_TYPE_COLLATERALS,
    MOCK_CHECKED_DATA_FALSE,
    MOCK_CHECKED_DATA_TRUE,
    MOCK_COLLATERAL_CONFIG,
    MOCK_COLLATERAL_FINAL_DATA_WITH_TOTAL_ROW,
    MOCK_COLLATERALS_DATA_TO_SHOW_LIST,
    MOCK_GUARN_COLLATERAL_OBJ,
    MOCK_KEYS,
    MOCK_LIMIT_LIMITTYPEID,
    MOCK_LINKAGES
} from './collaterals-list.data';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {CreateCollateralModule} from 'app/collateral/create-collateral/create-collateral.module';
import {Collateral} from 'app/collateral/model/collateral';
import {
    collateralCodesData,
    collateralCodesDataFilter,
    collateralData
} from 'app/collateral/new-collateral/new-collateral.data';

class MockPartyDetailsService {
    temp = new Observable(observer => {
        observer.next({'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'});
    });

    subscribeToCPDetails(temp) {
        return Observable.of({label: 'Personal Leadership Centre Pte.Ltd', value: 'GCIN0000000'});
    }
}

class MockCollateralsListService {

    configurationForCollaterals = MOCK_COLLATERAL_CONFIG;

    getRateValues(from: string, to: string) {
        if (from === '' && to === '') {
            return Observable.throw({status: 404});
        } else {
            const data = [{'rate': 1}];
            return Observable.of(data);
        }
    }

    getStoredCurrencyRate(argFrom: string, argTo: string) {
        if (argFrom === '' && argTo === '') {
            return Observable.throw({status: 404});

        } else {
            const tempRate = [{'rate': 1}];
            return Observable.of(tempRate);
        }
    }

    getCurrency() {
        const data = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        return Observable.of(data);
    }

    getCollateralsInfo(collateralType: string, collateralId?: string): Observable<any> {
        switch (collateralType) {
            case 'GUARN':
                return Observable.of(GUARN_TYPE_COLLATERALS);
            case 'DEPOS':
                return Observable.throw(DEPOS_TYPE_COLLATERALS);
            default:
                return Observable.throw('Invalid Collateral Type');
        }
    }

    withdrawCollateral(collateralID: string, reasonCode: string, collateralType: string): Observable<any> {
        return Observable.of('success');
    }

    getCollateralTypes() {
        return Observable.of(COLLATERAL_CODES_TYPES_DATA);
    }

    getConfigurationsForCollaterals() {
        return Observable.of(MOCK_COLLATERAL_CONFIG);
    }

    getCollateralsList() {
        return Observable.of(GUARN_TYPE_COLLATERALS);
    }

    getLimitsByLimitTypeId(filter?: any) {
        return Observable.of(MOCK_LIMIT_LIMITTYPEID);
    }

    getCollateralInqRes() {
        return Observable.of({});
    }
}

class MockCollateralSummaryService {
    selectedCollateralType: any;
    masterCollateralListFromService: any = MOCK_GUARN_COLLATERAL_OBJ;
    collateralOperation: any;
    collateralConfigListFromService: any;


    rateConversionArray = [
        {'from': 'SGD', 'to': 'INR', 'rate': '48.7923883874116'},
        {'from': 'SGD', 'to': 'RUB', 'rate': '46.3951006773685'},
        {'from': 'SGD', 'to': 'PKR', 'rate': '76.5990042129452'},
        {'from': 'SGD', 'to': 'BOB', 'rate': '5.07598753337462'},
        {'from': 'SGD', 'to': 'SGD', 'rate': '1'}
    ];

    getStoredCurrencyRate(argFrom: string, argTo: string) {
        if (argFrom === '' && argTo === '') {
            return Observable.throw({status: 404});

        } else {
            const tempRate = [{'rate': 1}];
            return Observable.of(tempRate);
        }
    }

    getCurrency() {
        const data = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        return Observable.of(data);
    }

    getCollateralSummaryData() {
        return Observable.of(MockCollateralData);
    }

    getCollateralsList(collateralType: string, collateralApi?: string, filter?: any) {
        return Observable.of([collateralData]);
    }

    getRateValues(from: string, to: string) {
        if (from === '' && to === '') {
            return Observable.throw({status: 404});
        } else {
            const data = [{'rate': 10}];
            return Observable.of(data);
        }
    }
}

class MockCollateralService {
    /* getCollateralTypes() {
     return Observable.of(COLLATERAL_CODES_TYPES_DATA);
     } */

    _fb: FormBuilder = new FormBuilder();
    collateral: Collateral = new Collateral();
    tabSections: Array<String> = [];
    disableTab = false;

    getCollateralTypes() {
        return Observable.of(COLLATERAL_CODES_TYPES_DATA);
    }

    getCollateralCodes(filter: any) {
        if (filter === undefined) {
            return Observable.of(collateralCodesData);
        } else {
            return Observable.of(collateralCodesDataFilter);
        }
    }

    getDetailsForm() {
        return this._fb.group({
            collateralid: ['']
        });
    }

    getParticularsForm() {
        return this._fb.group({
            particularsList: ['']
        });
    }

    getBeneficiaryForm() {
        return this._fb.group({
            beneficiaryList: [this.collateral.beneficiaryDetails]
        });
    }

    clearCollateral() {

    }

    isCollateralLocked(collateralId: string, collateralType: string): Observable<any> {
        return Observable.of(false);
    }

    getCollateral() {
        return this.collateral;
    }

    getDocumentForm(document?: Document) {
        return this._fb.group({
            documentidList: []
        });
    }

    getChargeForm() {
        return this._fb.group({
            chargeList: ['']
        });
    }

    getApportionForm() {
        return this._fb.group({
            // apportionList: [CollateralReponse.CollateralValuationDetail, [Validators.required]]
        });
    }

    getOwnershipForm() {
        return this._fb.group({
            ownershipid: []
        });
    }

    postCollateral(collateral) {
        return Observable.of(collateralData);
    }

    getCollateralForm() {
        return this._fb.group({
            details: this.getDetailsForm(),
            beneficiary: this.getBeneficiaryForm(),
            charge: this.getChargeForm(),
            valuation: this.getApportionForm(),
            document: this.getDocumentForm(),
            ownership: this.getOwnershipForm(),
            particulars: this.getParticularsForm()
        });
    }

    getLinkages() {
        return Observable.of(null);
    }

    getLimitsByLimitTypeId(filter?: any) {
        return Observable.of(MOCK_LIMIT_LIMITTYPEID);
    }
}
export class MockElementRef extends ElementRef {
    nativeElement = {};

    constructor() {
        super(null);
    }
}

describe('Collateral List Component Test Cases', () => {

    let collateralsListComponent: CollateralsListComponent;
    let fixture: ComponentFixture<CollateralsListComponent>;
    let mockCollateralSummarySerivce: MockCollateralSummaryService;
    let mockCollateralService: CollateralService;

    const router = {
        navigate: jasmine.createSpy('navigate')
    };

    const MockActivatedRoute = {
        queryParams: Observable.of({'gcin': '', 'label': 'Label', 'ctype': ''})
    };

    beforeEach(async(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 2000000;
        TestBed.configureTestingModule({
            imports: [CommonModule, BrowserModule, GridModule, DialogModule,
                ButtonsModule, InputsModule, ReactiveFormsModule, AutoCompleteModule,
                DateInputsModule, CommonUIModule, PopupDialogModule, ToggleButtonModule,
                IntlModule, ClsSharedCommonModule, DropDownsModule, CounterpartyDetailsModule,
                CustomPanelModule, BrowserAnimationsModule, LoaderModule, CreateCollateralModule, PopupDialogOnleaveModule],
            declarations: [CollateralsListComponent],
            providers: [{provide: CounterPartyDetailsService, useClass: MockPartyDetailsService},
                {provide: CollateralSummaryService, useClass: MockCollateralSummaryService},
                {provide: CollateralsListService, useClass: MockCollateralsListService},
                {provide: ElementRef, useValue: new MockElementRef()},
                {provide: CollateralService, useClass: MockCollateralService},
                {provide: ActivatedRoute, useValue: MockActivatedRoute},
                {provide: Router, useValue: router}, FormBuilder]
        }).compileComponents();
    }));

    beforeEach(async(() => {
        fixture = TestBed.createComponent(CollateralsListComponent);
        collateralsListComponent = fixture.componentInstance;
        mockCollateralSummarySerivce = TestBed.get(CollateralSummaryService);
        mockCollateralService = TestBed.get(CollateralService);
        fixture.detectChanges();
    }));

    afterEach(() => {
        mockCollateralSummarySerivce = null;
        mockCollateralService = null;
        collateralsListComponent = null;
    });

    it('should create', (() => {
        expect(collateralsListComponent).toBeTruthy();
    }));

    it('should Withdraw Collateral when Remove icon clicked and confirmed ', () => {
        let selectedCollateral: any = undefined;
        let index: number = -1;
        let collateralType: string = 'OTWER';
        collateralsListComponent.collateralsDataToShowList = MOCK_COLLATERAL_FINAL_DATA_WITH_TOTAL_ROW;
        // negative check
        expect(collateralsListComponent.removeCollateralItem(1, selectedCollateral, index, collateralType)).toBeUndefined();
        selectedCollateral = MOCK_COLLATERAL_FINAL_DATA_WITH_TOTAL_ROW['GUARN'][0];
        index = 0;
        collateralType = 'GUARN';
        // Postive check  from GUARN
        spyOn(collateralsListComponent, 'removeCollateralFromGrid');
        collateralsListComponent.removeCollateralItem(1, selectedCollateral, index, collateralType);
        expect(collateralsListComponent.showPopupDialogForRemoveConfirmation).toBeTruthy();
        collateralsListComponent.selectedCollateral = selectedCollateral;
        collateralsListComponent.withdrawReason = 'Not Applicable';
        collateralsListComponent.confirmCollateralRemoval();
        expect(collateralsListComponent.removeCollateralFromGrid).toHaveBeenCalled();
        expect(collateralsListComponent.showPopupDialogForRemoveConfirmation).toBeFalsy();
    });

    it('should navigate to summary page based on Collateral id when collateral id is clicked', async(() => {
        // setup data
        let selectedCollateral: any = undefined;
        let index: number = -1;
        let collateralType: string = 'OTHER';
        this.masterCollateralList = MOCK_GUARN_COLLATERAL_OBJ;
        selectedCollateral = GUARN_TYPE_COLLATERALS[0];
        index = 0;
        collateralType = 'GUARN';
        collateralsListComponent.editSummaryCollateralItem(selectedCollateral, index, collateralType);
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'cid': 'aaaaaaa',
                'ctype': 'GUARN',
                'gcin': '',
                'label': 'Label'
            }
        };
        expect(router.navigate).toHaveBeenCalledWith(['./collateral'], navigationExtras);
    }));

    it('should start Edit workflow based on Collateral type when Edit Icon clicked', async(() => {
        // setup data
        let selectedCollateral: any = undefined;
        let index: number = -1;
        let collateralType: string = 'OTHER';

        // negative check
        expect(collateralsListComponent.editCollateralItem(selectedCollateral, index, collateralType)).toBeUndefined();
        // Postive check  from GUARN
        this.masterCollateralList = MOCK_GUARN_COLLATERAL_OBJ;
        selectedCollateral = GUARN_TYPE_COLLATERALS[0];
        index = 0;
        collateralType = 'GUARN';
        collateralsListComponent.editCollateralItem(selectedCollateral, index, collateralType);
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'cid': 'aaaaaaa',
                'ctype': 'GUARN',
                'gcin': '',
                'label': 'Label'
            }
        };
        expect(router.navigate).toHaveBeenCalledWith(['./collateral'], navigationExtras);
    }));

    it('should return column header when passing column position', async(() => {
        collateralsListComponent.COLLATERAL_CONFIG = MOCK_COLLATERAL_CONFIG;
        expect(collateralsListComponent.colPositionFun(1, 'GUARN', 'colHeader')).toEqual('Collateral Id');
    }));

    it('should return column field when passing column position', async(() => {
        collateralsListComponent.COLLATERAL_CONFIG = MOCK_COLLATERAL_CONFIG;
        expect(collateralsListComponent.colPositionFun(1, 'GUARN', 'fieldName')).toEqual('collateralId');
    }));

    it('should setUpCollateralsListPage on init when master collateral list is pre filled with data from collateral summary page', () => {
        mockCollateralSummarySerivce.masterCollateralListFromService = MOCK_GUARN_COLLATERAL_OBJ;
        mockCollateralSummarySerivce.collateralConfigListFromService = MOCK_COLLATERAL_CONFIG;
        collateralsListComponent.setUpCollateralsListPage();
        expect(collateralsListComponent.masterCollateralList).toEqual(MOCK_GUARN_COLLATERAL_OBJ);
    });

    it('should convert data for calling unitconver', async(() => {
        collateralsListComponent.unitConverter('Unit');
        expect(collateralsListComponent.showLoader).toBe(true);
        expect(collateralsListComponent.presentCurrencyUnit).toBe('Unit');
        expect(collateralsListComponent.currencyDivider).toBe(1);
        collateralsListComponent.unitConverter('Million');
        expect(collateralsListComponent.currencyDivider).toBe(1.0e+6);
        collateralsListComponent.unitConverter('Thousand');
        expect(collateralsListComponent.currencyDivider).toBe(1.0e+3);
    }));

    it('should convert data for calling selectionCurrencyChange', async(() => {
        collateralsListComponent.presentCurrencyFormat = 'Unit';
        collateralsListComponent.selectionCurrencyChange('SGD');
        expect(collateralsListComponent.showLoader).toBe(true);
        expect(collateralsListComponent.presentCurrencyFormat).toBe('SGD');

        collateralsListComponent.presentCurrencyUnit = 'Million';
        collateralsListComponent.selectionCurrencyChange('SGD');
        expect(collateralsListComponent.currencyFormatValue).toBe(3);

        collateralsListComponent.presentCurrencyUnit = 'Thousand';
        collateralsListComponent.selectionCurrencyChange('SGD');
        expect(collateralsListComponent.currencyFormatValue).toBe(3);

    }));

    it('should cover if condition for error message method ', () => {
        const error = {
            _body: '404 Not Found'
        };
        collateralsListComponent.ratesErrorMsgsList = [];
        collateralsListComponent.errorMsgShow(error);
        expect(collateralsListComponent.ratesErrorMsgsList[0]).toBe('404 Not Found');
    });

    it('should cover else condition for error message method ', () => {
        const error = undefined;
        collateralsListComponent.presentCurrencyFormat = 'RU1';
        collateralsListComponent.ratesErrorMsgsList = [];
        collateralsListComponent.errorMsgShow(error);
        expect(collateralsListComponent.showHeadErrorPanel).toBe(true);
    });

    it('should remove collateral from grid ', () => {
        collateralsListComponent.selectedCollateralIndex = 2;
        collateralsListComponent.collateralsDataToShowList = MOCK_COLLATERALS_DATA_TO_SHOW_LIST;
        collateralsListComponent.keys = MOCK_KEYS;
        spyOn(collateralsListComponent, 'changeBackGroundColor');
        collateralsListComponent.removeCollateralFromGrid(3, 'GUARN');
        expect(collateralsListComponent.collateralsDataToShowList['GUARN'].length).toBe(MOCK_COLLATERALS_DATA_TO_SHOW_LIST['GUARN'].length);
    });

    it('should test toggle checkbox functionality when user clicks on checkbox ', () => {
        const $event_true = {
            target: {checked: true}
        };
        collateralsListComponent.collateralsDataToShowList = MOCK_COLLATERALS_DATA_TO_SHOW_LIST;
        spyOn(collateralsListComponent, 'checkedBgColorChange');
        collateralsListComponent.toggleCheckBox(1, 'GUARN', $event_true);
        expect(collateralsListComponent.checkBoxSelectedAll['GUARN']['0']).toBe(MOCK_CHECKED_DATA_TRUE['0']);

        const $event_false = {
            target: {checked: false}
        };
        collateralsListComponent.collateralsDataToShowList = MOCK_COLLATERALS_DATA_TO_SHOW_LIST;
        //  spyOn(collateralsListComponent,'checkedBgColorChange');
        collateralsListComponent.toggleCheckBox(3, 'GUARN', $event_false);
        expect(collateralsListComponent.checkBoxSelectedAll['GUARN']['0']).toBe(MOCK_CHECKED_DATA_FALSE['0']);
    });

    it('should test collateral list data', () => {
        let list = [];
        list = MOCK_COLLATERALS_DATA_TO_SHOW_LIST['GUARN'];
        expect(collateralsListComponent.checkForCollateralListData(list)).toBe(true);
        list = [];
        expect(collateralsListComponent.checkForCollateralListData(list)).toBe(false);
    });

    it('should test miscellaneous functions from html', () => {

        collateralsListComponent.redirectToAddNewCollateral();
        expect(collateralsListComponent.createCollateral).toBe(true);

        collateralsListComponent.onCancel(true);
        expect(collateralsListComponent.createCollateral).toBe(true);

        collateralsListComponent.onCancel(false);
        expect(collateralsListComponent.createCollateral).toBe(false);

        const error = {
            status: 500
        };

        expect(collateralsListComponent.returnError(error)).toEqual(Observable.throw(new Error('500')));
        error['status'] = 404;
        expect(collateralsListComponent.returnError(error)).toEqual(Observable.throw(new Error('404')));
        error['status'] = 400;
        expect(collateralsListComponent.returnError(error)).toEqual(Observable.throw(new Error('400')));
        error['status'] = 409;
        expect(collateralsListComponent.returnError(error)).toEqual(Observable.throw(new Error('409')));

        collateralsListComponent.selectionChangeEventForWithdrawSelect('res1');
        expect(collateralsListComponent.withdrawReason).toEqual('res1');


    });

    it('should test check box checked event method when user clicks on checkbox for a particular collateral row', () => {
        const $event_true = {
            target: {checked: true}
        };
        collateralsListComponent.collateralsDataToShowList = MOCK_COLLATERALS_DATA_TO_SHOW_LIST;
        collateralsListComponent.checkBoxSelectedAll['GUARN'] = [true, true, true];
        spyOn(collateralsListComponent, 'checkedBgColorChange');
        collateralsListComponent.checkedEvent(1, $event_true, 'GUARN', 1);
        expect(collateralsListComponent.checkAllBox['GUARN']).toBe(true);
    });

    it('should navigate to facility linkage page o Add and Edit linkaegs', () => {
        // beneficiary: any, linkages: any, selectedCollateral: any, collateralType: string, flag: string)
        const selectedCollateral = GUARN_TYPE_COLLATERALS[0];
        const beneficiary = {value: 'TEST_BENEFICIARY', key: 'TEST'};
        const linkages = {'TEST': ['LIM01', 'LIM02']};
        const navigationExtras = {
            queryParams: {
                gcinLabel: 'TEST_BENEFICIARY', gcinValue: 'TEST', functionFlag: 'EDIT',
                source: 'CollateralList', gcin: '', label: 'Label'
            }
        };

        collateralsListComponent.COLLATERAL_CONFIG = MOCK_COLLATERAL_CONFIG;
        collateralsListComponent.getLinkage(beneficiary, linkages, selectedCollateral, 'GUARN', 'EDIT');

        expect(router.navigate).toHaveBeenCalledWith(['./facilityLinkage'], navigationExtras);

        collateralsListComponent.getLinkage(beneficiary, linkages, selectedCollateral, 'GUARN', 'ADD');
        navigationExtras.queryParams.functionFlag = 'ADD';
        expect(router.navigate).toHaveBeenCalledWith(['./facilityLinkage'], navigationExtras);
    });
    it('should get limits based on beneficiary', () => {
        const linkaegs = MOCK_LINKAGES;
        const obj: any = {linkages: null};
        collateralsListComponent.getLimitsBeneficiaryMap(linkaegs, obj);
        expect(obj.linkages).not.toBeNull();
    });
    it('should close popup dialog on click of close icon', () => {
        collateralsListComponent.closeEventFromPopupDialog(false);
        expect(collateralsListComponent.showPopupDialog).toBe(false);
    });
    it('should check canDeactive guard', () => {
        collateralsListComponent.backBtnPress = false;
        expect(collateralsListComponent.canDeactivate()).toBe(true);
        collateralsListComponent.popUpShow = true;
        collateralsListComponent.backBtnPress = true;
        expect(collateralsListComponent.canDeactivate()).toBe(true);
        collateralsListComponent.backBtnPress = true;
        collateralsListComponent.popUpShow = false;
        expect(collateralsListComponent.canDeactivate()).toBe(false);
    });

});

