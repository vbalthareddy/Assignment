import {DraftRecordService} from '../../../draftrecord/draft-record.service';
import {Component, HostListener, Input, OnInit, ViewEncapsulation} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {CollateralService} from '../../collateral.service';
import {CollateralSummaryService} from 'app/collateral/collateral-summary/collateral-summary.service';

import {ActivatedRoute, NavigationExtras, Params, Router} from '@angular/router';

import {ClaimDetails} from '../../model/collateral';

import {Observable} from 'rxjs/Observable';
import {InsuranceClaimsDetailsService} from './insurance-claim-details.service';

import {ToastsComponent} from '../../../shared/toasts/toasts.component';
import {InsuranceService} from '../../insurance/insurance.component.service';
import {CurrencyFormatPipe} from '../../../shared/currency-pipe/currency-pipe';
import {PlatformLocation} from '@angular/common';

@Component({
    selector: 'insurance-claim-details',
    templateUrl: './insurance-claim-details.html',
    encapsulation: ViewEncapsulation.Emulated,
    styleUrls: ['./insurance-claim-details.scss']
})

export class InsuranceClaimDetailsComponent implements OnInit {
    backBtnPress: boolean;
    showPopupDialog: boolean = false;
    popUpShow: boolean = false;
    titleDialogBox: string = 'Leave Form';
    actionTypeDialogBox: string = 'leaveForm';

    public insuranceClaimDetailsForm: FormGroup;
    validationMessages = {};
    functionFlag: string;
    insuranceListIndex: number;
    insurancePurchaser: string;
    insuranceType: string;
    insuranceTypeDescription: string;
    policyNumber: string;
    public maxDate: Date = new Date();
    public insuranceClaimStatus: any = {};
    public insuranceTypes: any = {};
    public insuranceClaimItemModel: ClaimDetails = new ClaimDetails();
    argToastMessageObject: any;
    toastsComponent: ToastsComponent = new ToastsComponent();
    public panelHeaderText: string = '';
    // validation flags section
    claimAmountValidate: boolean = false;
    settledAmountValidate: boolean = false;
    filingDateValidate: boolean = false;
    acknowldgementDateValidate: boolean = false;
    dateSequnceInValidValidation: boolean = false;
    claimStatusValidate: boolean = false;
    gcinCpValue: string;
    gcinDesc: string;
    ctype: string;
    claimDateValidate: boolean = false;

    @Input() gcin: { label?: any, value?: any } = {};

    constructor(private route: ActivatedRoute, private _fb: FormBuilder,
                private collateralService: CollateralService,
                private collateralSummaryService: CollateralSummaryService,
                private insuranceClaimDetailService: InsuranceClaimsDetailsService,
                private insuranceService: InsuranceService,
                private router: Router, private draftRecordService: DraftRecordService, location: PlatformLocation) {

        this.route.queryParams.subscribe((params: Params) => {
            this.functionFlag = params['functionFlag'];
            this.policyNumber = params['policyNumber'];
            this.gcinCpValue = params['gcin'];
            this.gcinDesc = params['label'];
            this.ctype = params['ctype'];
        });
        location.onPopState(() => {
            this.backBtnPress = true;
            location.pushState('', '', '');
        });
        this.collateralService.checkPopupDialogBox = false;
    }

    getInsuranceListIndexFromPolicyNumber(policyNumber: string): number {
        let insuranceListIndexFromPolicyNumber: number = -1;
        if (!policyNumber) {
            return -1;
        } else {
            const insuranceJSON = this.collateralService.collateral.insuranceDetails;
            const listLenghth = insuranceJSON.length;
            for (let i = 0; i < listLenghth; i++) {
                const obj = insuranceJSON[i];
                if (obj['policyDetails']['policyNo'] === policyNumber) {
                    insuranceListIndexFromPolicyNumber = i;
                    break;
                }
            }
        }
        return insuranceListIndexFromPolicyNumber;
    }

    ngOnInit() {
        this.initializeServices();
        this.insuranceListIndex = this.getInsuranceListIndexFromPolicyNumber(this.policyNumber);
        this.initializeInsuranceClaimdDetailsForm();
        this.populateInsuranceClaimdDetailsFromService();
        this.processFunctionFlag();

    }

    @HostListener('window:onbeforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        if (this.popUpShow) {
            return this.popUpShow;
        } else {
            if (this.backBtnPress) {
                this.titleDialogBox = 'Warning';
                this.actionTypeDialogBox = 'warning';
                this.backBtnPress = false;
            } else {
                this.titleDialogBox = 'Leave Form';
                this.actionTypeDialogBox = 'leaveForm';
            }
            this.showPopupDialog = true;
            return this.popUpShow;
        }
    }


    processFunctionFlag() {
        if (this.functionFlag === 'ADD') {
            this.panelHeaderText = 'Add Claim Details';
        }

        if (this.functionFlag === 'EDIT') {
            this.panelHeaderText = 'Update Claim Details';
        }

    }

    initializeInsuranceClaimdDetailsForm() {
        this.insuranceClaimDetailsForm = this._fb.group({
            claimedAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            claimedAmtCurrencyType: [],
            claimFilingDate: [null, [<any>Validators.required, <any>Validators.required]],
            claimAckDate: [null, [<any>Validators.required, <any>Validators.required]],
            comments: [''],
            settledAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            settledAmtCurrencyType: [],
            claimStatus: ['', [<any>Validators.required, <any>Validators.required]]
        });
    }

    initializeServices() {
        this.insuranceClaimDetailService.getInsuranceClaimStatus().subscribe(
            response => {
                this.insuranceClaimStatus = response;
            },
            error => {
                this.errorReturn(error);
            });

        this.insuranceService.getInsuranceTypesfromService().subscribe(
            response => {
                this.insuranceTypes = response;
                this.insuranceTypeDescription = this.insuranceTypes.find(temp => temp.code === this.insuranceType).description;
            },
            error => {
                this.errorReturn(error);
            });

    }

    populateInsuranceClaimdDetailsFromService() {
        let selectedInsuranceListItem: any = {};
        selectedInsuranceListItem = this.collateralService.collateral.insuranceDetails[this.insuranceListIndex];
        this.insurancePurchaser = selectedInsuranceListItem['insuranceCharge'];
        this.insuranceType = selectedInsuranceListItem['insuranceType'];
        this.populateInsuranceClaimItemModel(selectedInsuranceListItem['claimDetails']);
    }

    populateInsuranceClaimItemModel(claimDetails: any) {
        if (((typeof claimDetails) === 'undefined') || ((claimDetails.claimStatus) === '') || ((claimDetails.claimStatus) === null)) {
            return false;
        }

        if (((typeof claimDetails) !== 'undefined')) {
            this.insuranceClaimItemModel.claimAckDate = claimDetails['claimAckDate'];
            this.insuranceClaimItemModel.claimFilingDate = claimDetails['claimFilingDate'];
            this.insuranceClaimItemModel.claimStatus = claimDetails['claimStatus'];

            this.insuranceClaimItemModel.claimedAmt.value = claimDetails['claimedAmt']['value'];
            this.insuranceClaimItemModel.claimedAmt.ccy = claimDetails['claimedAmt']['ccy'];

            this.insuranceClaimItemModel.settledAmt.value = claimDetails['settledAmt']['value'];
            this.insuranceClaimItemModel.settledAmt.ccy = claimDetails['settledAmt']['ccy'];

            this.insuranceClaimItemModel.comments = claimDetails['comments'];

            this.populateInsuranceClaimForm();

            return true;
        }
    }

    populateModelwithFormValues() {

        this.insuranceClaimItemModel.claimAckDate = this.insuranceClaimDetailsForm.value;

        this.insuranceClaimItemModel.claimAckDate = this.insuranceClaimDetailsForm.controls['claimAckDate'].value;
        this.insuranceClaimItemModel.claimFilingDate = this.insuranceClaimDetailsForm.controls['claimFilingDate'].value;
        ;
        this.insuranceClaimItemModel.claimStatus = this.insuranceClaimDetailsForm.controls['claimStatus'].value;

        this.insuranceClaimItemModel.claimedAmt.value = CurrencyFormatPipe.transformAsNumberFromString(this.insuranceClaimDetailsForm.controls['claimedAmt'].value);
        this.insuranceClaimItemModel.claimedAmt.ccy = this.insuranceClaimDetailsForm.controls['claimedAmtCurrencyType'].value;

        this.insuranceClaimItemModel.settledAmt.value = CurrencyFormatPipe.transformAsNumberFromString(this.insuranceClaimDetailsForm.controls['settledAmt'].value);
        this.insuranceClaimItemModel.settledAmt.ccy = this.insuranceClaimDetailsForm.controls['settledAmtCurrencyType'].value;

        this.insuranceClaimItemModel.comments = this.insuranceClaimDetailsForm.controls['comments'].value;
    }

    populateInsuranceClaimForm() {
        (<FormControl>this.insuranceClaimDetailsForm.controls['claimedAmt'])
            .setValue(this.insuranceClaimItemModel.claimedAmt.value);
        (<FormControl>this.insuranceClaimDetailsForm.controls['claimedAmtCurrencyType'])
            .setValue(this.insuranceClaimItemModel.claimedAmt.ccy);

        (<FormControl>this.insuranceClaimDetailsForm.controls['settledAmt'])
            .setValue(this.insuranceClaimItemModel.settledAmt.value);
        (<FormControl>this.insuranceClaimDetailsForm.controls['settledAmtCurrencyType'])
            .setValue(this.insuranceClaimItemModel.settledAmt.ccy);

        (<FormControl>this.insuranceClaimDetailsForm.controls['claimFilingDate'])
            .setValue(new Date(this.insuranceClaimItemModel.claimFilingDate));

        (<FormControl>this.insuranceClaimDetailsForm.controls['claimAckDate'])
            .setValue(new Date(this.insuranceClaimItemModel.claimAckDate));

        (<FormControl>this.insuranceClaimDetailsForm.controls['comments'])
            .setValue(this.insuranceClaimItemModel.comments);
        (<FormControl>this.insuranceClaimDetailsForm.controls['claimStatus'])
            .setValue(this.insuranceClaimItemModel.claimStatus);
    }

    errorReturn(error: any) {
        if (error.status === 500) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 400) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 409) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 404) {
            return Observable.throw(new Error(error.status));
        }
    }

    submitInsuranceClaim(): boolean {
        this.popUpShow = true;
        this.canDeactivate();
        this.populateModelwithFormValues();
        if (!this.validateForm()) {
            return false;
        } else {
            this.updateInsuranceClaim();
            return true;
        }
    }

    updateInsuranceClaim(flag?: any) {
        this.collateralService.collateral.insuranceDetails[this.insuranceListIndex]['claimDetails']
            = JSON.parse(JSON.stringify(this.insuranceClaimItemModel));

        let argMsg: string = '';

        if (this.functionFlag === 'EDIT') {
            argMsg = 'Claim details for policy ' + this.policyNumber + ' has been succesfully updated.';
            this.collateralSummaryService.setMessageToken('INSURANCE_CLAIM', 'INSURANCE_MAIN', 'SHOW_TOAST', argMsg, new Date().toLocaleString());
        }

        if (this.functionFlag === 'ADD') {
            argMsg = 'Claim details for policy ' + this.policyNumber + ' has been succesfully added.';
            this.collateralSummaryService.setMessageToken('INSURANCE_CLAIM', 'INSURANCE_MAIN', 'SHOW_TOAST', argMsg, new Date().toLocaleString());
        }
        if (flag !== 'save') {
            this.navigateBack();
        }
    }

    validateForm(): boolean {
        let formValidFlag: boolean = true;
        const claimedAmount: string = this.insuranceClaimDetailsForm['controls']['claimedAmt'].value;
        const settledAmount: string = this.insuranceClaimDetailsForm['controls']['settledAmt'].value;
        const filingDate: string = this.insuranceClaimDetailsForm['controls']['claimFilingDate'].value;
        const acknowledgementDate: string = this.insuranceClaimDetailsForm['controls']['claimAckDate'].value;
        const claimSelectedStatus: string = this.insuranceClaimDetailsForm['controls']['claimStatus'].value;

        // Check for mandatory field Validity
        if (this.validateFilingdate()) {
            formValidFlag = formValidFlag && true;
        } else {
            formValidFlag = formValidFlag && false;
        }

        if (this.validateAcknowldgementDate()) {
            formValidFlag = formValidFlag && true;
        } else {
            formValidFlag = formValidFlag && false;
        }

        if (this.isValidNumber(claimedAmount)) {
            formValidFlag = formValidFlag && true;
            this.claimAmountValidate = false;
        } else {
            formValidFlag = formValidFlag && false;
            this.claimAmountValidate = true;
        }

        if (this.isValidNumber(settledAmount)) {
            formValidFlag = formValidFlag && true;
            this.settledAmountValidate = false;
        } else {
            formValidFlag = formValidFlag && false;
            this.settledAmountValidate = true;
        }
        // check if dates are  within range
        if (Date.parse(filingDate) <= Date.parse(acknowledgementDate)) {
            formValidFlag = formValidFlag && true;
            this.dateSequnceInValidValidation = false;

        } else {
            formValidFlag = formValidFlag && false;
            this.dateSequnceInValidValidation = true;
        }
        // Check if status has been selected
        if (this.validateClaimStatus()) {
            formValidFlag = formValidFlag && true;
        } else {
            formValidFlag = formValidFlag && false;
        }

        return formValidFlag;
    }

    navigateBack() {
        this.popUpShow = true;
        this.canDeactivate();
        this.collateralSummaryService.collateralOperation = 'INSURANCE_CLAIM';
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'cid': this.collateralService.collateral.collateralId,
                'ctype': this.ctype,
                'gcin': this.gcinCpValue,
                'label': this.gcinDesc
            }
        };
        this.router.navigate(['./collateral'], navigationExtras);
    }

    /*Function to validate Claimed Status */
    public validateClaimStatus(): boolean {
        const claimSelectedStatus: string = this.insuranceClaimDetailsForm['controls']['claimStatus'].value;
        if ((claimSelectedStatus) && (claimSelectedStatus !== '')) {
            this.claimStatusValidate = false;
        } else {
            this.claimStatusValidate = true;
        }

        return !this.claimStatusValidate;
    }

    /*Function to validate Claimed amount (because using Currency Component)*/
    validateClaimedAmount($event) {
        if (this.isValidNumber($event.amount)) {
            this.claimAmountValidate = false;
        } else {
            this.claimAmountValidate = true;
        }
    }

    /*Function to validate Claimed amount (because using Currency Component)*/
    validateSettleddAmount($event) {
        if (this.isValidNumber($event.amount)) {
            this.settledAmountValidate = false;
        } else {
            this.settledAmountValidate = true;
        }
    }

    isValidNumber(amt: string): boolean {
        if (amt === '') {
            return false;
        }
        const amtTest = String(amt).replace(/\,/g, '');

        if (!isNaN(Number(amtTest))) {
            return true;
        } else {
            return false;
        }
    }

    resetAllValidationFlags() {
        this.claimAmountValidate = false;
        this.settledAmountValidate = false;
    }

    validateFilingdate(): boolean {
        const claimAckDate1 = this.insuranceClaimDetailsForm['controls']['claimAckDate'].value;
        const claimFilingDate1 = this.insuranceClaimDetailsForm['controls']['claimFilingDate'].value;
        if (!this.isDate(this.insuranceClaimDetailsForm['controls']['claimFilingDate'].value)) {
            this.filingDateValidate = true;
            return false;
        } else {
            if (claimAckDate1) {
                if (claimFilingDate1 > claimAckDate1) {
                    this.acknowldgementDateValidate = true;
                    this.claimDateValidate = true;
                } else {
                    this.acknowldgementDateValidate = false;
                    this.claimDateValidate = false;
                }
            }
            this.filingDateValidate = false;
            return true;
        }
    }

    validateAcknowldgementDate(): boolean {
        const claimAckDate1 = this.insuranceClaimDetailsForm['controls']['claimAckDate'].value;
        const claimFilingDate1 = this.insuranceClaimDetailsForm['controls']['claimFilingDate'].value;
        if (!this.isDate(this.insuranceClaimDetailsForm['controls']['claimAckDate'].value)) {
            this.acknowldgementDateValidate = true;
            this.claimDateValidate = false;
            return false;
        } else {
            if (claimAckDate1) {
                if (claimFilingDate1 > claimAckDate1) {
                    this.acknowldgementDateValidate = true;
                    this.claimDateValidate = true;
                } else {
                    this.acknowldgementDateValidate = false;
                    this.claimDateValidate = false;
                }
            }
            return true;
        }
    }

    isDate(val): boolean {
        if ((val === '') || (!val)) {
            return false;
        }
        const d = new Date(val);
        return !isNaN(d.valueOf());
    }

    navigateToColl(value?: any) {
        this.showPopupDialog = false;
        this.popUpShow = true;
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'gcin': this.gcinCpValue,
                'label': this.gcinDesc
            }
        };
        if (value === 'save') {
            this.populateModelwithFormValues();
            this.updateInsuranceClaim('save');
            this.draftRecordService.saveCollateralAsDraft();
        }
        this.canDeactivate();
        if (this.collateralSummaryService.breadcrumbvalue) {
            this.router.navigate(['/collateralSummary'], navigationExtras);
        } else {
            this.router.navigate(['./collateralList'], navigationExtras);
        }
    }

    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.showPopupDialog = showPopupDialog;
    }
}
