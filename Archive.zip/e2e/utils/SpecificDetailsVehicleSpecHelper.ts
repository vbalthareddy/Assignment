import {E2eSpecHelper} from './E2eSpecHelper';
import {$, browser, protractor} from 'protractor';
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const specificDetails: any = {
    specificDetailsIdOnTab: $('#specific_details_tab'),
    addSpecificDetailsBtn: $('.add-specific-details-btn'),
    saveFormBtn: $('#save-form-btn'),
    updateFormBtn: $('#update-form-btn'),
    editIcon: $('#editIcon-0'),
    deleteIcon: $('#deleteIcon'),
    addDetailsBtn: $('#add-details-btn'),
    closeDialogIcon: $('.k-dialog-close'),
    selectDropdownList: $('.k-animation-container .k-list .k-item:last-child'),

    vehicleMakeDropdown: $('#vehicle-make-dropdown'),
    vehicleMakeSearch: (searchTerm: string): any => $('#vehicle-make-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

    vehicleTypeDropdown: $('#vehicle-type-dropdown'),
    vehicleTypeSearch: (searchTerm: string): any => $('#vehicle-type-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

    vehicleModelDropdown: $('#vehicle-model-dropdown'),
    vehicleModelSearch: (searchTerm: string): any => $('#vehicle-model-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

    vehicleRegistrationNumberInputBox: $('#registration-no'),
    vehicleRegistrationNumberInput: (inputTerm: string): any => $('#registration-no').sendKeys(inputTerm),
    chassisNumberInputBox: $('#chassis-no'),
    chassisNumberInput: (inputTerm: string): any => $('#chassis-no').sendKeys(inputTerm),
    vehicleRemarksTextarea: $('#vehicle-remarks.commentTextArea__input'),
    vehicleRemarksInput: (vehicleRemarksTextarea: string): any =>
        specificDetails.vehicleRemarksTextarea.sendKeys(vehicleRemarksTextarea),
    engineMakeInputBox: $('#engine-make'),
    engineMakeInput: (inputTerm: string): any => $('#engine-make').sendKeys(inputTerm),
    engineSnoInputBox: $('#engine-serial-no'),
    engineSnoInput: (inputTerm: string): any => $('#engine-serial-no').sendKeys(inputTerm),
    oldRegistrationInputBox: $('#old-registration-no'),
    oldRegistrationInput: (inputTerm: string): any => $('#old-registration-no').sendKeys(inputTerm),
    yearInputBox: $('#year-input'),
    yearInput: (inputTerm: string): any => $('#year-input').sendKeys(inputTerm),

    regAuthority: $('#reg-authority-dropdown'),
    regAuthoritySearch: (searchTerm: string): any => $('#reg-authority-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

    regState: $('#registration-state-dropdown'),
    regStateSearch: (searchTerm: string): any => $('#reg-authority-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

    regCountry: $('#reg-authority-dropdown'),
    regCountrySearch: (searchTerm: string): any => $('#country-reg-dropdown > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

    trackStatusDropdown: $('#tracking-status-dropdown'),
    trackStatusSearch: (searchTerm: string): any => $('#tracking-status-dropdown > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

    mfdYear: $('#mfd-year .input-group-addon'),
    mfdYearSelect: $('.btn.active'),
    purchaseDate: $('#purchase-date .input-group-addon'),
    purchaseDateSelect: $('.btn.active'),
    disposalDate: $('#disposal-date .input-group-addon'),
    disposalDateSelect: $('.btn.active'),
    trackStatusDate: $('#disposal-date .input-group-addon'),
    trackStatusDateSelect: $('.btn.active'),

    noRecordLink: $('#no-records-label-link'),

    addSubHirerLink: $('#addSubHirerLink')

};

exports.SpecificDetailsTestSuiteForVehicleCreateFlow = function () {
    describe('Specific_Details_Page', function () {

        it('should display Specific Details Tab on click', function () {
            browser.sleep(2000);
            specificDetails.specificDetailsIdOnTab.click();
            browser.waitForAngular();
            e2eSpecHelper.verifyTextContains('#specific_details_tab', 'Specific Details');
            e2eSpecHelper.verifyPresence('.tab-element-underline');
        });

        it('should check for No Record Found', function () {
            specificDetails.noRecordLink.click();
            specificDetails.closeDialogIcon.click();
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Specific Details Found');
            e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding specific details');
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should open popup dialog when clicked on Add Specific Details Button', function () {
            specificDetails.addSpecificDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Add Specific Details');
            e2eSpecHelper.verifyTextContains('.add-specific-details-btn', 'Add Specific Details');
        });

        it('should show validation errors when Specific Details fields are empty and clicked on save button', function () {
            specificDetails.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
        });

        it('validate Specific Details and save data to grid', function () {
            // close the popup
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.vehicleMakeDropdown.click();
            specificDetails.vehicleMakeSearch('Vehicle Make 001');
            e2eSpecHelper.sleepBrowser(2000);
            // specificDetails.selectDropdownList.click();
            e2eSpecHelper.verifyPresence('.form-group-sub-fields');

            specificDetails.vehicleTypeDropdown.click();
            specificDetails.vehicleTypeSearch('Vehicle Type 001');
            e2eSpecHelper.sleepBrowser(2000);
            // specificDetails.selectDropdownList.click();
            // e2eSpecHelper.sleepBrowser(1000);

            specificDetails.vehicleModelDropdown.click();
            specificDetails.vehicleModelSearch('Vehicle Model 001');
            e2eSpecHelper.sleepBrowser(2000);
            // specificDetails.selectDropdownList.click();
            // e2eSpecHelper.sleepBrowser(1000);

            specificDetails.vehicleRegistrationNumberInputBox.click();
            specificDetails.vehicleRegistrationNumberInput('0123');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.chassisNumberInputBox.click();
            specificDetails.chassisNumberInput('CHS123');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineMakeInputBox.click();
            specificDetails.engineMakeInput('EM045');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineMakeInputBox.click();
            specificDetails.engineMakeInput('ENSN567');
            e2eSpecHelper.sleepBrowser(1000);
            //check for date
            specificDetails.mfdYear.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.mfdYearSelect.click();
            specificDetails.purchaseDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.purchaseDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.regAuthority.click();
            specificDetails.regAuthoritySearch('i');
            specificDetails.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.regState.click();
            specificDetails.regStateSearch('a');
            specificDetails.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.oldRegistrationInputBox.click();
            specificDetails.oldRegistrationInput('678');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.regCountry.click();
            specificDetails.regCountrySearch('ACRA');
            // specificDetails.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(1000);
            // check for disposal date
            specificDetails.disposalDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.disposalDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.trackStatusDropdown.click();
            specificDetails.trackStatusSearch('TRS001');
            // specificDetails.selectDropdownList.click();
            // e2eSpecHelper.sleepBrowser(1000);
            // check for tracking status date
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.trackStatusDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.trackStatusDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.saveFormBtn.click();
            browser.waitForAngular('wait for toast message');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully Added.');
            e2eSpecHelper.verifyPresence('.k-grid');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should not show other fields for Engine Details When Engine Make is cleared', function () {
            e2eSpecHelper.verifyPresence('#editIcon-0');
            specificDetails.editIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineMakeInputBox.clear();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.form-group-sub-fields', false);
            specificDetails.closeDialogIcon.click();
            e2eSpecHelper.verifyPresence('.k-grid');
        });

        it('should update Specific Details', function () {
            e2eSpecHelper.verifyPresence('#editIcon-0');
            specificDetails.editIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Update Specific Details');
            specificDetails.vehicleRegistrationNumberInputBox.clear();
            specificDetails.vehicleRegistrationNumberInput('REG012');
            e2eSpecHelper.sleepBrowser(2000);
            specificDetails.updateFormBtn.click();
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should delete specific details item from grid when clicked on delete icon', function () {
            specificDetails.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully removed.');
        });
    });
};

exports.SpecificDetailsVehicleTestSuiteForEditFlow = function () {
    describe('Specific_Details_Page for edit flow', function () {

        it('should display Specific Details Tab on click', function () {
            browser.sleep(2000);
            specificDetails.specificDetailsIdOnTab.click();
            browser.waitForAngular();
            e2eSpecHelper.verifyTextContains('#specific_details_tab', 'Specific Details');
            e2eSpecHelper.verifyPresence('.tab-element-underline');
        });

        it('should check for No Record Found', function () {
            specificDetails.noRecordLink.click();
            specificDetails.closeDialogIcon.click();
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Specific Details Found');
            e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding specific details');
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should open popup dialog when clicked on Add Specific Details Button', function () {
            specificDetails.addSpecificDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Add Specific Details');
            e2eSpecHelper.verifyTextContains('.add-specific-details-btn', 'Add Specific Details');
        });

        it('should show validation errors when Specific Details fields are empty and clicked on save button', function () {
            specificDetails.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
        });

        it('validate Specific Details and save data to grid', function () {
            // close the popup
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.vehicleMakeDropdown.click();
            specificDetails.vehicleMakeSearch('Vehicle Make 001');
            e2eSpecHelper.sleepBrowser(2000);
            // specificDetails.selectDropdownList.click();
            e2eSpecHelper.verifyPresence('.form-group-sub-fields');

            specificDetails.vehicleTypeDropdown.click();
            specificDetails.vehicleTypeSearch('Vehicle Type 001');
            e2eSpecHelper.sleepBrowser(2000);
            // specificDetails.selectDropdownList.click();
            // e2eSpecHelper.sleepBrowser(1000);

            specificDetails.vehicleModelDropdown.click();
            specificDetails.vehicleModelSearch('Vehicle Model 001');
            e2eSpecHelper.sleepBrowser(2000);
            // specificDetails.selectDropdownList.click();
            // e2eSpecHelper.sleepBrowser(1000);

            specificDetails.vehicleRegistrationNumberInputBox.click();
            specificDetails.vehicleRegistrationNumberInput('0123');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.chassisNumberInputBox.click();
            specificDetails.chassisNumberInput('CHS123');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineMakeInputBox.click();
            specificDetails.engineMakeInput('EM045');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineMakeInputBox.click();
            specificDetails.engineMakeInput('ENSN567');
            e2eSpecHelper.sleepBrowser(1000);
            //check for date
            specificDetails.mfdYear.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.mfdYearSelect.click();
            specificDetails.purchaseDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.purchaseDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.regAuthority.click();
            specificDetails.regAuthoritySearch('i');
            specificDetails.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.regState.click();
            specificDetails.regStateSearch('a');
            specificDetails.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.oldRegistrationInputBox.click();
            specificDetails.oldRegistrationInput('678');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.regCountry.click();
            specificDetails.regCountrySearch('ACRA');
            // specificDetails.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(1000);
            // check for disposal date
            specificDetails.disposalDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.disposalDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.trackStatusDropdown.click();
            specificDetails.trackStatusSearch('TRS001');
            // specificDetails.selectDropdownList.click();
            // e2eSpecHelper.sleepBrowser(1000);
            // check for tracking status date
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.trackStatusDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.trackStatusDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.saveFormBtn.click();
            browser.waitForAngular('wait for toast message');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully Added.');
            e2eSpecHelper.verifyPresence('.k-grid');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should not show other fields for Engine Details When Engine Make is cleared', function () {
            e2eSpecHelper.verifyPresence('#editIcon-0');
            specificDetails.editIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineMakeInputBox.clear();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.form-group-sub-fields', false);
            specificDetails.closeDialogIcon.click();
            e2eSpecHelper.verifyPresence('.k-grid');
        });

        it('should update Specific Details', function () {
            e2eSpecHelper.verifyPresence('#editIcon-0');
            specificDetails.editIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Update Specific Details');
            specificDetails.vehicleRegistrationNumberInputBox.clear();
            specificDetails.vehicleRegistrationNumberInput('REG012');
            e2eSpecHelper.sleepBrowser(2000);
            specificDetails.updateFormBtn.click();
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should delete specific details item from grid when clicked on delete icon', function () {
            specificDetails.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully removed.');
        });
    });
};
