package com.dbs.cap.ct.batch.processor;

import com.dbs.cap.ct.batch.model.Corporate;
import com.dbs.cap.ct.batch.model.Customer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.util.StringUtils;

@Slf4j
public class ClsProcessor implements ItemProcessor<Corporate, Customer> {
    @Override
    public Customer process(Corporate corp) throws Exception {
        log.debug("Processing corp: " + corp.toString());
        Customer cust = new Customer();
        cust.setEntityId(corp.getCorpKey());
        cust.setEntityName(corp.getName());
        cust.setEntityType("CUST");
        cust.setCountryOfOperation(corp.getCorpKey().endsWith("DOA") ? "GPIN" : "GCIN");
        cust.setCountryOfIncorporation(corp.getCountryOfIncorporation());
        if(!StringUtils.isEmpty(corp.getBankBorrowerFlag()))
            cust.setBankCustomer(corp.getBankBorrowerFlag().equals("Y") ? true : false);
        log.debug("Processed customer: " + cust.toString());
        return cust;
    }
}
