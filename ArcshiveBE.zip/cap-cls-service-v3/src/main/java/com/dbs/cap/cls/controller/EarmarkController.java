package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.common.exception.KeyNotFoundException;
import com.dbs.cap.cls.service.EarmarkService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/cls/api/v1/")
@Api(value = "Services for Earmarks")
public class EarmarkController {
    @Autowired
    private EarmarkService earmarkService;

    @GetMapping(
            path = "earmark",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "Get earmark for given filter")
    public List<HashMap<String, Object>> getEarmarks(
            @RequestParam(value = ClsConstants.FILTER) String filter)
            throws KeyNotFoundException {
        return earmarkService.getEarmarks(filter);
    }

    @PutMapping(
            path = "earmark",
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "Update a earmark")
    public HashMap<String, Object> updateEarmark(
            @RequestBody HashMap<String, Object> earmarkRequest)
            throws KeyNotFoundException {
        return earmarkService.updateEarmark(earmarkRequest);
    }
}
