export * from './collateral.component';
export * from './collateral.route';
export * from './collateral.module';
// export * from './collateral.config';
