package com.dbs.cap.ct.batch;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@PropertySource("application-test.properties")
public class DSConfig {

  @Value("${spring.datasource.driverClassName}")
  private String driverClassName;
  @Value("${spring.datasource.url}")
  private String dbUrl;
  @Value("${spring.datasource.username}")
  private String dbUsrnm;
  @Value("${spring.datasource.password}")
  private String dbPass;

  @Bean
  DataSource dataSource() throws Exception {
    DriverManagerDataSource dataSource = new DriverManagerDataSource();
    dataSource.setDriverClassName(driverClassName);
    dataSource.setUrl(dbUrl);
    dataSource.setUsername(dbUsrnm);
    dataSource.setPassword(dbPass);
    return dataSource;
  }
}
