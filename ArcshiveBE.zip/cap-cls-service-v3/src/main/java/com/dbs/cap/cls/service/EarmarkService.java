package com.dbs.cap.cls.service;

import com.dbs.cap.cls.client.EarmarkClient;
import com.dbs.cap.cls.common.exception.KeyNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;

@Service
@Slf4j
public class EarmarkService {
    private static final String EARMARK_FILTER = "{\"where\":{\"earmarkId\":\"id\"}}";
    @Autowired
    private EarmarkClient earmarkClient;

    public List<HashMap<String, Object>> getEarmarks(String filter)
            throws KeyNotFoundException {
        if (StringUtils.isEmpty(filter)) {
            throw new KeyNotFoundException("Filter is required.");
        }
        log.debug("Get earmark filter {}", filter);
        return earmarkClient.getEarmarks(filter);
    }

    public HashMap<String, Object> updateEarmark(HashMap<String, Object> requestPayload) {
        HashMap<String, Object> map = new HashMap<>();
        if (CollectionUtils.isEmpty(requestPayload) || !requestPayload.containsKey("earmarkId") ||
                StringUtils.isEmpty(requestPayload.get("earmarkId").toString())) {
            throw new KeyNotFoundException("earmarkId is mandatory");
        } else {
            List<HashMap<String, Object>> list =
                    getEarmarks(EARMARK_FILTER.replaceAll("id", requestPayload.get("earmarkId").toString()));
            if (!CollectionUtils.isEmpty(list)) {
                map.put("earmarkId", list.get(0).get("earmarkId"));
                map.put("earmarkStatus", requestPayload.get("earmarkStatus"));
                map.put("wfStatus", requestPayload.get("wfStatus"));
                map.put("id", list.get(0).get("id"));
                map.put("_version", list.get(0).get("_version"));
            }
        }
        return earmarkClient.updateEarmark(map);
    }
}
