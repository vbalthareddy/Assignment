import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {Headers, Http, RequestOptions, Response, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {AppSettings} from './../../common/config/appsettings';

@Injectable()
export class CollateralGuarantorService {

    constructor(private http: Http) {
    }

    public getGuarantorIdDataService(data: any): Observable<any> {
        const urlToGetBeneficiaryId = AppSettings.apiBaseUrl + AppSettings.apiToGetCifId;
        const params: URLSearchParams = new URLSearchParams();
        params.set('access_token', null);
        const filter = {'order': 'code'};
        params.set('filter', JSON.stringify(filter));
        const headers = new Headers({'Content-Type': 'application/json'});
        const options = new RequestOptions({headers: headers});
        return this.http.post(urlToGetBeneficiaryId, data, {search: params})
            .map(
                res => res.json()
            )
            .catch(
                error => error.message || error
            );
    }

    addGuarantor(item: any): Observable<any> {
        const urlToPostBeneficiary = AppSettings.apiBaseUrl + AppSettings.apiCollateralCustomer;
        const customer = {
            'entityId': item.cifId,
            'entityType': 'C',
            'entityName': item.name
        };
        return this.http.post(urlToPostBeneficiary, customer)
            .map(onSuccessSuccess.bind(this))
            .catch(error => error.message || error);
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    public getGuaranteeType(filter?: any): Observable<any> {
        const urltoGetTypes = AppSettings.apiBaseUrl + AppSettings.guarantorTypes;
        const params: URLSearchParams = new URLSearchParams();
        params.set('access_token', null);
        if (!filter) {
            filter = {'order': 'code'};
        }
        params.set('filter', JSON.stringify(filter));
        const headers = new Headers({'Content-Type': 'application/json'});
        const options = new RequestOptions({headers: headers});
        return this.http.get(urltoGetTypes, {search: params})
            .map(
                res => res.json()
            )
            .catch(
                error => error.message || error
            );
    }
}
