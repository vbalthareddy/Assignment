import {CreateCollateralComponent} from 'app/collateral/create-collateral/create-collateral.component';
import {async, ComponentFixture, fakeAsync, TestBed} from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {CollateralService} from 'app/collateral/collateral.service';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {CollateralSummaryService} from 'app/collateral/collateral-summary/collateral-summary.service';
import {Observable} from 'rxjs/Rx';
import {MockCollateralData} from 'app/collateral/collateral-summary/collateral-summary-mock-data';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {Collateral} from 'app/collateral/model/collateral';
import {CollateralCode, CollateralType} from '../model';
import {
    collateralCodesData,
    collateralCodesDataFilter,
    collateralCodesTypesData,
    collateralData
} from 'app/collateral/new-collateral/new-collateral.data';
import {HttpModule} from '@angular/http';

class MockCollateralService {
    _fb: FormBuilder = new FormBuilder();
    collateral: Collateral = new Collateral();
    tabSections: Array<String> = [];
    selectedCollateralType: string;

    getCollateralCodes(filter: any, filterFlag: boolean) {
        if (filter === undefined) {
            return Observable.of(collateralCodesData);
        } else {
            return Observable.of(collateralCodesDataFilter);
        }
    }

    searchOnTypeAndFilter(collateralType: any, event: any) {
        return Observable.of(collateralCodesData);
    }

    getDetailsForm() {
        return this._fb.group({
            collateralid: ['']
        });
    }

    getParticularsForm() {
        return this._fb.group({
            particularsList: ['']
        });
    }

    getBeneficiaryForm() {
        return this._fb.group({
            beneficiaryList: [this.collateral.beneficiaryDetails]
        });
    }

    getCollateral() {
        return this.collateral;
    }

    getDocumentForm(document?: Document) {
        return this._fb.group({
            documentidList: []
        });
    }

    getChargeForm() {
        return this._fb.group({
            chargeList: ['']
        });
    }

    getApportionForm() {
        return this._fb.group({
            // apportionList: [CollateralReponse.CollateralValuationDetail, [Validators.required]]
        });
    }

    getOwnershipForm() {
        return this._fb.group({
            ownershipid: []
        });
    }

    getCollateralTypes() {
        return Observable.of(collateralCodesTypesData);
    }

    postCollateral(collateral) {
        return Observable.of(collateralData);
    }

    getCollateralForm() {
        return this._fb.group({
            details: this.getDetailsForm(),
            beneficiary: this.getBeneficiaryForm(),
            charge: this.getChargeForm(),
            valuation: this.getApportionForm(),
            document: this.getDocumentForm(),
            ownership: this.getOwnershipForm(),
            particulars: this.getParticularsForm()
        });
    }

    clearCollateral() {

    }
}

class MockCollateralSummaryService {
    rateConversionArray: any = [
        {
            from: 'SGD',
            to: 'INR',
            rate: 10
        }
    ];
    collateralOperation = 'Add';
    masterCollateralListFromService = {};
    collateralConfigListFromService = {};

    getCurrency() {
        const data = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        return Observable.of(data);
    }

    getCollateralSummaryData() {
        return Observable.of(MockCollateralData);
    }

    getRateValues(from: string, to: string) {
        if (from === '' && to === '') {
            return Observable.throw({status: 404});

        } else {
            const data = [{'rate': 10}];
            return Observable.of(data);
        }
    }

    getCollateralsList(collateralType: string, collateralApi?: string, filter?: any) {
        const objTemp = [
            {
                'CollateralValuationDetail': {
                    'collateralValue': {
                        'value': 10.00,
                        'ccy': 'SGD'
                    }
                }
            }];
        if (collateralType === '' && filter === '' && collateralApi === '') {
            return Observable.throw({status: 404});
        } else {
            return Observable.of(objTemp);
        }
    }

    getConfig() {
        const tempObj = {
            'GUARN': {
                'sequencePos': 1,
                'label': 'Guarantee',
                'description': 'Guarantee Description',
                'apiToHit': ''
            },
            'DEPOS': {
                'sequencePos': 2,
                'label': 'Guarantee',
                'description': 'Guarantee Description',
                'apiToHit': ''
            }
        };
        return Observable.of(tempObj);
    }
}

describe('CreateCollateralComponent', () => {
    let component: CreateCollateralComponent;
    let fixture: ComponentFixture<CreateCollateralComponent>;
    const router = {
        navigate: jasmine.createSpy('navigate')
    };
    let evt: any;

    const MockActivatedRoute = {
        queryParams: Observable.of({'gcin': 'GCIN00000', 'label': 'Label', 'ctype': 'GUARN', 'cid': 'COLL903'})
    };

    const MockNavigationExtras: NavigationExtras = {
        queryParams: {'gcin': 'GCIN00000', 'label': 'Label', 'ctype': 'GUARN', 'cid': 'COLL903'}
    };
    let mocksummarySerivce: MockCollateralSummaryService;
    let mockCollateralService: MockCollateralService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            declarations: [CreateCollateralComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [{provide: CollateralService, useClass: MockCollateralService}, {
                provide: Router,
                useValue: router
            },
                CounterPartyDetailsService,
                {provide: CollateralSummaryService, useClass: MockCollateralSummaryService},
                {provide: ActivatedRoute, useValue: MockActivatedRoute}, FormBuilder]
        })
            .compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CreateCollateralComponent);
        component = fixture.componentInstance;
        component.counterPartyDetails = {};
        component.counterPartyDetails.value = 'TEST';
        component.counterPartyDetails.label = 'TEST';
        component.createCollateralCustomForm = new FormGroup({});
        component.createCollateralCustomForm.addControl('selectedItem', new FormControl('', []));
        component.createCollateralCustomForm.addControl('selectedCode', new FormControl('', []));
        mocksummarySerivce = TestBed.get(CollateralSummaryService);
        mockCollateralService = TestBed.get(CollateralService);
    });

    afterEach(() => {
        mocksummarySerivce = null;
        mockCollateralService = null;
        component = null;
    });

    it('should create CreateCollateralComponent', () => {
        expect(component).toBeTruthy();
    });

    it('should Call ngOnInit and initialize', async(() => {
        component.ngOnInit();
        spyOn(component, 'initTypes');
        spyOn(component, 'initCodes');
        spyOn(component, 'subscribeCounterPartyDetail');
        expect(component.codePresent).toBe(false);
        expect(component.typePresent).toBe(false);
    }));

    it('on Type change undefined event', async(() => {
        evt = undefined;
        component.typeChange(evt);
        expect(component.collateralCodes[0].collateralCode).toBe('code01');
    }));

    it('on code change undefined event', async(() => {
        evt = undefined;
        component.codeChange(evt);
        expect(component.collateralTypes[0].collateralType).toBe('GUARN');
    }));

    it('on Type change valid event', async(() => {
        evt = {collateralType: 'GUARN'};
        component.typeChange(evt);
        console.log(component.collateralCodes[0]);
        expect(component.collateralCodes[0].collateralCode).toBe('code03');
    }));

    it('on code change valid event', async(() => {
        evt = {
            collateralCode: 'code03',
            collateralType: 'GUARN',
            parentModel: 'GUARNColtrlCode',
            _type: 'CollateralCodeMaster'
        };
        component.tempCollateralTypes = component.collateralTypes;
        component.codeChange(evt);
        expect(component.codePresent).toBe(false);
    }));

    it('on Collateral Code Select codePresent should be true', async(() => {
        component.onProceed({custom_ngModel: collateralCodesTypesData[0]}, {custom_ngModel: collateralCodesData[0]});
        expect(component.codePresent).toBe(false);
    }));

    it('on Collateral Code deselect codePresent should be false', async(() => {
        component.onProceed({custom_ngModel: collateralCodesTypesData[0]}, {custom_ngModel: undefined});
        expect(component.codePresent).toBe(true);
    }));

    it('on create collateral should navigate to newcollateral', async(() => {
        mockCollateralService.selectedCollateralType = 'GUARN';
        component.createCollateral(collateralData);
        expect(router.navigate).toHaveBeenCalledWith(['./collateral'], MockNavigationExtras);

    }));

    it('on proceed for valid type and code', fakeAsync(() => {
        const type = {value: {collateralType: 'GUARN'}};
        const code = {value: {collateralCode: 'code03', collateralType: 'GUARN'}};
        component.counterPartyDetails = {'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'};
        spyOn(component, 'createCollateral').and.returnValue(0);
    }));

    it('on cancel of pop up', async(() => {
        component.onCancel();
        component.selectedItem = <CollateralType>{};
        component.selectedCode = <CollateralCode>{};
        expect(component.codePresent).toBe(false);
    }));

    it('on Key in type', async(() => {
        component.keyInType('de');
        expect(component.collateralTypes[2].collateralType).toBe('DEPOS');
    }));

    it('on Key in code', async(() => {
        component.keyInCode('co');
        expect(component.collateralCodes[1].collateralCode).toBe('GAUCODE');
    }));

});
