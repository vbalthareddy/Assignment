import {Injectable} from '@angular/core';
import {AppSettings} from './../../common/config/appsettings';
import {Http, Response, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {ErrorResponse} from 'app/shared';
import {Collateral} from 'app/collateral/model/collateral';

@Injectable()
export class CollateralsListService {

    public ratesUrl = AppSettings.apiBaseUrl + AppSettings.apiToGetRates;
    public currencyUrl = AppSettings.apiBaseUrl + AppSettings.apiToGetCurrencyList;
    public urlToGetCollateralsUsingCounterPartyID = 'mock';
    public baseURLForCollateralCRUD = AppSettings.apiBaseUrl;
    public collateralApi = '';
    configurationForCollaterals: any;

    constructor(private http: Http) {

    }

    public getCurrency(): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const filter = {'fields': ['code', 'description'], 'order': 'code'};
        params.set('filter', JSON.stringify(filter));
        return this.http.get(this.currencyUrl, {search: params})
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    private extractData(res: Response) {
        const body = res.json();
        return body;
    }

    getCollateralsByCounterPartyGCID(counterpartyGCID: string) {
        return this.http.get(this.urlToGetCollateralsUsingCounterPartyID)
            .map(this.extractData)
            .catch(error => error.message || error);

    }

    getRateValues(fromCurreny: string, toCurrency: string): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const filter = '{"where":{"fromCurrency": "' + fromCurreny + '","toCurrency": "' + toCurrency + '"}}';
        params.set('filter', filter);
        return this.http.get(this.ratesUrl, {search: params})
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    getCollateralsInfo(collateralType: string, collateralId?: string): Observable<any> {
        let urlToGetCollateralsByTypeLocalVar = '';
        switch (collateralType) {
            case 'GUARN':
                this.collateralApi = AppSettings.apiGuarnCollaterals;
                break;
            case 'DEPOS':
                this.collateralApi = AppSettings.apiDeposCollaterals;
                break;
            default:
                return Observable.throw('Invalid Collateral Type');
        }

        if (!collateralId) {
            urlToGetCollateralsByTypeLocalVar = this.baseURLForCollateralCRUD + this.collateralApi;
        } else {
            urlToGetCollateralsByTypeLocalVar = this.baseURLForCollateralCRUD + this.collateralApi + '/' + collateralId;
        }

        return this.http.get(urlToGetCollateralsByTypeLocalVar)
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    getCollateralTypes(filter?: any): Observable<any> {
        // TODO: we need to use search filter
        const url = AppSettings.apiBaseUrl + AppSettings.apiGetcollateralTypes;
        const params: URLSearchParams = new URLSearchParams();
        if (filter) {
            params.set('filter', JSON.stringify(filter));
        }
        return this.http.get(url, {search: params})
            .map(onSuccessSuccess.bind(this))
            .catch(error => error.message || error);
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    withdrawCollateral(collateral: Collateral, reasonCode: string, collateralType: string): Observable<any> {

        let collateralApi;
        if (collateralType === 'GUARN') {
            collateralApi = AppSettings.apiGuarnCollaterals;
        } else if (collateralType === 'DEPOS') {
            collateralApi = AppSettings.apiDeposCollaterals;
        } else if (collateralType === 'AIRCF') {
            collateralApi = AppSettings.apiAircfCollaterals;
        } else if (collateralType === 'VEHIC') {
            collateralApi = AppSettings.apiVehicCollaterals;
        } else if (collateralType === 'BOATS') {
            collateralApi = AppSettings.apiBoatsCollaterals;
        } else {
            return Observable.throw('Invalid Collateral Type');
        }
        const url = AppSettings.apiBaseUrl + collateralApi;
        collateral.withdrawalDetail.withdraw = true;
        collateral.withdrawalDetail.reasonCode = reasonCode;
        collateral.withdrawalDetail.withdrawalDate = (new Date()).toISOString();
        return this.http.put(url, collateral)
            .map(onSuccessSuccess.bind(this))
            .catch(error => error.message || error);

        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    /*errorResponseFunction(error: any) {
        const ErrorResponse = <ErrorResponse>error;
        return Observable.throw(<ErrorResponse>ErrorResponse);
    }*/

    getCollateralsList(collateralType: string, collateralApi: string, filter?: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        if (filter) {
            params.set('filter', JSON.stringify(filter));
        }
        return this.http.get(AppSettings.apiBaseUrl + collateralApi, {search: params})
            .map(onSuccessSuccess.bind(this))
            .catch(error => error.message || error);
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    getConfigurationsForCollaterals(): Observable<any> {
        let configPath = '';
        configPath = '../assets/collaterals-config';
        return this.http.get(configPath)
            .map(res => res.json())
            .catch(error => error.message || error);
    }

    errorReturn(error: any) {
        if (error.status === 500) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 400) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 409) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 404) {
            return Observable.throw(new Error(error.status));
        }
    }
}
