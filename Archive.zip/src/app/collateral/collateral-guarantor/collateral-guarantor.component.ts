import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {CollateralGuarantorService} from './collateral-guarantor.service';
import {ToastsComponent} from '../../shared/toasts/toasts.component';
import {CollateralService} from '../collateral.service';
import {Observable} from 'rxjs/Observable';
import {OwnerShipList} from '../model/collateral';
import {TotalPercentageValidator} from './total-percentage-validator';
import {PercentageValidator} from '../../common/custom-validators/custom-percentage-validator';
import {CustomFormControl} from '../../common/custom-form-controls/custom-form-control';
@Component({
    selector: 'collateral-guarantor',
    templateUrl: './collateral-guarantor.component.html',
    styleUrls: ['./collateral-guarantor.component.scss']
})
export class CollateralGuarantorComponent implements OnInit {

    public addGuarantorDisable: boolean = true;
    public listItems: any = [];
    public showPopupDialog: boolean = false;
    public dialogTitleName: string = 'Add Guarantor Details';
    public guarantorForm: FormGroup;
    public gaurantorTypeInvalid: boolean = false;
    public idList: any[] = [];
    public divForNormalGrid: boolean = true;
    public guarantorGridData: any[] = [];
    public rowIndex: number;
    saveData: boolean = true;
    public sumOfPercentage: number = 0.00;
    public gridDisable: boolean = false;
    public showPopupDialogForConfirmation = false;
    public configureChangeAlertToastEnable: boolean = false;
    public dialogTitleNameConfirmation: string = 'Are You Sure To Reconfigure?';
    public guarantorSelectedValueNew: string = '';
    public guarantorSelectedValueOld: string = '';
    public guarantorIdInvalid: boolean = false;
    public guarantorValueErrDiv: boolean = false;
    public selectedGuarantorValue: string = '';
    @Input() showSummaryGrid: boolean = false;
    @Input() public collateralGuarantorForm: FormGroup;
    @Input() public showAddGuarantorBtn: boolean = true;
    public validateSelectedChangeValue: boolean = false;
    public onchangeSelectedValue: string = '';
    public errorValidatorMessage: string = 'Please make a selection';
    public errorValidatorMessageForPercentage: string = 'Please Enter Value';
    public guarantorPercentageValid: boolean = false;
    public percentageValidationCheck: boolean = false;
    public submitted: boolean = false;
    public argToastMessageObject: any;
    public disableGCINCIF: boolean = false;
    public duplicateValueCheck: any;
    public noDataFound: boolean = false;
    public errorMessage: boolean;
    toastsComponent: ToastsComponent = new ToastsComponent();
    public editPercentage: number = 0;
    public disablePercentageValue: boolean = false;
    public guarantorGridDataForHtml: any[] = [];
    public guaranteeList: any = [];
    showYesNoPrompt: boolean = false;
    guarantorDataToDelete: any;
    customFormGroup: FormGroup;

    constructor(private _fb: FormBuilder, private collateralGuarantorService: CollateralGuarantorService, private collateralService: CollateralService) {

    }

    ngOnInit() {
        this.getGuarantorTypes();
        this.intializeGuarantorForm();
        this.customForm();
        this.setGridData();
        this.customizeGuarantorGridForSummaryComp();
        this.validationReset();
    }

    getGuarantorTypes() {
        this.collateralGuarantorService.getGuaranteeType().subscribe(
            response => {
                const data = response;
                this.listItems = data.map(item => {
                    return item['code'];
                });
                this.guaranteeList = JSON.parse(JSON.stringify(this.listItems));
            },
            error => {
                this.errorMessage = true;
                return Observable.throw(new Error(error.status));
            }
        );

    }

    intializeGuarantorForm() {
        this.guarantorForm = this._fb.group({
            guarantorId: [''],
            guarantorDescription: [''],
            guarantorType: [''],
            gurantorName: [''],
            guaranteePercentage: ['', [PercentageValidator.percentageRequired]],
            gurantorRowStatus: [''],
            id: [''],
            _version: [' ']
        });
    }

    customForm() {
        this.customFormGroup = this._fb.group({
            guaranteeTypeCustomControl: [this.selectedGuarantorValue],
        });
    }

    setGridData() {
        this.collateralGuarantorForm.addControl('totalPercentageSum', new CustomFormControl('0.00', [TotalPercentageValidator.required]));
        (<CustomFormControl>this.collateralGuarantorForm.controls['totalPercentageSum']).type = 'text';
        (<CustomFormControl>this.collateralGuarantorForm.controls['totalPercentageSum']).label = 'Total Percentage';
        (<FormControl>this.collateralGuarantorForm.controls['totalPercentageSum'])
            .setValue(100.00);
        (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheckForJOINT'])
            .setValue(true);
        if (this.collateralService.getCollateral().ownershipDetails) {
            this.guarantorGridData = this.collateralService.getCollateral().ownershipDetails;
            this.guarantorGridDataForHtml = this.collateralService.getCollateral().ownershipDetails.filter(Data => Data.__row_status !== 'deleted');
            this.guarantorGridDataForHtml.map(item => {
                if (item['collateralOwnerShipPcnt'] === null) {
                    return item['collateralOwnerShipPcnt'] = 0;
                }
            });
            if (this.guarantorGridDataForHtml.length > 0) {
                this.selectedGuarantorValue = this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType;
                this.guarantorSelectedValueNew = this.selectedGuarantorValue;
                this.guarantorSelectedValueOld = this.selectedGuarantorValue;
                this.noDataFound = true;
                this.processFormItems();
                this.addGuarantorDisable = false;
                (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheck'])
                    .setValue(true);
                const colObj = this.collateralService.getCollateral();
                if (this.guarantorGridDataForHtml.length === 1 && ((colObj['LodgeCollateralTypeSpecificDetail']['guaranteeType'] === 'JOINT') || colObj['LodgeCollateralTypeSpecificDetail']['guaranteeType'] === 'JOINT&SEVERAL')) {
                    (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheckForJOINT'])
                        .setValue(false);
                } else {
                    (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheckForJOINT'])
                        .setValue(true);
                }
                (<FormControl>this.customFormGroup.controls['guaranteeTypeCustomControl'])
                    .setValue(this.selectedGuarantorValue);
                this.disableAddBtnForSingleGuaranteeType();
            }
        } else {
            this.guarantorGridData = [];
            this.guarantorGridDataForHtml = [];
        }
    }

    guarantorSelect(value: any) {
        if (value !== undefined && value !== '') {
            this.selectedGuarantorValue = value;
            this.onchangeSelectedValue = value;
            if (value !== this.guarantorSelectedValueOld && !(this.guarantorSelectedValueNew === '') && (this.guarantorGridDataForHtml.length > 0)) {
                this.addGuarantorDisable = true;
                this.configureChangeAlertToastEnable = true;
                this.gridDisable = true;
                this.validateSelectedChangeValue = true;
            } else {
                this.addGuarantorDisable = false;
                this.configureChangeAlertToastEnable = false;
                this.gridDisable = false;
                if (this.guarantorSelectedValueNew !== undefined) {
                    this.guarantorSelectedValueOld = value;
                    this.guarantorSelectedValueNew = value;
                }
            }
        } else {
            this.addGuarantorDisable = true;
        }
    }

    addGuarantor() {
        this.dialogTitleName = 'Add Guarantor';
        this.errorValidatorMessageForPercentage = 'Please enter value';
        this.showPopupDialog = true;
        this.saveData = true;
        this.editPercentage = 0.00;
        this.validationReset();
        this.guarantorForm.reset();
        this.disableGCINCIF = false;
        this.disablePercentageValue = false;
        if (this.selectedGuarantorValue === 'SEVERAL') {
            this.collateralGuarantorForm.addControl('totalPercentageSum', new CustomFormControl(this.sumOfPercentage, [TotalPercentageValidator.required]));
            (<CustomFormControl>this.collateralGuarantorForm.controls['totalPercentageSum']).type = 'boolean';
            (<CustomFormControl>this.collateralGuarantorForm.controls['totalPercentageSum']).label = 'Total Percentage';

        } else {
            (<FormControl>this.collateralGuarantorForm.controls['totalPercentageSum'])
                .setValue(100.00);
        }
        if (this.selectedGuarantorValue === 'JOINT' || this.selectedGuarantorValue === 'JOINT&SEVERAL' || this.selectedGuarantorValue === 'SINGLE') {
            this.disablePercentageValue = true;
            this.guarantorForm.controls['guaranteePercentage'].setValue(100);
            this.percentageChange(100);
        }
        (<FormControl>this.customFormGroup.controls['guaranteeTypeCustomControl'])
            .setValue(this.selectedGuarantorValue);
    }

    guarantorConfigure() {
        if ((this.guarantorGridData.length > 0) && (this.validateSelectedChangeValue) && (this.configureChangeAlertToastEnable)) {
            this.showPopupDialogForConfirmation = true;
        }
    }

    guarantorEditFunc(item: any, index: number): void {
        this.saveData = false;
        this.showPopupDialog = true;
        this.disableGCINCIF = true;
        this.dialogTitleName = 'Update Guarantor';
        this.errorValidatorMessageForPercentage = 'Please enter the correct % value with in range of 0.000%-100.000%';
        this.rowIndex = this.guarantorGridData.indexOf(item);
        this.validationReset();
        this.searchByGCINCIF(item.cifId);
        setTimeout(() => this.dataForEdit(item), 1000);
    }

    dataForEdit(item: any) {
        this.editPercentage = item['collateralOwnerShipPcnt'];
        this.saveData = false;
        this.showPopupDialog = true;
        if (this.idList !== undefined) {
            this.guarantorForm = this._fb.group({
                guarantorId: [item.cifId],
                guarantorDescription: [this.idList[0]['description']],
                guarantorType: [item.idType],
                gurantorName: [item.name],
                guaranteePercentage: [item.collateralOwnerShipPcnt, [PercentageValidator.percentageRequired]],
                gurantorRowStatus: [item.__row_status],
                id: [item.id],
                _version: [item._version]
            });
            this.duplicateValueCheck = this.guarantorForm.value;
        }
    }

    gaurantorRemoveItem(data: any, index: number) {
        this.rowIndex = index;
        this.showYesNoPrompt = true;
        this.guarantorDataToDelete = data;
    }

    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.showPopupDialog = showPopupDialog;
        this.saveData = true;
        this.guarantorForm.reset();
        this.editPercentage = 0.00;
        this.disableGCINCIF = false;
    }

    searchByGCINCIF(searchValue: string) {
        const bodyData = {'searchKeyword': searchValue};
        if (searchValue.length > 2) {
            this.idList = [];
            this.collateralGuarantorService.getGuarantorIdDataService(bodyData).subscribe(
                response => {
                    this.idList = response.map(function (item) {
                        return ({
                            'gcin': item.gcin,
                            'description': item.gcin + '   ' + this.modifiedNameFunc(item.description, item.gcin),
                            'type': item.type,
                            'name': this.modifiedNameFunc(item.description, item.gcin)
                        });

                    }, this);
                },
                error => {
                    this.errorMessage = true;
                    return Observable.throw(new Error(error.status));
                }
            );
        }
    }

    onSearchGCIDCIFSelect(event) {
        const dataObj = this.idList.find(item => item.description === event);
        if (!(dataObj === undefined)) {
            this.guarantorIdInvalid = false;
            this.guarantorForm.controls['guarantorType'].setValue(dataObj.type);
            this.guarantorForm.controls['guarantorId'].setValue(dataObj.gcin);
        } else {
            this.guarantorIdInvalid = true;
        }
    }

    submitGuarantorForm(data: any) {
        this.submitted = true;
        this.divForNormalGrid = true;
        this.errorValidatorMessage = 'Please make a selection';
        const errorFlag = this.validationCheck(data);
        if (errorFlag && !this.percentageValidationCheck && this.guarantorForm.valid) {
            this.updateGuarantorData(data, 'Save');
        }
    }

    updateGuarantorValue(data: any) {
        this.errorValidatorMessage = 'Please make a selection';
        const errorFlag = this.validationCheck(data, 'Update');
        if (errorFlag === true && this.guarantorForm.valid) {
            if (this.duplicateValueCheck.guarantorDescription !== data.guarantorDescription) {
                const dataObj = this.guarantorGridData.find(item => item.description === data.guarantorDescription);
                if (!(dataObj === undefined)) {
                    this.guarantorIdInvalid = true;
                } else {
                    this.updateGuarantorData(data, 'Update');
                }
            } else {
                this.updateGuarantorData(data, 'Update');
            }
        }
    }

    updateGuarantorData(data, functionType?: any) {
        if (functionType === 'Update') {
            const modifiedName = this.modifiedNameFunc(data.guarantorDescription, data.guarantorId);
            const guarantorItemModel = new OwnerShipList();
            guarantorItemModel.cifId = data['guarantorId'];
            guarantorItemModel.idType = data['guarantorType'];
            guarantorItemModel.name = modifiedName;
            guarantorItemModel.collateralOwnerShipPcnt = data['guaranteePercentage'];
            guarantorItemModel.id = data['id'];
            guarantorItemModel._version = data['_version'];
            if (data.gurantorRowStatus === undefined || data.gurantorRowStatus === null || data.gurantorRowStatus === '' || data.gurantorRowStatus === 'modified') {
                guarantorItemModel.__row_status = 'modified';
            } else if (data.gurantorRowStatus === 'added') {
                guarantorItemModel.__row_status = 'added';
            }
            this.sumOfPercentage = this.sumOfPercentage - this.editPercentage;
            this.guarantorGridData[this.rowIndex] = guarantorItemModel;
            this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                'A record of Guarantor details has been successfully Updated.',
                '', '');
            this.showPopupDialog = false;
            this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType = this.selectedGuarantorValue;
        } else if (functionType === 'Save') {
            const modifiedName = this.modifiedNameFunc(data.guarantorDescription, data.guarantorId);
            const dataObj = this.guarantorGridData.find(item => item.cifId === data.guarantorId);
            const guarantorItemModel = new OwnerShipList();
            guarantorItemModel.cifId = data['guarantorId'];
            guarantorItemModel.idType = data['guarantorType'];
            guarantorItemModel.name = modifiedName;
            guarantorItemModel.collateralOwnerShipPcnt = data['guaranteePercentage'];
            if (dataObj) {
                this.rowIndex = this.guarantorGridData.indexOf(dataObj);
                guarantorItemModel.__row_status = 'modified';
                guarantorItemModel.id = dataObj.id;
                guarantorItemModel._version = (dataObj['_version'] || dataObj['_version'] !== null) ? dataObj['_version'] : '';
                this.guarantorGridData[this.rowIndex] = guarantorItemModel;
            } else {
                guarantorItemModel.id = 'gurantor' + Math.random().toString(36).substr(2, 5) + Math.random().toString(36).substr(2, 5);
                guarantorItemModel.__row_status = 'added';
                guarantorItemModel._version = '';
                this.guarantorGridData.push(guarantorItemModel);
                this.collateralGuarantorService.addGuarantor(guarantorItemModel).subscribe(resdata => {
                }, error => {
                    this.errorMessage = true;
                });
            }
            this.guarantorIdInvalid = false;
            this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                'A record of Guarantor details has been successfully Added.',
                '', '');
            this.showPopupDialog = false;
            this.guarantorForm.reset();
            this.noDataFound = true;
            this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType = this.selectedGuarantorValue;

        } else if (functionType === 'DELETE') {
            const modifiedName = this.modifiedNameFunc(data.name, data.cifId);
            const guarantorItemModel = new OwnerShipList();
            guarantorItemModel.cifId = data['cifId'];
            guarantorItemModel.idType = data['idType'];
            guarantorItemModel.name = modifiedName;
            guarantorItemModel.collateralOwnerShipPcnt = data['collateralOwnerShipPcnt'];
            guarantorItemModel.id = data['id'];
            guarantorItemModel._version = this.guarantorGridData[this.rowIndex]['_version'];
            guarantorItemModel.__row_status = data.__row_status;
            if (guarantorItemModel.__row_status === 'modified' || guarantorItemModel.__row_status === undefined) {
                guarantorItemModel.__row_status = 'deleted';
                this.guarantorGridData[this.rowIndex] = guarantorItemModel;
            } else if (guarantorItemModel.__row_status === 'added') {
                this.guarantorGridData.splice(this.rowIndex, 1);
            }
            this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                'A record of Guarantor details has been successfully Deleted.',
                '', '');
        }
        this.guarantorGridDataForHtml = this.guarantorGridData.filter(Data => Data.__row_status !== 'deleted');
        this.collateralGuarantorForm.get('ownershipid').setValue(this.guarantorGridData);
        (<FormControl>this.customFormGroup.controls['guaranteeTypeCustomControl'])
            .setValue(this.selectedGuarantorValue);
        this.processFormItems();
        this.checkGridLength();
        this.disableAddBtnForSingleGuaranteeType();
    }

    checkGridLength() {
        if (this.guarantorGridDataForHtml.length === 0) {
            this.configureChangeAlertToastEnable = false;
            this.selectedGuarantorValue = '';
            this.guarantorSelectedValueNew = '';
            this.guarantorSelectedValueOld = '';
            this.noDataFound = false;
            this.addGuarantorDisable = true;
            this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType = '';
            (<FormControl>this.collateralGuarantorForm.controls['totalPercentageSum'])
                .setValue(100.00);
            (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheck'])
                .setValue(false);
            (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheckForJOINT'])
                .setValue(true);
            (<FormControl>this.customFormGroup.controls['guaranteeTypeCustomControl'])
                .setValue(this.selectedGuarantorValue);
        } else {
            (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheck'])
                .setValue(true);
            const colObj = this.collateralService.getCollateral();
            if (this.guarantorGridDataForHtml.length === 1 && ((colObj['LodgeCollateralTypeSpecificDetail']['guaranteeType'] === 'JOINT') || colObj['LodgeCollateralTypeSpecificDetail']['guaranteeType'] === 'JOINT&SEVERAL')) {
                (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheckForJOINT'])
                    .setValue(false);
            } else {
                (<FormControl>this.collateralGuarantorForm.controls['minGridLengthCheckForJOINT'])
                    .setValue(true);
            }
        }
    }

    private modifiedNameFunc(description: string, gcin: string): string {
        let tempName = description.replace(gcin, '');
        tempName = tempName.replace('()', '');
        return tempName;
    }

    getGridPercentageSum(): number {
        let gridSumOfGuarantorPercentage: number = 0.0;
        for (let i = 0; i < this.guarantorGridDataForHtml.length; i++) {
            gridSumOfGuarantorPercentage += parseFloat(this.guarantorGridDataForHtml[i]['collateralOwnerShipPcnt']);
        }
        gridSumOfGuarantorPercentage = this.roundNumber(gridSumOfGuarantorPercentage, 12);
        return gridSumOfGuarantorPercentage;
    }

    roundNumber(number, decimals): number {
        const newnumber = new Number(number + '').toFixed(parseInt(decimals));
        return parseFloat(newnumber);
    }

    processFormItems() {
        this.sumOfPercentage = 0.000;
        for (let i = 0; i < this.guarantorGridDataForHtml.length; i++) {
            this.sumOfPercentage = this.sumOfPercentage + parseFloat(this.guarantorGridDataForHtml[i]['collateralOwnerShipPcnt']);
        }
        this.sumOfPercentage = this.roundNumber(this.sumOfPercentage, 12);
        if (this.selectedGuarantorValue === 'SEVERAL') {
            (<FormControl>this.collateralGuarantorForm.controls['totalPercentageSum'])
                .setValue(this.sumOfPercentage);
        }
    }

    revertBackChangesForSelected() {
        this.addGuarantorDisable = false;
        this.selectedGuarantorValue = undefined;
        this.selectedGuarantorValue = this.guarantorSelectedValueOld;
        this.configureChangeAlertToastEnable = false;
        this.gridDisable = false;
        (<FormControl>this.customFormGroup.controls['guaranteeTypeCustomControl'])
            .setValue(this.selectedGuarantorValue);
        this.disableAddBtnForSingleGuaranteeType();
    }

    closeEventFromPopupDialogForConfirmation() {
        this.showPopupDialogForConfirmation = false;

    }

    revertBackChangesFromPopDialog() {
        this.showPopupDialogForConfirmation = false;
        this.configureChangeAlertToastEnable = false;
        this.selectedGuarantorValue = undefined;
        this.guarantorSelectedValueNew = this.guarantorSelectedValueOld;
        this.selectedGuarantorValue = this.guarantorSelectedValueOld;
        this.gridDisable = false;
        this.addGuarantorDisable = false;
        (<FormControl>this.customFormGroup.controls['guaranteeTypeCustomControl'])
            .setValue(this.selectedGuarantorValue);
        this.disableAddBtnForSingleGuaranteeType();
    }

    disableAddBtnForSingleGuaranteeType() {
        if (this.selectedGuarantorValue === 'SINGLE') {
            if (this.guarantorGridDataForHtml.length > 0) {
                this.addGuarantorDisable = true;
            }
        }
    }

    confirmConfigureChanges() {
        this.showPopupDialogForConfirmation = false;
        this.configureChangeAlertToastEnable = false;
        this.selectedGuarantorValue = this.onchangeSelectedValue;
        this.guarantorSelectedValueOld = this.selectedGuarantorValue;
        this.guarantorSelectedValueNew = this.selectedGuarantorValue;
        this.guarantorGridDataForHtml = [];
        this.addGuarantorDisable = false;
        this.sumOfPercentage = null;
        this.gridDisable = false;
        this.noDataFound = false;
        this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType = '';
        (<FormControl>this.collateralGuarantorForm.controls['totalPercentageSum'])
            .setValue(100.00);
        (<FormControl>this.customFormGroup.controls['guaranteeTypeCustomControl'])
            .setValue(this.selectedGuarantorValue);
        this.checkGridLength();
        this.onConfirmationGridDataDelete();
    }

    onConfirmationGridDataDelete() {
        const gridData = this.guarantorGridData.map(item => {
            if (item.__row_status === 'modified' || item.__row_status === undefined) {
                item.__row_status = 'deleted';
            }
            return item;
        });
        this.guarantorGridData = gridData.filter(Data => Data.__row_status !== 'added');
        this.collateralGuarantorForm.get('ownershipid').setValue(this.guarantorGridData);
    }

    validationCheck(data?: any, functionType?: any) {
        let valid = true;
        this.guarantorIdInvalid = false;
        this.guarantorPercentageValid = false;
        const guaratorIdCheck = this.guarantorGridDataForHtml.find(item => item.cifId === data.guarantorId);
        const dataObj = this.idList.find(item => item.description === data.guarantorDescription);
        if (((data.guarantorDescription === '') || (data.guarantorDescription === null)) || (dataObj === undefined) || (guaratorIdCheck !== undefined && (this.guarantorGridDataForHtml.length > 0) && (functionType !== 'Update'))) {
            this.guarantorIdInvalid = true;
            this.guarantorValueErrDiv = false;
            if (guaratorIdCheck !== undefined && (this.guarantorGridDataForHtml.length > 0) && (functionType !== 'Update')) {
                this.errorValidatorMessage = 'Duplicate Values are not allowed';
            }
            valid = false;
        }
        if (((data.guaranteePercentage === '') || (data.guaranteePercentage === null)) || (this.percentageValidationCheck)) {
            this.guarantorPercentageValid = true;
            valid = false;
        }
        return valid;
    }

    customizeGuarantorGridForSummaryComp() {
        if (this.guarantorGridDataForHtml.length > 0) {
            this.divForNormalGrid = !this.showSummaryGrid;
        }
    }

    validationReset() {
        this.guarantorIdInvalid = false;
        this.guarantorPercentageValid = false;
        this.submitted = false;
    }

    percentageChange(event: any) {
        this.guarantorPercentageValid = false;
        this.percentageValidationCheck = false;
        const totalPercentageSum = this.sumOfPercentage - this.editPercentage;
        this.errorValidatorMessageForPercentage = 'Please enter percentage value';
        if (event && totalPercentageSum && (this.guarantorGridDataForHtml.length > 0) && (this.selectedGuarantorValue === 'SEVERAL')) {
            const percentageSum = totalPercentageSum;
            const total = percentageSum + (parseInt(event));
            if (total > 100) {
                this.guarantorPercentageValid = true;
                this.percentageValidationCheck = true;
                this.errorValidatorMessageForPercentage = 'Total Percentage should not be exceed 100';
            } else {
                this.guarantorPercentageValid = false;
                this.errorValidatorMessageForPercentage = 'Please enter the correct % value with in range of 0.000%-100.000%';
                this.percentageValidationCheck = false;
            }
        }
        if ((this.selectedGuarantorValue === 'JOINT') || (this.selectedGuarantorValue === 'JOINT&SEVERAL')) {
            if (event === undefined || event === '' || event > 100) {
                this.guarantorPercentageValid = true;
                this.percentageValidationCheck = true;
                this.errorValidatorMessageForPercentage = 'Please enter the correct % value with in range of 0.000%-100.000%';
            }
        }
        if ((this.selectedGuarantorValue === 'SINGLE')) {
            if (parseInt(event) !== 100) {
                this.guarantorPercentageValid = true;
                this.percentageValidationCheck = true;
                this.errorValidatorMessageForPercentage = 'Percentage should be 100';
            }
        }
        if ((event !== undefined) && (this.guarantorGridDataForHtml.length === 0)) {
            this.guarantorPercentageValid = false;
        }
        if ((this.selectedGuarantorValue === 'SEVERAL') && event > 100) {
            this.guarantorPercentageValid = true;
            this.percentageValidationCheck = true;
            this.errorValidatorMessageForPercentage = 'Total Percentage should not be exceed 100';
        }
        (<FormControl>this.customFormGroup.controls['guaranteeTypeCustomControl'])
            .setValue(this.selectedGuarantorValue);
    }

    getStringInSmall(str: string) {
        str = str.toLowerCase().replace(/\b[a-z]/g, function (letter) {
            return letter.toUpperCase();
        });
        return str;
    }

    public filterChangeGuaranteeType(filter: any): void {
        if (this.listItems) {
            const tempArray = JSON.parse(JSON.stringify(this.listItems));
            this.guaranteeList = tempArray.filter((s) => s.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
        }
    }

    confirmationFromYesNo(dlgPayload: any[]) {
        this.showYesNoPrompt = false;
        if (dlgPayload[0] === 'yes') {
            this.updateGuarantorData(this.guarantorDataToDelete, 'DELETE');
        }
    }
}


