import {inject, TestBed} from '@angular/core/testing';
import {MockBackend, MockConnection} from '@angular/http/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {InspectionService} from './inspection.service';
import {InspectionFrequencyListResponse, InspectionTypeListResponse} from './inspection.data';
import {AppSettings} from './../../common/config/appsettings';
import {AppConfigData} from './../../common/config/app-config.data';

describe('InspectionService', () => {
    let inspectionService: InspectionService;
    let mockBackend: MockBackend;
    const urlToGetBeneficiaryID = AppConfigData.apiBaseUrl + AppSettings.apiToGetCifId;
    const urlToAddBeneficiary = AppConfigData.apiBaseUrl + AppSettings.apiCollateralCustomer;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                }, InspectionService
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([InspectionService, MockBackend], (service: InspectionService, backend: MockBackend) => {
            inspectionService = service;
            mockBackend = backend;
        })
    );
    it('Inspection service should be defined', () => {
        expect(inspectionService).toBeDefined();
    });
    it('getInspectionType service should call endpoint and return it\'s result', (done) => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const options = new ResponseOptions({
                body: JSON.stringify(InspectionTypeListResponse)
            });
            connection.mockRespond(new Response(options));
        });
        inspectionService.getInspectionTypeService()
            .subscribe((response) => {
                expect(response).toEqual(InspectionTypeListResponse);
                done();
            });
    });
    it('getInspectionFrequency service should call endpoint and return it\'s result', (done) => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const options = new ResponseOptions({
                body: JSON.stringify(InspectionFrequencyListResponse)
            });
            connection.mockRespond(new Response(options));
        });
        inspectionService.getInspectionFrequencyService()
            .subscribe((response) => {
                expect(response).toEqual(InspectionFrequencyListResponse);
                done();
            });
    });
    it('getInspectionFrequency service should call endpoint and return error', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        inspectionService.getInspectionFrequencyService()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });
    it('getInspectionType service should call endpoint and return error', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        inspectionService.getInspectionTypeService()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

});
