package com.dbs.cap.ct.batch.model;

import lombok.Data;

import java.util.Date;

@Data
public class BaseModel {
    private String updateFlag;
    private Date updateDate;
}
