import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {ChangeDetectorRef, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {CollateralService} from '../collateral.service';
import {FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {Collateral} from '../../collateral/model/collateral';
import {Observable} from 'rxjs/Rx';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {GridModule} from '@progress/kendo-angular-grid';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {IntlModule} from '@progress/kendo-angular-intl';
import {AutoCompleteModule} from '@progress/kendo-angular-dropdowns';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';
import {CommonUIModule} from '../../common/commonUI.module';
import {BeneficiaryComponent} from './beneficiary.component';
import {BeneficiaryService} from './beneficiary.component.service';
import {
    BeneficiaryIdModifiedList,
    beneficiaryLimitData,
    BeneficiaryListResponse,
    BeneficiaryRankJson
} from './beneficiary.data';
import {BeneficiaryList} from '../model/collateral';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {RouterTestingModule} from '@angular/router/testing';
import {CounterPartyDetailsService} from '../../common/counterparty-details/counterparty.service';
class MockBeneficiaryService {
    getBeneficiaryIdDataService(data: any) {
        if (data.searchKeyword.length > 3) {
            return Observable.of(BeneficiaryIdModifiedList);
        } else {
            return Observable.throw({status: 404});
        }
    }

    getBeneficiaryEmptyList() {
        return [];
    }

    getBeneficiaryRankService() {
        return Observable.of(BeneficiaryRankJson);
    }

    getBeneficiaryList(data: any) {
        const mockBeneficiaryListItem = new BeneficiaryList();
        mockBeneficiaryListItem.beneficiaryId = data.beneficiaryId;
        mockBeneficiaryListItem.beneficiaryIdType = data.beneficiaryIdType;
        mockBeneficiaryListItem.beneficiaryName = data.beneficiaryName;
        return mockBeneficiaryListItem;
    }

    getMockBeneficiaryIdList(data: any) {
        return data;
    }

    addBeneficiary(data: BeneficiaryList) {
        const sampleObj = {};
        return Observable.of(sampleObj);
    }
}
class MockCollateralService {
    limitDataBeneficiary = beneficiaryLimitData;
    collateral = this.getCollateral();

    getLimitData() {
        return beneficiaryLimitData;
    }

    getCollateral() {
        const mockCollateral = new Collateral();
        const mockBeneficiaryListItem = new BeneficiaryList();
        mockBeneficiaryListItem.beneficiaryId = 'GC0001045990';
        mockBeneficiaryListItem.beneficiaryIdType = 'COUNTERPARTY1';
        mockBeneficiaryListItem.beneficiaryName = '16R2A GCIN4NF CN002 ';
        mockCollateral.beneficiaryDetails.push(mockBeneficiaryListItem);
        mockCollateral.linkageDetails = [];
        return new Collateral();
    }

    getCounterParty(): Object {
        const item = {beneficiaryName: 'hh', beneficiaryId: 'GCIN000'};
        const data = new BeneficiaryList();
        data.__row_status = 'modified';
        data.beneficiaryId = item.beneficiaryId;
        data.beneficiaryName = item.beneficiaryName;
        return data;
    }
}
class MockPartyDetailsService {
    temp = new Observable(observer => {
        observer.next({'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'});
    });

    subscribeToCPDetails(temp) {
        return Observable.of({label: 'Personal Leadership Centre Pte.Ltd', value: 'GCIN0000000'});
    }
}
class MockFormBuilder extends FormBuilder {
    getBlankForm() {
        const formBuilder = new FormBuilder;
        const formGroup = formBuilder.group({
            beneficiaryId: ['', [Validators.required]],
            beneficiaryIdType: ['', [Validators.required]],
            beneficiaryName: ['', [Validators.required]],
            beneficiaryDescription: ['', [Validators.required]],
            beneficiaryRankToShow: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            beneficiaryRankToSubmit: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            beneficiaryCapAmount: ['', [<any>Validators.required, <any>Validators.required]],
            beneficiaryCapAmountType: ['', [<any>Validators.required, <any>Validators.required]]
        });
        return formGroup;
    }

    getAddForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            beneficiaryDescription: ['GC0001045992   16R2A GCIN4NF CN006 ', [Validators.required]],
            beneficiaryIdType: ['COUNTERPARTY', [Validators.required]],
            beneficiaryName: ['16R2A GCIN4NF CN006 ', [Validators.required]],
            beneficiaryId: ['GC0001045992', [Validators.required]],
            beneficiaryRankToShow: ['1DBS', [<any>Validators.required, <any>Validators.minLength(0)]],
            beneficiaryRankToSubmit: [0, [<any>Validators.required, <any>Validators.minLength(0)]],
            beneficiaryCapAmount: ['', [<any>Validators.required, <any>Validators.required]],
            beneficiaryCapAmountType: ['', [<any>Validators.required, <any>Validators.required]]
        });
        return formGroup;
    }

    getMainForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            beneficiaryList: ['', [Validators.required]]
        });
        return formGroup;
    }

    setMainForm(data: any) {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            beneficiaryList: [data, [Validators.required]]
        });
        return formGroup;
    }
}
class MockChangeDetectorRef {
}
describe('Beneficiary Component test cases', () => {
    let component: BeneficiaryComponent;
    let fixture: ComponentFixture<BeneficiaryComponent>;
    const beneficiaryData = {
        'beneficiaryName': '16R2A GCIN4NF CN002 ',
        'beneficiaryIdType': 'COUNTERPARTY1',
        'beneficiaryId': 'GC0001045990',
        'beneficiaryDescription': 'GC0001045990   16R2A GCIN4NF CN002 ',
        'beneficiaryRankToShow': '1DBS',
        'beneficiaryRankToSubmit': 0,
        'beneficiaryCapAmount': '',
        'beneficiaryCapAmountType': ''
    };
    const router = {
        navigate: jasmine.createSpy('navigate')
    };
    const MockActivatedRoute = {
        queryParams: Observable.of({'label': '16R2A GCIN4NF CN002 ', 'gcin': 'GC0001045990', 'ctype': 'COUNTERPARTY'})
    };
    const mockbeneficiaryIdList = BeneficiaryIdModifiedList;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                CommonModule,
                BrowserModule, FormsModule, ReactiveFormsModule,
                ButtonsModule, BrowserAnimationsModule,
                LoaderModule, GridModule, ClsSharedCommonModule, DateInputsModule, IntlModule, AutoCompleteModule
                , PopupDialogModule, CommonUIModule, RouterTestingModule
            ],
            declarations: [BeneficiaryComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [{provide: CollateralService, useClass: MockCollateralService},
                {provide: BeneficiaryService, useClass: MockBeneficiaryService},
                {provide: Router, useValue: router},
                {provide: FormBuilder, useClass: MockFormBuilder},
                {provide: ActivatedRoute, useValue: MockActivatedRoute},
                {provide: CounterPartyDetailsService, useClass: MockPartyDetailsService},
                {provide: ChangeDetectorRef, useClass: MockChangeDetectorRef}
            ]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(BeneficiaryComponent);
        component = fixture.componentInstance;
        component.counterPartyDetails = {'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'};
        fixture.detectChanges();
    });
    it('should create Beneficiary Component',
        async(() => {
            fixture.detectChanges();
            expect(component).toBeTruthy();
        }));
    it('Should show normalgrid on init',
        async(() => {
            component.divForNormalGrid = true;
            component.showSummaryGrid = false;
            expect(component.divForNormalGrid).toBe(true);
            component.setUpBeneficiaryComponent();
            if (component.showSummaryGrid) {
                expect(component.divForNormalGrid).toBe(false);
            } else {
                expect(component.divForNormalGrid).toBe(true);
            }
        }));
    it('should show no-record-component-found when no data from service',
        async(() => {
            const mockBeneficiaryService: MockBeneficiaryService = new MockBeneficiaryService();
            component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryEmptyList());
            component.setUpBeneficiaryComponent();
            expect(component.noRecordsFlag).toBe(true);
        }));
    it('should not show no-record-component-found when data will come from service',
        async(() => {
            const mockFormBuilder = new MockFormBuilder();
            let collateralService: CollateralService;
            collateralService = TestBed.get(CollateralService);
            const collateral: Collateral = new Collateral;
            const mockBeneficiaryService = new MockBeneficiaryService();
            const beneficiaryDetails = [mockBeneficiaryService.getBeneficiaryList(beneficiaryData)];
            collateral.beneficiaryDetails = beneficiaryDetails;
            spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
            component.setUpBeneficiaryComponent();
            expect(component.noRecordsFlag).toBe(false);
        }));
    it('PopDialog should be disabled',
        async(() => {
            expect(component.showPopupDialog).toBe(false);
        }));
    it('Conterparty details add to grid on load of component init',
        async(() => {
            fixture.detectChanges();
            const collateralMockservice = new MockCollateralService();
            component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
            expect(component.beneficiaryGridData.length).toBe(1);
        }));
    it('PopDialog box should open onclick of ADD Beneficiary button',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = false;
            component.addBeneficiary();
            expect(component.showPopupDialog).toBe(true);
        }));
    it('Beneficiary form should be defined onclick of ADD Beneficiary button',
        async(() => {
            fixture.detectChanges();
            const mockForm = new MockFormBuilder();
            component.AddBeneficiaryForm = mockForm.getBlankForm();
            component.showPopupDialog = false;
            component.addBeneficiary();
            expect(component.AddBeneficiaryForm).toBeDefined();
        }));
    it('Data should add to grid on click of save button',
        async(() => {
            fixture.detectChanges();
            expect(component.beneficiaryGridData.length).toBe(0);
            component.showPopupDialog = false;
            component.AddBeneficiaryForm = null;
            component.addBeneficiary();
            const mockForm = new MockFormBuilder();
            component.AddBeneficiaryForm = mockForm.getAddForm();
            component.beneficiaryForm = mockForm.getMainForm();
            const mockBeneficiaryService: MockBeneficiaryService = new MockBeneficiaryService();
            component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
            component.beneficiaryRankList = BeneficiaryRankJson;
            component.addBeneficiaryData(beneficiaryData);
            expect(component.beneficiaryGridData.length).toBeGreaterThan(0);
        }));
    it('Error should thrown if beneficiary id is blank',
        async(() => {
            fixture.detectChanges();
            expect(component.beneficiaryGridData.length).toBe(0);
            component.showPopupDialog = false;
            component.AddBeneficiaryForm = null;
            component.addBeneficiary();
            const mockForm = new MockFormBuilder();
            component.AddBeneficiaryForm = mockForm.getBlankForm();
            component.addBeneficiaryData(beneficiaryData);
            expect(component.beneficiaryIdInvalid).toBe(true);
            expect(component.duplicateValueErrDiv).toBe(false);
        }));
    it('PopDialog box should be close onclick of Cancel button',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = true;
            component.cancelForm();
            expect(component.showPopupDialog).toBe(false);
        }));
    it('PopDialog box should be close  onclick of close  button',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = true;
            component.closeEventFromPopupDialog(false);
            expect(component.showPopupDialog).toBe(false);
        }));
    it('Data should display in grid when beneficiary component loaded', async(() => {
        fixture.detectChanges();
        component.beneficiaryGridData = BeneficiaryListResponse;
        expect(component.beneficiaryGridData).toBe(BeneficiaryListResponse);
    }));
    it('Data should get from backend when something is entered in beneficiary id field',
        async(() => {
            fixture.detectChanges();
            component.idList = [];
            expect(component.idList.length).toBe(0);
            component.searchByGCINCIF('gcin');
            expect(component.idList.length).toBeGreaterThan(0);
        }));
    it('Error should get from backend when something wrong is entered in beneficiary id field',
        async(() => {
            fixture.detectChanges();
            component.idList = [];
            expect(component.idList.length).toBe(0);
            component.searchByGCINCIF('gfx');
            expect(component.errMsg).toBe(true);
        }));
    it('Error will hide if data is erased in beneficiary id field',
        async(() => {
            fixture.detectChanges();
            component.idList = [];
            expect(component.idList.length).toBe(0);
            component.searchByGCINCIF('');
            expect(component.beneficiaryIdInvalid).toBe(false);
            expect(component.duplicateValueErrDiv).toBe(false);
        }));
    it('Data should get rank list from api when component will create',
        async(() => {
            fixture.detectChanges();
            component.beneficiaryRankList = [];
            component.getBeneficiaryRank();
            expect(component.beneficiaryRankList[0]).toBe(BeneficiaryRankJson[0]);
        }));
    it('value in beneficiary type will be set when beneficiary description value selected ',
        async(() => {
            fixture.detectChanges();
            component.idList = [];
            expect(component.idList.length).toBe(0);
            const mockForm = new MockFormBuilder();
            component.AddBeneficiaryForm = mockForm.getBlankForm();
            const mockBeneficiaryService = new MockBeneficiaryService();
            component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
            component.AddBeneficiaryForm.controls['beneficiaryDescription'].setValue('GC0001045995   16R2A GCIN4NF CN010 ');
            component.onSearchGCIDCIFSelect('GC0001045995   16R2A GCIN4NF CN010 ');
            expect(component.AddBeneficiaryForm.controls['beneficiaryId'].value).toBe('GC0001045995');
            expect(component.AddBeneficiaryForm.controls['beneficiaryName'].value).toBe('16R2A GCIN4NF CN010 ');
        }));
    it('Data should display in form onclick of edit icon',
        async(() => {
            fixture.detectChanges();
            component.beneficiaryGridData = [];
            component.showPopupDialog = false;
            const mockForm = new MockFormBuilder();
            component.AddBeneficiaryForm = mockForm.getAddForm();
            const mockBeneficiaryService = new MockBeneficiaryService();
            component.beneficiaryEditFunc(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
            fixture.detectChanges();
            expect(component.AddBeneficiaryForm.controls['beneficiaryDescription'].value).toBe('GC0001045992   16R2A GCIN4NF CN006 ');
        }));
    it('Data should update in Grid  onclick of update button',
        async(() => {
            fixture.detectChanges();
            component.beneficiaryGridData = [];
            component.showPopupDialog = false;
            const collateralMockservice = new MockCollateralService();
            component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
            expect(component.beneficiaryGridData.length).toBe(1);
            const mockBeneficiaryService = new MockBeneficiaryService();
            const mockForm = new MockFormBuilder();
            component.beneficiaryForm = mockForm.getMainForm();
            component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
            expect(component.beneficiaryGridData.length).toBe(2);
            const beneficiaryEditData = {
                'beneficiaryName': '16R2A GCIN4NF CN002 ',
                'beneficiaryIdType': 'COUNTERPARTY1',
                'beneficiaryId': 'GC0001045990',
                'beneficiaryDescription': 'GC0001045990   16R2A GCIN4NF CN002 ',
                'beneficiaryRankToShow': '2ND',
                'beneficiaryRankToSubmit': 2,
                'beneficiaryCapAmount': '',
                'beneficiaryCapAmountType': '',
                'beneficiaryRowStatus': 'modified',
            };
            component.rowIndex = 1;
            component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
            component.duplicateValueCheck = beneficiaryData;
            component.updateBeneficiaryGridList(beneficiaryEditData);
            expect(component.beneficiaryGridData[1].beneficiaryName).toBe(beneficiaryEditData.beneficiaryName);
        }));
    it('the first error field will be focused when click on save or update button with no data',
        async(() => {
            fixture.detectChanges();
            expect(component.beneficiaryGridData.length).toBe(0);
            component.showPopupDialog = false;
            component.AddBeneficiaryForm = null;
            component.addBeneficiary();
            const mockForm = new MockFormBuilder();
            component.AddBeneficiaryForm = mockForm.getAddForm();
            component.beneficiaryForm = mockForm.getMainForm();
            const mockBeneficiaryService: MockBeneficiaryService = new MockBeneficiaryService();
            component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
            component.beneficiaryRankList = BeneficiaryRankJson;
            const beneficiaryBlankData = {
                'beneficiaryName': '',
                'beneficiaryIdType': '',
                'beneficiaryId': '',
                'beneficiaryDescription': '',
                'beneficiaryRankToShow': '',
                'beneficiaryRankToSubmit': null,
                'beneficiaryCapAmount': '',
                'beneficiaryCapAmountType': '',
                'beneficiaryRowStatus': 'modified',
            };
            component.addBeneficiaryData(beneficiaryBlankData);
        }));
    it('delete promt box should open on click of delete icon',
        async(() => {
            fixture.detectChanges();
            component.beneficiaryGridData = [];
            component.showPopupDialog = false;
            const collateralMockservice = new MockCollateralService();
            component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
            expect(component.beneficiaryGridData.length).toBe(1);
            const mockBeneficiaryService = new MockBeneficiaryService();
            const mockForm = new MockFormBuilder();
            component.beneficiaryForm = mockForm.getMainForm();
            component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
            expect(component.beneficiaryGridData.length).toBe(2);
            component.beneficiaryRemoveItemFunc(beneficiaryData);
            expect(component.showYesNoPrompt).toBe(true);
        }));
    it('Data should Delete in Grid  onclick of yes button in promt box',
        async(() => {
            fixture.detectChanges();
            component.beneficiaryGridData = [];
            component.showPopupDialog = false;
            const collateralMockservice = new MockCollateralService();
            component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
            expect(component.beneficiaryGridData.length).toBe(1);
            const mockBeneficiaryService = new MockBeneficiaryService();
            const mockForm = new MockFormBuilder();
            component.beneficiaryForm = mockForm.getMainForm();
            component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
            expect(component.beneficiaryGridData.length).toBe(2);
            component.beneficiaryDataForDelete = beneficiaryData;
            component.confirmationFromYesNo(['yes']);
            expect(component.beneficiaryGridDataForHtml.length).toBeLessThan(2);
        }));
    it('on click of add or esit linkage link it should redirect to facility linkage page',
        async(() => {
            fixture.detectChanges();
            component.getLinkage(beneficiaryData, 'ADD');
            component.ctype = 'COUNTERPARTY';
            component.gcinCpValue = 'GC0001045990';
            component.gcinDesc = '16R2A GCIN4NF CN002 ';
            const navigationExtras: NavigationExtras = {
                queryParams: {
                    'gcinLabel': beneficiaryData.beneficiaryName,
                    'gcinValue': beneficiaryData.beneficiaryId,
                    'functionFlag': 'ADD',
                    'ctype': component.ctype,
                    'gcin': component.gcinCpValue,
                    'label': component.gcinDesc
                }
            };
            expect(router.navigate).toHaveBeenCalledWith(['./facilityLinkage'], Object({
                queryParams: Object({
                    gcinLabel: '16R2A GCIN4NF CN002 ',
                    gcinValue: 'GC0001045990',
                    functionFlag: 'ADD',
                    ctype: 'COUNTERPARTY',
                    gcin: 'GC0001045990',
                    label: '16R2A GCIN4NF CN002 '
                })
            }));
        }));
    it('Rank data should be set in form on select of rank value in rank dropdown',
        async(() => {
            fixture.detectChanges();
            component.beneficiaryRankList = BeneficiaryRankJson;
            const mockForm = new MockFormBuilder();
            component.AddBeneficiaryForm = mockForm.getBlankForm();
            component.onRankSelect(0);
            expect(component.AddBeneficiaryForm.controls['beneficiaryRankToSubmit'].value).toBe(0);
            expect(component.AddBeneficiaryForm.controls['beneficiaryRankToShow'].value).toBe('1DBS');
        }));
    it('Rank data should be set to null if no rank value in rank dropdown',
        async(() => {
            fixture.detectChanges();
            component.beneficiaryRankList = BeneficiaryRankJson;
            const mockForm = new MockFormBuilder();
            component.AddBeneficiaryForm = mockForm.getBlankForm();
            component.rankValidation('');
            expect(component.AddBeneficiaryForm.controls['beneficiaryRankToSubmit'].value).toBe(null);
        }));
});
