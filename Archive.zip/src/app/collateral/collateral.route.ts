import { PendingChangesGuard } from './new-collateral/new-collateral-deactivate.guard';
import {Route} from '@angular/router';

import {UserRouteAccessService} from '../shared';
import {CollateralComponent} from './collateral.component';
import {NewCollateralComponent} from './new-collateral/new-collateral.component';

export const COLLATERAL_ROUTE: Route = {
    path: 'collateralSummary',
    component: CollateralComponent,
    data: {
        pageTitle: 'CLS - Collateral'
    },
    children: [{
        path: 'collateral',
        component: NewCollateralComponent,
        data: {
            pageTitle: 'CLS - New Collateral'
        }
    }],
    canActivate: [UserRouteAccessService],
    canDeactivate: [PendingChangesGuard]
};