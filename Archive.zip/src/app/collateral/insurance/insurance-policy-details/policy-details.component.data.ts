export const MOCK_INSURANCE_DATA = [{
    'insuranceTypeNew': 'INSURANCE12',
    'insurancePurchaser': '',
    'policyDetails': {
        'policyHolderName': '',
        'policyNo': '1213',
        'policyAmt': {
            'id': '',
            '_type': '',
            'value': 100,
            'ccy': 'SGD',
            '_createdBy': '',
            '_modifiedBy': '',
            '_createdOn': null,
            '_modifiedOn': null,
            '_isDeleted': false,
            '_oldVersion': '',
            '_version': '',
            '_requestId': '',
            '_newVersion': ''
        },
        'riskCoverStartDate': null,
        'riskCoverEndDate': null,
        'itemsInsured': '',
        'bankId': '',
        'branchId': '',
        'accountId': '',
        'bankIdentifierCode': '',
        'premiumAmt': {
            'value': 0,
            'ccy': '',
            'id': '',
            '_type': '',
            '_createdBy': '',
            '_modifiedBy': '',
            '_createdOn': null,
            '_modifiedOn': null,
            '_isDeleted': false,
            '_oldVersion': '',
            '_version': '',
            '_requestId': '',
            '_newVersion': ''
        },
        'premiumStatus': '',
        'frequency': '',
        'paymentMethod': '',
        'lastPremiumPaidDate': null,
        'lastPremiumCollectionDate': null,
        'nextPremiumDueDate': null,
        'cancellationDate': null,
        'insuranceAction': '',
        'id': '',
        'typeOfCover': ''
    },
    'claimDetails': {
        'claimFilingDate': null,
        'claimStatus': '',
        'claimedAmt': {
            'value': 0,
            'ccy': '',
            'id': '',
            '_type': '',
            '_createdBy': '',
            '_modifiedBy': '',
            '_createdOn': null,
            '_modifiedOn': null,
            '_isDeleted': false,
            '_oldVersion': '',
            '_version': '',
            '_requestId': '',
            '_newVersion': ''
        },
        'settledAmt': {
            'value': 0,
            'ccy': '',
            'id': '',
            '_type': '',
            '_createdBy': '',
            '_modifiedBy': '',
            '_createdOn': null,
            '_modifiedOn': null,
            '_isDeleted': false,
            '_oldVersion': '',
            '_version': '',
            '_requestId': '',
            '_newVersion': ''
        },
        'claimAckDate': null,
        'comments': '',
        'id': ''
    },
    'insuranceCompanyDetails': {
        'agentName': '',
        'panelCompany': '',
        'insuranceAgencyPhNo': '',
        'insuranceCompany': '',
        'addressLine1': '',
        'addressLine2': '',
        'addressLine3': '',
        'city': '',
        'state': '',
        'country': '',
        'postalCode': '',
        'phoneNo': '',
        'emailAddress': '',
        'telexNo': '',
        'faxNo': '',
        'id': ''
    },
    'delete': false,
    'reqSent': false,
    'id': '',
    'collateralId': '',
    '__row_status': ''
}];
export const InsuranceActionResponse = [
    {
        'code': '02',
        'description': 'Premium Refund To Bank'
    },
    {
        'code': '06',
        'description': 'Cancel Policy'
    },
    {
        'code': '05',
        'description': 'Cancel Policy & Eff Under BK MSTR'
    },
    {
        'code': '04',
        'description': 'Refund Prem To Bnk(COSYIII)'
    },
    {
        'code': '03',
        'description': 'Premium Refund To Customer'
    },
    {
        'code': '01',
        'description': 'Delete Bank Interest'
    }
];
export const BankIdResponse = [
    {
        'code': 'BNKID2',
        'description': 'bankID2'
    },
    {
        'code': 'BNKID1',
        'description': 'bankID1'
    }
];
export const BranchIdResponse = [
    {
        'code': 'BRNCHID2',
        'description': 'branchID2'
    },
    {
        'code': 'BRNCHID1',
        'description': 'branchID1'
    }
];
export const PaymentMethodResponse = [
    {
        'code': 'PAYMETHOD1',
        'description': 'Payment Method 1'
    },
    {
        'code': 'PAYMETHOD2',
        'description': 'Payment Method 2'
    }
];
export const InsuredTypesResponse = [
    {
        'code': '0'
    },
    {
        'code': '1'

    }
];
export const FrequencyResponse = [
    {
        'code': '3YEARS',
        'description': 'Three Years'
    },
    {
        'code': 'HALFYEARLY',
        'description': 'HalfYearly Frequency'
    },
    {
        'code': 'MONTHLY',
        'description': 'Monthly Frequency'
    },
    {
        'code': 'YEARLY',
        'description': 'Yearly Frequency'
    }
];
export const CoverTypeResponse = [
    {
        'code': 'COVER1',
        'description': 'Coverage Type one.'
    }
];


