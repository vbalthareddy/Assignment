package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.exception.ApiNotFoundException;
import com.dbs.cap.cls.service.GatewayService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;

import static org.springframework.web.bind.annotation.RequestMethod.*;

@RestController
@Slf4j
public class GatewayController {
    @Autowired
    private GatewayService gatewayService;

    @RequestMapping(
            value = "/cls/api/**",
            method = {GET, POST, PUT, DELETE},
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    public String gateway(RequestEntity<Object> request) throws ApiNotFoundException,
            UnsupportedEncodingException, URISyntaxException {
        URI uri = gatewayService.getServiceUri(request);
        return gatewayService.execute(uri, request.getMethod(), request.getBody(), request.getHeaders());
    }
}
