import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot} from '@angular/router';
import {CollateralService} from 'app/collateral/collateral.service';

@Injectable()
export class FacilityGuardService implements CanActivate {

    constructor(private router: Router, private  collateralService: CollateralService) {
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (this.collateralService.getCollateral() && this.collateralService.getCollateral().collateralId) {
            return true;
        } else {
            this.router.navigate(['./']);
        }
    }
}
