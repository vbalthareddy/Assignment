import { TestBed } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { inject } from '@angular/core/testing';
import { FacilityLinkageDataService } from 'app/collateral/facility-linkage-data/facility-linkage-data.service';
import { MockBackend } from '@angular/http/testing';



describe('Facility Linkage data service Test Cases', () => {
    let facilityLinkageDataService: FacilityLinkageDataService = null;
    let mockBackend: MockBackend = null;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [FacilityLinkageDataService, MockBackend],
            imports: [HttpModule]
        });
    });
    beforeEach(
        inject([FacilityLinkageDataService, MockBackend], (service: FacilityLinkageDataService, backend: MockBackend) => {
            facilityLinkageDataService = service;
            mockBackend = backend;
        })
    );
    it('should Create Facility Linkage Data Service', inject([FacilityLinkageDataService], (service: FacilityLinkageDataService) => {
        expect(service).toBeTruthy();
    }));

    it('should set and get the same linakge', inject([FacilityLinkageDataService], (service: FacilityLinkageDataService) => {
        const linkage = {limit: 123};
        facilityLinkageDataService.setLinkages(linkage);
        expect(facilityLinkageDataService.getLinkages()).toBe(linkage);
    }));

});