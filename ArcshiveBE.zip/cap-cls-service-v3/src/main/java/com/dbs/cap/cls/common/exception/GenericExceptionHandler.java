package com.dbs.cap.cls.common.exception;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.multipart.MultipartException;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.util.Collections;

@RestController
@ControllerAdvice
@Slf4j
public class GenericExceptionHandler {
    @ExceptionHandler(NoSuchMethodException.class)
    public ResponseEntity<Object> noSuchMethodException(NoSuchMethodException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.NOT_FOUND.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message("Requested method or URL not found.")
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(URISyntaxException.class)
    public ResponseEntity<Object> uriSyntaxException(URISyntaxException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.NOT_FOUND.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message("Requested URL not found.")
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<Object> ioException(IOException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message("IOException at server end.")
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(FileUploadException.class)
    public ResponseEntity<Object> handleFileUploadExceptionException(FileUploadException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message("Error during file upload.")
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<Object> handleMultiPartException(MultipartException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message("Error during file upload.")
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(HttpClientErrorException.class)
    public ResponseEntity<Object> httpClientErrorException(HttpClientErrorException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
    }

    @ExceptionHandler(ResourceAccessException.class)
    public ResponseEntity<Object> resourceAccessException(ResourceAccessException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.GATEWAY_TIMEOUT.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.GATEWAY_TIMEOUT);
    }

    @ExceptionHandler(ApiNotFoundException.class)
    public ResponseEntity<Object> apiNotFoundException(ApiNotFoundException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.NOT_FOUND.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(KeyNotFoundException.class)
    public ResponseEntity<Object> keyNotFoundException(KeyNotFoundException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.BAD_REQUEST.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<Object> entityNotFoundException(EntityNotFoundException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.NOT_FOUND.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DuplicateEntityException.class)
    public ResponseEntity<Object> duplicateEntityException(DuplicateEntityException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.BAD_REQUEST.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EntityLinkageException.class)
    public ResponseEntity<Object> entityLinkageException(EntityLinkageException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(FeignClientException.class)
    public ResponseEntity<Object> feignClientException(FeignClientException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(e.getError(), HttpStatus.valueOf(e.getStatus()));
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<Object> missingServletRequestParameterException(MissingServletRequestParameterException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.BAD_REQUEST.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(FeignException.class)
    public ResponseEntity<Object> feignException(FeignException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(e.status())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.valueOf(e.status()));
    }

    @ExceptionHandler(JSONException.class)
    public ResponseEntity<Object> jsonException(JSONException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(SocketTimeoutException.class)
    public ResponseEntity<Object> socketTimeoutException(SocketTimeoutException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(
                Error.builder()
                        .status(HttpStatus.GATEWAY_TIMEOUT.value())
                        .message(e.getMessage())
                        .errors(
                                Collections.singletonList(Errors.builder()
                                        .code("")
                                        .message(e.getMessage())
                                        .retriable(false)
                                        .path("").build()))
                        .build(), HttpStatus.GATEWAY_TIMEOUT);
    }

    @ExceptionHandler(HttpServerErrorException.class)
    public ResponseEntity<Object> httpServerErrorException(HttpServerErrorException e) {
        log.error("Exception Message: {}", e.getMessage());
        return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
    }
}

