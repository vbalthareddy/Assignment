package com.dbs.cap.ct.batch.utils;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class TrevorUtil {
    public static String decryptPassword(String password, String key) {
        StandardPBEStringEncryptor decryptor = new StandardPBEStringEncryptor();
        decryptor.setPassword(key);
        return decryptor.decrypt(password);
    }
}
