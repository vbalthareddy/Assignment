import {AppSettings} from '../../common/config/appsettings';

export const GUARN_TYPE_COLLATERALS = [
    {
        'LodgeReceiptAndPayment': {
            'receiptAndPayment': []
        },
        'LodgeDocumentationDetail': {
            'document': []
        },
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'guaranteeType': '',
            'guarantorName': '',
            'guarantorCifId': '',
            'guarantorType': '',
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                'ccy': '',
                '_isDeleted': false
            },
            'proposeAmt': {
                'ccy': '',
                '_isDeleted': false
            },
            'approvedAmt': {
                'ccy': '',
                '_isDeleted': false
            },
            'addressLine1': '',
            'addressLine2': '',
            'addressLine3': '',
            'city': '',
            'state': '',
            'country': '',
            'postalCode': ''
        },
        'FeeDetail': null,
        'CollateralValueDetail': {
            'unitValueMethod': false,
            'directValueMethod': false,
            'netValueMethod': false,
            'derivedValueMethod': false,
            'itemBasedMethod': false,
            'customerDerivationMethod': false,
            'defaultValueMethod': false,
            'childCollateralMethod': false
        },
        'collateralId': 'aaaaaaa',
        'collateralCode': 'code03',
        'generalDetail': {
            'collateralDesc': 'Modified Description for Guarn',
            'globalCollateral': false,
            'collateralClass': 'COLTRLCLS1',
            'collateralGroup': 'COLTRLGRP1',
            'collateralCreationDate': '2017-08-01T00:00:00.000Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'collateralStatus': '',
            'applicationDetail': {
                'formNo': '',
                'receivedDate': null,
                'reviewDate': null,
                'nextReviewDate': null,
                'signingDate': null,
                'executionDate': null,
                'comments': ''
            },
            'solicitorDetails': {
                'solicitorName': '',
                'approvedSolicitor': false,
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': ''
            },
            'remarks': 'aaaaaaaa',
            'method': '',
            'collateralGrp': '',
            'solicitorName': '',
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': {
            'withdraw': false,
            'reasonCode': '',
            'withdrawalDate': null
        },
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-19T05:03:18.535Z',
        '_modifiedOn': '2017-08-01T10:35:11.096Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': 'bb7b5a4d-ee7f-4a19-bf94-de95438388c5',
        '_version': 'bdca1617-8385-42df-be1b-bce34ce85777',
        '_requestId': '',
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': {
            'receiptAndPayment': [
                {
                    'receiptOrPaymentInd': 'R',
                    'receiptType': 'RECPT2',
                    'receiptAmt': {
                        'value': 100,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'paymentType': '',
                    'paymentAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
                    'dateFrom': '',
                    'dateTo': '',
                    'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
                    'paymentMode': '',
                    'notes': '',
                    'name': '',
                    'addressLine1': '',
                    'addressLine2': '',
                    'addressLine3': '',
                    'city': '',
                    'state': '',
                    'country': '',
                    'postalCode': '',
                    'delete': false
                }
            ]
        },
        'LodgeDocumentationDetail': {
            'document': [
                {
                    'documentCode': 'DOCCODE1',
                    'documentDate': '2017-06-02T12:33:43.707Z',
                    'documentId': '',
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'documentReceivedDate': '2017-06-02T12:33:43.707Z',
                    'documentExpirationDate': '2017-06-02T12:33:43.707Z',
                    'documentStatus': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'CollateralValuationDetail': {
            'loanToValuePcnt': 40,
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 100000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 100000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 100000,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'guaranteeType': '',
            'guarantorName': 'Parvez',
            'guarantorCifId': 'CUST2',
            'guarantorType': '',
            'supportingCollateralsHeld': false,
            'guaranteePcnt': 10,
            'guaranteeAmt': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            },
            'proposedPcnt': 0,
            'proposeAmt': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            },
            'approvedPcnt': 0,
            'approvedAmt': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            },
            'addressLine1': 'DBS Bank LTD',
            'addressLine2': 'Marina Bay',
            'addressLine3': 'Marina Bay Financial Centre Tower 3',
            'city': 'SINGAPORE',
            'state': 'SN',
            'country': 'SINGAPORE',
            'postalCode': '018982'
        },
        'FeeDetail': {
            'debitA/cForFees': 'DebitAcct02',
            'feeDetailList': [
                {
                    'feeType': 'FEE1',
                    'feeCode': 'FEECODE1',
                    'overrideFeeSetup': false,
                    'feeDistributable': false,
                    'multiple': false,
                    'frequency': '',
                    'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
                    'maxNumberOfAssessements': 0,
                    'amortize': false,
                    'amortizationTerm': 0,
                    'method': '',
                    'scriptName': '',
                    'userEnteredAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'userEnteredPcnt': 0,
                    'comments': '',
                    'delete': false
                }
            ],
            'feeCollectionAccount': '',
            'computedAmount': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            },
            'collectableAmountPcnt': 0,
            'collectableAmount': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            }
        },
        'CollateralValueDetail': {
            'unitValueMethod': false,
            'directValueMethod': false,
            'netValueMethod': false,
            'derivedValueMethod': false,
            'itemBasedMethod': false,
            'customerDerivationMethod': false,
            'defaultValueMethod': false,
            'childCollateralMethod': false
        },
        'collateralId': 'COLL10',
        'collateralCode': 'code03',
        'generalDetail': {
            'collateralDesc': 'Lodgement for guarnt',
            'globalCollateral': false,
            'collateralClass': 'COLTRLCLS1',
            'collateralCreationDate': '2017-06-20T12:33:43.707Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'collateralStatus': '',
            'applicationDetail': {
                'formNo': 'A2343223',
                'receivedDate': '2017-06-02T12:33:43.707Z',
                'reviewDate': '2017-06-02T12:33:43.707Z',
                'nextReviewDate': '2017-06-02T12:33:43.707Z',
                'signingDate': '2017-06-02T12:33:43.707Z',
                'executionDate': '2017-06-02T12:33:43.707Z',
                'comments': ''
            },
            'solicitorDetails': {
                'solicitorName': '',
                'approvedSolicitor': false,
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': ''
            },
            'collateralGrp': 'COLTRLGRP1',
            'businessLocation': 'INDIA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': {
            'withdraw': false,
            'reasonCode': '',
            'withdrawalDate': '2017-06-02T12:33:43.707Z'
        },
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-20T12:22:43.480Z',
        '_modifiedOn': '2017-06-20T12:22:43.480Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '9d8ae773-d849-49ba-a268-8ca49f4fe289',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': null,
        'LodgeDocumentationDetail': null,
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                '_isDeleted': false
            }
        },
        'FeeDetail': null,
        'CollateralValueDetail': null,
        'collateralId': 'COLL100',
        'collateralCode': 'code03',
        'generalDetail': {
            'globalCollateral': false,
            'collateralCreationDate': '2017-06-27T10:13:10.249Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': null,
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-27T10:13:10.415Z',
        '_modifiedOn': '2017-06-27T10:13:10.415Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '6032831a-26bb-4846-825d-8a0b1cf6139a',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': null,
        'LodgeDocumentationDetail': null,
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                '_isDeleted': false
            }
        },
        'FeeDetail': null,
        'CollateralValueDetail': null,
        'collateralId': 'COLL1000',
        'collateralCode': 'GAUCODE',
        'generalDetail': {
            'globalCollateral': false,
            'collateralCreationDate': '2017-07-05T08:39:27.349Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': null,
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-05T08:39:27.483Z',
        '_modifiedOn': '2017-07-05T08:39:27.483Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '56d0b356-ce84-49ae-a88f-6c40780796f4',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': null,
        'LodgeDocumentationDetail': null,
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                '_isDeleted': false
            }
        },
        'FeeDetail': null,
        'CollateralValueDetail': null,
        'collateralId': 'COLL1001',
        'collateralCode': 'GAUCODE',
        'generalDetail': {
            'globalCollateral': false,
            'collateralCreationDate': '2017-07-05T08:46:54.442Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': null,
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-05T08:46:54.609Z',
        '_modifiedOn': '2017-07-05T08:46:54.609Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '29be7c81-78bb-4e6e-80d3-cabe409021b2',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': null,
        'LodgeDocumentationDetail': null,
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                '_isDeleted': false
            }
        },
        'FeeDetail': null,
        'CollateralValueDetail': null,
        'collateralId': 'COLL1002',
        'collateralCode': 'GAUCODE',
        'generalDetail': {
            'globalCollateral': false,
            'collateralCreationDate': '2017-07-05T08:49:18.432Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': null,
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-05T08:49:18.615Z',
        '_modifiedOn': '2017-07-05T08:49:18.615Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': 'e2e1bdc6-5773-4868-bb01-1c8fd740907d',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': null,
        'LodgeDocumentationDetail': null,
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                '_isDeleted': false
            }
        },
        'FeeDetail': null,
        'CollateralValueDetail': null,
        'collateralId': 'COLL1003',
        'collateralCode': 'GAUCODE',
        'generalDetail': {
            'globalCollateral': false,
            'collateralCreationDate': '2017-07-05T08:50:40.875Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': null,
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-05T08:50:41.121Z',
        '_modifiedOn': '2017-07-05T08:50:41.121Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '0435d3e9-77ce-4c08-838a-866b0c17c3f8',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': null,
        'LodgeDocumentationDetail': null,
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                '_isDeleted': false
            }
        },
        'FeeDetail': null,
        'CollateralValueDetail': null,
        'collateralId': 'COLL1004',
        'collateralCode': 'GAUCODE',
        'generalDetail': {
            'globalCollateral': false,
            'collateralCreationDate': '2017-07-05T08:56:37.895Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': null,
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-05T08:56:38.134Z',
        '_modifiedOn': '2017-07-05T08:56:38.134Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '8ce81aa4-64d1-4c73-bd04-f0b8cc4e1c40',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': null,
        'LodgeDocumentationDetail': null,
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                '_isDeleted': false
            }
        },
        'FeeDetail': null,
        'CollateralValueDetail': null,
        'collateralId': 'COLL1005',
        'collateralCode': 'GAUCODE',
        'generalDetail': {
            'globalCollateral': false,
            'collateralCreationDate': '2017-07-05T08:58:47.020Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': null,
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-05T08:58:47.215Z',
        '_modifiedOn': '2017-07-05T08:58:47.215Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '27f907e5-9b6e-476c-bea5-ec8051c54e30',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': null,
        'LodgeDocumentationDetail': null,
        'CollateralValuationDetail': {
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'supportingCollateralsHeld': false,
            'guaranteeAmt': {
                '_isDeleted': false
            }
        },
        'FeeDetail': null,
        'CollateralValueDetail': null,
        'collateralId': 'COLL1006',
        'collateralCode': 'code03',
        'generalDetail': {
            'globalCollateral': false,
            'collateralCreationDate': '2017-07-05T09:01:38.622Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'businessLocation': 'USA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': null,
        '_type': 'GUARNCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-05T09:01:38.835Z',
        '_modifiedOn': '2017-07-05T09:01:38.835Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '6b8f5686-6162-4ed6-8060-fc267cb8e0e6',
        '_requestId': null,
        '_newVersion': null
    }
];

export const DEPOS_TYPE_COLLATERALS = [
    {
        'LodgeReceiptAndPayment': {
            'receiptAndPayment': [
                {
                    'receiptOrPaymentInd': 'P',
                    'receiptType': '',
                    'receiptAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'paymentType': 'PYMT1',
                    'paymentAmt': {
                        'value': 100,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
                    'dateFrom': '',
                    'dateTo': '',
                    'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
                    'paymentMode': 'PAYMODE1',
                    'notes': '',
                    'name': '',
                    'addressLine1': '',
                    'addressLine2': '',
                    'addressLine3': '',
                    'city': '',
                    'state': '',
                    'country': '',
                    'postalCode': '',
                    'delete': false
                }
            ]
        },
        'LodgeDocumentationDetail': {
            'document': [
                {
                    'documentCode': 'DOCCODE1',
                    'documentDate': '2017-06-02T12:33:43.707Z',
                    'documentId': '',
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'documentReceivedDate': '2017-06-02T12:33:43.707Z',
                    'documentExpirationDate': '2017-06-02T12:33:43.707Z',
                    'documentStatus': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'CollateralValuationDetail': {
            'loanToValuePcnt': 40,
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 40000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 40000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 4000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 36000,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'fullBenefit': false,
            'depositDetails': [
                {
                    'depositAcctNo': 'depAcct1',
                    'maturityDate': '2017-06-02T12:33:43.707Z',
                    'term': 0,
                    'acctBalance': {
                        'value': 30000,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'avlblBalance': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'earmarkAmount': {
                        'ccy': 'SGD',
                        'value': 40000,
                        '_type': '',
                        '_createdBy': '',
                        '_modifiedBy': '',
                        '_createdOn': null,
                        '_modifiedOn': null,
                        '_isDeleted': false,
                        '_oldVersion': '',
                        '_version': '',
                        '_requestId': '',
                        '_newVersion': '',
                        'id': ''
                    },
                    'proposedAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'approvedAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'bankId': '',
                    'bankIdentifierCode': '',
                    'branchId': '',
                    'comments': '',
                    'delete': false,
                    'principle': {
                        'ccy': 'SGD',
                        'value': 40000,
                        '_isDeleted': false
                    }
                }
            ]
        },
        'FeeDetail': {
            'debitA/cForFees': 'DebitAcct02',
            'feeDetailList': [
                {
                    'feeType': 'FEE1',
                    'feeCode': 'FEECODE1',
                    'overrideFeeSetup': false,
                    'feeDistributable': false,
                    'multiple': false,
                    'frequency': '',
                    'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
                    'maxNumberOfAssessements': 0,
                    'amortize': false,
                    'amortizationTerm': 0,
                    'method': '',
                    'scriptName': '',
                    'userEnteredAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'userEnteredPcnt': 0,
                    'comments': '',
                    'delete': false
                }
            ],
            'feeCollectionAccount': '',
            'computedAmount': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            },
            'collectableAmountPcnt': 0,
            'collectableAmount': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            }
        },
        'CollateralValueDetail': {
            'unitValueMethod': false,
            'directValueMethod': false,
            'netValueMethod': false,
            'derivedValueMethod': false,
            'itemBasedMethod': false,
            'customerDerivationMethod': false,
            'defaultValueMethod': false,
            'childCollateralMethod': false
        },
        'multiCcy': false,
        'collateralId': 'COLL1',
        'collateralCode': 'code02',
        'generalDetail': {
            'collateralDesc': 'Lodgement for deposit',
            'globalCollateral': false,
            'collateralClass': 'COLTRLCLS1',
            'collateralCreationDate': '2017-06-20T12:33:43.707Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'collateralStatus': '',
            'applicationDetail': {
                'formNo': 'A2343223',
                'receivedDate': '2017-06-02T12:33:43.707Z',
                'reviewDate': '2017-06-02T12:33:43.707Z',
                'nextReviewDate': '2017-06-02T12:33:43.707Z',
                'signingDate': '2017-06-02T12:33:43.707Z',
                'executionDate': '2017-06-02T12:33:43.707Z',
                'comments': ''
            },
            'solicitorDetails': {
                'solicitorName': '',
                'approvedSolicitor': false,
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': ''
            },
            'collateralGrp': 'COLTRLGRP1',
            'businessLocation': 'INDIA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': {
            'withdraw': false,
            'reasonCode': '',
            'withdrawalDate': '2017-06-02T12:33:43.707Z'
        },
        '_type': 'DEPOSCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-20T07:50:23.701Z',
        '_modifiedOn': '2017-06-20T07:54:55.974Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': '85e06895-93dd-4cb0-945f-36e5488f54c8',
        '_version': '5682253e-a28c-4a21-9444-032abf22dd4c',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': {
            'receiptAndPayment': [
                {
                    'receiptOrPaymentInd': 'P',
                    'receiptType': '',
                    'receiptAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'paymentType': 'PYMT1',
                    'paymentAmt': {
                        'value': 100,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
                    'dateFrom': '',
                    'dateTo': '',
                    'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
                    'paymentMode': 'PAYMODE1',
                    'notes': '',
                    'name': '',
                    'addressLine1': '',
                    'addressLine2': '',
                    'addressLine3': '',
                    'city': '',
                    'state': '',
                    'country': '',
                    'postalCode': '',
                    'delete': false
                }
            ]
        },
        'LodgeDocumentationDetail': {
            'document': [
                {
                    'documentCode': 'DOCCODE1',
                    'documentDate': '2017-06-02T12:33:43.707Z',
                    'documentId': '',
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'documentReceivedDate': '2017-06-02T12:33:43.707Z',
                    'documentExpirationDate': '2017-06-02T12:33:43.707Z',
                    'documentStatus': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'CollateralValuationDetail': {
            'loanToValuePcnt': 40,
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 40000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 40000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 4000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 36000,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'fullBenefit': false,
            'depositDetails': [
                {
                    'depositAcctNo': 'depAcct1',
                    'maturityDate': '2017-06-02T12:33:43.707Z',
                    'term': 0,
                    'acctBalance': {
                        'value': 30000,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'avlblBalance': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'proposedAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'approvedAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'bankId': '',
                    'bankIdentifierCode': '',
                    'branchId': '',
                    'comments': '',
                    'delete': false,
                    'principle': {
                        'ccy': 'SGD',
                        'value': 40000,
                        '_isDeleted': false
                    }
                }
            ]
        },
        'FeeDetail': {
            'debitA/cForFees': 'DebitAcct02',
            'feeDetailList': [
                {
                    'feeType': 'FEE1',
                    'feeCode': 'FEECODE1',
                    'overrideFeeSetup': false,
                    'feeDistributable': false,
                    'multiple': false,
                    'frequency': '',
                    'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
                    'maxNumberOfAssessements': 0,
                    'amortize': false,
                    'amortizationTerm': 0,
                    'method': '',
                    'scriptName': '',
                    'userEnteredAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'userEnteredPcnt': 0,
                    'comments': '',
                    'delete': false
                }
            ],
            'feeCollectionAccount': '',
            'computedAmount': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            },
            'collectableAmountPcnt': 0,
            'collectableAmount': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            }
        },
        'CollateralValueDetail': {
            'unitValueMethod': false,
            'directValueMethod': false,
            'netValueMethod': false,
            'derivedValueMethod': false,
            'itemBasedMethod': false,
            'customerDerivationMethod': false,
            'defaultValueMethod': false,
            'childCollateralMethod': false
        },
        'multiCcy': false,
        'collateralId': 'COLL2',
        'collateralCode': 'code02',
        'generalDetail': {
            'collateralDesc': 'Lodgement for deposit',
            'globalCollateral': false,
            'collateralClass': 'COLTRLCLS1',
            'collateralCreationDate': '2017-06-20T12:33:43.707Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'collateralStatus': '',
            'applicationDetail': {
                'formNo': 'A2343223',
                'receivedDate': '2017-06-02T12:33:43.707Z',
                'reviewDate': '2017-06-02T12:33:43.707Z',
                'nextReviewDate': '2017-06-02T12:33:43.707Z',
                'signingDate': '2017-06-02T12:33:43.707Z',
                'executionDate': '2017-06-02T12:33:43.707Z',
                'comments': ''
            },
            'solicitorDetails': {
                'solicitorName': '',
                'approvedSolicitor': false,
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': ''
            },
            'collateralGrp': 'COLTRLGRP1',
            'businessLocation': 'INDIA'
        },
        'collateralOwnerShipType': null,
        'withdrawalDetail': {
            'withdraw': false,
            'reasonCode': '',
            'withdrawalDate': '2017-06-02T12:33:43.707Z'
        },
        '_type': 'DEPOSCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-20T07:50:39.275Z',
        '_modifiedOn': '2017-06-20T07:54:56.187Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': 'a4bdbe53-82fb-44a3-8f12-7346803c19db',
        '_version': 'a8c8eae6-4a8a-4e77-adac-0367ceb33a97',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': {
            'receiptAndPayment': [
                {
                    'receiptOrPaymentInd': 'P',
                    'receiptType': '',
                    'receiptAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'paymentType': 'PYMT1',
                    'paymentAmt': {
                        'value': 100,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
                    'dateFrom': '',
                    'dateTo': '',
                    'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
                    'paymentMode': 'PAYMODE1',
                    'notes': '',
                    'name': '',
                    'addressLine1': '',
                    'addressLine2': '',
                    'addressLine3': '',
                    'city': '',
                    'state': '',
                    'country': '',
                    'postalCode': '',
                    'delete': false
                }
            ]
        },
        'LodgeDocumentationDetail': {
            'document': [
                {
                    'documentCode': '913',
                    'documentDate': '2017-06-02T12:33:43.707Z',
                    'documentId': '',
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'documentReceivedDate': '2017-06-02T12:33:43.707Z',
                    'documentExpirationDate': '2017-06-02T12:33:43.707Z',
                    'documentStatus': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'CollateralValuationDetail': {
            'loanToValuePcnt': 40,
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 40000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 40000,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 40000,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'fullBenefit': false,
            'depositDetails': [
                {
                    'depositAcctNo': 'depAcct1',
                    'sourceSystem': '',
                    'maturityDate': '2017-06-02T12:33:43.707Z',
                    'term': 0,
                    'principal': {
                        'value': 40000,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'acctBalance': {
                        'value': 30000,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'avlblBalance': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'proposedAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'approvedAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'bankId': '',
                    'bankIdentifierCode': '',
                    'branchId': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'FeeDetail': {
            'debitA/cForFees': 'DebitAcct02',
            'feeDetailList': [
                {
                    'feeType': 'FEE1',
                    'feeCode': 'FEECODE1',
                    'overrideFeeSetup': false,
                    'feeDistributable': false,
                    'multiple': false,
                    'frequency': '',
                    'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
                    'maxNumberOfAssessements': 0,
                    'amortize': false,
                    'amortizationTerm': 0,
                    'method': '',
                    'scriptName': '',
                    'userEnteredAmt': {
                        'value': 0,
                        'ccy': '',
                        '_isDeleted': false
                    },
                    'userEnteredPcnt': 0,
                    'comments': '',
                    'delete': false
                }
            ],
            'feeCollectionAccount': '',
            'computedAmount': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            },
            'collectableAmountPcnt': 0,
            'collectableAmount': {
                'value': 0,
                'ccy': '',
                '_isDeleted': false
            }
        },
        'CollateralValueDetail': {
            'unitValueMethod': false,
            'directValueMethod': false,
            'netValueMethod': false,
            'derivedValueMethod': false,
            'itemBasedMethod': false,
            'customerDerivationMethod': false,
            'defaultValueMethod': false,
            'childCollateralMethod': false
        },
        'multiCcy': false,
        'collateralId': 'COLL2312',
        'collateralCode': 'code02',
        'generalDetail': {
            'collateralDesc': 'Lodgement for deposit',
            'globalCollateral': false,
            'country': 'INDIA',
            'collateralClass': 'COLTRLCLS1',
            'collateralGroup': 'COLTRLGRP1',
            'collateralCreationDate': '2017-07-24T06:13:39.248Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'collateralStatus': '',
            'applicationDetail': {
                'formNo': 'A2343223',
                'receivedDate': '2017-06-02T12:33:43.707Z',
                'reviewDate': '2017-06-02T12:33:43.707Z',
                'nextReviewDate': '2017-06-02T12:33:43.707Z',
                'signingDate': '2017-06-02T12:33:43.707Z',
                'executionDate': '2017-06-02T12:33:43.707Z',
                'comments': ''
            },
            'solicitorDetails': {
                'solicitorName': '',
                'approvedSolicitor': false,
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': ''
            },
            'remarks': 'Deposit'
        },
        'collateralOwnerShipType': '',
        'withdrawalDetail': {
            'withdraw': false,
            'reasonCode': '',
            'withdrawalDate': '2017-06-02T12:33:43.707Z'
        },
        '_type': 'DEPOSCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-24T09:36:21.498Z',
        '_modifiedOn': '2017-07-24T09:36:21.498Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '25c975e7-6ba8-478a-bcfa-773c3d0b9761',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': {
            'receiptAndPayment': [
                {
                    'receiptOrPaymentInd': 'P',
                    'receiptType': '',
                    'receiptAmt': {
                        'value': 0,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'paymentType': 'PYMT1',
                    'paymentAmt': {
                        'value': 10,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
                    'dateFrom': '',
                    'dateTo': '',
                    'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
                    'paymentMode': 'PAYMODE1',
                    'notes': '',
                    'name': '',
                    'addressLine1': '',
                    'addressLine2': '',
                    'addressLine3': '',
                    'city': '',
                    'state': '',
                    'country': '',
                    'postalCode': '',
                    'delete': false
                }
            ]
        },
        'LodgeDocumentationDetail': {
            'document': [
                {
                    'documentCode': '058',
                    'documentDate': '2017-06-02T12:33:43.707Z',
                    'documentId': '',
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'documentReceivedDate': '2017-06-02T12:33:43.707Z',
                    'documentExpirationDate': '2017-06-02T12:33:43.707Z',
                    'documentStatus': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'CollateralValuationDetail': {
            'loanToValuePcnt': 40,
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 100,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 100,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 100,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'fullBenefit': false,
            'depositDetails': [
                {
                    'depositAcctNo': 'depAcct1',
                    'sourceSystem': '',
                    'maturityDate': '2017-07-11T00:00:00.000Z',
                    'term': 0,
                    'principal': {
                        'value': 100,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'acctBalance': {
                        'value': 50,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'avlblBalance': {
                        'value': 50,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'proposedAmt': {
                        'value': 40,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'approvedAmt': {
                        'value': 30,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'bankId': '',
                    'bankIdentifierCode': '',
                    'branchId': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'FeeDetail': {
            'debitA/cForFees': 'DebitAcct02',
            'feeDetailList': [
                {
                    'feeType': 'FEE1',
                    'feeCode': 'FEECODE1',
                    'overrideFeeSetup': false,
                    'feeDistributable': false,
                    'multiple': false,
                    'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
                    'maxNumberOfAssessements': 0,
                    'amortize': false,
                    'amortizationTerm': 0,
                    'method': '',
                    'scriptName': '',
                    'userEnteredAmt': {
                        'value': 0,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'userEnteredPcnt': 0,
                    'comments': '',
                    'delete': false
                }
            ],
            'feeCollectionAccount': '',
            'computedAmount': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collectableAmountPcnt': 0,
            'collectableAmount': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'CollateralValueDetail': {
            'unitValueMethod': false,
            'directValueMethod': false,
            'netValueMethod': false,
            'derivedValueMethod': false,
            'itemBasedMethod': false,
            'customerDerivationMethod': false,
            'defaultValueMethod': false,
            'childCollateralMethod': false
        },
        'multiCcy': false,
        'collateralId': 'COLL2442',
        'collateralCode': 'code03',
        'generalDetail': {
            'collateralDesc': 'Lodgement for guarnt',
            'globalCollateral': false,
            'country': 'INDIA',
            'collateralClass': 'COLTRLCLS1',
            'collateralGroup': 'COLTRLGRP1',
            'collateralCreationDate': '2017-07-25T00:00:00.000Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'collateralStatus': '',
            'applicationDetail': {
                'formNo': 'A2343223',
                'receivedDate': '2017-06-02T12:33:43.707Z',
                'reviewDate': '2017-06-02T12:33:43.707Z',
                'nextReviewDate': '2017-06-02T12:33:43.707Z',
                'signingDate': '2017-06-02T12:33:43.707Z',
                'executionDate': '2017-06-02T12:33:43.707Z'
            },
            'solicitorDetails': {
                'solicitorName': '',
                'approvedSolicitor': false,
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': ''
            },
            'remarks': 'Deposit'
        },
        'collateralOwnerShipType': '',
        'withdrawalDetail': {
            'withdraw': false,
            'reasonCode': '',
            'withdrawalDate': '2017-06-02T12:33:43.707Z'
        },
        '_type': 'DEPOSCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-25T04:37:55.672Z',
        '_modifiedOn': '2017-07-25T04:37:55.672Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': 'eafdb224-2320-4015-9017-f66cbbfd0b5a',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'LodgeReceiptAndPayment': {
            'receiptAndPayment': [
                {
                    'receiptOrPaymentInd': 'P',
                    'receiptType': '',
                    'receiptAmt': {
                        'value': 0,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'paymentType': 'PYMT1',
                    'paymentAmt': {
                        'value': 10,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
                    'dateFrom': '',
                    'dateTo': '',
                    'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
                    'paymentMode': 'PAYMODE1',
                    'notes': '',
                    'name': '',
                    'addressLine1': '',
                    'addressLine2': '',
                    'addressLine3': '',
                    'city': '',
                    'state': '',
                    'country': '',
                    'postalCode': '',
                    'delete': false
                }
            ]
        },
        'LodgeDocumentationDetail': {
            'document': [
                {
                    'documentCode': '058',
                    'documentDate': '2017-06-02T12:33:43.707Z',
                    'documentId': '',
                    'dueDate': '2017-06-02T12:33:43.707Z',
                    'documentReceivedDate': '2017-06-02T12:33:43.707Z',
                    'documentExpirationDate': '2017-06-02T12:33:43.707Z',
                    'documentStatus': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'CollateralValuationDetail': {
            'loanToValuePcnt': 40,
            'externalChargeAmt': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collateralValue': {
                'value': 100,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'finalCollateralValue': {
                'value': 100,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'apportioningMethod': 'P',
            'totalApportionedValue': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'balanceApportionableAmt': {
                'value': 100,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'LodgeCollateralTypeSpecificDetail': {
            'fullBenefit': false,
            'depositDetails': [
                {
                    'depositAcctNo': 'depAcct1',
                    'sourceSystem': '',
                    'maturityDate': '2017-07-11T00:00:00.000Z',
                    'term': 0,
                    'principal': {
                        'value': 100,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'acctBalance': {
                        'value': 50,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'avlblBalance': {
                        'value': 50,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'proposedAmt': {
                        'value': 40,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'approvedAmt': {
                        'value': 30,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'bankId': '',
                    'bankIdentifierCode': '',
                    'branchId': '',
                    'comments': '',
                    'delete': false
                }
            ]
        },
        'FeeDetail': {
            'debitA/cForFees': 'DebitAcct02',
            'feeDetailList': [
                {
                    'feeType': 'FEE1',
                    'feeCode': 'FEECODE1',
                    'overrideFeeSetup': false,
                    'feeDistributable': false,
                    'multiple': false,
                    'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
                    'maxNumberOfAssessements': 0,
                    'amortize': false,
                    'amortizationTerm': 0,
                    'method': '',
                    'scriptName': '',
                    'userEnteredAmt': {
                        'value': 0,
                        'ccy': 'SGD',
                        '_isDeleted': false
                    },
                    'userEnteredPcnt': 0,
                    'comments': '',
                    'delete': false
                }
            ],
            'feeCollectionAccount': '',
            'computedAmount': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            },
            'collectableAmountPcnt': 0,
            'collectableAmount': {
                'value': 0,
                'ccy': 'SGD',
                '_isDeleted': false
            }
        },
        'CollateralValueDetail': {
            'unitValueMethod': false,
            'directValueMethod': false,
            'netValueMethod': false,
            'derivedValueMethod': false,
            'itemBasedMethod': false,
            'customerDerivationMethod': false,
            'defaultValueMethod': false,
            'childCollateralMethod': false
        },
        'multiCcy': false,
        'collateralId': 'COLL2444',
        'collateralCode': 'code03',
        'generalDetail': {
            'collateralDesc': 'Lodgement for guarnt',
            'globalCollateral': false,
            'country': 'INDIA',
            'collateralClass': 'COLTRLCLS1',
            'collateralGroup': 'COLTRLGRP1',
            'collateralCreationDate': '2017-07-25T00:00:00.000Z',
            'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
            'currencyCode': 'SGD',
            'BASELEligible': false,
            'collateralStatus': '',
            'applicationDetail': {
                'formNo': 'A2343223',
                'receivedDate': '2017-06-02T12:33:43.707Z',
                'reviewDate': '2017-06-02T12:33:43.707Z',
                'nextReviewDate': '2017-06-02T12:33:43.707Z',
                'signingDate': '2017-06-02T12:33:43.707Z',
                'executionDate': '2017-06-02T12:33:43.707Z'
            },
            'solicitorDetails': {
                'solicitorName': '',
                'approvedSolicitor': false,
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': ''
            },
            'remarks': 'Deposit'
        },
        'collateralOwnerShipType': '',
        'withdrawalDetail': {
            'withdraw': false,
            'reasonCode': '',
            'withdrawalDate': '2017-06-02T12:33:43.707Z'
        },
        '_type': 'DEPOSCollateral',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-07-25T04:38:12.284Z',
        '_modifiedOn': '2017-07-25T04:38:12.284Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': 'ed5d3761-3cc7-4e86-8963-b63686c83d18',
        '_requestId': null,
        '_newVersion': null
    }
];

export const MOCK_COLLATERAL_CONFIG = {
    'GUARN': {
        'sequencePos': 2,
        'label': 'Guarantee',
        'description': 'Guarantee Description',
        'apiToHit': AppSettings.apiGuarnCollaterals,
        'columnsToShow': [
            {
                'position': 1,
                'colHeader': 'Collateral Id',
                'fieldName': 'collateralId'
            },
            {
                'position': 2,
                'colHeader': 'Collateral Code',
                'fieldName': 'collateralCode'
            },
            {
                'position': 3,
                'colHeader': 'Guarantor',
                'fieldName': 'guarantor'
            },
            {
                'position': 4,
                'colHeader': 'Original Currency',
                'fieldName': 'originalCurrency'
            },
            {
                'position': 5,
                'colHeader': 'Original Collateral Value'
            },
            {
                'position': 6,
                'colHeader': 'Converted Collateral Value'
            },
            {
                'position': 7,
                'colHeader': 'Beneficiary Id'
            },
            {
                'position': 8,
                'colHeader': 'Facility Linkage'
            },
            {
                'position': 9,
                'colHeader': 'Remarks',
                'fieldName': 'remarks'
            }
        ]
    }
};

export const MOCK_GUARN_COLLATERAL_OBJ = {'GUARN': GUARN_TYPE_COLLATERALS};

export const MOCK_COLLATERALS_DATA_TO_SHOW_LIST = {
    'GUARN': [{
        'collateralId': 'COLL5594',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5593',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5591',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }]
};

export const MOCK_COLLATERAL_FINAL_DATA_WITH_TOTAL_ROW = {
    'GUARN': [{
        'collateralId': 'COLL5594',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5593',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5591',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5590',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5587',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5586',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5584',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5582',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5581',
        'collateralCode': 'code03',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'collateralId': 'COLL5569',
        'collateralCode': 'GAUCODE',
        'originalCurrency': 'SGD',
        'originalCollateralValue': 0,
        'displayOriginalCollateralValue': 0,
        'convertedCollateralValue': 0,
        'beneficiaryID': '-',
        'remarks': '-',
        'guarantor': '-'
    }, {
        'checkboxId': 'Total',
        'collateralId': '',
        'collateralCode': '',
        'originalCurrency': '',
        'beneficiaryID': '',
        'remarks': '',
        'guarantor': '',
        'convertedCollateralValue': 0
    }
    ]
};

export const COLLATERAL_CODES_TYPES_DATA = [{
    'collateralType': 'GUARN',
    'collateralTypeDesc': 'Guarantee Collateral Type',
    'sections': {
        'code': {
            'sections': [{
                'subSections': [],
                'CollateralCodeLinkageDetail': true
            },
                {
                    'subSections': [],
                    'CollateralCodeAlertEventDetail': true
                },
                {
                    'subSections': [],
                    'CollateralCodeSecurityDetail': false
                },
                {
                    'subSections': [],
                    'CollateralCodeAdditionalDetail': true
                },
                {
                    'subSections': [],
                    'CollateralCodeUnitValueDetail': false
                },
                {
                    'subSections': [],
                    'CollateralCodeDetailsInAltLang': true
                },
                {
                    'subSections': [],
                    'CollateralCodeCompanyDetail': false
                }
            ]
        },
        'lodge': {
            'sections': [{
                'subSections': [],
                'LodgeChargeDetail': false
            },
                {
                    'subSections': [],
                    'LodgeReceiptAndPayment': true
                },
                {
                    'subSections': [],
                    'LodgeInspectionAndAppraisal': false
                },
                {
                    'subSections': [],
                    'LodgeDocumentationDetail': true
                },
                {
                    'subSections': [],
                    'LodgeBeneficiaryDetail': true
                },
                {
                    'subSections': [],
                    'LodgeInsuranceDetail': false
                },
                {
                    'subSections': [],
                    'CollateralValuationDetail': true
                },
                {
                    'subSections': [],
                    'LodgeDynamicSection': false
                },
                {
                    'subSections': [],
                    'LodgeSalesNotesDetail': false
                },
                {
                    'subSections': [{
                        'subSections': [],
                        'OwnerShipDetail': true
                    },
                        {
                            'subSections': [],
                            'LodgeTenancyDetail': false
                        }
                    ],
                    'LodgeOwnerShipDetail': true
                },
                {
                    'subSections': [{
                        'subSections': [],
                        'LodgeGuaranteeDetail': true
                    },
                        {
                            'subSections': [],
                            'LodgeOtherDetail': false
                        },
                        {
                            'subSections': [],
                            'LodgeDepositDetail': false
                        }
                    ],
                    'LodgeCollateralTypeSpecificDetail': true
                },
                {
                    'subSections': [{
                        'subSections': [],
                        'ForeClosureDetail': false
                    },
                        {
                            'subSections': [],
                            'RepossessionDetail': false
                        }
                    ],
                    'LodgeNonPerformanceDetail': false
                }
            ]
        },
        'common': {
            'sections': [{
                'FeeDetail': true,
                'subSections': []
            },
                {
                    'subSections': [{
                        'subSections': [],
                        'CalculationMethod': true
                    }],
                    'CollateralValueDetail': true
                }
            ]
        }
    },
    'id': '6efaad55-52ac-495f-b635-97063ac008c2',
    '_version': 'a066669d-c5cf-4345-ba0b-42209465b307',
    '_createdBy': 'upload',
    '_modifiedBy': 'upload'
},
    {
        'collateralType': 'OTHRS',
        'collateralTypeDesc': 'Others Collateral Type',
        'sections': {
            'code': {
                'sections': [{
                    'subSections': [],
                    'CollateralCodeLinkageDetail': true
                },
                    {
                        'subSections': [],
                        'CollateralCodeAlertEventDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeSecurityDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeAdditionalDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeUnitValueDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeDetailsInAltLang': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeCompanyDetail': false
                    }
                ]
            },
            'lodge': {
                'sections': [{
                    'subSections': [],
                    'LodgeChargeDetail': true
                },
                    {
                        'subSections': [],
                        'LodgeReceiptAndPayment': true
                    },
                    {
                        'subSections': [],
                        'LodgeInspectionAndAppraisal': true
                    },
                    {
                        'subSections': [],
                        'LodgeDocumentationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeBeneficiaryDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeInsuranceDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralValuationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeDynamicSection': false
                    },
                    {
                        'subSections': [],
                        'LodgeSalesNotesDetail': false
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'OwnerShipDetail': true
                        },
                            {
                                'subSections': [],
                                'LodgeTenancyDetail': false
                            }
                        ],
                        'LodgeOwnerShipDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'LodgeGuaranteeDetail': false
                        },
                            {
                                'subSections': [],
                                'LodgeOtherDetail': true
                            },
                            {
                                'subSections': [],
                                'LodgeDepositDetail': false
                            }
                        ],
                        'LodgeCollateralTypeSpecificDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'ForeClosureDetail': false
                        },
                            {
                                'subSections': [],
                                'RepossessionDetail': false
                            }
                        ],
                        'LodgeNonPerformanceDetail': false
                    }
                ]
            },
            'common': {
                'sections': [{
                    'FeeDetail': true,
                    'subSections': []
                },
                    {
                        'subSections': [{
                            'subSections': [],
                            'CalculationMethod': true
                        }],
                        'CollateralValueDetail': true
                    }
                ]
            }
        },
        'id': '879a67e4-d8b4-4174-b842-6c82d16929df',
        '_version': '8a8071e1-7111-4e99-972f-b2757db12876',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload'
    },
    {
        'collateralType': 'DEPOS',
        'collateralTypeDesc': 'Deposit Collateral Type',
        'sections': {
            'code': {
                'sections': [{
                    'subSections': [],
                    'CollateralCodeLinkageDetail': true
                },
                    {
                        'subSections': [],
                        'CollateralCodeAlertEventDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeSecurityDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeAdditionalDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeUnitValueDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeDetailsInAltLang': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeCompanyDetail': false
                    }
                ]
            },
            'lodge': {
                'sections': [{
                    'subSections': [],
                    'LodgeChargeDetail': false
                },
                    {
                        'subSections': [],
                        'LodgeReceiptAndPayment': true
                    },
                    {
                        'subSections': [],
                        'LodgeInspectionAndAppraisal': false
                    },
                    {
                        'subSections': [],
                        'LodgeDocumentationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeBeneficiaryDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeInsuranceDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralValuationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeDynamicSection': false
                    },
                    {
                        'subSections': [],
                        'LodgeSalesNotesDetail': false
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'OwnerShipDetail': true
                        },
                            {
                                'subSections': [],
                                'LodgeTenancyDetail': false
                            }
                        ],
                        'LodgeOwnerShipDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'LodgeGuaranteeDetail': false
                        },
                            {
                                'subSections': [],
                                'LodgeOtherDetail': false
                            },
                            {
                                'subSections': [],
                                'LodgeDepositDetail': true
                            }
                        ],
                        'LodgeCollateralTypeSpecificDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'ForeClosureDetail': false
                        },
                            {
                                'subSections': [],
                                'RepossessionDetail': false
                            }
                        ],
                        'LodgeNonPerformanceDetail': false
                    }
                ]
            },
            'common': {
                'sections': [{
                    'FeeDetail': true,
                    'subSections': []
                },
                    {
                        'subSections': [{
                            'subSections': [],
                            'CalculationMethod': true
                        }],
                        'CollateralValueDetail': true
                    }
                ]
            }
        },
        'id': '889604e4-5583-4826-8753-0c6d9646bf8b',
        '_version': 'b2bf8f0c-3f40-4767-9bf5-55cd37050a3f',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload'
    },
    {
        'collateralType': 'BASKT',
        'collateralTypeDesc': 'Basket Collateral Type',
        'sections': {
            'code': {
                'sections': [{
                    'subSections': [],
                    'CollateralCodeLinkageDetail': true
                },
                    {
                        'subSections': [],
                        'CollateralCodeAlertEventDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeSecurityDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeAdditionalDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeUnitValueDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeDetailsInAltLang': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeCompanyDetail': false
                    }
                ]
            },
            'lodge': {
                'sections': [{
                    'subSections': [],
                    'LodgeChargeDetail': true
                },
                    {
                        'subSections': [],
                        'LodgeReceiptAndPayment': true
                    },
                    {
                        'subSections': [],
                        'LodgeInspectionAndAppraisal': false
                    },
                    {
                        'subSections': [],
                        'LodgeDocumentationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeBeneficiaryDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeInsuranceDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralValuationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeDynamicSection': true
                    },
                    {
                        'subSections': [],
                        'LodgeSalesNotesDetail': false
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'OwnerShipDetail': true
                        },
                            {
                                'subSections': [],
                                'LodgeTenancyDetail': false
                            }
                        ],
                        'LodgeOwnerShipDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'LodgeGuaranteeDetail': false
                        },
                            {
                                'subSections': [],
                                'LodgeOtherDetail': false
                            },
                            {
                                'subSections': [],
                                'LodgeDepositDetail': false
                            },
                            {
                                'subSections': [],
                                'LodgeBasketDetail': true
                            }
                        ],
                        'LodgeCollateralTypeSpecificDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'ForeClosureDetail': false
                        },
                            {
                                'subSections': [],
                                'RepossessionDetail': false
                            }
                        ],
                        'LodgeNonPerformanceDetail': false
                    }
                ]
            },
            'common': {
                'sections': [{
                    'FeeDetail': true,
                    'subSections': []
                },
                    {
                        'subSections': [{
                            'subSections': [],
                            'CalculationMethod': true
                        }],
                        'CollateralValueDetail': true
                    }
                ]
            }
        },
        'id': 'bf4aabd1-d08e-4ed6-b5cb-32862172fa19',
        '_version': 'f0c824ed-5c60-434c-8ff9-ebfa74ab3996',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload'
    }
];

export const MOCK_KEYS = [{
    'type': 'AIRCF',
    'apiToHit': 'collateral/aircraft',
    'label': 'Aircraft',
    'include': ['beneficiaryDetails', 'ownershipDetails', 'inspectionAndAppraisals', 'insuranceDetails', 'linkageDetails']
}, {
    'type': 'DEPOS',
    'apiToHit': 'collateral/deposit',
    'label': 'Cash',
    'include': ['beneficiaryDetails', 'ownershipDetails', 'linkageDetails']
}, {
    'type': 'GUARN',
    'apiToHit': 'collateral/guarantee',
    'label': 'Guarantee',
    'include': ['beneficiaryDetails', 'ownershipDetails', 'linkageDetails']
}, {
    'type': 'VEHIC',
    'apiToHit': 'collateral/vehicle',
    'label': 'Vehicle',
    'include': ['beneficiaryDetails', 'ownershipDetails', 'inspectionAndAppraisals', 'insuranceDetails', 'linkageDetails']
}, {
    'type': 'BOATS',
    'apiToHit': 'collateral/boat',
    'label': 'Vessel',
    'include': ['beneficiaryDetails', 'ownershipDetails', 'inspectionAndAppraisals', 'insuranceDetails', 'linkageDetails']
}];

export const MOCK_CHECKED_DATA_TRUE = {
    0: true,
    1: true,
    2: true,
};

export const MOCK_CHECKED_DATA_FALSE = {
    0: false,
    1: false,
    2: false,
};

export const MOCK_LINKAGES =[
    {
       'beneficiaryId':null,
       'entityId':'AB100317',
       'collateralId':'COLL10619',
       'sourceSystem':'CLS',
       'apportionedPercentage':10,
       'apportionedValue':{
          'value':9268.300000000001,
          'ccy':'SGD',
          '_isDeleted':false
       },
       'loanToValuePcnt':12,
       'drawingPower':{
          'value':1112.1960000000001,
          'ccy':'SGD',
          '_isDeleted':false
       },
       'nature':'Primary',
       'method':'L',
       'unlinkReasonCode':'',
       'entityType':'',
       'id':'480f4de3-5c98-48b8-8eda-521462977e1a',
       '_type':'CollateralLinkageDetail',
       '_createdBy': 'cls-user',
       '_modifiedBy': 'cls-user',
       '_createdOn': '2017-10-18T09:31:18.625Z',
       '_modifiedOn': '2017-10-25T07:54:13.394Z',
       'scope': null,
       '_isDeleted': false,
       '_oldVersion': 'ee025767-832c-4385-820c-2a9e63ce90ca',
       '_version': '9bb593eb-6b1f-4e42-962c-679dfcd8f3cd',
       '_requestId': null,
       '_newVersion': null
    },
    {
       'beneficiaryId': null,
       'entityId': 'AB120227',
       'collateralId': 'COLL10619',
       'sourceSystem': 'CLS',
       'apportionedPercentage': 10,
       'apportionedValue': {
          'value': 9268.300000000001,
          'ccy': 'SGD',
          '_isDeleted': false
       },
       'loanToValuePcnt': 12,
       'drawingPower': {
          'value': 1112.1960000000001,
          'ccy': 'SGD',
          '_isDeleted': false
       },
       'nature': 'Primary',
       'method': 'L',
       'unlinkReasonCode': '',
       'entityType': '',
       'id': '8ecbae44-b837-4c1e-a8e4-ab07fc7a1140',
       '_type': 'CollateralLinkageDetail',
       '_createdBy': 'cls-user',
       '_modifiedBy': 'cls-user',
       '_createdOn': '2017-10-18T09:31:18.963Z',
       '_modifiedOn': '2017-10-25T07:54:13.522Z',
       'scope': null,
       '_isDeleted': false,
       '_oldVersion': '6e270f34-f034-4cb4-919f-3fa40dbc1169',
       '_version': 'd84540d2-85c0-4345-bb71-b98744e25a91',
       '_requestId': null,
       '_newVersion': null
    },
    {
       'beneficiaryId': null,
       'entityId': 'AB120225',
       'collateralId': 'COLL10619',
       'sourceSystem': 'CLS',
       'apportionedPercentage': 10,
       'apportionedValue': {
          'value': 9268.300000000001,
          'ccy': 'SGD',
          '_isDeleted': false
       },
       'loanToValuePcnt': 12,
       'drawingPower': {
          'value': 1112.1960000000001,
          'ccy': 'SGD',
          '_isDeleted': false
       },
       'nature': 'Primary',
       'method': 'L',
       'unlinkReasonCode': '',
       'entityType': '',
       'id': 'ad3f2559-4f37-4013-b8d8-b05c9d939e27',
       '_type': 'CollateralLinkageDetail',
       '_createdBy': 'cls-user',
       '_modifiedBy': 'cls-user',
       '_createdOn': '2017-10-18T07:30:28.948Z',
       '_modifiedOn': '2017-10-25T07:54:13.628Z',
       'scope': null,
       '_isDeleted': false,
       '_oldVersion': '8bfadcf1-fede-4924-b392-ce241919fb48',
       '_version': 'c6eace0c-c2b7-4f70-a4b4-3c8c82b63493',
       '_requestId': null,
       '_newVersion': null
    },
    {
       'beneficiaryId': null,
       'entityId': 'AB120073',
       'collateralId': 'COLL10619',
       'sourceSystem': 'CLS',
       'apportionedPercentage': 10,
       'apportionedValue': {
          'value': 9268.300000000001,
          'ccy': 'SGD',
          '_isDeleted': false
       },
       'loanToValuePcnt': 12,
       'drawingPower': {
          'value': 1112.1960000000001,
          'ccy': 'SGD',
          '_isDeleted': false
       },
       'nature': 'Primary',
       'method': 'L',
       'unlinkReasonCode': '',
       'entityType': '',
       'id': 'cfcc1e51-d27f-4fa0-9652-985d896be9e6',
       '_type': 'CollateralLinkageDetail',
       '_createdBy': 'cls-user',
       '_modifiedBy': 'cls-user',
       '_createdOn': '2017-10-18T09:31:18.705Z',
       '_modifiedOn': '2017-10-25T07:54:13.751Z',
       'scope': null,
       '_isDeleted': false,
       '_oldVersion': 'b23ff8a7-5d1f-47a0-abfa-9104c1d37617',
       '_version': '9b7aebfb-3397-4579-a1f3-3659834949f9',
       '_requestId': null,
       '_newVersion': null
    },
    {
       'beneficiaryId': null,
       'entityId': 'AB88705',
       'collateralId': 'COLL10619',
       'sourceSystem': 'CLS',
       'apportionedPercentage': 10,
       'apportionedValue': {
          'value': 9268.300000000001,
          'ccy': 'SGD',
          '_isDeleted': false
       },
       'loanToValuePcnt': 12,
       'drawingPower': {
          'value': 1112.1960000000001,
          'ccy': 'SGD',
          '_isDeleted': false
       },
       'nature': 'Primary',
       'method': 'L',
       'unlinkReasonCode': '',
       'entityType': '',
       'id': 'ef3bf790-73f2-4ce0-8f44-465e06c19755',
       '_type': 'CollateralLinkageDetail',
       '_createdBy': 'cls-user',
       '_modifiedBy': 'cls-user',
       '_createdOn': '2017-10-18T09:31:19.043Z',
       '_modifiedOn': '2017-10-25T07:54:13.853Z',
       'scope': null,
       '_isDeleted': false,
       '_oldVersion': '53ea510e-4b79-4259-bc80-2736f63c264c',
       '_version': 'b4358c3e-6e05-4bcc-987a-6452de7a9eb6',
       '_requestId': null,
       '_newVersion': null
    }
 ];

 export const MOCK_LIMIT_LIMITTYPEID = [
    {
       'limitTypeId': 'GC0000013455',
       'limitId': 'AB100317'
    },
    {
       'limitTypeId': 'GC0000013455',
       'limitId': 'AB120073'
    },
    {
       'limitTypeId': 'GC0000013455',
       'limitId': 'AB120225'
    },
    {
       'limitTypeId': 'GC0000013455',
       'limitId': 'AB120227'
    },
    {
       'limitTypeId': 'GC0000013455',
       'limitId': 'AB88705'
    }
 ];

