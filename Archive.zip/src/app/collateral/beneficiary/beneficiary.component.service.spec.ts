import {inject, TestBed} from '@angular/core/testing';
import {MockBackend, MockConnection} from '@angular/http/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {BeneficiaryService} from '../../../../src/app/collateral/beneficiary/beneficiary.component.service';
import {BeneficiaryIdList, BeneficiaryRankJson} from './beneficiary.data';
import {AppSettings} from './../../common/config/appsettings';
import {AppConfigData} from './../../common/config/app-config.data';

describe('BeneficiaryService', () => {
    let beneficiaryService: BeneficiaryService;
    let mockBackend: MockBackend;
    const urlToGetBeneficiaryID = AppConfigData.apiBaseUrl + AppSettings.apiToGetCifId;
    const urlToAddBeneficiary = AppConfigData.apiBaseUrl + AppSettings.apiCollateralCustomer;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                }, BeneficiaryService
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([BeneficiaryService, MockBackend], (service: BeneficiaryService, backend: MockBackend) => {
            beneficiaryService = service;
            mockBackend = backend;
        })
    );
    it('Beneficiary service should be defined', () => {
        expect(beneficiaryService).toBeDefined();
    });
    it('getbeneficiaryId service should call endpoint and return it\'s result', (done) => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const options = new ResponseOptions({
                body: JSON.stringify(BeneficiaryIdList)
            });
            connection.mockRespond(new Response(options));
        });
        beneficiaryService.getBeneficiaryIdDataService({'searchKeyword': 'gci'})
            .subscribe((response) => {
                expect(response).toEqual(BeneficiaryIdList);
                done();
            });
    });
    it('addbeneficiary service should call endpoint and return it\'s result', (done) => {
        const item = {
            'beneficiaryId': '123',
            'entityType': 'C',
            'entityName': 'Soumya'
        };
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const options = new ResponseOptions({
                body: JSON.stringify({'result': true})
            });
            connection.mockRespond(new Response(options));
        });
        beneficiaryService.addBeneficiary(item)
            .subscribe((response) => {
                expect(response).toEqual({'result': true});
                done();
            });
    });
    it('getBeneficiaryRank service should call endpoint and return it\'s result', (done) => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const options = new ResponseOptions({
                body: JSON.stringify(BeneficiaryRankJson)
            });
            connection.mockRespond(new Response(options));
        });
        beneficiaryService.getBeneficiaryRankService()
            .subscribe((response) => {
                expect(response).toEqual(BeneficiaryRankJson);
                done();
            });
    });
    it('getbeneficiaryId service should call endpoint and return error', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        beneficiaryService.getBeneficiaryIdDataService({'searchKeyword': 'gci'})
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });
    it('addbeneficiary service should call endpoint and return error', (done) => {
        const item = {
            'beneficiaryId': '123',
            'entityType': 'C',
            'entityName': 'Soumya'
        };
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        beneficiaryService.addBeneficiary(item)
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });
    it('getBeneficiaryRank service should call endpoint and return error', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        beneficiaryService.getBeneficiaryRankService()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

});
