package com.dbs.cap.cls.common.io;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class ResourceFileReader {
    public static String readResourceFileToString(String filename) throws IOException {
        InputStream resource = ResourceFileReader.class.getClassLoader().getResourceAsStream(filename);
        if (resource == null) {
            throw new IOException("File not found: " + filename);
        }
        return IOUtils.toString(resource, StandardCharsets.UTF_8);
    }
}
