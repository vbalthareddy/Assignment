import {E2eSpecHelper} from './E2eSpecHelper';
import {$, protractor} from 'protractor';
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const collateralGuarantor: any = {
    saveFormBtn: $('#save-form-btn'),
    addDetailsBtn: $('#add-details-btn'),
    closeDialogIcon: $('.k-dialog-close'),
    noRecordLink: $('#no-records-label a'),
    deleteIcon: $('#guarantorDeleteIcon-0'),
    guarantorForPopDialog: $('.clsBtnSecondary'),
    guarantorIdOnTab: $('#gaurantor_tab'),
    guarantorSelect: $('#coll-guarantor-dropdown'),
    guarantorType: $('.k-list-container .k-list .k-item:last-child'),
    guarantorDropDownId: $('.guarantor_id'),
    guarantorDropDownResult: $('.k-list-container .k-list .k-item:first-child'),
    guarantorDropDownResult1: $('.k-list-container .k-list .k-item:last-child'),
    guarantorPercentage: $('#guarantor_percentage'),
    guarantorReverchange: $('.revertChanges'),
    guarantorConfigureBtn: $('#configure-btn'),
    disableGridClass: $('.disabledGuarontorGrid'),
    confirmationBtnDialog: $('#confirmation_btn'),
    guarantorEditIcon: $('#guarantorEditIcon-0'),
    revertbtnDialog: $('#dialog_revert_btn'),
    updateFormBtn: $('#update_form_btn'),
    gcinDropDownId: $('#gcinDropDownId .k-searchbar > .k-input'),
    guarantorSelectId: $('#coll-guarantor-dropdown .k-searchbar > .k-input'),
    guarantorPercentageInput: (searchTerm: string): any => $('#guarantor_percentage > div > input').sendKeys(searchTerm),
    guarantorDropDownIdValue: (searchTerm: string): any => $('.guarantor_id .k-searchbar > .k-input').sendKeys(searchTerm),
    guarantorTypeSelect: (searchTerm: string): any => $('#coll-guarantor-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER)
};
exports.GuarantorTestSuite = function () {
    describe('Guarantor Page', function () {
        it('should Select Guarantor tab, function ', () => {
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorIdOnTab.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should enable add button if user select guarantor value', () => {
            collateralGuarantor.guarantorTypeSelect('Several');
            e2eSpecHelper.sleepBrowser(4000);
        });
        it('should check form validations with empty form', () => {
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.closeDialogIcon.click();
        });
        it('should add data into grid from popup dialog box', () => {
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult.click();
            collateralGuarantor.guarantorPercentageInput('23');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should show warning message if changing guarantor type', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Joint');
            e2eSpecHelper.sleepBrowser(4000);
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
        });
        it('should revert selected value onclick of revert function', () => {
            collateralGuarantor.guarantorReverchange.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should show configuaration confirmation dialog box on click of configuration button if conditions true', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Joint');
            e2eSpecHelper.sleepBrowser(4000);
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorConfigureBtn.click();
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.revertbtnDialog.click();

        });
        it('should show configuaration confirmation dialog box on click of configuration button if conditions true', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Joint');
            e2eSpecHelper.sleepBrowser(4000);
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorConfigureBtn.click();
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.confirmationBtnDialog.click();
        });
        it('should add data into grid from popup dialog box', () => {
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult.click();
            collateralGuarantor.guarantorPercentageInput('23');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should Edit data into popup dialog box', () => {
            collateralGuarantor.guarantorEditIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.gcinDropDownId.clear();
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult1.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.updateFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should delete data from grid', () => {
            collateralGuarantor.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should get percentage validation error incase its not equal to 100 if selected guarantee single', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Single');
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult.click();
            collateralGuarantor.guarantorPercentageInput('23');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.closeDialogIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should add data into grid incase percentage equal to 100 if selected guarantee single', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Single');
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult.click();
            collateralGuarantor.guarantorPercentageInput('100');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should delete data from grid', () => {
            collateralGuarantor.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
    });
};

exports.GuarantorTestSuiteForEditFlow = function () {
    describe('Guarantor Page for Edit Flow', function () {
        it('should Select Guarantor tab, function ', () => {
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorIdOnTab.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should enable add button if user select guarantor value', () => {
            collateralGuarantor.guarantorTypeSelect('Several');
            e2eSpecHelper.sleepBrowser(4000);
        });
        it('should check form validations with empty form', () => {
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.closeDialogIcon.click();
        });
        it('should add data into grid from popup dialog box', () => {
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult.click();
            collateralGuarantor.guarantorPercentageInput('23');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should show warning message if changing guarantor type', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Joint');
            e2eSpecHelper.sleepBrowser(4000);
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
        });
        it('should revert selected value onclick of revert function', () => {
            collateralGuarantor.guarantorReverchange.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should show configuaration confirmation dialog box on click of configuration button if conditions true', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Joint');
            e2eSpecHelper.sleepBrowser(4000);
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorConfigureBtn.click();
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.revertbtnDialog.click();

        });
        it('should show configuaration confirmation dialog box on click of configuration button if conditions true', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Joint');
            e2eSpecHelper.sleepBrowser(4000);
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorConfigureBtn.click();
            e2eSpecHelper.verifyPresence('.warning-message');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.confirmationBtnDialog.click();
        });
        it('should add data into grid from popup dialog box', () => {
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult.click();
            collateralGuarantor.guarantorPercentageInput('23');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should Edit data into popup dialog box', () => {
            collateralGuarantor.guarantorEditIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.gcinDropDownId.clear();
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult1.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.updateFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should delete data from grid', () => {
            collateralGuarantor.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should get percentage validation error incase its not equal to 100 if selected guarantee single', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Single');
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult.click();
            collateralGuarantor.guarantorPercentageInput('23');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.closeDialogIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should add data into grid incase percentage equal to 100 if selected guarantee single', () => {
            collateralGuarantor.guarantorSelectId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorTypeSelect('Single');
            collateralGuarantor.addDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.guarantorDropDownId.click();
            collateralGuarantor.guarantorDropDownIdValue('gcin');
            e2eSpecHelper.sleepBrowser(1000);
            collateralGuarantor.guarantorDropDownResult.click();
            collateralGuarantor.guarantorPercentageInput('100');
            e2eSpecHelper.sleepBrowser(2000);
            collateralGuarantor.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should delete data from grid', () => {
            collateralGuarantor.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });
    });
};
