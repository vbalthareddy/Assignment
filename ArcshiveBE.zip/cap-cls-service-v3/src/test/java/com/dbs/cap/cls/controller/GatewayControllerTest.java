package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.oauth.OAuth2TestHelper;
import com.dbs.cap.cls.common.test.BaseMockMvcWiremockIntegrationTest;
import com.dbs.cap.cls.common.test.IntegrationTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Category(IntegrationTest.class)
@ActiveProfiles("test")
public class GatewayControllerTest extends BaseMockMvcWiremockIntegrationTest {
    @Autowired
    private OAuth2TestHelper oauthHelper;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        mockResponse(WireMock.post(WireMock.urlMatching("^/oauth/token.*")),
                "{\"access_token\":\"token1234\",\"expires_in\":28776}");
    }

    @Test
    public void test_get_reference_data() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Countrys.*")),
                null);
        MockHttpServletRequestBuilder getCountrys = get("/cls/api/v1/country")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getCountrys.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void test_gateway_pathparam() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/customermaster/v1/external/rating/.*")),
                null);
        MockHttpServletRequestBuilder getRating = get("/cls/api/v1/customer-master/rating?gcin=12345")
                .header("test", "test")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getRating.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }
}