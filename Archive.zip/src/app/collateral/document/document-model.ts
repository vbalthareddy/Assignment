export class DocumentItemModel {
    documentCode: string;
    documentStatus: string;
    documentDate: Date;
    dueDate: Date;
    documentReceivedDate: Date;
    documentExpirationDate: Date;
    comments: string;
    delete: boolean;
    id: string;

    constructor() {
        this.documentCode = '';
        this.documentStatus = '';
        this.documentDate = null;
        this.dueDate = null;
        this.documentReceivedDate = null;
        this.documentExpirationDate = null;
        this.comments = '-';
    }
}