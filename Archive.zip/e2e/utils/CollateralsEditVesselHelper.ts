import {E2eSpecHelper} from './E2eSpecHelper';
import {browser} from 'protractor';

const collateralSpecSuite = require('./CollateralSpecHelper');
const summarySpecSuite = require('./SummarySpecHelper');
const valuationSpecSuite = require('./ValuationSpecHelper');
const ownershipSpecSuite = require('./OwnershipSpecHelper');
const chargeSpecSuite = require('./ChargeSpecHelper');
const documentSpecSuite = require('./DocumentSpecHelper');
const collateralDetailSpecSuite = require('./CollateralDetailSpecHelper');
const viewCollateralsSpecSuite = require('./ViewCollateralsSpecHelper');
const beneficiarySpecSuite = require('./BeneficiarySpecHelper');
const specificDetailSpecSuite = require('./SpecificDetailsSpecHelper');

const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

exports.EditCollateralVesselTestSuite = function () {
    describe('should edit collateral of vehicle type', () => {
        browser.ignoreSynchronization = true;

        /*E2E for setting up add collateral Page*/
        const processCollateralPageForViewCollaterals = () => {
            collateralSpecSuite.CollateralTestSuiteForViewCollaterals();
        };

        /*E2E for verifying view collaterals Page*/
        const processViewCollateralsPage = () => {
            viewCollateralsSpecSuite.ViewCollateralsTestSuite();
        };

        /*E2E for Collateral Details Page*/
        const processCollateralDetailsPage = () => {
            collateralDetailSpecSuite.CollateralDetailsTestSuiteForEditFlow();
        };

        /*E2E for Specific Details Page*/
        const processSpecificDetailsPage = () => {
            specificDetailSpecSuite.SpecificDetailsTestSuiteForVesselEditFlow();
        };

        /*E2E for Beneficiary Page*/
        const processBeneficiaryDetailsPage = () => {
            beneficiarySpecSuite.BeneficiaryTestSuiteForEditFlow();
        };

        /*E2E for Ownership Page*/
        const processOwnershipDetailsPage = () => {
            ownershipSpecSuite.OwnershipTestSuiteForEditFlow();
        };

        /*E2E for Document Page*/
        const processDocumentDetailsPage = () => {
            documentSpecSuite.DocumentTestSuiteForEditFlow();
        };

        /*E2E for Valuation Page*/
        const processValuationDetailsPage = () => {
            valuationSpecSuite.ValuationTestSuiteForEditFlow();
        };

        /*E2E for Summary Page*/
        const processSummaryPage = () => {
            summarySpecSuite.SummaryTestSuite('Vessel');
        };

        describe('should verify details on add/update collaterals page', () => {
            processCollateralPageForViewCollaterals();
        });

        describe('should verify details on view collaterals page', () => {
            processViewCollateralsPage();
        });

        it('should click on Edit button from vessel grid and continue towards edit flow', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.buttonClick('#DEPOS-EditIcon-0');
        });

        describe('should verify details on collateral-details page', () => {
            processCollateralDetailsPage();
        });

        xdescribe('should verify details on beneficiary-details page', () => {
            processBeneficiaryDetailsPage();
        });

        xdescribe('should verify details on ownership-details page', () => {
            processOwnershipDetailsPage();
        });

        describe('should verify details on document-details page', () => {
            processDocumentDetailsPage();
        });

        describe('should verify details on valuation tab page', () => {
            processValuationDetailsPage();
        });

        describe('should verify data from summary page', () => {
            processSummaryPage();
        });

        it('should click on Submit button to submit vessel type collateral', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.buttonClick('#final_submit_btn');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('#gblMsgId');
        });

    });
};
