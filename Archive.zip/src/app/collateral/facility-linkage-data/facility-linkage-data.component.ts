import {PlatformLocation} from '@angular/common';
import {DraftRecordService} from '../../draftrecord/draft-record.service';
import {Component, ElementRef, HostListener, Input, OnInit} from '@angular/core';
import {FormGroup} from '@angular/forms';
import * as _ from 'underscore';
import {CollateralService} from 'app/collateral/collateral.service';
import {ActivatedRoute, NavigationExtras, Params, Router} from '@angular/router';
import {FacilityLinkageDataService} from 'app/collateral/facility-linkage-data/facility-linkage-data.service';
import {CollateralSummaryService} from 'app/collateral/collateral-summary/collateral-summary.service';
import {Collateral, LinkageDetails} from 'app/collateral/model/collateral';
import {JsonConvert} from 'json2typescript';
import {Observable} from 'rxjs/Observable';

@Component({
    selector: 'facility-linkage-data',
    templateUrl: './facility-linkage-data.html',
    styleUrls: ['./facility-linkage.scss']
})
export class FacilityLinkageDataComponent implements OnInit {
    backBtnPress: boolean = false;
    popUpShow: boolean = false;
    showPopupDialog: boolean = false;
    titleDialogBox: string = 'Leaving Form';
    actionTypeDialogBox: string = 'leaveForm';
    limitsData: any[];
    limitsForm: FormGroup;
    selectedData: any[] = [];
    parsedData: any[] = [];
    keys: any;
    checkedKeys: any = [];
    checkedSelectedKeys: any = [];
    totalValues: any[] = [];
    noLimitFlag: boolean;
    functionFlag: string;
    source: string;
    linkedLimitForGCIN: string;
    selectedLimit: any[] = [];
    gcinCpValue: string;
    gcinDesc: string;
    ctype: string;
    @Input()
    gcin: { label?: any, value?: any } = {};

    constructor(private route: ActivatedRoute, private collateralService: CollateralService, private facilityLinkageDataService: FacilityLinkageDataService, private router: Router, private collateralSummaryService: CollateralSummaryService, private _displayContent: ElementRef, private draftRecordService: DraftRecordService, location: PlatformLocation) {
        this.route.queryParams.subscribe((params: Params) => {
            this.gcin.label = params['gcinLabel'];
            this.gcin.value = params['gcinValue'];
            this.functionFlag = params['functionFlag'];
            this.source = params['source'];
            this.gcinCpValue = params['gcin'];
            this.gcinDesc = params['label'];
            this.ctype = params['ctype'];
        });
        location.onPopState(() => {
            this.backBtnPress = true;
            location.pushState('', '', '');
        });
    }

    ngOnInit() {
        this.setUpFacilityLinkage();
        this.applyBGForLinkedLimit();
    }

    @HostListener('window:onbeforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        if (this.popUpShow) {
            return this.popUpShow;
        } else {
            if (this.backBtnPress) {
                this.titleDialogBox = 'Warning';
                this.actionTypeDialogBox = 'warning';
                this.backBtnPress = false;
            } else {
                this.titleDialogBox = 'Leaving Form';
                this.actionTypeDialogBox = 'leaveForm';
            }
            this.showPopupDialog = true;
            return this.popUpShow;
        }
    }

    setUpFacilityLinkage() {
        this.collateralService.getLimitsByLimitTypeId({where: {limitTypeId: this.gcin.value}}).subscribe(
            data => {
                this.noLimitFlag = false;
                this.PrepareData(data);
            },
            error => {
                this.noLimitFlag = true;
            }
        );
    }

    private applyBGForLinkedLimit() {
        setTimeout(() => {
            if (this.functionFlag === 'EDIT') {
                const limitArr = _.toArray(this.limitsData);
                for (let k = 0; k < limitArr.length; k++) {
                    for (let j = 0; j < limitArr[k].length; j++) {
                        for (let i = 0; i < this.selectedLimit.length; i++) {
                            if (limitArr[k][j].limitId === this.selectedLimit[i]) {
                                this._displayContent.nativeElement.querySelectorAll('.k-grid')[k].querySelectorAll('tbody tr')[j].style.background = 'rgba(117, 203, 255, 0.24)';
                            }
                        }

                    }
                }
            }
        }, 500);
    }

    PrepareData(limitData: any) {
        this.limitsData = limitData;

        this.limitsData = _.map(this.limitsData, function (obj) {
            return ({
                limitId: obj.limitId,
                limitName: obj.description,
                riskTaker: obj.riskTaker,
                approved: obj.approvedLimit.value,
                activated: obj.activatedLimit.value,
                totalExposure: obj.totalExposure,
                facilityRiskRating: obj.facilityRiskRating,
                tenor: obj.tenorYears,
                remarks: obj.remarks,
                riskType: obj.riskType,
                limitTypeId: obj.limitTypeId
            });
        });
        if (this.collateralService.limitDataBeneficiary[this.gcin.value]) {
            this.selectedLimit = _.map(this.collateralService.limitDataBeneficiary[this.gcin.value], function (element, index, list) {
                return element.limitId;
            });
            const selectedLimit = this.selectedLimit;
            if (this.selectedLimit) {
                this.selectedData = _.filter(this.limitsData, function (element) {
                    return (selectedLimit.indexOf(element.limitId) !== -1);
                });
            }
        }
        this.limitsData = _.groupBy(this.limitsData, function (obj) {
            return obj.riskType;
        });

        this.keys = Object.keys(this.limitsData);
        this.checkedKeys = _.map(this.keys, function (key) {
            return false;
        });
        this.checkedSelectedKeys = _.map(this.keys, function (key) {
            return false;
        });
        ;
        const totalValues: any[] = [];

        this.totalValues = _.map(this.limitsData, function (element, index, list) {
            if (element.length > 1) {
                return _.reduce(element, function (mem, ele) {
                    return {
                        activated: mem.activated + ele.activated,
                        approved: mem.approved + ele.approved,
                        totalExposure: mem.totalExposure + ele.totalExposure
                    };
                });
            } else {
                return {
                    activated: element[0].activated,
                    approved: element[0].approved,
                    totalExposure: element[0].totalExposure
                };
            }
        });
    }

    linkCollateral() {
        this.popUpShow = true;
        this.canDeactivate();
        this.facilityLinkageDataService.setLinkages(this.selectedData);
        this.updateRowStatus();
        const collateralId = this.collateralService.collateral.collateralId;
        const entity = _.map(this.selectedData, function (obj) {
            return ({
                entityType: 'LIMIT',
                entityId: obj.limitId,

            });
        });
        if (entity) {
            this.collateralService.postELC(entity).subscribe(data => {
            }, error => {
            });
        }

        if (this.selectedData && this.gcin.value) {
            this.collateralService.limitDataBeneficiary[this.gcin.value] = _.map(this.selectedData, function (element, index, list) {
                return {limitId: element.limitId, collateralId: collateralId};
            });
        } else {
            delete this.collateralService.limitDataBeneficiary[this.gcin.value];
        }
        this.collateralSummaryService.collateralOperation = 'FACILITY LINKAGE';
        if (this.source === 'CollateralList') {
            this.collateralService.submitCollateral().subscribe(data => {
                    this.collateralService.collateral = JsonConvert.deserializeString(JSON.stringify(data), Collateral);
                    this.collateralSummaryService.collateralOperation = 'COLLATERSL_SUCCESS';
                    let navigationExtras: NavigationExtras;
                    navigationExtras = {
                        queryParams: {
                            'gcin': this.gcinCpValue,
                            'label': this.gcinDesc
                        }
                    };
                    this.router.navigate(['./collateralList'], navigationExtras);
                },
                error => {

                });
        } else {
            let navigationExtras: NavigationExtras;
            navigationExtras = {
                queryParams: {
                    'cid': this.collateralService.collateral.collateralId,
                    'ctype': this.ctype,
                    'gcin': this.gcinCpValue,
                    'label': this.gcinDesc
                }
            };
            this.router.navigate(['./collateral'], navigationExtras);
        }

    }

    updateRowStatus() {
        const existedLimits = this.collateralService.limitDataBeneficiary[this.gcin.value];
        const collateralId = this.collateralService.collateral.collateralId;

        this.selectedData.forEach(element => {
            const index = _.findIndex(this.collateralService.collateral.linkageDetails, {entityId: element.limitId});
            // 	const obj = _.where(this.collateralService.collateral.linkageDetails, 'entityId:' + element.limitId);
            if (index !== -1 && this.collateralService.collateral.linkageDetails[index] && this.collateralService.collateral.linkageDetails[index].__row_status !== 'added') {
                this.collateralService.collateral.linkageDetails[index].__row_status = 'modified';
            } else if (index !== -1 && this.collateralService.collateral.linkageDetails[index] && this.collateralService.collateral.linkageDetails[index].__row_status === 'added') {
                this.collateralService.collateral.linkageDetails[index].__row_status = 'added';
            } else {
                // this.collateralService.collateral.linkageDetails[index].__row_status = 'added';
                const newLinkage = new LinkageDetails();
                newLinkage.beneficiaryId = this.gcin.value;
                newLinkage.entityId = element.limitId;
                newLinkage.collateralId = collateralId;
                newLinkage.__row_status = 'added';
                newLinkage.method = 'L';
                if (this.collateralService.collateral && this.collateralService.collateral.CollateralValuationDetail) {
                    newLinkage.loanToValuePcnt = this.collateralService.collateral.CollateralValuationDetail.loanToValuePcnt;
                }
                delete newLinkage._version;
                delete newLinkage.id;
                this.collateralService.collateral.linkageDetails.push(newLinkage);
            }
        });
        if (existedLimits) {
            existedLimits.forEach(element => {
                const index = _.findIndex(this.selectedData, {limitId: element.limitId});
                const collateralIndex = _.findIndex(this.collateralService.collateral.linkageDetails, {entityId: element.limitId});
                if (index === -1 && this.collateralService.collateral.linkageDetails[collateralIndex] &&
                    this.collateralService.collateral.linkageDetails[collateralIndex].__row_status !== 'added') {
                    this.collateralService.collateral.linkageDetails[collateralIndex].__row_status = 'deleted';
                } else if (index === -1 && this.collateralService.collateral.linkageDetails[collateralIndex] &&
                    this.collateralService.collateral.linkageDetails[collateralIndex].__row_status === 'added') {
                    this.collateralService.collateral.linkageDetails.splice(collateralIndex, 1);
                } else if (index === -1) {
                    const newLinkage = new LinkageDetails();
                    newLinkage.beneficiaryId = this.gcin.value;
                    newLinkage.entityId = element.limitId;
                    newLinkage.collateralId = collateralId;
                    newLinkage.__row_status = 'added';
                    newLinkage.method = 'L';

                    if (this.collateralService.collateral && this.collateralService.collateral.CollateralValuationDetail) {
                        newLinkage.loanToValuePcnt = this.collateralService.collateral.CollateralValuationDetail.loanToValuePcnt;
                    }

                    delete newLinkage._version;
                    delete newLinkage.id;
                    this.collateralService.collateral.linkageDetails.push(newLinkage);
                }

            });
        }
    }

    getData(index: any, data: any, event: any, rowIndex: number) {
        if (event.target.checked) {
            this._displayContent.nativeElement.querySelectorAll('.k-grid')[index].querySelectorAll('tbody tr')[rowIndex].style.background = 'rgba(117, 203, 255, 0.24)';
            this.selectedData.push(data);
            if (this.selectedLimit.indexOf(data.limitId) === -1) {
                this.selectedLimit.push(data.limitId);
            }
        } else {
            this._displayContent.nativeElement.querySelectorAll('.k-grid')[index].querySelectorAll('tbody tr')[rowIndex].style.background = 'white';
            this.selectedData.splice(this.selectedData.indexOf(data), 1);
            if (this.selectedLimit.indexOf(data.limitId) !== -1) {
                this.selectedLimit.splice(this.selectedLimit.indexOf(data.limitId), 1);
            }
            if (this.checkedSelectedKeys[index]) {
                this.checkedSelectedKeys[index] = false;
            }
        }
    }

    toggleCheckBox(i: any, event: any) {
        this.checkedKeys[i] = event.target.checked;
        const childElement = this._displayContent.nativeElement.querySelectorAll('.k-grid')[i].querySelectorAll('tbody tr');
        for (let count = 0; count < childElement.length; count++) {
            if (event.target.checked) {
                childElement[count].style.background = 'rgba(117, 203, 255, 0.24)';
            } else {
                childElement[count].style.background = 'white';
            }
        }
        if (event.target.checked) {
            this.limitsData[this.keys[i]].forEach(element => {
                if (this.selectedData.indexOf(element) === -1) {
                    this.selectedData.push(element);
                    if (this.selectedLimit.indexOf(element.limitId) === -1) {
                        this.selectedLimit.push(element.limitId);
                    }
                }
            });
        } else {
            this.limitsData[this.keys[i]].forEach(element => {
                if (this.selectedData.indexOf(element) !== -1) {
                    this.selectedData.splice(this.selectedData.indexOf(element), 1);
                    if (this.selectedLimit.indexOf(element.limitId) !== -1) {
                        this.selectedLimit.splice(this.selectedLimit.indexOf(element.limitId), 1);
                    }
                }
            });
        }
    }

    navigateBack() {
        this.popUpShow = true;
        this.canDeactivate();
        this.collateralSummaryService.collateralOperation = 'FACILITY LINKAGE';
        if (this.source === 'CollateralList') {
            let navigationExtras: NavigationExtras;
            navigationExtras = {
                queryParams: {
                    'gcin': this.gcinCpValue,
                    'label': this.gcinDesc
                }
            };
            this.router.navigate(['./collateralList'], navigationExtras);
        } else {
            let navigationExtras: NavigationExtras;
            navigationExtras = {
                queryParams: {
                    'cid': this.collateralService.collateral.collateralId,
                    'ctype': this.ctype,
                    'gcin': this.gcinCpValue,
                    'label': this.gcinDesc
                }
            };
            this.router.navigate(['./collateral'], navigationExtras);
        }
    }

    navigateToColl(value?: any) {
        this.showPopupDialog = false;
        this.popUpShow = true;
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'gcin': this.gcinCpValue,
                'label': this.gcinDesc
            }
        };
        this.canDeactivate();
        if (value === 'save') {
            this.linkCollateral();
            this.draftRecordService.saveCollateralAsDraft();
        }
        if (this.collateralSummaryService.breadcrumbvalue) {
            this.router.navigate(['/collateralSummary'], navigationExtras);
        } else {
            this.router.navigate(['./collateralList'], navigationExtras);
        }
    }

    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.showPopupDialog = showPopupDialog;
    }
}

