import { DeactivateLoading } from './new-collateral/new-collateral-deactivate.guard';
import { Component, HostListener, OnInit, ViewEncapsulation } from '@angular/core';
import {FormGroup} from '@angular/forms';
import {OauthService} from '../shared';
import {CollateralReponse} from './collateralData';
import { PlatformLocation } from '@angular/common';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'collateral',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './collateral.html',
    styleUrls: ['./collateral.component.scss']

})
export class CollateralComponent implements OnInit,DeactivateLoading {
    backBtnPress: boolean = false;
    popUpShow: boolean = false;
    showPopupDialog: boolean = false;

    public newCollateralForm: FormGroup;

    constructor(private oauthService: OauthService,location: PlatformLocation) {
        location.onPopState(() => {
            this.backBtnPress = true;
          });
    }

    ngOnInit(): void {

    }
    @HostListener('window:onbeforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        if(this.backBtnPress){
            this.showPopupDialog = true;
            this.backBtnPress = false;
        } else {
            this.showPopupDialog = false;
            this.popUpShow = true;
        }
        return  this.popUpShow;
      }
      closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.showPopupDialog = showPopupDialog;
    }
    popUpshowEvent(event:any){
        this.popUpShow = event;
        this.canDeactivate();
    }

}
