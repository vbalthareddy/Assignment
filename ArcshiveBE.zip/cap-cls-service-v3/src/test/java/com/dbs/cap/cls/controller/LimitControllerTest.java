package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.oauth.OAuth2TestHelper;
import com.dbs.cap.cls.common.test.BaseMockMvcWiremockIntegrationTest;
import com.dbs.cap.cls.common.test.IntegrationTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.http.Fault;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Category(IntegrationTest.class)
@ActiveProfiles("test")
public class LimitControllerTest extends BaseMockMvcWiremockIntegrationTest {
    @Autowired
    private OAuth2TestHelper oauthHelper;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        mockResponse(WireMock.post(WireMock.urlMatching("^/oauth/token.*")),
                "{\"access_token\":\"token1234\",\"expires_in\":28776}");
    }

    @Test
    public void create_limit_200() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")),
                null);
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\"}");
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Entitys/linkEntityToLimitNode.*")),
                null);
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Customers.*")),
                null);
        MockHttpServletRequestBuilder createLimit = post("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content("{\"approvalRefNo\":\"12345\"}");
        mvc.perform(createLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.limitId").value("LIMIT12345"));
    }

    @Test
    public void create_limit_null_approvalrefno() throws Exception {
        MockHttpServletRequestBuilder createLimit = post("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content("{\"approvalRefNo2\":\"12345\"}");
        mvc.perform(createLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void create_limit_duplicate_found_for_approvalrefno() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\"}");
        MockHttpServletRequestBuilder createLimit = post("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName");
        mvc.perform(createLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void create_limit_customer_exist() throws Exception {
        wireMockRule.stubFor(WireMock.post(WireMock.urlMatching("^/api/Customers.*"))
                .willReturn(aResponse().withFault(Fault.MALFORMED_RESPONSE_CHUNK)));
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")), null);
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\"}");
        MockHttpServletRequestBuilder createLimit = post("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content("{\"approvalRefNo\":\"12345\"}");
        mvc.perform(createLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void create_limit_and_customer() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Customers.*")),
                null);
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Customers.*")), null);
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")), null);
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\"}");
        MockHttpServletRequestBuilder createLimit = post("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content("{\"approvalRefNo\":\"12345\"}");
        mvc.perform(createLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void exception_for_invalid_url() throws Exception {
        MockHttpServletRequestBuilder createLimit = get("/cls/api/v1/limits/LIM123")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(createLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isNotFound());
    }

    @Test
    public void createLimit_invalidRequest_DuplicateEntityException() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")),
                "[{\"limitId\":\"LIMIT12345\"}]");
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Customers.*")), null);
        wireMockRule.stubFor(WireMock.post(WireMock.urlMatching("^/api/Limits.*"))
                .willReturn(aResponse().withStatus(HttpStatus.UNPROCESSABLE_ENTITY.value()).withBody
                        ("{\"limitId\":\"LIMIT12345\"}")));
        MockHttpServletRequestBuilder createLimit = post("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .header("gcin", "gcin")
                .header("borrowerName", "gcin_name")
                .content("{\"approvalRefNo\":\"12345\"}");
        mvc.perform(createLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void getLimits_returnsLimitList_200OK() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")),
                "[{\"limitId\":\"LIMIT12345\"}]");
        MockHttpServletRequestBuilder getLimits = get("/cls/api/v1/limit?filter=test")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getLimits.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void getLimits_Throws_Exception_Empty_Filter() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")),
                "[{\"limitId\":\"LIMIT12345\"}]");
        MockHttpServletRequestBuilder getLimits = get("/cls/api/v1/limit?filter=")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getLimits.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void getLimits_NetworkProblem_returnsErrorClientError() throws Exception {
        wireMockRule.resetAll();
        MockHttpServletRequestBuilder getLimitsWithInvalidUrl = get("/cls/api/v1/limit")
                .param("filter", "filter_1234")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(getLimitsWithInvalidUrl.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isNotFound());
    }

    @Test
    public void updateLimit_validRequest_returns200OK() throws Exception {
        String getLimitResponse = "[{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"approvalRefNo\": " +
                "\"TEST1234/1/TEST-7\",\"id\": \"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\","
                + "\"accounts\": [{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST1\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\": \"ODA1\",\"tenorYears\": 24}"
                + ",{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST2\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\":" +
                " " +
                "\"ODA1\",\"tenorYears\": 24}]}]";
        String request = "{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"approvalRefNo\": " +
                "\"TEST1234/1/TEST-7\",\"id\": \"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\","
                + "\"accounts\": [{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST1\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\": \"ODA1\",\"tenorYears\": 24}"
                + ",{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST3\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\":" +
                " " +
                "\"ODA1\",\"tenorYears\": 24}]}";
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")), getLimitResponse);
        mockResponse(WireMock.put(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\"}");
        MockHttpServletRequestBuilder updateLimit = put("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content(request);
        mvc.perform(updateLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void update_limit_check_acitvated_limit_status() throws Exception {
        String getLimitResponse = "[{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"approvalRefNo\": " +
                "\"TEST1234/1/TEST-7\",\"id\": \"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\","
                + "\"limitStatus\":\"ACTIVATED\","
                + "\"drawingLimitIndicator\":\"E\","
                + "\"drawingLimit\":100000.00,"
                + "\"accounts\": [{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST1\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\": \"ODA1\",\"tenorYears\": 24}"
                + ",{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST2\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\":" +
                " " +
                "\"ODA1\",\"tenorYears\": 24}]}]";
        String request = "{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"approvalRefNo\": " +
                "\"TEST1234/1/TEST-7\",\"id\": \"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\","
                + "\"limitStatus\":\"APPROVED\","
                + "\"accounts\": [{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST1\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\": \"ODA1\",\"tenorYears\": 24}"
                + ",{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST3\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\":" +
                " " +
                "\"ODA1\",\"tenorYears\": 24}]}";
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")), getLimitResponse);
        mockResponse(WireMock.put(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\",\"limitStatus\":\"ACTIVATED\"}");
        MockHttpServletRequestBuilder updateLimit = put("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content(request);
        mvc.perform(updateLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.limitStatus", is("ACTIVATED")));
//				.andExpect(jsonPath("$.drawingLimit", is(100000.00)))
//				.andExpect(jsonPath("$.drawingLimitIndicator", is("E")));
    }

    @Test
    public void updateLimit_DeleteAllEntity_validRequest_returns200OK() throws Exception {
        String getLimitResponse = "[{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"approvalRefNo\": " +
                "\"TEST1234/1/TEST-7\",\"id\": \"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\","
                + "\"accounts\": [{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST1\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\": \"ODA1\",\"tenorYears\": 24}"
                + ",{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST2\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\":" +
                " " +
                "\"ODA1\",\"tenorYears\": 24}]}]";
        String request = "{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"approvalRefNo\": " +
                "\"TEST1234/1/TEST-7\",\"id\": \"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\"}";
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")), getLimitResponse);
        mockResponse(WireMock.put(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\"}");
        MockHttpServletRequestBuilder updateLimit = put("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content(request);
        mvc.perform(updateLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void updateLimit_blank_approvalRefNo_throwsException() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")),
                "[{\"limitId\":\"LIMIT12345\"}]");
        MockHttpServletRequestBuilder updateLimit = put("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .content("{\"approvalRefNo2\":\"12345\"}");
        mvc.perform(updateLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void updateLimit_without_approvalRefNo_and_limitid() throws Exception {
        MockHttpServletRequestBuilder updateLimit = put("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content("{\"description\": \"LIMIT-TEST\"}");
        mvc.perform(updateLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void updateLimit_NoApprovalRefno_returns_200OK() throws Exception {
        String getLimitResponse = "[{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"approvalRefNo\": " +
                "\"TEST1234/1/TEST-7\",\"id\": \"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\","
                + "\"accounts\": [{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST1\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\": \"ODA1\",\"tenorYears\": 24}"
                + ",{\"entityType\": \"ODA\",\"entityId\": \"ODA1-TEST2\",\"sourceSystem\": \"CASP\"," +
                "\"productCode\":" +
                " " +
                "\"ODA1\",\"tenorYears\": 24}]}]";
        String request = "{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"id\": " +
                "\"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\"}";
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")), getLimitResponse);
        mockResponse(WireMock.put(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\"}");
        MockHttpServletRequestBuilder updateLimit = put("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content(request);
        mvc.perform(updateLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void updateLimit_invalidApprovalRefno_createLimit() throws Exception {
        String request = "{\"limitId\": \"LIM22766\",\"description\": \"LIMIT-TEST-7\",\"approvalRefNo\": " +
                "\"TEST1234/1/TEST-7\",\"id\": \"36440a3d-beda-4557-a797-92b7346e9559\","
                + "\"customerId\": \"3d172a07-1952-4e92-acd5-afe84220cadc\",\"_version\": " +
                "\"187a2875-d893-4cce-a6ce-b58e65ee2a23\"}";
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")), "[]");
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Limits.*")),
                "{\"limitId\":\"LIMIT12345\"}");
        MockHttpServletRequestBuilder updateLimit = put("/cls/api/v1/limit")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .header("gcin", "gcin")
                .header("borrowerName", "borrowerName")
                .content(request);
        mvc.perform(updateLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void deleteLimit_validRequest_returns200OK() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")),
                "[{\"limitId\":\"LIMIT12345\",\"id\":\"jkiyy-jhyu-hgtyyu-huuj\"}]");
        mockResponse(WireMock.delete(WireMock.urlMatching("^/api/Limits.*")),
                "{\"count\":1}");
        MockHttpServletRequestBuilder deleteLimit = delete("/cls/api/v1/limit/FIG071120171046")
                .contentType(MediaType.APPLICATION_JSON_UTF8);
        mvc.perform(deleteLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void deleteLimit_throws_EntityNotFoundException() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Limits.*")),
                "[]");
        MockHttpServletRequestBuilder deleteLimit = delete("/cls/api/v1/limit/test")
                .contentType(MediaType.APPLICATION_JSON_UTF8);
        mvc.perform(deleteLimit.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isNotFound());
    }
}