import {MockBackend, MockConnection} from '@angular/http/testing';
import {fakeAsync, inject, TestBed} from '@angular/core/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {ChargeService} from './charge.component.service';
import {Observable} from 'rxjs/Observable';
import {ChargeRankJSON, MOCK_NATURE_OF_CHARGES, MOCK_REGISTRATION_AUTHOURITY} from './charge.data';

class MockChargeService {
    getNatureOfCharges() {
        return Observable.of(MOCK_NATURE_OF_CHARGES);
    }

    getChargeRank() {
        return Observable.of(ChargeRankJSON);
    }
}

describe('ChargeService', () => {
    let mockBackend: MockBackend;
    let chargeService: ChargeService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                {provide: ChargeService, useClass: MockChargeService}, ChargeService
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([ChargeService, MockBackend], (service: ChargeService, backend: MockBackend) => {
            chargeService = service;
            mockBackend = backend;
        })
    );

    it('should Create charge service ', inject([ChargeService], (chargeServiceLoc: ChargeService) => {
        expect(chargeServiceLoc).toBeTruthy();
    }));

    it('should call getNatureOfCharges API from service ', fakeAsync(() => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(MOCK_NATURE_OF_CHARGES)});
            connection.mockRespond(new Response(response));
        });
        chargeService.getNatureOfCharges().subscribe((response: Response) => {
            expect(response).toEqual(MOCK_NATURE_OF_CHARGES);
        });
    }));

    it('should throw error when getNatureOfCharges function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        chargeService.getNatureOfCharges()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });
    it('should call getRegistrationAuthorityDetails API from service ', fakeAsync(() => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(MOCK_REGISTRATION_AUTHOURITY)});
            connection.mockRespond(new Response(response));
        });
        chargeService.getRegistrationAuthorityDetails().subscribe((response: Response) => {
            expect(response).toEqual(MOCK_REGISTRATION_AUTHOURITY);
        });
    }));

    it('should throw error when getRegistrationAuthorityDetails function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        chargeService.getRegistrationAuthorityDetails()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

    it('should call getChargeRank API from service', fakeAsync(() => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(ChargeRankJSON)});
            connection.mockRespond(new Response(response));
        });
        chargeService.getChargeRank().subscribe((response: Response) => {
            expect(response).toEqual(ChargeRankJSON);
        });
    }));

    it('should throw error when getChargeRank function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        chargeService.getChargeRank()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });
});
