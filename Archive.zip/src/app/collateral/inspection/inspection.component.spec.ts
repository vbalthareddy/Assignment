import {async, ComponentFixture, TestBed, tick, fakeAsync} from '@angular/core/testing';
import {InspectionComponent} from './inspection.component';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {CommonUIModule} from '../../common/commonUI.module';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';
import {
    AutoCompleteModule,
    ComboBoxModule,
    DropDownListModule,
    DropDownsModule
} from '@progress/kendo-angular-dropdowns';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {InspectionService} from './inspection.service';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {BrowserModule} from '@angular/platform-browser';
import {CommonModule} from '@angular/common';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {CollateralService} from '../collateral.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {InspectionAndAppraisals} from '../model/collateral';
import {Collateral} from '../../collateral/model/collateral';
import {Observable} from 'rxjs/Rx';
import {InspectionFrequencyListResponse, InspectionTypeListResponse} from './inspection.data';

class MockCollateralService {
    getCollateral() {
        return new Collateral();
    }
}
class MockInspectionService {
    getInspectionTypeService() {
        return Observable.of(InspectionTypeListResponse);
    }

    getInspectionFrequencyService() {
        return Observable.of(InspectionFrequencyListResponse);
    }

    getInspectionEmptyList() {
        return [];
    }

    getInspectionList(data: any) {
        const mockInspectionListItem = new InspectionAndAppraisals();
        mockInspectionListItem.inspectionAppraisalType = data.inspectionAppraisalType;
        mockInspectionListItem.inspectionEmployeeId = data.inspectionEmployeeId;
        mockInspectionListItem.firstInspectionAppraisalDate = data.firstInspectionAppraisalDate;
        mockInspectionListItem.latestInspectionAppraisalDate = data.latestInspectionAppraisalDate;
        mockInspectionListItem.frequencyMonths = data.frequencyToSubmit;
        mockInspectionListItem.nextInspectionAppraisalDate = data.nextInspectionAppraisalDate;
        mockInspectionListItem.__row_status = data.__row_status;
        mockInspectionListItem.processIdentifier = 'I';
        mockInspectionListItem.id = 'inspection1234567';
        return mockInspectionListItem;
    }
}
class MockFormBuilder extends FormBuilder {
    getBlankForm() {
        const formBuilder = new FormBuilder;
        const formGroup = formBuilder.group({
            inspectionAppraisalType: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            inspectionEmployeeId: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            firstInspectionAppraisalDate: [''],
            latestInspectionAppraisalDate: [''],
            frequencyToSubmit: [null],
            nextInspectionAppraisalDate: [''],
            inspectionRowStatus: [''],
            inspectionId: [''],
            inspectionVersion: ['']
        });
        return formGroup;
    }

    getAddForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            inspectionAppraisalType: ['Market Value (Current) - Gross Development Value', [<any>Validators.required, <any>Validators.minLength(0)]],
            inspectionEmployeeId: ['test123', [<any>Validators.required, <any>Validators.minLength(0)]],
            firstInspectionAppraisalDate: ['Mon Sep 11 2017 00:00:00 GMT+0530 (India Standard Time)'],
            latestInspectionAppraisalDate: ['Wed Sep 13 2017 00:00:00 GMT+0530 (India Standard Time)'],
            frequencyToSubmit: [0],
            nextInspectionAppraisalDate: ['Sun Sep 17 2017 00:00:00 GMT+0530 (India Standard Time)'],
            inspectionRowStatus: ['added'],
            inspectionId: ['193bc544-27af-51c7-d1f8-19c19745894f'],
            inspectionVersion: ['hdgsdgdhuwhduhewuhdu']
        });
        return formGroup;
    }

    getMainForm() {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            inspectionAppraisalList: ['', [Validators.required]]
        });
        return formGroup;
    }

    setMainForm(data: any) {
        const formBuilder: FormBuilder = new FormBuilder;
        const formGroup: FormGroup = formBuilder.group({
            inspectionAppraisalList: [data, [Validators.required]]
        });
        return formGroup;
    }
}

describe('InspectionComponent', () => {
    let component: InspectionComponent;
    let fixture: ComponentFixture<InspectionComponent>;
    const inspectionData = {
        'inspectionAppraisalType': '16',
        'inspectionEmployeeId': 'test123',
        'firstInspectionAppraisalDate': 'Mon Sep 11 2017 00:00:00 GMT+0530 (India Standard Time)',
        'latestInspectionAppraisalDate': 'Wed Sep 13 2017 00:00:00 GMT+0530 (India Standard Time)',
        'frequencyToSubmit': 0,
        'nextInspectionAppraisalDate': 'Sun Sep 17 2017 00:00:00 GMT+0530 (India Standard Time)',
        'inspectionRowStatus': 'added',
        'inspectionId': '193bc544-27af-51c7-d1f8-19c19745894f',
        'processIdentifier': 'I',
        'inspectionVersion': 'hdgsdgdhuwhduhewuhdu'
    };
    const inpectionDataToDelete = {
        processIdentifier: 'I',
        inspectionAppraisalAgency: '',
        inspectionAppraisalType: 'Market Value (Current) - Gross Development Value',
        inspectionEmployeeId: 'test123',
        frequencyMonths: 'Monthly',
        firstInspectionAppraisalDate: 'Mon Sep 11 2017 00:00:00 GMT+0530 (India Standard Time)',
        latestInspectionAppraisalDate: 'Wed Sep 13 2017 00:00:00 GMT+0530 (India Standard Time)',
        nextInspectionAppraisalDate: 'Sun Sep 17 2017 00:00:00 GMT+0530 (India Standard Time)',
        id: 'inspection1234567',
        __row_status: 'added',
    };
    const blankInpectionData = {
        processIdentifier: '',
        inspectionAppraisalAgency: '',
        inspectionAppraisalType: '',
        inspectionEmployeeId: '',
        frequencyMonths: '',
        firstInspectionAppraisalDate: '',
        latestInspectionAppraisalDate: '',
        nextInspectionAppraisalDate: '',
        id: '',
        __row_status: '',
    };
    const inspectionEditData = {
        'inspectionAppraisalType': 'Market Value (Current) - Gross Development Value',
        'inspectionEmployeeId': 'test123',
        'firstInspectionAppraisalDate': 'Mon Sep 11 2017 00:00:00 GMT+0530 (India Standard Time)',
        'latestInspectionAppraisalDate': 'Wed Sep 13 2017 00:00:00 GMT+0530 (India Standard Time)',
        'frequencyToSubmit': 'CUSTOM',
        'nextInspectionAppraisalDate': 'Sun Sep 17 2017 00:00:00 GMT+0530 (India Standard Time)',
        'inspectionRowStatus': 'added',
        'inspectionId': '193bc544-27af-51c7-d1f8-19c19745894f',
        'inspectionVersion': 'hdgsdgdhuwhduhewuhdu'
    };
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                CommonModule, BrowserModule, LoaderModule, ButtonsModule, CommonUIModule, ClsSharedCommonModule, PopupDialogModule, AutoCompleteModule, DateInputsModule, ComboBoxModule, DropDownListModule, DropDownsModule
            ],
            declarations: [InspectionComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [{provide: CollateralService, useClass: MockCollateralService},
                {provide: InspectionService, useClass: MockInspectionService},
                {provide: FormBuilder, useClass: MockFormBuilder}, InspectionAndAppraisals
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(InspectionComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('Should show normalgrid on init',
        async(() => {
            component.divForNormalGrid = true;
            component.showSummaryGrid = false;
            expect(component.divForNormalGrid).toBe(true);
            component.setUpInspectionTab();
            if (component.showSummaryGrid) {
                expect(component.divForNormalGrid).toBe(false);
            } else {
                expect(component.divForNormalGrid).toBe(true);
            }
        }));
    it('should show no-record-component-found when no data from service',
        async(() => {
            const mockInspectionService: MockInspectionService = new MockInspectionService();
            component.inspectionGridData.push(mockInspectionService.getInspectionEmptyList());
            component.setUpInspectionTab();
            expect(component.noRecordsFlag).toBe(true);
        }));
    it('Data should get from backend for frequency when component is loaded',
        async(() => {
            fixture.detectChanges();
            component.inspectionFrequencyList = [];
            expect(component.inspectionFrequencyList.length).toBe(0);
            component.setUpInspectionTab();
            expect(component.inspectionFrequencyList.length).toBeGreaterThan(0);
        }));
    it('Data should get from backend for inspection type when component is loaded',
        async(() => {
            fixture.detectChanges();
            component.inspectionTypeList = [];
            expect(component.inspectionTypeList.length).toBe(0);
            component.setUpInspectionTab();
            expect(component.inspectionTypeList.length).toBeGreaterThan(0);
        }));
    it('PopDialog should be disabled',
        async(() => {
            expect(component.showPopupDialog).toBe(false);
        }));
    it('PopDialog box should open onclick of ADD Inspection button',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = false;
            component.addInspection();
            expect(component.showPopupDialog).toBe(true);
        }));
    it('PopDialog box should open onclick of ADD Inspection link in no data',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = false;
            component.addInspectionClickedInNoData();
            expect(component.showPopupDialog).toBe(true);
        }));
    it('validation of each field should reset onclick of ADD Inspection button',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = false;
            component.addInspection();
            expect(component.inspectionTypeInvalid).toBe(false);
            expect(component.employeeIdInvalid).toBe(false);
            expect(component.firstInspectionDateInvalid).toBe(false);
            expect(component.latestInspectionDateInvalid).toBe(false);
            expect(component.frequencyInvalid).toBe(false);
            expect(component.nextInspectionDateInvalid).toBe(false);
        }));
    it('Inspection form should be defined onload of component',
        async(() => {
            fixture.detectChanges();
            const mockForm = new MockFormBuilder();
            component.AddInspectionForm = mockForm.getBlankForm();
            component.setUpInspectionTab();
            expect(component.AddInspectionForm).toBeDefined();
        }));
    it('PopDialog box should be close  onclick of close  button',
        async(() => {
            fixture.detectChanges();
            component.showPopupDialog = true;
            component.closeEventFromPopupDialog(false);
            expect(component.showPopupDialog).toBe(false);
        }));
    it('Data should add to grid on click of save button',
        async(() => {
            fixture.detectChanges();
            expect(component.inspectionGridData.length).toBe(0);
            component.showPopupDialog = false;
            component.AddInspectionForm = null;
            component.addInspection();
            const mockForm = new MockFormBuilder();
            component.inspectionForm = mockForm.getMainForm();
            component.AddInspectionForm = mockForm.getAddForm();
            const mockInspectionService: MockInspectionService = new MockInspectionService();
            component.addInspectionData(inspectionData);
            expect(component.inspectionGridData.length).toBeGreaterThan(0);
        }));
    it('Data should display in form onclick of edit icon',
        async(() => {
            fixture.detectChanges();
            component.inspectionGridData = [];
            component.showPopupDialog = false;
            const mockForm = new MockFormBuilder();
            component.AddInspectionForm = mockForm.getAddForm();
            const mockBeneficiaryService = new MockInspectionService();
            component.inspectionTypeList = InspectionTypeListResponse;
            component.inspectionEditFunc(mockBeneficiaryService.getInspectionList(inspectionEditData), 1);
            fixture.detectChanges();
            expect(component.AddInspectionForm.controls['inspectionEmployeeId'].value).toBe('test123');
        }));
    it('Data should update in Grid  onclick of update button',
        async(() => {
            fixture.detectChanges();
            component.inspectionGridData = [];
            component.showPopupDialog = false;
            const mockinspectionService = new MockInspectionService();
            const mockForm = new MockFormBuilder();
            component.inspectionForm = mockForm.getMainForm();
            component.inspectionGridData.push(mockinspectionService.getInspectionList(inspectionData));
            fixture.detectChanges();
            expect(component.inspectionGridData.length).toBeGreaterThan(0);
            component.inspectionTypeList = InspectionTypeListResponse;
            component.inspectionFrequencyList = InspectionFrequencyListResponse;
            const inspectionEditData1 = {
                'inspectionAppraisalType': '16',
                'inspectionEmployeeId': 'test123',
                'firstInspectionAppraisalDate': 'Mon Sep 11 2017 00:00:00 GMT+0530 (India Standard Time)',
                'latestInspectionAppraisalDate': 'Wed Sep 13 2017 00:00:00 GMT+0530 (India Standard Time)',
                'frequencyToSubmit': 1,
                'nextInspectionAppraisalDate': 'Sun Sep 17 2017 00:00:00 GMT+0530 (India Standard Time)',
                'inspectionRowStatus': 'added',
                'inspectionId': 'inspection1234567',
                'inspectionVersion': 'hdgsdgdhuwhduhewuhdu'

            };
            component.rowIndex = 0;
            component.updateInspectionGridList(inspectionEditData1);
            expect(component.inspectionGridData[0].frequencyMonths).toBe(inspectionEditData1.frequencyToSubmit);
        }));
    it('validation check for each field onclick of update/save button',
        async(() => {
            fixture.detectChanges();
            component.inspectionGridData = [];
            component.showPopupDialog = false;
            const mockinspectionService = new MockInspectionService();
            const mockForm = new MockFormBuilder();
            component.inspectionForm = mockForm.getMainForm();
            component.inspectionGridData.push(mockinspectionService.getInspectionList(inspectionData));
            expect(component.inspectionGridData.length).toBe(1);
            const inspectionEditData1 = {
                'inspectionAppraisalType': '',
                'inspectionEmployeeId': '',
                'firstInspectionAppraisalDate': '',
                'latestInspectionAppraisalDate': '',
                'frequencyToSubmit': null,
                'nextInspectionAppraisalDate': '',
                'inspectionRowStatus': '',
                'inspectionId': '',
                'inspectionVersion': 'hdgsdgdhuwhduhewuhjhd'
            };
            component.inspectionTypeList = InspectionTypeListResponse;
            component.inspectionFrequencyList = InspectionFrequencyListResponse;
            component.rowIndex = 0;
            component.updateInspectionGridList(inspectionEditData1);
            expect(component.inspectionTypeInvalid).toBe(true);
            expect(component.employeeIdInvalid).toBe(true);
            expect(component.firstInspectionDateInvalid).toBe(true);
            expect(component.latestInspectionDateInvalid).toBe(true);
            expect(component.frequencyInvalid).toBe(true);
            expect(component.nextInspectionDateInvalid).toBe(true);
        }));
    it('Yes no promt box should appear onclick of Delete icon',
        async(() => {
            fixture.detectChanges();
            component.inspectionGridData = [];
            component.showPopupDialog = false;
            const mockInspectionService = new MockInspectionService();
            const mockForm = new MockFormBuilder();
            component.inspectionForm = mockForm.getMainForm();
            component.inspectionGridData.push(mockInspectionService.getInspectionList(inspectionData));
            expect(component.inspectionGridData.length).toBe(1);
            component.inspectionRemoveItemFunc(inpectionDataToDelete);
            expect(component.showYesNoPrompt).toBe(true);
        }));
    it('newly added data should delete from grid onclick yes icon from promt box',
        async(() => {
            fixture.detectChanges();
            component.inspectionGridData = [];
            component.showPopupDialog = false;
            const mockInspectionService = new MockInspectionService();
            const mockForm = new MockFormBuilder();
            component.inspectionForm = mockForm.getMainForm();
            component.inspectionGridData.push(mockInspectionService.getInspectionList(inspectionData));
            expect(component.inspectionGridData.length).toBe(1);
            component.dataforDelete = inpectionDataToDelete;
            component.confirmationFromYesNo(['yes']);
            expect(component.inspectionGridDataForHtml).toBeLessThan(1);
        }));
    it('pre existing data should delete from grid onclick yes icon from promt box',
        async(() => {
            fixture.detectChanges();
            component.inspectionGridData = [];
            component.showPopupDialog = false;
            const mockInspectionService = new MockInspectionService();
            const mockForm = new MockFormBuilder();
            component.inspectionForm = mockForm.getMainForm();
            component.inspectionGridData.push(mockInspectionService.getInspectionList(inspectionData));
            expect(component.inspectionGridData.length).toBe(1);
            const DataToDelete = {
                processIdentifier: 'I',
                inspectionAppraisalAgency: '',
                inspectionAppraisalType: 'Market Value (Current) - Gross Development Value',
                inspectionEmployeeId: 'test123',
                frequencyMonths: 'Monthly',
                firstInspectionAppraisalDate: 'Mon Sep 11 2017 00:00:00 GMT+0530 (India Standard Time)',
                latestInspectionAppraisalDate: 'Wed Sep 13 2017 00:00:00 GMT+0530 (India Standard Time)',
                nextInspectionAppraisalDate: 'Sun Sep 17 2017 00:00:00 GMT+0530 (India Standard Time)',
                id: 'inspection1234567',
                __row_status: 'modified',
            };
            component.dataforDelete = DataToDelete;
            component.confirmationFromYesNo(['yes']);
            expect(component.inspectionGridDataForHtml).toBeLessThan(1);
        }));
    it('error message should hide if there on first inpection date change',
        async(() => {
            fixture.detectChanges();
            component.onDateChange('123', 'FIRST');
            expect(component.firstInspectionDateInvalid).toBe(false);
        }));
    it('error message should hide if there on latest inpection date change',
        async(() => {
            fixture.detectChanges();
            component.onDateChange('123', 'LATEST');
            expect(component.latestInspectionDateInvalid).toBe(false);
        }));
    it('next inspection will set if frequency is present on latest inpection date change',
        async(() => {
            fixture.detectChanges();
            const mockForm = new MockFormBuilder();
            component.AddInspectionForm = mockForm.getAddForm();
            component.inspectionFrequencyList = InspectionFrequencyListResponse;
            component.onDateChange('123', 'LATEST');
            expect(component.nextInspectionDateInvalid).toBe(false);
        }));
    it('error message should hide if there on next inpection date change',
        async(() => {
            fixture.detectChanges();
            component.onDateChange('123', 'NEXT');
            expect(component.nextInspectionDateInvalid).toBe(false);
            expect(component.frequencyInvalid).toBe(false);
        }));
    it('error message should hide if there on inspection value select',
        async(() => {
            fixture.detectChanges();
            component.typeFilterChange('');
            expect(component.nextInspectionDateInvalid).toBe(false);
            expect(component.frequencyInvalid).toBe(false);
        }));
    it('error message should hide if there on frequency select',
        async(() => {
            fixture.detectChanges();
            component.frequencyFilterChange('');
            expect(component.frequencyInvalid).toBe(false);
        }));
    it('focus on error field',
        fakeAsync(() => {
            component.addInspectionData(blankInpectionData);
            tick(500);
            fixture.detectChanges();
            fixture.whenStable().then(() => {
                // component.ele = ['<div><button class ="k-button has-error"></button></div>'];
            });
        }));
    it('On inspection Type select',
        async(() => {
            fixture.detectChanges();
            component.inspectionTypeList = InspectionTypeListResponse;
            component.onInspectionTypeSelect('16');
            expect(component.inspectionTypeInvalid).toBe(false);
        }));
    it('On invalid frequency select',
        async(() => {
            fixture.detectChanges();
            const mockForm = new MockFormBuilder();
            component.AddInspectionForm = mockForm.getBlankForm();
            component.inspectionFrequencyList = InspectionFrequencyListResponse;
            component.onFrequencySelect(0);
            expect(component.frequencyInvalid).toBe(true);
        }));
    it('Data should filter according to the value entered in inspection types', async(() => {
        component.inspectionTypeList = InspectionTypeListResponse;
        component.typeFilterChange('2');
        expect(component.inspectionTypeData.length).toBe(1);
    }));
    it('Data should filter according to the value entered in inspection frequency', async(() => {
        component.inspectionFrequencyList = InspectionFrequencyListResponse;
        component.frequencyFilterChange('2');
        expect(component.inspectionFrequencyData.length).toBe(1);
    }));
});
