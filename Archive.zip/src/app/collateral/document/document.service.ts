import {Injectable} from '@angular/core';
import {Http, Response, URLSearchParams} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import {Observable} from 'rxjs/Observable';
import {AppSettings} from './../../common/config/appsettings';

@Injectable()
export class DocumentService {

    constructor(private http: Http) {
    }

    public getDocumentCodes(filter?: any): Observable<any> {
        const url = AppSettings.apiBaseUrl + AppSettings.documentCodes;
        const params: URLSearchParams = new URLSearchParams();
        params.set('access_token', null);
        if (!filter) {
            filter = {'fields': ['code', 'description'], 'order': 'code'};
        }
        params.set('filter', JSON.stringify(filter));
        return this.http.get(url, {search: params})
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    public getDocumentStatus(filter?: any): Observable<any> {
        const url = AppSettings.apiBaseUrl + AppSettings.apiDocumentStatus;
        const params: URLSearchParams = new URLSearchParams();
        params.set('access_token', null);
        if (!filter) {
            filter = {'fields': ['code', 'description'], 'order': 'code'};
        }
        params.set('filter', JSON.stringify(filter));
        return this.http.get(url, {search: params})
            .map(this.extractData)
            .catch(error => error.message || error);
    }

    private extractData(res: Response) {
        const body = res.json();
        return body;
    }
}
