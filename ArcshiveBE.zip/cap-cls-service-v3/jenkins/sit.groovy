final APP_NAME = 'cap-cls-service-v3'
def GIT_BRANCH = "develop"
node {
    stage 'Checkout'
    git branch: "${GIT_BRANCH}", url: "https://gitlab.dev.apps.cs.sgp.dbs.com/cap/${APP_NAME}.git"

    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'
    jenkins.maven()
    jenkins.checkSonar("com.dbs.cap:$APP_NAME")
    jenkins.fortify('CST_CAP', APP_NAME, '${GIT_BRANCH}')
    def reportsFileName = "jacoco-report-api-${env.BUILD_NUMBER}.zip"
    sh "zip -r -9 ${reportsFileName} target/site/jacoco-ut"
    jenkins.uploadArtifact(APP_NAME, "${reportsFileName}", "${reportsFileName}")
    sh "rm -f ${reportsFileName}"
    jenkins.uploadArtifact(APP_NAME, "${APP_NAME}.jar", "target/${APP_NAME}.jar")
    jenkins.downloadManifest("https://gitlab.dev.apps.cs.sgp.dbs.com/cap/${APP_NAME}/raw/${GIT_BRANCH}/cloudfoundry/sit.yml")
    jenkins.loginWithCred('api.dev.sys.cs.sgp.dbs.com', 'ecb8efc3-6d07-4e55-bbe1-0a3b08636957')
    jenkins.target("-o dev-credit-risk -s cap-cls-service-v3-sit")
    jenkins.deploy(APP_NAME, "-p target/${APP_NAME}.jar")
}
