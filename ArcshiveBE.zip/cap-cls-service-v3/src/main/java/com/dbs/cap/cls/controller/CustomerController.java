package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.client.EntitySearchClient;
import com.dbs.cap.cls.common.configuration.UAA3Configuration;
import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.common.exception.EntityNotFoundException;
import com.dbs.cap.cls.dto.CounterParty;
import com.dbs.cap.cls.service.CustomerService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/cls/api/v1/")
@Api(value = "Service for Customer")
@Slf4j
public class CustomerController {
    private static final String COUNTER_PARTY = "COUNTERPARTY";
    @Autowired
    private EntitySearchClient entitySearchClient;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private UAA3Configuration uaa3Configuration;

    @PostMapping(path = "/customer/search/",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Search Customer Information")
    public List<CounterParty> searchCustomer(@RequestBody String query) {
        return entitySearchClient.searchByKeyword(query,
                ClsConstants.BEARER + uaa3Configuration.uaa2RestTemplate().getAccessToken().getValue())
                .getSearchResult().getGroupResults().stream()
                .filter(result -> COUNTER_PARTY.equalsIgnoreCase(result.getGroupName()))
                .flatMap(result -> result.getEntities().stream())
                .map(entity -> new CounterParty(entity.getLabel(), entity.getValue(), COUNTER_PARTY, COUNTER_PARTY))
                .collect(Collectors.toList());
    }

    @PostMapping(path = "/entity/search",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation("get counter party's")
    public HashMap<String, Object> getCounterParties(
            @RequestBody HashMap<String, Object> search) {
        return entitySearchClient.searchByKeyword(search,
                ClsConstants.BEARER + uaa3Configuration.uaa2RestTemplate().getAccessToken().getValue());
    }

    @PutMapping(path = "/customer",
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Update a customer in CLS")
    public HashMap<String, Object> updateCustomer(
            @RequestBody HashMap<String, Object> customer) throws EntityNotFoundException {
        return customerService.updateCustomer(customer);
    }

    @PutMapping(path = "/customer/relationship",
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Update customer relationship in CLS")
    public HashMap<String, Object> updateCustomerRelationship(
            @RequestBody HashMap<String, Object> customerRelationship) throws EntityNotFoundException {
        return customerService.updateCustomerRelationship(customerRelationship);
    }
}