import { PopupDialogOnleaveModule } from '../../common/popupdialog-onleave/popupdialog-onleave.module';
import {CommonModule} from '@angular/common';
import {CUSTOM_ELEMENTS_SCHEMA, ModuleWithProviders, NgModule} from '@angular/core';
import {FacilityLinkageDataComponent} from './facility-linkage-data.component';
import {CommonUIModule} from '../../common/commonUI.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {GridModule} from '@progress/kendo-angular-grid';
import {CounterpartyDetailsModule} from '../../shared/counterparty-details/counterparty-details.module';
import {CustomPanelModule} from '../../common/custom-panel/custom-panel.module';
import {FacilityLinkageDataService} from './facility-linkage-data.service';

@NgModule({
    imports: [CommonModule, BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
        BrowserAnimationsModule, CounterpartyDetailsModule,
        GridModule, ClsSharedCommonModule, CommonUIModule, CustomPanelModule,PopupDialogOnleaveModule],
    declarations: [FacilityLinkageDataComponent],
    exports: [FacilityLinkageDataComponent],
    providers: [FacilityLinkageDataService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]

})

export class FacilityLinkageModule {
    public static forRoot(): ModuleWithProviders {
        return {ngModule: FacilityLinkageModule, providers: []};
    }
}