package com.dbs.cap.ct.batch.model;

import lombok.Data;

@Data
public class Corporate extends BaseModel {
    private String corpId;
    private String corpKey;
    private String name;
    private String nativeName;
    private String status;
    private String rm;
    private String crm;
    private String countryOfIncorporation;
    private String type;
    private String customerSegment;
    private String legalParentEntity;
    private String bankBorrowerFlag;
}
