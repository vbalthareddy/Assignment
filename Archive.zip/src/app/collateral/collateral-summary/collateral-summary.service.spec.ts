import {fakeAsync, inject, TestBed} from '@angular/core/testing';
import {MockBackend, MockConnection} from '@angular/http/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {GUARN_TYPE_COLLATERALS, MockCollateralData} from './collateral-summary-mock-data';
import {CollateralSummaryService} from './collateral-summary.service';
import {AppSettings} from './../../common/config/appsettings';
import {AppConfigData} from './../../common/config/app-config.data';
import {Observable} from 'rxjs/Rx';


class MockCollateralSummaryService {
    rateConversionArray: any = [
        {
            from: 'SGD',
            to: 'INR',
            rate: 10
        }
    ];
    collateralOperation = 'Add';
    masterCollateralListFromService = {};
    collateralConfigListFromService = {};

    getCurrency() {
        const data = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        return Observable.of(data);
    }

    getCollateralSummaryData() {
        return Observable.of(MockCollateralData);
    }

    getRateValues(from: string, to: string) {
        if (from === '' && to === '') {
            return Observable.throw({status: 404});

        } else {
            const data = [{'rate': 10}];
            return Observable.of(data);
        }
    }

    getCollateralsList(collateralType: string, collateralApi?: string, filter?: any) {
        const objTemp = [
            {
                'CollateralValuationDetail': {
                    'collateralValue': {
                        'value': 10.00,
                        'ccy': 'SGD'
                    }
                }
            }];
        if (collateralType === '' && filter === '' && collateralApi === '') {
            return Observable.throw({status: 404});
        } else {
            return Observable.of(objTemp);
        }
    }

    getConfig() {
        const tempObj = {
            'GUARN': {
                'sequencePos': 1,
                'label': 'Guarantee',
                'description': 'Guarantee Description',
                'apiToHit': ''
            },
            'DEPOS': {
                'sequencePos': 2,
                'label': 'Guarantee',
                'description': 'Guarantee Description',
                'apiToHit': ''
            }
        };
        return Observable.of(tempObj);
    }
}
class MockActivatedRoute {
    queryParams = {
        subscribe: jasmine.createSpy('subscribe')
            .and
            .returnValue(Observable.of(null))
    };
}


describe('CollateralSummaryService', () => {
    let collateralSummaryService: CollateralSummaryService = null;
    const ratesUrl = AppConfigData.apiBaseUrl + AppSettings.apiToGetRates;
    const currencyUrl = AppConfigData.apiBaseUrl + AppSettings.apiToGetCurrencyList;
    let mockBackend: MockBackend = null;
    const data = MockCollateralData;
    const currencyDropdownList = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
    const mockRateValues = [{rate: 10}, {rate: 17}, {rate: 18}];
    const currencyRateValue = AppConfigData.apiBaseUrl + 'rate';
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                {provide: CollateralSummaryService, useClass: MockCollateralSummaryService},
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                CollateralSummaryService
            ],
            imports: [HttpModule]
        });
    });
    beforeEach(
        inject([CollateralSummaryService, MockBackend], (service: CollateralSummaryService, backend: MockBackend) => {
            collateralSummaryService = service;
            mockBackend = backend;
        })
    );
    it('should Create Collateral Summary service ', inject([CollateralSummaryService], (service: CollateralSummaryService) => {
        expect(service).toBeTruthy();
    }));
    it('Should get response for currency list ', fakeAsync(() => {
        const dataValues = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        const mockResponseBody = dataValues;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralSummaryService.getCurrency().subscribe((response: Response) => {
            expect(response).toEqual(dataValues);
        });
    }));
    it('Should get response for Rate Values', fakeAsync(() => {
        const dataValue = [{'rate': 10}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralSummaryService.getRateValues('', '').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
    }));
    it('Should get response for getCollateralsList', fakeAsync(() => {
        const mockResponseBody = GUARN_TYPE_COLLATERALS;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralSummaryService.getCollateralsList('GUARN', ' ', 'n').subscribe((response: Response) => {
            expect(response).toEqual(GUARN_TYPE_COLLATERALS);
        });
    }));
    it('Should get response for getMsgToken', fakeAsync(() => {
        collateralSummaryService.setMessageToken('', '', '', '', '');
        const resoponse = {'raisedBy': '', 'raisedFor': '', 'actionCode': '', 'message': '', 'timestamp': ''};
        expect(collateralSummaryService.messageToken).toEqual(resoponse);
    }));
    it('Should get response for getMsgToken', fakeAsync(() => {
        collateralSummaryService.messageToken = 'message';
        collateralSummaryService.getMessageToken();
        expect(collateralSummaryService.messageToken).toEqual('message');
        collateralSummaryService.messageToken = null;
        collateralSummaryService.getMessageToken();
        expect(collateralSummaryService.messageToken).toEqual(null);
    }));
    it('Should get response for getCollateralInqRes', fakeAsync(() => {
        const mockResponseBody = GUARN_TYPE_COLLATERALS;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralSummaryService.getCollateralInqRes('BenId123').subscribe((response: Response) => {
            expect(response).toEqual(GUARN_TYPE_COLLATERALS);
        });
    }));

    it('Should get response for getCollateralInqRes', fakeAsync(() => {
        const tempObj = {
            'GUARN': {
                'sequencePos': 1,
                'label': 'Guarantee',
                'description': 'Guarantee Description',
                'apiToHit': ''
            },
            'DEPOS': {
                'sequencePos': 2,
                'label': 'Guarantee',
                'description': 'Guarantee Description',
                'apiToHit': ''
            }
        };
        const mockResponseBody = tempObj;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralSummaryService.getConfig().subscribe((response: Response) => {
            expect(response).toEqual(tempObj);
        });
    }));
    it('all service should call endpoint and return error', (() => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        collateralSummaryService.getConfig()
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
        collateralSummaryService.getCollateralInqRes()
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
        collateralSummaryService.getCollateralInqRes('BenId123')
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
        collateralSummaryService.getCollateralsList('')
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
        collateralSummaryService.getRateValues()
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
        collateralSummaryService.getCurrency()
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
        //
    }));
});
