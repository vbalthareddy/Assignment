class MockSeqGenService {
    getToken() {
        return 'token';
    }

}

class MockLoginService {
}

class MockOathService {
}

