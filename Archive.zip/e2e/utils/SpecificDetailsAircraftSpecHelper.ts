import {E2eSpecHelper} from './E2eSpecHelper';
import {$, browser, protractor} from 'protractor';
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const specificDetails: any = {
    specificDetailsIdOnTab: $('#specific_details_tab'),
    addSpecificDetailsBtn: $('.add-specific-details-btn'),
    saveFormBtn: $('#save-form-btn'),
    updateFormBtn: $('#update-form-btn'),
    editIcon: $('#editIcon-0'),
    deleteIcon: $('#deleteIcon'),
    addDetailsBtn: $('#add-details-btn'),
    closeDialogIcon: $('.k-dialog-close'),
    airframeMakeDropdown: $('#airframe-make-dropdown'),
    airframeMakeSearch: (searchTerm: string): any => $('#airframe-make-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
    airframeModelDropdown: $('#airframe-model-dropdown'),
    airframeModelSearch: (searchTerm: string): any => $('#airframe-model-dropdown .k-searchbar > .k-input').sendKeys(searchTerm),
    selectDropdownList: $('.k-animation-container .k-list .k-item:last-child'),
    airframeSerialInputBox: $('#airframe-serial'),
    airframeSerialInput: (inputTerm: string): any => $('#airframe-serial').sendKeys(inputTerm),
    engineMake: $('#engine-make'),
    engineMakeInput: (inputTerm: string): any => $('#engine-make').sendKeys(inputTerm),
    engineModel: $('#engine-model'),
    engineModelInput: (inputTerm: string): any => $('#engine-model').sendKeys(inputTerm),
    engineSno: $('#engine-sno'),
    engineSnoInput: (inputTerm: string): any => $('#engineSno').sendKeys(inputTerm),
    fusulageNo: $('#fusulage-no'),
    fusulageNoInput: (inputTerm: string): any => $('#fusulageNo').sendKeys(inputTerm),
    tailNo: $('#tail-no'),
    tailNoInput: (inputTerm: string): any => $('#tailNo').sendKeys(inputTerm),
    mfdYear: $('#mfd-year'),
    mfdYearInput: (inputTerm: string): any => $('#mfd-year').sendKeys(inputTerm),
    purchasedDateIcon: $('#purchased-date .input-group-addon'),
    purchasedDateSelect: $('.btn.active'),
    engineRemarksTextarea: $('#engine-remarks.commentTextArea__input'),
    engineRemarksInput: (engineRemarksTextarea: string): any =>
        specificDetails.engineRemarksTextarea.sendKeys(engineRemarksTextarea),

    manufacturerName: $('#manufacturer-name'),
    manufacturerNameInput: (inputTerm: string): any => $('#manufacturer-name').sendKeys(inputTerm),
    operatorName: $('#operator-name'),
    operatorNameInput: (inputTerm: string): any => $('#operator-name').sendKeys(inputTerm),
    noRecordLink: $('#no-records-label-link'),

    addSubHirerLink: $('#addSubHirerLink')

};

const aircraftSubHirerSpecSuiteCreateFlow = require('./SpecificDetailsAircraftSubHirerSpecHelper');

exports.SpecificDetailsTestSuite = function () {
    describe('Specific_Details_Page', function () {

        it('should check for No Record Found', function () {
            specificDetails.noRecordLink.click();
            specificDetails.closeDialogIcon.click();
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Specific Details Found');
            e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding specific details');
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should open popup dialog when clicked on Add Specific Details Button', function () {
            specificDetails.addSpecificDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Add Specific Details');
            e2eSpecHelper.verifyTextContains('.add-specific-details-btn', 'Add Specific Details');
        });

        it('should show validation errors when Specific Details fields are empty and clicked on save button', function () {
            specificDetails.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
        });

        it('validate Specific Details and save data to grid', function () {
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.airframeMakeDropdown.click();
            specificDetails.airframeMakeSearch('AIRFRAME001');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('.form-group-sub-fields');
            specificDetails.airframeModelDropdown.click();
            specificDetails.airframeModelSearch('AIRFRMODEL002');
            specificDetails.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.airframeSerialInputBox.click();
            specificDetails.airframeSerialInput('ARFSN001');
            specificDetails.engineMake.click();
            specificDetails.engineMakeInput('ENGINEMK01');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineModel.click();
            specificDetails.engineModelInput('ENGINEMD01');
            specificDetails.engineSno.click();
            specificDetails.engineSnoInput('ENGINESN01');
            specificDetails.fusulageNo.click();
            specificDetails.fusulageNoInput('FUSN01');
            specificDetails.tailNo.click();
            specificDetails.tailNoInput('TN01');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineRemarksInput.click();
            specificDetails.engineRemarksTextarea('Text Remarks');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.mfdYear.click();
            specificDetails.mfdYearInput('1920');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.purchasedDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            specificDetails.purchasedDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.manufacturerName.click();
            specificDetails.manufacturerNameInput('Marissa');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.operatorName.click();
            specificDetails.operatorNameInput('Marissa');
            e2eSpecHelper.sleepBrowser(2000);
            specificDetails.saveFormBtn.click();
            browser.waitForAngular('wait for toast message');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully Added.');
            e2eSpecHelper.verifyPresence('.k-grid');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should not show other fields for Engine Details When Engine Make is cleared', function () {
            e2eSpecHelper.verifyPresence('#editIcon-0');
            specificDetails.editIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineMakeInput.clear();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.form-group-sub-fields', false);
            specificDetails.closeDialogIcon.click();
            e2eSpecHelper.verifyPresence('.k-grid');
        });

        it('should update Specific Details', function () {
            e2eSpecHelper.verifyPresence('#editIcon-0');
            specificDetails.editIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Update Specific Details');
            specificDetails.manufacturerName.clear();
            specificDetails.manufacturerNameInput('Dave');
            e2eSpecHelper.sleepBrowser(2000);
            specificDetails.updateFormBtn.click();
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should delete specific details item from grid when clicked on delete icon', function () {
            specificDetails.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully removed.');
        });

    });
};

exports.SpecificDetailsTestSuiteForEditFlow = function () {
    describe('Specific_Details_Page for edit flow', function () {

        it('should display Specific Details Tab on click', function () {
            browser.sleep(2000);
            specificDetails.specificDetailsIdOnTab.click();
            browser.waitForAngular();
            e2eSpecHelper.verifyTextContains('#specific_details_tab', 'Specific Details');
            e2eSpecHelper.verifyPresence('.tab-element-underline');
        });

        it('should check for No Record Found', function () {
            specificDetails.noRecordLink.click();
            specificDetails.closeDialogIcon.click();
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Specific Details Found');
            e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding specific details');
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should open popup dialog when clicked on Add Specific Details Button', function () {
            specificDetails.addSpecificDetailsBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Add Specific Details');
            e2eSpecHelper.verifyTextContains('.add-specific-details-btn', 'Add Specific Details');
        });

        it('should show validation errors when Specific Details fields are empty and clicked on save button', function () {
            specificDetails.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
        });

        it('validate Specific Details and save data to grid', function () {
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.airframeMakeDropdown.click();
            specificDetails.airframeMakeSearch('AIRFRAME001');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('.form-group-sub-fields');
            specificDetails.airframeModelDropdown.click();
            specificDetails.airframeModelSearch('AIRFRMODEL002');
            specificDetails.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.airframeSerialInputBox.click();
            specificDetails.airframeSerialInput('ARFSN001');
            specificDetails.engineMake.click();
            specificDetails.engineMakeInput('ENGINEMK01');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineModel.click();
            specificDetails.engineModelInput('ENGINEMD01');
            specificDetails.engineSno.click();
            specificDetails.engineSnoInput('ENGINESN01');
            specificDetails.fusulageNo.click();
            specificDetails.fusulageNoInput('FUSN01');
            specificDetails.tailNo.click();
            specificDetails.tailNoInput('TN01');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineRemarksInput.click();
            specificDetails.engineRemarksTextarea('Test Remarks');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.mfdYear.click();
            specificDetails.mfdYearInput('1920');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.purchasedDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            specificDetails.purchasedDateSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.manufacturerName.click();
            specificDetails.manufacturerNameInput('Marissa');
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.operatorName.click();
            specificDetails.operatorNameInput('Marissa');
            e2eSpecHelper.sleepBrowser(2000);
            specificDetails.saveFormBtn.click();
            browser.waitForAngular('wait for toast message');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully Added.');
            e2eSpecHelper.verifyPresence('.k-grid');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should not show other fields for Engine Details When Engine Make is cleared', function () {
            e2eSpecHelper.verifyPresence('#editIcon-0');
            specificDetails.editIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            specificDetails.engineMakeInput.clear();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.form-group-sub-fields', false);
            specificDetails.closeDialogIcon.click();
            e2eSpecHelper.verifyPresence('.k-grid');
        });

        it('should update Specific Details', function () {
            e2eSpecHelper.verifyPresence('#editIcon-0');
            specificDetails.editIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Update Specific Details');
            specificDetails.manufacturerName.clear();
            specificDetails.manufacturerNameInput('Dave');
            e2eSpecHelper.sleepBrowser(2000);
            specificDetails.updateFormBtn.click();
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should delete specific details item from grid when clicked on delete icon', function () {
            specificDetails.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully removed.');
        });
    });
};
