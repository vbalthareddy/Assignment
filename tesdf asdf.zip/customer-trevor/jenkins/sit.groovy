final APP_NAME = 'customer-trevor'
def GIT_BRANCH = "develop"
node {
    stage 'Checkout'
    git branch: "${GIT_BRANCH}", url: "https://gitlab.dev.apps.cs.sgp.dbs.com/cap/${APP_NAME}.git"

    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'
    jenkins.maven()
    jenkins.uploadArtifact(APP_NAME, "${APP_NAME}.jar", "target/${APP_NAME}.jar")
    jenkins.downloadManifest("https://gitlab.dev.apps.cs.sgp.dbs.com/cap/${APP_NAME}/raw/${GIT_BRANCH}/cloudfoundry/sit.yml")
    jenkins.loginWithCred('api.dev.sys.cs.sgp.dbs.com', 'ecb8efc3-6d07-4e55-bbe1-0a3b08636957')
    jenkins.target("-o dev-credit-risk -s customer-trevor-sit")
    jenkins.deploy(APP_NAME, "-p target/${APP_NAME}.jar")
}
