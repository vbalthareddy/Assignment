package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.client.CollateralClient;
import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.common.io.ResourceFileReader;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Date;
import java.util.Random;

@RestController
@RequestMapping("/cls/api/v1/collateral/")
@Api(value = "Backend API services for collateral")
public class CollateralController {
    @Autowired
    private CollateralClient collateralClient;

    @GetMapping(path = "charge-rank", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "get the ranks of charges")
    public ResponseEntity<Object> getChargeRank() throws IOException {
        return new ResponseEntity<>(
                ResourceFileReader.readResourceFileToString("fixtures/charge_rank.json"),
                HttpStatus.OK);
    }

    @GetMapping(path = "valuation-frequency", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "get the list frequencies for valuation")
    public ResponseEntity<Object> getValuationFrequency() throws IOException {
        return new ResponseEntity<>(
                ResourceFileReader.readResourceFileToString("fixtures/valuation_frequency.json"),
                HttpStatus.OK);
    }

    @GetMapping(path = "bank-detail", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "get bank details")
    public ResponseEntity<String> getBankDetails(
            @RequestParam(value = "bankId", required = false) String bankId,
            @RequestParam(value = "accountNum", required = false) String accountNum) {
        //TODO this need to be updated once we get 3rd Party API to search Account details
        Random random = new Random();
        String bankID = bankId == null ? "" : bankId;
        String accountNumber = accountNum == null ? "123" + Integer.toString(random.nextInt(99999) + 999) : accountNum;
        return new ResponseEntity<>(
                "{\r\n" + "\t\"bankId\":\"" + bankID + "\",\r\n"
                        + "\t\"accountNum\":\"" + accountNumber + "\",\r\n"
                        + "\t\"maturityDate\":\"" + new Date() + "\",\r\n"
                        + "\t\"principalAmount\":\"" + Integer.toString(random.nextInt(99999) + 999) + "\",\r\n"
                        + "\t\"term\":\"term1\",\r\n"
                        + "\t\"availableBalance\":\"" + Integer.toString(random.nextInt(99999) + 999) + "\",\r\n"
                        + "\t\"bankName\":\"DBS Singapore\",\r\n"
                        + "\t\"depositAccName\":\"Marissa\"\r\n"
                        + "}",
                HttpStatus.OK);
    }

    @GetMapping(path = "bank-id", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "get bank id")
    public ResponseEntity<Object> getBankIds() throws IOException {
        return new ResponseEntity<>(
                ResourceFileReader.readResourceFileToString("fixtures/bank_id.json"),
                HttpStatus.OK);
    }

    @GetMapping(
            path = "deposit/{id}/linkage-detail",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "get deposit collateral linkage details")
    public ResponseEntity<?> getDepositCollateralLinkageById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestParam(value = ClsConstants.FILTER, required = false) String filter) {
        return collateralClient.getDepositCollateralLinkageById(id, filter);
    }

    @PutMapping(
            path = "deposit/{id}/linkage-detail",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "update deposit collateral linkage details")
    public ResponseEntity<?> updateDepositCollateralLinkageById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestBody String linkageJson) {
        return collateralClient.updateDepositCollateralLinkageById(id, linkageJson);
    }

    @GetMapping(
            path = "guarantee/{id}/linkage-detail",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "get guarantee collateral linkage details")
    public ResponseEntity<?> getGuranteeCollateralLinkageById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestParam(value = ClsConstants.FILTER, required = false) String filter) {
        return collateralClient.getGuaranteeCollateralLinkageById(id, filter);
    }

    @PutMapping(
            path = "guarantee/{id}/linkage-detail",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "update gurantee collateral linkage details")
    public ResponseEntity<?> updateGuaranteeCollateralLinkageById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestBody String linkageJson) {
        return collateralClient.updateGuaranteeCollateralLinkageById(id, linkageJson);
    }

    @PutMapping(
            path = "guarantee/{id}/withdraw",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "update guarantee collateral withdraw details")
    public ResponseEntity<?> updateGuaranteeCollateralWithdrawById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestBody String guaranteeWithdrawJson) {
        return collateralClient.updateGuarnteeCollateralWithdrawById(id, guaranteeWithdrawJson);
    }

    @PutMapping(
            path = "deposit/{id}/withdraw",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "update deposit collateral withdraw details")
    public ResponseEntity<?> updateDepositCollateralWithdrawById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestBody String depositWithdrawJson) {
        return collateralClient.updateDepositCollateralWithdrawById(id, depositWithdrawJson);
    }

    @GetMapping(
            path = "items-insured",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ApiOperation(value = "get items insured")
    public ResponseEntity<?> getItemsInsured() throws IOException {
        return new ResponseEntity<>(
                ResourceFileReader.readResourceFileToString("fixtures/items-insured.json"),
                HttpStatus.OK);
    }
}
