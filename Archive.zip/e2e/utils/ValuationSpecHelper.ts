import {$, by, element} from 'protractor';
import {E2eSpecHelper} from './E2eSpecHelper';

exports.ValuationTestSuite = function () {
    describe('Valuation_Page', function () {
        const sh = new E2eSpecHelper();
        const collateralSpecSuite = require('./CollateralSpecHelper');

        const valuation: any = {
            valuationIdOnTab: $('#valuation_tab'),
            collDetailsIdOnTab: $('#collDetails_tab'),
            CCYAmt: $('#cdd input[type="text"]'),
            inputVal: '12345',
            outputVal: 'SGD 12,345.00',
            waitTime: 500,
            collValueInputs: element.all(by.xpath('//*[@id="valuation-details-section"]/div[2]/ul/li')),
            GUARNTypeLabel: element(by.cssContainingText('label', 'GUARN')),
            extChargeLabel: element(by.cssContainingText('label', 'External Charge Amount')),
            firstCollValueInput: element.all(by.xpath('//*[@id="valuation-details-section"]/div[2]/ul/li')).get(0),
            valuationHeader: element(by.css('custom-panel')).element(by.cssContainingText('span', 'Valuation'))
        };

        const goToValuationTab = () => {
            const valuationTab = valuation.valuationIdOnTab;
            expect(valuationTab).toBeTruthy();
            valuationTab.click();
            expect(valuationTab.getText()).toEqual('Valuation');
            expect(valuation.valuationHeader).toBeTruthy();
            // sh.sleepBrowser(valuation.waitTime);
        };

        const goToCollateralDetailsTab = () => {
            const collateralDetailsTab = valuation.collDetailsIdOnTab;
            expect(collateralDetailsTab).toBeTruthy();
            collateralDetailsTab.click();
            // sh.sleepBrowser(valuation.waitTime);
        };

        const enterCollateralDetailsCCYAmt = () => {
            expect(valuation.CCYAmt.isPresent()).toBeTruthy();
            valuation.CCYAmt.click();
            sh.sleepBrowser(valuation.waitTime);
            valuation.CCYAmt.clear();
            valuation.CCYAmt.sendKeys(valuation.inputVal);
            element(by.cssContainingText('label', 'CCY Amount')).click();
            // sh.sleepBrowser(valuation.waitTime);
        };

        const checkInitValues = () => {
            if (valuation.GUARNTypeLabel.isPresent()) {
                expect(valuation.collValueInputs.count()).toEqual(4);
            } else {
                expect(valuation.collValueInputs.count()).toEqual(5);
            }
            let count = 0;
            valuation.collValueInputs.each((collVal) => {
                expect(collVal.isPresent()).toBeTruthy();
                if (count === 2) {
                    expect(collVal.element(by.className('section-subsection-value')).getText()).toBe('SGD 0.00');
                } else {
                    expect(collVal.element(by.className('section-subsection-value')).getText()).toBe('SGD 12.00');
                }
                count++;
            });
            // sh.sleepBrowser(valuation.waitTime);
        };

        it('should show Valuation Tab Section', () => {
            goToValuationTab();
        });

        it('all initial currency values should be verified', () => {
            // browser.sleep(valuation.waitTime);
            checkInitValues();
        });

        it('external charge field missing if type \'GUARN\' ', () => {
            if (valuation.GUARNTypeLabel.isPresent()) {
                expect(valuation.extChargeLabel.isPresent()).toBeFalsy();
            } else {
                expect(valuation.extChargeLabel.isPresent()).toBeTruthy();
            }
        });

        it('should reflect the collateral details tab CCY Amount in Valuation Tab\'s Collateral Value Amount', () => {
            // browser.sleep(valuation.waitTime);
            goToCollateralDetailsTab();
            enterCollateralDetailsCCYAmt();
            goToValuationTab();
            expect(valuation.firstCollValueInput.isPresent()).toBeTruthy();
            expect(valuation.firstCollValueInput.element(by.className('section-subsection-value')).getText()).toBe(valuation.outputVal);
        });
    });
};

exports.ValuationTestSuiteForEditFlow = function () {
    describe('Valuation_Page for Edit Flow', function () {
        /*TODO*/
    });
};

exports.ValuationTestForAircraftEditSuite = function () {

};
