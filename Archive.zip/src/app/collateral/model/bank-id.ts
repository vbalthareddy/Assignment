export interface BankId {
    code: string;
    description: string;
    id: string;


}