package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.oauth.OAuth2TestHelper;
import com.dbs.cap.cls.common.test.BaseMockMvcWiremockIntegrationTest;
import com.dbs.cap.cls.common.test.IntegrationTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Category(IntegrationTest.class)
@ActiveProfiles("test")
@WithMockUser
public class CustomerControllerTest extends BaseMockMvcWiremockIntegrationTest {
    @Autowired
    private OAuth2TestHelper oauthHelper;

    @Before
    public void setup() throws Exception {
        mockResponse(WireMock.post(WireMock.urlMatching("^/oauth/token.*")),
                "{\"access_token\":\"token1234\",\"expires_in\":28776}");
    }

    @Test
    public void post_search_entity() throws Exception {
        mockResponse(WireMock.post(WireMock.urlMatching("^/cap-entitysearch/search/.*")),
                null, MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(post("/cls/api/v1/entity/search/")
                .content("{ \"searchKeyword\": \"183105\" }")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void post_search_customer() throws Exception {
        mockResponse(WireMock.post(WireMock.urlMatching("^/cap-entitysearch/search/.*")),
                "{\n" +
                        "    \"searchResult\": {\n" +
                        "        \"topResultPageSize\": 5,\n" +
                        "        \"searchResults\": [\n" +
                        "            {\n" +
                        "                \"groupName\": \"COUNTERPARTY\",\n" +
                        "                \"groupLabel\": \"COUNTERPARTY\",\n" +
                        "                \"totalCount\": 1,\n" +
                        "                \"topSearchResult\": [\n" +
                        "                    {\n" +
                        "                        \"value\": \"GC0000183105\",\n" +
                        "                        \"label\": \"XXXX XXXX XXX (GC0000183105)\"\n" +
                        "                    }\n" +
                        "                ]\n" +
                        "            },\n" +
                        "            {\n" +
                        "                \"groupName\": \"DOA\",\n" +
                        "                \"groupLabel\": \"DOA\",\n" +
                        "                \"totalCount\": 0,\n" +
                        "                \"topSearchResult\": []\n" +
                        "            },\n" +
                        "            {\n" +
                        "                \"groupName\": \"MAS639\",\n" +
                        "                \"groupLabel\": \"MAS639 GROUP\",\n" +
                        "                \"totalCount\": 0,\n" +
                        "                \"topSearchResult\": []\n" +
                        "            },\n" +
                        "            {\n" +
                        "                \"groupName\": \"COUNTRY\",\n" +
                        "                \"groupLabel\": \"COUNTRY\",\n" +
                        "                \"totalCount\": 0,\n" +
                        "                \"topSearchResult\": []\n" +
                        "            }\n" +
                        "        ]\n" +
                        "    }\n" +
                        "}");
        mvc.perform(post("/cls/api/v1/customer/search/")
                .content("{ \"searchKeyword\": \"183105\" }")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void put_customer() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Customers.*")),
                "[{\"entityId\": \"GC1000009262\", \"entityType\":\"CUST\",\"entityName\": \"TEST_GCIN_ML201611211105\",\"id\":\"12345\",\"_version\":\"12345\"}]");
        mockResponse(WireMock.put(WireMock.urlMatching("^/api/Customers.*")),
                null, MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(put("/cls/api/v1/customer")
                .content("{ \"entityId\": \"GC1000009262\", \"entityType\":\"CUST\",\"entityName\": \"TEST_GCIN_ML201611211105\"}")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void put_customer_not_found() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Customers.*")),
                "");
        mockResponse(WireMock.post(WireMock.urlMatching("^/api/Customers.*")),
                "");
        mockResponse(WireMock.put(WireMock.urlMatching("^/api/Customers.*")),
                null, MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(put("/cls/api/v1/customer")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .content("{ \"entityId\": \"GC112345678\"}")
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void put_customer_relationship_gcin_not_exist() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Customers.*")),
                null);
        mvc.perform(put("/cls/api/v1/customer/relationship")
                .content("{ \"childCorpKey\": \"GC1000009262\"}")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isNotFound());
    }

    @Test
    public void put_customer_relationship() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Customers.*")),
                "[{\"entityId\": \"GC1000009262\", \"entityType\":\"CUST\",\"entityName\": \"TEST_GCIN_ML201611211105\",\"id\":\"12345\",\"_version\":\"12345\"}]");
        mockResponse(WireMock.put(WireMock.urlMatching("^/api/Customers.*")),
                null, MediaType.APPLICATION_JSON_UTF8_VALUE);
        mvc.perform(put("/cls/api/v1/customer/relationship")
                .content("{ \"childCorpKey\": \"GC1000009262\", \"linkages\" : \"GPIN1, GPIN2\"}")
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }
}

