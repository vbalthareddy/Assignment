// Required Parameters
// APP_NAME = 'cap-cls-service' or 'cap-cls-service-v3' or 'customer-trevor'
// BUILD_NUMBER
// CF_API_URL = 'sys1 & sys2'
// CF_USERNAME
// CF_PASSWORD
// ORG
// SPACE
node {
    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'
    jenkins.downloadArtifactory(APP_NAME, BUILD_NUMBER, "${APP_NAME}.jar")
    jenkins.downloadArtifactory(APP_NAME, BUILD_NUMBER, "manifest.yml")
    jenkins.login(CF_API_URL, CF_USERNAME, CF_PASSWORD, ORG, SPACE)
    jenkins.deploy(APP_NAME, "-p ${APP_NAME}.jar")
}