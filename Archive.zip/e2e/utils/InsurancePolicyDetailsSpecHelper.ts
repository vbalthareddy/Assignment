import {$, by, element, protractor} from 'protractor';
import {E2eSpecHelper} from './E2eSpecHelper';

exports.InsurancePolicyDetailsTestSuite = function () {
    const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
    describe('Insurance_Policy_Details_Page', function () {
        it('should  navigate to policy Details Page', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#insurance-policy-details-panel-id', 'Add Policy Details');
        });
        it('should validate the Amount fields', () => {
            e2eSpecHelper.sleepBrowser(2000);
            element(by.css('[placeholder="Enter Policy amount"]')).sendKeys('');
            element(by.id('amount')).click();
            expect(element.all(by.id('currencyAmounterror')).getText()).toContain('Please enter amount.');
        });

        it('should navigate to insurance page on click of back button.', () => {

        });
        it('should fill the appropriate data and click on submit button.', () => {
            e2eSpecHelper.sleepBrowser(2000);
            element(by.css('[placeholder="Enter Policy amount"]')).sendKeys('12');
            element(by.css('[placeholder="Enter policy holder name"]')).sendKeys('policy holder name');
            $('#itemsInsured').click();
            $('#itemsInsured .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            $('#frequency').click();
            $('#frequency .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            $('#paymentMethod').click();
            $('#paymentMethod .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            $('#bankID').click();
            $('#bankID .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            $('#branchID').click();
            $('#branchID .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            $('#insuranceAction').click();
            $('#insuranceAction .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            $('#coverType').click();
            $('#coverType .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            element(by.css('[placeholder="Search premium collection A/C ID"]')).sendKeys('collectionID');
            const submitButton = element.all(by.id('policySubmitButton'));
            submitButton.click();

        });
    });
};

