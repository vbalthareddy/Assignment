export const InsuranceTypeResponse = [{
    'code': '013',
    'description': 'Marine Cargo Insurance'
},
{
    'code': '007',
    'description': 'Life Insurance Policy'
},
{
    'code': '004',
    'description': '3rd Party Insurance Policy'
}];


