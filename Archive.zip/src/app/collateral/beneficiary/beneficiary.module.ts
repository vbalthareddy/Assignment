import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {GridModule} from '@progress/kendo-angular-grid';
import {BeneficiaryComponent} from './beneficiary.component';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {AutoCompleteModule, DropDownsModule} from '@progress/kendo-angular-dropdowns';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';
import {BeneficiaryList} from '../model/collateral';
import {BeneficiaryService} from './beneficiary.component.service';
import {CommonUIModule} from '../../common/commonUI.module';
import {WarningPanelModule} from '../../common/warning-panel/warning-panel.module';

@NgModule({
    imports: [CommonModule,
        BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
        BrowserAnimationsModule, DropDownsModule, AutoCompleteModule,
        LoaderModule, GridModule, ClsSharedCommonModule, PopupDialogModule, CommonUIModule, WarningPanelModule
    ],
    declarations: [
        BeneficiaryComponent
    ],
    providers: [BeneficiaryService, BeneficiaryList],
    exports: [BeneficiaryComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class BeneficiaryModule {
}
