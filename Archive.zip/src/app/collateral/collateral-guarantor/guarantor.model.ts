export class GuarantorItemModel {
    cifId: string;
    idType: string;
    idNo: string;
    name: string;
    guarantorType: string;
    collateralOwnerShipPcnt: number;
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
    phoneNo: string;
    emailAddress: string;
    telexNo: string;
    faxNo: string;
    delete: boolean;
    id: string = '';
    __row_status: string = '';

    constructor() {
        this.cifId = '';
        this.idType = '';
        this.idNo = '';
        this.name = '';
        this.collateralOwnerShipPcnt = null;
        this.addressLine1 = '';
        this.addressLine2 = '';
        this.addressLine3 = '';
        this.city = '';
        this.state = '';
        this.country = '';
        this.postalCode = '';
        this.phoneNo = '';
        this.emailAddress = '';
        this.telexNo = '';
        this.faxNo = '';
        this.__row_status = '';
        this.id = '';
        this.delete = false;
    }
}