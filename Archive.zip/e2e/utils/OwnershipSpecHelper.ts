import {E2eSpecHelper} from './E2eSpecHelper';
import {$, browser, protractor} from 'protractor';

exports.OwnershipTestSuite = function () {
    describe('Ownership_Details_Page', function () {
        const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

        const ownershipDOM: any = {
            ownershipIdOnTab: $('#ownership_tab'),
            closeDialogIcon: $('.k-dialog-close'),
            ownershipDetailsList: $(''),
            noRecordFoundSymbol: $('.no-record-container'),
            addOwnershipDetailsLink: $('#no-records-label-link'),
            openOwnershipDetailsDialog: $('#btn_showAddOwnershipDialog'),
            ownershipName: $('.autocomplete-dropdown'),
            ownershipNameDropdownValue: (searchTerm: string): any => $('.autocomplete-dropdown .k-searchbar > .k-input').sendKeys(searchTerm),
            ownershipNameDropdownResult: $('.k-list-container .k-list .k-item:first-child'),
            ownershipNameDropdownResultLastValue: $('.k-list-container .k-list .k-item:last-child'),
            ownershipNameValidation: $('#txt_OwnershipName'),
            ownershipType: $(''),
            ownershipTypeValidation: $(''),
            ownershipPercentage: $('.prefix_percentage_class input'),
            ownershipPercentageInput: (searchTerm: string): any => $('#id_OwnershipPercentage > div > input').sendKeys(searchTerm),
            ownershipPercentageValidation: $(''),
            saveOwnershipDetails: $('#btn_OwnershipDetailSave'),
            pickOwnershipForUpdate: $('.k-grid table tbody tr:first-child #ownershipEditIcon'),
            pickOwnershpForDelete: $('.k-grid table tr:nth-child(1) #ownershipDeleteIcon')
        };

        it('should have the title of tab as Ownership', function () {
            e2eSpecHelper.sleepBrowser(2000);
            ownershipDOM.ownershipIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#ownership_tab', 'Ownership');
        });

        it('should display no-record-component when no data is shown in ownership grid', function () {     // to be dobe as error / undefined
            e2eSpecHelper.verifyPresence('.no-record-container');
        });

        it('should display Add-ownership-Dialog  when clciked on the add ownership detail link ownership grid', function () {
            ownershipDOM.addOwnershipDetailsLink.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyContentOf('.k-dialog-title', 'Add Ownership Details');
            ownershipDOM.closeDialogIcon.click();
        });

        it('should display Add-ownership-Dialog  when clciked on the add ownership detail Button and close down when close clicked', function () {
            ownershipDOM.openOwnershipDetailsDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            ownershipDOM.closeDialogIcon.click();
        });

        it('should display validation errors for a blank Add-ownership-record on Save Button click ', function () {
            ownershipDOM.openOwnershipDetailsDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            ownershipDOM.saveOwnershipDetails.click();
            e2eSpecHelper.verifyPresence('.has-error');
            ownershipDOM.closeDialogIcon.click();
        });

        it('should Add ownership data with valid values and show it on Ownership grid', function () {
            ownershipDOM.openOwnershipDetailsDialog.click();

            // Populate the ownership  name and Type
            ownershipDOM.ownershipName.click();
            e2eSpecHelper.sleepBrowser(1000);
            ownershipDOM.ownershipNameDropdownValue('GCIN');
            e2eSpecHelper.sleepBrowser(2000);       // the interval very much needed - DONOT DELETE
            ownershipDOM.ownershipNameDropdownResult.click();

            // Populate the Ownership Percetnage
            ownershipDOM.ownershipPercentage.click();
            e2eSpecHelper.sleepBrowser(2000);
            ownershipDOM.ownershipPercentageInput('23.547');

            // save the record
            ownershipDOM.saveOwnershipDetails.click();

            //  The sucecss toast should be visible
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of ownership details has been successfully added.');
        });

        it('should not allow Duplicate Ownership data to be Added to Ownership grid', function () {

            ownershipDOM.openOwnershipDetailsDialog.click();

            // Populate the ownership  name and Type
            ownershipDOM.ownershipName.click();
            e2eSpecHelper.sleepBrowser(1000);
            ownershipDOM.ownershipNameDropdownValue('GCIN');
            e2eSpecHelper.sleepBrowser(2000);       // the interval very much needed - DONOT DELETE
            ownershipDOM.ownershipNameDropdownResult.click();

            // Populate the Ownership Percetnage
            ownershipDOM.ownershipPercentage.click();
            e2eSpecHelper.sleepBrowser(2000);
            ownershipDOM.ownershipPercentageInput('23.547');

            // save the record
            ownershipDOM.saveOwnershipDetails.click();
            e2eSpecHelper.verifyTextContains('#id_DuplicateRecord', 'This value already exists in Ownership list.');
            ownershipDOM.closeDialogIcon.click();

        });

        it('should not allow Ownership percentage > 100.00 Ownership Detail ', function () {
            ownershipDOM.openOwnershipDetailsDialog.click();

            // Populate the ownership  name and Type
            ownershipDOM.ownershipName.click();
            e2eSpecHelper.sleepBrowser(1000);
            ownershipDOM.ownershipNameDropdownValue('GCIN');
            e2eSpecHelper.sleepBrowser(2000);       // the interval very much needed - DONOT DELETE
            ownershipDOM.ownershipNameDropdownResultLastValue.click();

            // Populate the Ownership Percetnage
            ownershipDOM.ownershipPercentage.click();
            e2eSpecHelper.sleepBrowser(2000);
            ownershipDOM.ownershipPercentageInput('84.547');

            // save the record
            ownershipDOM.saveOwnershipDetails.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#id_NetPercentageExceedHundred', 'Net percentage cannot be gerater than 100.00%');

            ownershipDOM.closeDialogIcon.click();

        });

        it('should Update ownership data with valid values and show it on Ownership grid upon Update Icon Click ', function () {

            // Select ownership detail to be updated via update icon
            ownershipDOM.pickOwnershipForUpdate.click();
            e2eSpecHelper.sleepBrowser(5000);      // donot delete as this interval is needed for the css to be indetifiefd.

            // Populate the Ownership Percetnage
            ownershipDOM.ownershipPercentage.click();
            e2eSpecHelper.sleepBrowser(2000);

            browser.actions().sendKeys(protractor.Key.DELETE).perform();
            browser.actions().sendKeys(protractor.Key.DELETE).perform();
            browser.actions().sendKeys(protractor.Key.DELETE).perform();
            browser.actions().sendKeys(protractor.Key.DELETE).perform();
            browser.actions().sendKeys(protractor.Key.DELETE).perform();
            browser.actions().sendKeys(protractor.Key.DELETE).perform();
            browser.actions().sendKeys(protractor.Key.DELETE).perform();

            ownershipDOM.ownershipPercentageInput('45.678');

            // save the record
            ownershipDOM.saveOwnershipDetails.click();

            //  The sucecss toast should be visible
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of ownership details has been successfully updated.');

            e2eSpecHelper.sleepBrowser(5000);
        });

        it('should Delete ownership data from Ownership grid upon Delete Icon Click ', function () {

            // Select ownership detail to be updated via update icon
            ownershipDOM.pickOwnershpForDelete.click();

            //  The sucecss toast should be visible
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of ownership details has been successfully removed.');

            e2eSpecHelper.sleepBrowser(5000);
        });

    });
};

exports.OwnershipTestSuiteForEditFlow = function () {
    describe('Ownership_Details_Page for Edit Flow', function () {
        /*TODO */
    });
};

exports.OwnershipTestForAircraftEditSuite = function () {

};
