import {DraftRecordService} from '../../../draftrecord/draft-record.service';
import {CurrencyDropdownService} from '../../../common/currency-dropdown/currency-dropdown.service';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {InsuranceClaimDetailsComponent} from './insurance-claim-details.component';
import {BrowserModule} from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, ElementRef, NO_ERRORS_SCHEMA} from '@angular/core';
import {FormBuilder, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {CollateralService} from '../../../collateral/collateral.service';
import {CollateralSummaryService} from 'app/collateral/collateral-summary/collateral-summary.service';
import {CommonModule} from '@angular/common';
import {CommonUIModule} from '../../../common/commonUI.module';
import {ActivatedRoute, Router} from '@angular/router';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../../shared/shared-common.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {GridModule} from '@progress/kendo-angular-grid';
import {CounterpartyDetailsModule} from '../../../shared/counterparty-details/counterparty-details.module';
import {CustomPanelModule} from '../../../common/custom-panel/custom-panel.module';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {ComboBoxModule} from '@progress/kendo-angular-dropdowns';
import {Observable} from 'rxjs/Observable';
import {InsuranceClaimsDetailsService} from './insurance-claim-details.service';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {collateralResData, insuranceClaimStatus} from './insurance-claim-details-data';
import {InsuranceService} from '../insurance.component.service';
import {InsuranceTypeResponse} from 'app/collateral/insurance/insurance.component.data';


class MockElementRef implements ElementRef {
    nativeElement = {};
}

class MockCollateralSummaryService {
    collateralOperation = 'INSURANCE_CLAIM';

    setMessageToken(raisedBy: string, raisedFor: string, actionCode: string, message: string, timestamp?: string) {
        return true;
    }

}
class MockCollateralService {
    collateral = collateralResData;
    checkPopupDialogBox: boolean = false;
}

class MockInsuranceClaimsDetailsService {
    getInsuranceClaimStatus() {
        return Observable.of(insuranceClaimStatus);
    }

}

class MockCurrencyService {
    getCurrencies(filter?: any) {
        return {
            body: [
                {
                    'code': 'SGD',
                    'description': 'SGD Currency',
                    'id': '5f30e506-a276-4865-95aa-210667ded1a8'
                },
                {
                    'code': 'EUR',
                    'description': 'EUR Currency',
                    'id': '6acc19da-6c8a-441d-ba8b-7d41efbe9ab9'
                }],
            subscribe: function (data?: any) {
            }
        };
    }
}
class MockInsuranceService {
    getInsuranceTypesfromService() {
        return Observable.of(InsuranceTypeResponse);
    }

}
class MockPartyDetailsService {
    temp = new Observable(observer => {
        observer.next({'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'});
    });

    subscribeToCPDetails(temp) {
        return Observable.of({label: 'Personal Leadership Centre Pte.Ltd', value: 'GCIN0000000'});
    }

}
class MockDraftRecordService {
    putDraftRecord() {
        return Observable.of(null);
    }

    postDraftRecord() {
        return Observable.of(null);
    }

    saveCollateralAsDraft() {
        return null;
    }

}


describe('Insurance Claim Component Test Cases', () => {

    let component: InsuranceClaimDetailsComponent;
    let fixture: ComponentFixture<InsuranceClaimDetailsComponent>;
    const router = {
        navigate: jasmine.createSpy('navigate')
    };

    const MockActivatedRoute = {
        queryParams: Observable.of({
            'policyNumber': '1213',
            'functionFlag': 'EDIT',
            'gcin': '1234567',
            'label': 'ABC',
            'ctype': 'COUNTERPATY'
        })
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
                BrowserAnimationsModule, CounterpartyDetailsModule,
                GridModule, ClsSharedCommonModule, CommonUIModule, CustomPanelModule, DateInputsModule, ComboBoxModule],
            declarations: [InsuranceClaimDetailsComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [
                {provide: CounterPartyDetailsService, useClass: MockPartyDetailsService},
                {provide: ElementRef, useValue: new MockElementRef()},
                {provide: Router, useValue: router},
                {provide: ActivatedRoute, useValue: MockActivatedRoute},
                {provide: CollateralService, useClass: MockCollateralService},
                {provide: InsuranceClaimsDetailsService, useClass: MockInsuranceClaimsDetailsService},
                {provide: CollateralSummaryService, useClass: MockCollateralSummaryService},
                {provide: InsuranceService, useClass: MockInsuranceService},
                {provide: CurrencyDropdownService, useClass: MockCurrencyService},
                {provide: DraftRecordService, useClass: MockDraftRecordService}
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(InsuranceClaimDetailsComponent);
        component = fixture.componentInstance;
        component.insuranceTypes = InsuranceTypeResponse;
        component.insuranceType = '013';
        fixture.detectChanges();
    });

    it('should create',
        async(() => {
            fixture.detectChanges();
            expect(component).toBeTruthy();
        }));

    it('should initialise the claim form',
        async(() => {
            fixture.detectChanges();
            component.initializeInsuranceClaimdDetailsForm();
            expect(component.initializeInsuranceClaimdDetailsForm).toBeDefined();
        }));

    it('should populate the claim form with claim info if availible in selected collaterall - insurance item ',
        async(() => {
            fixture.detectChanges();
            component.insuranceListIndex = 0;
            component.populateInsuranceClaimdDetailsFromService();
            expect(component.insuranceClaimItemModel).toBeDefined();
        }));

    it('should populate claim status  values ',
        async(() => {
            fixture.detectChanges();
            component.insuranceTypes = InsuranceTypeResponse;
            component.insuranceType = '013';
            component.initializeServices();
            expect(component.insuranceClaimStatus.length).toBeGreaterThan(0);
        }));

    it('should  proceed to save only on valid data on mandatory fields',
        async(() => {
            fixture.detectChanges();
            component.insuranceListIndex = 0;
            component.initializeInsuranceClaimdDetailsForm();
            component.populateInsuranceClaimdDetailsFromService();
            expect(component.submitInsuranceClaim()).toBeFalsy();
        }));

    it('should Validate the form before submisison',
        async(() => {
            fixture.detectChanges();
            component.insuranceListIndex = 0;
            component.initializeInsuranceClaimdDetailsForm();
            component.populateInsuranceClaimdDetailsFromService();
            component.insuranceClaimDetailsForm['controls']['claimedAmt'].setValue(100.00);
            component.insuranceClaimDetailsForm['controls']['settledAmt'].setValue(300.00);
            component.insuranceClaimDetailsForm['controls']['claimFilingDate'].setValue(new Date('10-11-2001'));
            component.insuranceClaimDetailsForm['controls']['claimAckDate'].setValue(new Date('10-12-2001'));
            component.insuranceClaimDetailsForm['controls']['claimStatus'].setValue('rejected');
            component.functionFlag = 'ADD';
            component.processFunctionFlag();
            expect(component.panelHeaderText).toBe('Add Claim Details');
            component.submitInsuranceClaim();
            expect(component.validateForm()).toBe(false);

        }));

    it('should  Validate the form for bad data and return false',
        async(() => {
            fixture.detectChanges();
            component.insuranceListIndex = 0;
            component.initializeInsuranceClaimdDetailsForm();
            component.populateInsuranceClaimdDetailsFromService();
            component.insuranceClaimDetailsForm['controls']['claimedAmt'].setValue('');
            component.insuranceClaimDetailsForm['controls']['settledAmt'].setValue('');
            component.insuranceClaimDetailsForm['controls']['claimFilingDate'].setValue(new Date('10-12-2001'));
            component.insuranceClaimDetailsForm['controls']['claimAckDate'].setValue(new Date('10-11-2001'));
            component.insuranceClaimDetailsForm['controls']['claimStatus'].setValue('');

            expect(component.validateForm()).toBeFalsy();

        }));
    it('should  save data and return navigate back',
        async(() => {
            fixture.detectChanges();
            component.insuranceListIndex = 0;
            component.initializeInsuranceClaimdDetailsForm();
            component.populateInsuranceClaimdDetailsFromService();
            component.insuranceClaimDetailsForm['controls']['claimedAmt'].setValue('');
            component.insuranceClaimDetailsForm['controls']['settledAmt'].setValue('');
            component.insuranceClaimDetailsForm['controls']['claimFilingDate'].setValue(new Date('10-12-2001'));
            component.insuranceClaimDetailsForm['controls']['claimAckDate'].setValue(new Date('10-11-2001'));
            component.insuranceClaimDetailsForm['controls']['claimStatus'].setValue('');

            expect(component.validateForm()).toBeFalsy();

        }));

    it(' error function throws observable errorrs',
        async(() => {
            fixture.detectChanges();
            const er: Error = new Error('hello');
            er['status'] = 500;
            expect(component.errorReturn(er)).toBeDefined();
            er['status'] = 400;
            expect(component.errorReturn(er)).toBeDefined();
            er['status'] = 409;
            expect(component.errorReturn(er)).toBeDefined();
            er['status'] = 404;
            expect(component.errorReturn(er)).toBeDefined();
        }));

    it(' - resetAllValidationFlags function resets flags ',
        async(() => {
            fixture.detectChanges();
            component.resetAllValidationFlags();

            expect(component.claimAmountValidate).toBeFalsy();
            expect(component.settledAmountValidate).toBeFalsy();
        }));

    it(' - validateClaimedAmount checks for valid entry in claim amount',
        async(() => {
            fixture.detectChanges();

            const evt: Event = new Event('test');

            evt['amount'] = '';
            component.validateClaimedAmount(evt);
            expect(component.claimAmountValidate).toBeTruthy();

            evt['amount'] = 100.00;
            component.validateClaimedAmount(evt);
            expect(component.claimAmountValidate).toBeFalsy();

        }));

    it(' - validateSettleddAmount checks for valid entry in settled  amount ',
        async(() => {
            fixture.detectChanges();

            const evt: Event = new Event('test');

            evt['amount'] = '';
            component.validateSettleddAmount(evt);
            expect(component.settledAmountValidate).toBeTruthy();

            evt['amount'] = 100.00;
            component.validateSettleddAmount(evt);
            expect(component.settledAmountValidate).toBeFalsy();

        }));
    it('on click of back it should navigate back to insuarnce page',
        async(() => {
            fixture.detectChanges();
            component.navigateBack();
            expect(router.navigate).toHaveBeenCalledWith(['./collateral'], Object({
                queryParams: Object({
                    cid: 'COLL12500', ctype: 'COUNTERPATY', gcin: '1234567', label: 'ABC'
                })
            }));
        }));
    it('ackowledgement date should be greater than filling date error should display',
        async(() => {
            fixture.detectChanges();
            const mockFormBuilder = new FormBuilder();
            component.insuranceClaimDetailsForm = mockFormBuilder.group({
                claimedAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                claimedAmtCurrencyType: [],
                claimFilingDate: ['Tue Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                claimAckDate: ['Mon Sep 11 2017 00:00:00 GMT+0530 (India Standard Time)'],
                comments: [''],
                settledAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                settledAmtCurrencyType: [],
                claimStatus: ['', [<any>Validators.required, <any>Validators.required]]
            });
            component.validateFilingdate();
            expect(component.acknowldgementDateValidate).toBe(true);
            expect(component.claimDateValidate).toBe(true);
        }));
    it('ackowledgement date should be greater than filling date error should not be display',
        async(() => {
            fixture.detectChanges();
            const mockFormBuilder = new FormBuilder();
            component.insuranceClaimDetailsForm = mockFormBuilder.group({
                claimedAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                claimedAmtCurrencyType: [],
                claimFilingDate: ['Tue Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                claimAckDate: ['Tues Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                comments: [''],
                settledAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                settledAmtCurrencyType: [],
                claimStatus: ['', [<any>Validators.required, <any>Validators.required]]
            });
            component.validateFilingdate();
            expect(component.acknowldgementDateValidate).toBe(false);
            expect(component.claimDateValidate).toBe(false);
        }));
    it('ackowledgement date should be greater than filling date error should display',
        async(() => {
            fixture.detectChanges();
            const mockFormBuilder = new FormBuilder();
            component.insuranceClaimDetailsForm = mockFormBuilder.group({
                claimedAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                claimedAmtCurrencyType: [],
                claimFilingDate: ['Tue Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                claimAckDate: ['Mon Sep 11 2017 00:00:00 GMT+0530 (India Standard Time)'],
                comments: [''],
                settledAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                settledAmtCurrencyType: [],
                claimStatus: ['', [<any>Validators.required, <any>Validators.required]]
            });
            component.validateAcknowldgementDate();
            expect(component.acknowldgementDateValidate).toBe(true);
            expect(component.claimDateValidate).toBe(true);
        }));
    it('ackowledgement date should be greater than filling date error should not be display',
        async(() => {
            fixture.detectChanges();
            const mockFormBuilder = new FormBuilder();
            component.insuranceClaimDetailsForm = mockFormBuilder.group({
                claimedAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                claimedAmtCurrencyType: [],
                claimFilingDate: ['Tue Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                claimAckDate: ['Tues Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                comments: [''],
                settledAmt: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                settledAmtCurrencyType: [],
                claimStatus: ['', [<any>Validators.required, <any>Validators.required]]
            });
            component.validateAcknowldgementDate();
            expect(component.acknowldgementDateValidate).toBe(false);
            expect(component.claimDateValidate).toBe(false);
        }));
    it('should  save data on edit flow and return navigate back',
        async(() => {
            fixture.detectChanges();
            const mockFormBuilder = new FormBuilder();
            component.insuranceClaimDetailsForm = mockFormBuilder.group({
                claimedAmt: ['123', [<any>Validators.required, <any>Validators.minLength(0)]],
                claimedAmtCurrencyType: ['SGD'],
                claimFilingDate: ['Tue Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                claimAckDate: ['Tues Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                comments: [''],
                settledAmt: ['123', [<any>Validators.required, <any>Validators.minLength(0)]],
                settledAmtCurrencyType: ['SGD'],
                claimStatus: ['1', [<any>Validators.required, <any>Validators.required]]
            });
            component.submitInsuranceClaim();
            expect(router.navigate).toHaveBeenCalledWith(['./collateral'], Object({
                queryParams: Object({
                    cid: 'COLL12500', ctype: 'COUNTERPATY', gcin: '1234567', label: 'ABC'
                })
            }));
        }));
    it('should  save data on add flow and return navigate back',
        async(() => {
            fixture.detectChanges();
            const mockFormBuilder = new FormBuilder();
            component.insuranceClaimDetailsForm = mockFormBuilder.group({
                claimedAmt: ['123', [<any>Validators.required, <any>Validators.minLength(0)]],
                claimedAmtCurrencyType: ['SGD'],
                claimFilingDate: ['Tue Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                claimAckDate: ['Tues Sep 12 2017 00:00:00 GMT+0530 (India Standard Time)'],
                comments: [''],
                settledAmt: ['123', [<any>Validators.required, <any>Validators.minLength(0)]],
                settledAmtCurrencyType: ['SGD'],
                claimStatus: ['1', [<any>Validators.required, <any>Validators.required]]
            });
            component.functionFlag = 'ADD';
            component.submitInsuranceClaim();
            expect(router.navigate).toHaveBeenCalledWith(['./collateral'], Object({
                queryParams: Object({
                    cid: 'COLL12500', ctype: 'COUNTERPATY', gcin: '1234567', label: 'ABC'
                })
            }));
        }));
    it('should close popup dialog on click of close icon', () => {
        component.closeEventFromPopupDialog(false);
        expect(component.showPopupDialog).toBe(false);
    });
    it('should check canDeactive guard', () => {
        component.popUpShow = false;
        expect(component.canDeactivate()).toBe(false);
        component.popUpShow = true;
        component.backBtnPress = true;
        expect(component.canDeactivate()).toBe(true);
        component.backBtnPress = true;
        component.popUpShow = false;
        expect(component.canDeactivate()).toBe(false);
    });
    it('should save data in draft service and navigate to collateral page', () => {
        spyOn(component, 'populateModelwithFormValues');
        spyOn(component, 'updateInsuranceClaim');
        component.navigateToColl('save');
        expect(component.popUpShow).toBe(true);
        let mockCollateralSummary: CollateralSummaryService;
        mockCollateralSummary = TestBed.get(CollateralSummaryService);
        mockCollateralSummary.breadcrumbvalue = true;
        component.navigateToColl('save');
        expect(component.popUpShow).toBe(true);
    });

});

