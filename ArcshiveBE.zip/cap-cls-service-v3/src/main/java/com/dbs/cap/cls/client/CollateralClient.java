package com.dbs.cap.cls.client;

import com.dbs.cap.cls.common.constants.ClsConstants;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@FeignClient(
        name = "CollateralClient",
        url = "${ev.collateral.host}"
)
public interface CollateralClient {
    @RequestMapping(
            path = "/api/DEPOSCollaterals/{id}/linkageDetails",
            method = RequestMethod.GET
    )
    ResponseEntity<Object> getDepositCollateralLinkageById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestParam(value = ClsConstants.FILTER, required = false) String filter);

    @RequestMapping(
            path = "/api/DEPOSCollaterals/{id}/linkageDetails",
            method = RequestMethod.PUT
    )
    ResponseEntity<Object> updateDepositCollateralLinkageById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestBody String linkageJson);

    @RequestMapping(
            path = "/api/GUARNCollaterals/{id}/linkageDetails",
            method = RequestMethod.GET
    )
    ResponseEntity<Object> getGuaranteeCollateralLinkageById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestParam(value = ClsConstants.FILTER, required = false) String filter);

    @RequestMapping(
            path = "/api/GUARNCollaterals/{id}/linkageDetails",
            method = RequestMethod.PUT
    )
    ResponseEntity<Object> updateGuaranteeCollateralLinkageById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestBody String linkageJson);

    @RequestMapping(
            path = "/api/GUARNCollaterals/{id}/withdraw",
            method = RequestMethod.PUT
    )
    ResponseEntity<Object> updateGuarnteeCollateralWithdrawById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestBody String guaranteeWithdrawJson);

    @RequestMapping(
            path = "/api/DEPOSCollaterals/{id}/withdraw",
            method = RequestMethod.PUT
    )
    ResponseEntity<Object> updateDepositCollateralWithdrawById(
            @PathVariable(value = ClsConstants.ID) String id,
            @RequestBody String depositWithdrawJson);
}
