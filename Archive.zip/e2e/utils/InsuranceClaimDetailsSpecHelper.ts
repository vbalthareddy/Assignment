import {$, by, element, protractor} from 'protractor';
import {E2eSpecHelper} from './E2eSpecHelper';

exports.InsurancePolicyDetailsTestSuite = function () {
    const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

    const insuranceClaim: any = {
        claimdetailspanel: $('#claim-details-panel'),
        claimedAmountInput: $('#claimedAmountInput'),
        claimedAmountInputValue: (claimedAmountInputVal: string): any => $('#claimedAmountInput input.cls-text').sendKeys(claimedAmountInputVal),
        claimFilingDate: $('#claimFilingDate  .k-select'),
        claimAckDate: $('#claimAckDate  .k-select'),
        dateToday: $('.k-today '),

        settledAmountInput: $('#settledAmountInput'),
        settledAmountInputValue: (claimedAmountInputVal: string): any => $('#settledAmountInput input.cls-text').sendKeys(claimedAmountInputVal),

        claimSatatusDropDowm: $('#claimStatusDropDown'),
        claimStatusDropDownValue: (searchTerm: string): any => $('#claimStatusDropDown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
        selectDropdownList: $('.k-animation-container .k-list .k-item:last-child')
    };

    describe('Insurance_Claim_Details_Page', function () {
        it('should  navigate to Claim Details Page', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#claim-details-panel', 'Add Claim Details');
        });

        it('should validate the Amount fields', () => {
            e2eSpecHelper.sleepBrowser(2000);

            insuranceClaim.claimedAmountInput.click();
            insuranceClaim.claimedAmountInputValue('');
            insuranceClaim.claimFilingDate.click();

            expect(element.all(by.css('error_message_ccy_component')).getText()).toContain('Please enter claimed amount.');
        });

        it('should add insurance claim data with valid values and submit it ', function () {

            insuranceClaim.claimedAmountInput.click();
            insuranceClaim.claimedAmountInputValue('100k');

            insuranceClaim.claimFilingDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            insuranceClaim.dateToday.click();

            insuranceClaim.claimAckDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            insuranceClaim.dateToday.click();

            insuranceClaim.settledAmountInput.click();
            insuranceClaim.settledAmountInputValue('200k');

            insuranceClaim.claimSatatusDropDowm.click();
            insuranceClaim.claimStatusDropDownValue('c');
            e2eSpecHelper.sleepBrowser(1000);
            insuranceClaim.selectDropdownList();

            e2eSpecHelper.buttonClick('#claimDetailsSubmitButton');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'successfully added.');
            e2eSpecHelper.sleepBrowser(3000);
        });
    });

    it('should navigate to insurance page on click of back button.', () => {
        e2eSpecHelper.buttonClick('#claimDetailsBackButton');
        expect(e2eSpecHelper.verifyTextContains('#claim-details-panel', 'Add Claim Details')).toBeFalsy();
    });

}

exports.InsurancePolicyDetailsTestSuiteEditWorkflow = function () {
    const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

    const insuranceClaim: any = {
        claimdetailspanel: $('#claim-details-panel'),
        claimedAmountInput: $('#claimedAmountInput'),
        claimedAmountInputValue: (claimedAmountInputVal: string): any => $('#claimedAmountInput input.cls-text').sendKeys(claimedAmountInputVal),
        claimFilingDate: $('#claimFilingDate  .k-select'),
        claimAckDate: $('#claimAckDate  .k-select'),
        dateToday: $('.k-today '),

        settledAmountInput: $('#settledAmountInput'),
        settledAmountInputValue: (claimedAmountInputVal: string): any => $('#settledAmountInput input.cls-text').sendKeys(claimedAmountInputVal),

        claimSatatusDropDowm: $('#claimStatusDropDown'),
        claimStatusDropDownValue: (searchTerm: string): any => $('#claimStatusDropDown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
        selectDropdownList: $('.k-animation-container .k-list .k-item:last-child')
    };

    describe('Insurance_Claim_Details_Page', function () {
        it('should  navigate to Claim Details Page', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#claim-details-panel', 'Update Claim Details');
        });

        it('should validate the Amount fields', () => {
            e2eSpecHelper.sleepBrowser(2000);

            insuranceClaim.claimedAmountInput.click();
            insuranceClaim.claimedAmountInputValue('');
            insuranceClaim.claimFilingDate.click();

            expect(element.all(by.css('error_message_ccy_component')).getText()).toContain('Please enter claimed amount.');
        });

        it('should update insurance claim data with valid values and submit it ', function () {

            insuranceClaim.claimedAmountInput.click();
            insuranceClaim.claimedAmountInput.clear();
            insuranceClaim.claimedAmountInputValue('200k');

            insuranceClaim.claimFilingDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            insuranceClaim.dateToday.click();

            insuranceClaim.claimAckDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            insuranceClaim.dateToday.click();

            insuranceClaim.settledAmountInput.click();
            insuranceClaim.settledAmountInput.clear();
            insuranceClaim.settledAmountInputValue('300k');

            insuranceClaim.claimSatatusDropDowm.click();
            insuranceClaim.claimSatatusDropDowm.clear();
            insuranceClaim.claimStatusDropDownValue('d');
            e2eSpecHelper.sleepBrowser(1000);
            insuranceClaim.selectDropdownList();

            e2eSpecHelper.buttonClick('#claimDetailsSubmitButton');
            e2eSpecHelper.sleepBrowser(3000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'successfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });
    });

    it('should navigate to insurance page on click of back button.', () => {
        e2eSpecHelper.buttonClick('#claimDetailsBackButton');
        expect(e2eSpecHelper.verifyTextContains('#claim-details-panel', 'Update Claim Details')).toBeFalsy();
    });

}

