import {BrowserModule} from '@angular/platform-browser';
import {APP_INITIALIZER, NgModule} from '@angular/core';
import {Http, RequestOptions, XHRBackend} from '@angular/http';
import {OAuthModule} from 'angular-oauth2-oidc';

import {routing} from './app.routes';
import {ReferenceDataModule} from './reference-data/';
import {CollateralModule} from './collateral/';
import {SequenceGeneratorModule} from './sequence-generator/sequence-generator.module';
import {ClsMainComponent, HeaderModule} from './layouts';
import { ClsSharedModule, SeqGenService, UserRouteAccessService } from './shared/index';
import {HttpInterceptor} from './shared/httpapi/http-interceptor.servie';
import {ClsHomeModule} from './home';
import {ClsLoginModule} from './login';
import {CollateralSummaryModule} from './collateral/collateral-summary/collateral-summary.module';
import {CollateralsListModule} from './collateral/collaterals-list/collaterals-list.module';
import {ConfigService} from './common/config/config.service';
import { SessionService } from './shared/auth/session.service';

export function getHttpInterceptor(backend: XHRBackend, defaultOptions: RequestOptions) {
    return new HttpInterceptor(backend, defaultOptions);
}

export function startupServiceFactory(startupService: ConfigService): Function {
    console.log('startupService', startupService);
    return () => {
        return startupService.loadEnvironmentalVariables();
    }; // => required, otherwise `this` won't work inside StartupService::load
}

@NgModule({
    declarations: [
        ClsMainComponent
    ],
    imports: [
        BrowserModule,
        ClsLoginModule,
        ClsSharedModule,
        HeaderModule,
        SequenceGeneratorModule,
        CollateralModule,
        ReferenceDataModule,
        CollateralSummaryModule,
        CollateralsListModule,
        ClsHomeModule,
        routing,
        OAuthModule.forRoot()
    ],
    providers: [{
        provide: Http,
        useFactory: getHttpInterceptor,
        deps: [XHRBackend, RequestOptions]
    }, {
        provide: APP_INITIALIZER,
        useFactory: startupServiceFactory,
        deps: [ConfigService],
        multi: true
    }, SeqGenService,
        UserRouteAccessService, ClsSharedModule,
        ConfigService, SessionService
    ],

    bootstrap: [ClsMainComponent]
})


export class AppModule {
}
