package com.dbs.cap.ct.batch.model;

import lombok.Data;

@Data
public class CorpRelationship extends BaseModel {
    private String childCorpKey;
    private String linkages;
}
