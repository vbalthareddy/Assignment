package com.dbs.cap.ct.batch.model;

import lombok.Data;

@Data
public class RelationCustomer {
    private String childCorpKey;
    private String linkages;
}
