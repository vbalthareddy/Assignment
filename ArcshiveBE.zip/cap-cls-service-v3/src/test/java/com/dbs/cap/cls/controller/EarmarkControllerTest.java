package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.oauth.OAuth2TestHelper;
import com.dbs.cap.cls.common.test.BaseMockMvcWiremockIntegrationTest;
import com.dbs.cap.cls.common.test.IntegrationTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.http.Fault;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Category(IntegrationTest.class)
@ActiveProfiles("test")
public class EarmarkControllerTest extends BaseMockMvcWiremockIntegrationTest {
    @Autowired
    private OAuth2TestHelper oauthHelper;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        mockResponse(WireMock.post(WireMock.urlMatching("^/oauth/token.*")),
                "{\"access_token\":\"token1234\",\"expires_in\":28776}");
    }

    @Test
    public void get_earmark_with_filter_ok() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Earmarks.*")),
                null);
        MockHttpServletRequestBuilder getEarmark = get("/cls/api/v1/earmark?filter=12345")
                .contentType(MediaType.APPLICATION_JSON_UTF8);
        mvc.perform(getEarmark.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void get_earmark_with_filter_400() throws Exception {
        MockHttpServletRequestBuilder getEarmark = get("/cls/api/v1/earmark")
                .contentType(MediaType.APPLICATION_JSON_UTF8);
        mvc.perform(getEarmark.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void update_earmark_ok() throws Exception {
        mockResponse(WireMock.get(WireMock.urlMatching("^/api/Earmarks.*")),
                "[{\n" +
                        "  \"earmarkId\": \"1712-19\",\n" +
                        "  \"earmarkStatus\":\"UPLIFTED\",\n" +
                        "  \"wfStatus\":\"FINAL\",\n" +
                        "  \"id\": \"8ce753f7-3975-4481-b727-cd927d167f48\",\n" +
                        "  \"_version\": \"896b85b8-6958-4472-9873-f73dfc46e7e1\"\n" +
                        "}]");
        mockResponse(WireMock.put(WireMock.urlMatching("^/api/Earmarks.*")),
                null);
        MockHttpServletRequestBuilder updateEarmark = put("/cls/api/v1/earmark")
                .content("{\n" +
                        "  \"earmarkId\": \"1712-19\",\n" +
                        "  \"earmarkStatus\":\"UPLIFTED\",\n" +
                        "  \"wfStatus\":\"FINAL\"\n" +
                        "}")
                .contentType(MediaType.APPLICATION_JSON_UTF8);
        mvc.perform(updateEarmark.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isOk());
    }

    @Test
    public void update_earmark_without_payload() throws Exception {
        MockHttpServletRequestBuilder updateEarmark = put("/cls/api/v1/earmark")
                .contentType(MediaType.APPLICATION_JSON_UTF8);
        mvc.perform(updateEarmark.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void update_earmark_without_earmarkId() throws Exception {
        MockHttpServletRequestBuilder updateEarmark = put("/cls/api/v1/earmark")
                .content("{\"test\":\"test\"}")
                .contentType(MediaType.APPLICATION_JSON_UTF8);
        mvc.perform(updateEarmark.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void update_earmark_with_earmarkId_column_but_missing_value() throws Exception {
        MockHttpServletRequestBuilder updateEarmark = put("/cls/api/v1/earmark")
                .content("{\"earmarkId\":\"\"}")
                .contentType(MediaType.APPLICATION_JSON_UTF8);
        mvc.perform(updateEarmark.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
                .andExpect(status().isBadRequest());
    }
}