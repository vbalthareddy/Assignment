package com.dbs.cap.ct.batch;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import javax.sql.DataSource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import com.dbs.cap.ct.batch.config.BatchConfiguration;
import com.dbs.cap.ct.batch.mapper.CorpRelationshipRowMapper;
import com.dbs.cap.ct.batch.mapper.CorporateRowMapper;
import com.dbs.cap.ct.batch.model.CorpRelationship;
import com.dbs.cap.ct.batch.model.Corporate;
import com.dbs.cap.ct.batch.model.Customer;
import com.dbs.cap.ct.batch.model.RelationCustomer;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {Application.class, DSConfig.class, BatchTestConfig.class})
public class BatchRunnerTest {

  @Autowired
  private DataSource ds;

  @Autowired
  private BatchConfiguration batchJobConfig;

  private CorporateRowMapper corpRowMapper;
  private CorpRelationshipRowMapper corpRelationshipRowMapper;

  private ResultSet metaData;
  private Corporate corporate;
  private CorpRelationship corpRelationship;
  private Customer cust;
  private RelationCustomer relCust;

  @Before
  public void setUp() throws Exception {
    batchJobConfig.perform();
    setMetaData();
    corpRowMapper = new CorporateRowMapper();
    corpRelationshipRowMapper = new CorpRelationshipRowMapper();
    setCorporateObject();
    setCorpRelationshipObject();
  }

  private void setMetaData() throws Exception {
    DatabaseMetaData databaseMetaData = ds.getConnection().getMetaData();
    metaData = databaseMetaData.getTables(null, null, null, null);
  }

  private void setCorporateObject() throws Exception {
    Connection conn = ds.getConnection();
    ResultSet rs = conn.prepareStatement(getQuery()).executeQuery();
    rs.next();
    corporate = corpRowMapper.mapRow(rs, 0);
  }

  private void setCorpRelationshipObject() throws Exception {
    Connection conn = ds.getConnection();
    ResultSet rs = conn.prepareStatement(getCorpRelationQuery()).executeQuery();
    rs.next();
    corpRelationship = corpRelationshipRowMapper.mapRow(rs, 0);
  }

  private static String getQuery() {
    final String query =
        "select c.*, (select GROUP_CONCAT(PARENT_CORP_KEY SEPARATOR ', ')  from CORP_RELATIONSHIP "
            + " WHERE c.CORP_KEY  = CHILD_CORP_KEY and RELATIONSHIP = 'DOA' group by CHILD_CORP_KEY ) as LINKAGES "
            + " from CORPORATE c where ( c.corp_type = 'CUST') ";
    return query;
  }

  private static String getCorpRelationQuery() {
    final String query =
        "select CHILD_CORP_KEY, GROUP_CONCAT(PARENT_CORP_KEY SEPARATOR ', ') as LINKAGES "
            + "from CORP_RELATIONSHIP WHERE "
            + " CHILD_CORP_KEY LIKE 'GP%' and RELATIONSHIP = 'DOA' GROUP BY CHILD_CORP_KEY";
    return query;
  }

  @Test
  public void test_Corporate_table_Exists() throws Exception {
    while (metaData.next()) {
      String tableName = metaData.getString("TABLE_NAME");
      if ("CORPORATE".equals(tableName)) {
        assertEquals("CORPORATE", tableName);
      }
    }
  }

  @Test
  public void test_Corporate_RelationShip_table_Exists() throws Exception {
    while (metaData.next()) {
      String tableName = metaData.getString("TABLE_NAME");
      if ("CORP_RELATIONSHIP".equals(tableName)) {
        assertEquals("CORP_RELATIONSHIP", tableName);
      }
    }
  }

  @Test
  public void test_Corporate_Data_Exists() throws Exception {
    assertNotNull(corporate);
    assertEquals(corporate.getCorpKey(), "GP030226DOA");
  }

  @Test
  public void test_Corporate_Relationship_Data_Exists() throws Exception {
    assertNotNull(corpRelationship);
    assertEquals(corpRelationship.getChildCorpKey(), "GP030226DOA");
  }

  @Test
  public void test_Corporate_Customer_Processor() throws Exception {
    cust = batchJobConfig.corpProcessor().process(corporate);
    assertNotNull(cust);
    assertEquals(cust.getEntityId(), "GP030226DOA");
  }

  @Test
  public void test_Corporate_Relationship_Processor() throws Exception {
    relCust = batchJobConfig.corpRelationProcessor().process(corpRelationship);
    assertNotNull(relCust);
    assertEquals(relCust.getChildCorpKey(), "GP030226DOA");
  }

  @Test
  public void test_Corporate_Customer_Writer() throws Exception {
    test_Corporate_Customer_Processor();
    batchJobConfig.corpWrite().write(new ArrayList<Customer>(Arrays.asList(cust)));
  }

  @Test
  public void test_Corp_Relationship_Customer_Writer() throws Exception {
    test_Corporate_Relationship_Processor();
    batchJobConfig.corpRelationWrite()
        .write(new ArrayList<RelationCustomer>(Arrays.asList(relCust)));
  }

}
