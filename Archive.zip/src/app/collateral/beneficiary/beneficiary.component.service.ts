import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {Headers, Http, RequestOptions, Response, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {AppSettings} from './../../common/config/appsettings';

@Injectable()
export class BeneficiaryService {
    public params: any;

    constructor(private http: Http) {

    }

    public getBeneficiaryIdDataService(data: any): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        params.set('access_token', null);
        const filter = {'order': 'gcin'};
        params.set('filter', JSON.stringify(filter));
        const urlToGetBeneficiaryId = AppSettings.apiBaseUrl + AppSettings.apiToGetCifId;
        const headers = new Headers({'Content-Type': 'application/json'});
        const options = new RequestOptions({headers: headers});
        return this.http.post(urlToGetBeneficiaryId, data, {search: params})
            .map(
                res => res.json()
            )
            .catch(
                error => error.message || error
            );
    }

    addBeneficiary(item: any): Observable<any> {
        const urlToPostBeneficiary = AppSettings.apiBaseUrl + AppSettings.apiCollateralCustomer;
        const customer = {
            'entityId': item.beneficiaryId,
            'entityType': 'C',
            'entityName': item.beneficiaryName
        };
        return this.http.post(urlToPostBeneficiary, customer)
            .map(onSuccessSuccess.bind(this))
            .catch(error => error.message || error);
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

    public getBeneficiaryRankService(): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const filter = {'fields': ['code', 'description'], 'order': 'description'};
        params.set('filter', JSON.stringify(filter));
        const urlToGetBeneficiaryRank = AppSettings.apiBaseUrl + AppSettings.apiToGetBeneficiaryRank;
        return this.http.get(urlToGetBeneficiaryRank, {search: params})
            .map(
                res => res.json()
            )
            .catch(error => error.message || error);
    }

}
