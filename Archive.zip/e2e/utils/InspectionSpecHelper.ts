import {E2eSpecHelper} from './E2eSpecHelper';
import {$} from 'protractor';

const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const inspection: any = {
    inspectionIdOnTab: $('#inspection_tab'),
    addIInspectionBtnForPopDialog: $('.clsBtnSecondary'),
    inspectionSaveBtn: $('#inspection_save'),
    inspectionUpdateBtn: $('#inspection_update'),
    closeButton: $('.k-dialog-close'),
    inspectionTypeDropdown: $('.inspection_type'),
    inspectionTypeDropdownResult: $('.k-list-container .k-list .k-item:nth-child(1)'),
    inspectionTypeDropdownValue: (searchTerm: string): any => $('.inspection_type .k-searchbar > .k-input').sendKeys(searchTerm),
    inspectionEmployeeId: $('.employee_id'),
    inspectionEmployeeIdValue: (searchTerm: string): any => $('.employee_id > input').sendKeys(searchTerm),
    firstInspectionDate: $('#firstInspectionAppraisalDate .k-select'),
    latestInspectionDate: $('#latestInspectionAppraisalDate .k-select'),
    nextInspectionDate: $('#nextInspectionAppraisalDate .k-select'),
    dateToday: $('.k-today '),
    dateWeekend: $('.k-weekend'),
    inspectionFrequencyDropdown: $('.frequency'),
    inspectionFrequencyDropdownResult: $('.k-list-container .k-list .k-item:nth-child(4)'),
    inspectionFrequencyDropdownValue: (searchTerm: string): any => $('.frequency .k-searchbar > .k-input').sendKeys(searchTerm),
    inspectionEditIcon: $('.k-grid table tr:nth-child(1) #inspectionEditIcon'),
    inspectionDeleteIcon: $('.k-grid table tr:nth-child(1) #inspectionDeleteIcon'),
    noRecordLink: $('#no-records-label-link')

};

exports.InspectionTestSuite = function () {
    describe('Inspection_Page', function () {
        it('should have the title of tab as Inspection', function () {
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#inspection_tab', 'Inspection');
        });
        it('should display validation errors in inspection dialog box when entering invalid value for Inspection Data', function () {
            e2eSpecHelper.sleepBrowser(1000);
            inspection.addIInspectionBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionSaveBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(2000);
        });
        it('should add valid inspection data, display toast and reflect on grid on click of add inspection button', function () {
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionTypeDropdown.click();
            inspection.inspectionTypeDropdownValue('Market');
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionTypeDropdownResult.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionEmployeeId.click();
            inspection.inspectionEmployeeIdValue('TestEmployee123');
            e2eSpecHelper.sleepBrowser(1000);
            inspection.firstInspectionDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.dateWeekend.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.latestInspectionDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.dateToday.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionFrequencyDropdown.click();
            inspection.inspectionFrequencyDropdownValue('CUS');
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionFrequencyDropdownResult.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionSaveBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of inspection details has been successfully added.');
        });
        it('should update valid inspection data, display toast and reflect on grid on click of add inspection button', function () {
            e2eSpecHelper.verifyPresence('#inspectionEditIcon');
            inspection.inspectionEditIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.nextInspectionDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.dateToday.click();
            e2eSpecHelper.sleepBrowser(1000);
            inspection.inspectionUpdateBtn.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of inspection details has been successfully updated.');
        });
        it('should delete inspection data, display toast and reflect on grid on click of delete icon', function () {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('#inspectionDeleteIcon');
            e2eSpecHelper.sleepBrowser(2000);
            inspection.inspectionDeleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of inspection details has been successfully deleted.');
        });
        it('should display no-record-component when no data is shown in inspection grid', function () {
            e2eSpecHelper.sleepBrowser(1000);
            inspection.noRecordLink.click();
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Inspection Details Found');
            e2eSpecHelper.sleepBrowser(2000);
            inspection.closeButton.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding inspection details');
        });
    });
};

exports.InspectionTestSuiteForEditFlow = function () {
    describe('Inspection_Page for Edit Flow', function () {
        describe('Inspection_Page', function () {
            it('should have the title of tab as Inspection', function () {
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionIdOnTab.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('#inspection_tab', 'Inspection');
            });
            it('should display validation errors in inspection dialog box when entering invalid value for Inspection Data', function () {
                e2eSpecHelper.sleepBrowser(1000);
                inspection.addIInspectionBtnForPopDialog.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionSaveBtn.click();
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyPresence('.has-error');
                e2eSpecHelper.sleepBrowser(2000);
            });
            it('should add valid inspection data, display toast and reflect on grid on click of add inspection button', function () {
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionTypeDropdown.click();
                inspection.inspectionTypeDropdownValue('Market');
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionTypeDropdownResult.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionEmployeeId.click();
                inspection.inspectionEmployeeIdValue('TestEmployee123');
                e2eSpecHelper.sleepBrowser(1000);
                inspection.firstInspectionDate.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.dateWeekend.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.latestInspectionDate.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.dateToday.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionFrequencyDropdown.click();
                inspection.inspectionFrequencyDropdownValue('CUS');
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionFrequencyDropdownResult.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionSaveBtn.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of inspection details has been successfully added.');
            });
            it('should update valid inspection data, display toast and reflect on grid on click of add inspection button', function () {
                e2eSpecHelper.verifyPresence('#inspectionEditIcon');
                inspection.inspectionEditIcon.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.nextInspectionDate.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.dateToday.click();
                e2eSpecHelper.sleepBrowser(1000);
                inspection.inspectionUpdateBtn.click();
                e2eSpecHelper.sleepBrowser(1000);
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of inspection details has been successfully updated.');
            });
            it('should delete inspection data, display toast and reflect on grid on click of delete icon', function () {
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyPresence('#inspectionDeleteIcon');
                e2eSpecHelper.sleepBrowser(2000);
                inspection.inspectionDeleteIcon.click();
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of inspection details has been successfully deleted.');
            });
            it('should display no-record-component when no data is shown in inspection grid', function () {
                e2eSpecHelper.sleepBrowser(1000);
                inspection.noRecordLink.click();
                e2eSpecHelper.verifyTextContains('#no-records-header', 'No Inspection Details Found');
                e2eSpecHelper.sleepBrowser(2000);
                inspection.closeButton.click();
                e2eSpecHelper.sleepBrowser(2000);
                e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding inspection details');
            });
        });
    });

    exports.InspectionTestForAircraftEditSuite = function () {

    }

}