import {Component, Input} from '@angular/core';
import {FormGroup} from '@angular/forms';

@Component({
    moduleId: module.id,
    selector: 'collateral-details',
    templateUrl: 'collateral-details.html',
})
export class CollateralDetailsComponent {
    @Input()
    public collateralDetailsForm: FormGroup;

    @Input()
    collateralLoaded: boolean = false;

    constructor() {

    }
}
