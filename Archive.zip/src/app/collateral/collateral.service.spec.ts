import { inject, TestBed, fakeAsync } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { CollateralService } from './collateral.service';
import { AutoSaveService } from '../common/autosave/auto-save.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CollateralSummaryService } from './collateral-summary/collateral-summary.service';
import { Observable } from 'rxjs/Rx';
import { CurrencyDropdownService } from '../common/currency-dropdown/currency-dropdown.service';
import {
    Collateral,
    CollateralValuationDetail,
    DeposLodgeCollateralTypeSpecificDetail,
    GuarnLodgeCollateralTypeSpecificDetail,
    OwnerShipList
} from './model/collateral';
import { MOCK_CHARGE_DETAILS_LIST, MOCK_SPECIFIC_DETAIL_DATA_FOR_DEPOS, MOCK_VALUATION, draftCollateralData } from './collateralData';
import { CustomFormControl } from '../common/custom-form-controls/custom-form-control';
import { SessionService } from 'app/shared/auth/session.service';
import { collateralConfig } from './new-collateral/new-collateral.data';

class MockAutoSaveService {
    unsubscribeToFormChanges() {

    }
}

class MockSessionService {
    getUsername() {
       return 'cmsadmin';
    }
}

class MockFormBuilder {
    _fb: FormBuilder = new FormBuilder();
}

class MockCollateralService {
    _fb: FormBuilder = new FormBuilder();
    collateral: Collateral = new Collateral();
    collateralForm: FormGroup;

    createCollateralForm() {
        this.collateralForm = this._fb.group({
            details: this.getDetailsForm(),
            beneficiary: this.getBeneficiaryForm(),
            charge: this.getChargeForm(),
            valuation: this.getApportionForm(),
            document: this.getDocumentForm(),
            ownership: this.getOwnershipForm(),
            particulars: this.getParticularsForm(),
            inspection: this.getInspectionForm(),
            insurance: this.getInsuranceForm()
        });

        return this.collateralForm;
    }

    getRateForCurrency(from: string, to: string) {
        if (from === to) {
            return 1;
        } else {
            const data = [{
                fromCurrency: 'SGD',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            },
            {
                fromCurrency: 'INR',
                toCurrency: 'SGD',
                rate: 10
            }];
            return Observable.of(data);
        }
    }

    getRateValues(from: string, to: string) {
        if (to === '') {
            return Observable.throw({ status: 404 });

        } else {
            const data = [{
                fromCurrency: 'SGD',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            }, {
                fromCurrency: 'INR',
                toCurrency: 'SGD',
                rate: 10
            }];
            return Observable.of(data);
        }
    }

    getDetailsForm() {
        return this._fb.group({
            collateralid: ['']
        });
    }

    getParticularsForm() {
        return this._fb.group({
            particularsList: ['']
        });
    }

    getBeneficiaryForm() {
        return this._fb.group({
            beneficiaryList: [this.collateral.beneficiaryDetails]
        });
    }

    getDocumentForm(document?: Document) {
        return this._fb.group({
            documentidList: []
        });
    }

    getChargeForm() {
        return this._fb.group({
            chargeList: ['']
        });
    }

    getApportionForm() {
        return this._fb.group({
            // apportionList: [CollateralReponse.CollateralValuationDetail, [Validators.required]]
        });
    }

    getOwnershipForm() {
        return this._fb.group({
            ownershipid: []
        });
    }

    getInspectionForm() {
        return this._fb.group({
            ownershipid: []
        });
    }

    getInsuranceForm() {
        return this._fb.group({
            ownershipid: []
        });
    }
    getDraftCollateral(collateralId: string): Observable<any> {
        return Observable.of(draftCollateralData);
    }
}

class MockCollateralSummaryService {

    getRateValues(from: string, to: string) {
        const data = [{
            fromCurrency: 'SGD',
            toCurrency: 'INR',
            rate: 10
        }, {
            fromCurrency: 'SGD',
            toCurrency: 'SGD',
            rate: 1
        }, {
            fromCurrency: 'INR',
            toCurrency: 'SGD',
            rate: 10
        }, {
            fromCurrency: 'SGD',
            toCurrency: 'SGD',
            rate: 1
        }];
        return Observable.of(data);
    }
    getCollateralsList(collateralType: string, collateralApi?: string, filter?: any): Observable<any> {
        return Observable.of([draftCollateralData[0].modelData]);
    }
}

class MockCurrencyService {
    getCurrencies(filter?: any) {
        return {
            body: [
                {
                    'code': 'SGD',
                    'description': 'SGD Currency',
                    'id': '5f30e506-a276-4865-95aa-210667ded1a8'
                },
                {
                    'code': 'EUR',
                    'description': 'EUR Currency',
                    'id': '6acc19da-6c8a-441d-ba8b-7d41efbe9ab9'
                }],
            subscribe: function (data?: any) {
            }
        };
    }
}

describe('CollateralService', () => {
    let collateralService: CollateralService;
    let mockBackend: MockBackend;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                { provide: AutoSaveService, useclass: MockAutoSaveService },
                { provide: FormBuilder, useClass: MockFormBuilder },
                { provide: CollateralSummaryService, useClass: MockCollateralSummaryService },
                { provide: SessionService, useClass: MockSessionService },
                { provide: CurrencyDropdownService, useClass: MockCurrencyService },
                { provide: CollateralService, useClass: MockCollateralService }, FormBuilder,
                CollateralService
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([CollateralService, MockBackend], (service: CollateralService, backend: MockBackend) => {
            collateralService = service;
            mockBackend = backend;
        })
    );

    it('should ...', inject([CollateralService], (service: CollateralService) => {
        expect(service).toBeTruthy();
    }));

    it('should process collateral value when selected collateral is DEPOS', () => {
        const collateralCurrency = 'SGD';
        const formField: CustomFormControl = new CustomFormControl();
        let collateralService: CollateralService;
        collateralService = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral();
        const deposSpecificDetailObj = new DeposLodgeCollateralTypeSpecificDetail();
        deposSpecificDetailObj.depositDetails = MOCK_SPECIFIC_DETAIL_DATA_FOR_DEPOS;
        collateral.LodgeCollateralTypeSpecificDetail = deposSpecificDetailObj;
        collateralService.selectedCollateralType = 'DEPOS';
        const collateralValuationDetails = new CollateralValuationDetail();
        collateral.CollateralValuationDetail = MOCK_VALUATION;
        spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'INR',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            }
        ];
        collateralService.processCollateralValueForCollateralType(collateralCurrency, formField);
        expect(collateralService.ratesLoaded).toBeTruthy();
        expect(formField.value).toBe('40000');
    });

    it('should process collateral value when selected collateral is GUARN', () => {
        const collateralCurrency = 'SGD';
        const formField: CustomFormControl = new CustomFormControl();
        formField.setValue(5.00);
        let collateralService: CollateralService;
        collateralService = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral();
        collateralService.selectedCollateralType = 'GUARN';
        const collateralValuationDetails = new CollateralValuationDetail();
        collateral.CollateralValuationDetail = MOCK_VALUATION;
        spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'INR',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            }
        ];
        collateralService.processCollateralValueForCollateralType(collateralCurrency, formField);
        expect(collateralService.ratesLoaded).toBeTruthy();
        expect(formField.value).toBe(5.00);
    });

    it('should process collateral value when selected collateral other than GUARN and DEPOS and when collateral value is smaller than external charge', () => {
        const collateralCurrency = 'SGD';
        const formField: CustomFormControl = new CustomFormControl();
        formField.setValue(5.00);
        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        collateralService_1.chargeCompErrors = [];
        const collateral: Collateral = new Collateral();
        collateral.LodgeChargeDetail.chargeDetailList = MOCK_CHARGE_DETAILS_LIST;
        collateralService_1.selectedCollateralType = 'AIRCF';
        const collateralValuationDetails = new CollateralValuationDetail();
        collateral.CollateralValuationDetail = MOCK_VALUATION;
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'INR',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            }
        ];
        collateralService_1.processCollateralValueForCollateralType(collateralCurrency, formField);
        expect(collateralService_1.ratesLoaded).toBeTruthy();
        expect(collateralService_1.chargeCompErrors[0]).toEqual('Total External charge should not exceed the collateral value.');
    });

    it('should process collateral value when selected collateral other than GUARN and DEPOS and when collateral value is greater than external charge', () => {
        const collateralCurrency = 'SGD';
        const formField: CustomFormControl = new CustomFormControl();
        formField.setValue(123456.00);
        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        collateralService_1.chargeCompErrors = [];
        const collateral: Collateral = new Collateral();
        collateral.LodgeChargeDetail.chargeDetailList = MOCK_CHARGE_DETAILS_LIST;
        collateralService_1.selectedCollateralType = 'AIRCF';
        const collateralValuationDetails = new CollateralValuationDetail();
        collateral.CollateralValuationDetail = MOCK_VALUATION;
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'INR',
                toCurrency: 'INR',
                rate: 10
            }
        ];
        collateralService_1.processCollateralValueForCollateralType(collateralCurrency, formField);
        expect(collateralService_1.ratesLoaded).toBeTruthy();
        expect(collateralService_1.chargeCompErrors.length).toEqual(0);
    });

    it('should test get currency api when rate conversion array has values', () => {
        const collateralCcy = 'INR';
        const amountCcy = 'SGD';
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'SGD',
                toCurrency: 'INR',
                rate: 10
            }, {
                fromCurrency: 'SGD',
                toCurrency: 'SGD',
                rate: 1
            }
        ];
        expect(collateralService.getRateForCurrency(collateralCcy, amountCcy)).toEqual(10);
    });

    it('should test get currency api when rate conversion array has values but dont have specified currencies', () => {
        const collateralCcy = 'INR';
        const amountCcy = 'SGD';
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [
            {
                fromCurrency: 'USD',
                toCurrency: 'PSD',
                rate: 10
            }
        ];
        expect(collateralService.getRateForCurrency(collateralCcy, amountCcy)).toEqual(0);
    });

    it('should test get currency api when rate conversion array has no values', () => {
        const collateralCcy = 'INR';
        const amountCcy = 'SGD';
        let mockCollateralSummaryService: CollateralSummaryService;
        mockCollateralSummaryService = TestBed.get(CollateralSummaryService);
        spyOn(mockCollateralSummaryService, 'getRateValues').and.callThrough();
        mockCollateralSummaryService.rateConversionArray = [];
        expect(collateralService.getRateForCurrency(collateralCcy, amountCcy)).toEqual(0);
    });

    it('should test amount formatter method for various test scenarios', () => {
        expect(collateralService.amountFormatter('1k')).toEqual('1000');
        expect(collateralService.amountFormatter('1m')).toEqual('1000000');
        expect(collateralService.amountFormatter('1b')).toEqual('1000000000');
        expect(collateralService.amountFormatter(null)).toEqual('');
    });

    it('should successfully post collateral', () => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({ body: JSON.stringify(mockResponseBody) });
            connection.mockRespond(new Response(response));
        });

        const collateral: Collateral = new Collateral;
        collateralService.selectedCollateralType = 'GUARN';
        collateralService.collateralConfig = collateralConfig;
        collateralService.postCollateral(collateral).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'DEPOS';
        collateralService.postCollateral(collateral).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'AIRCF';
        collateralService.postCollateral(collateral).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'VEHIC';
        collateralService.postCollateral(collateral).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'BOATS';
        collateralService.postCollateral(collateral).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
    });

    it('should create collateral form', () => {
        collateralService = TestBed.get(CollateralService);
        spyOn(collateralService, 'getDetailsForm').and.returnValue(null);
        spyOn(collateralService, 'getBeneficiaryForm').and.returnValue(null);
        spyOn(collateralService, 'getChargeForm').and.returnValue(null);
        spyOn(collateralService, 'getApportionForm').and.returnValue(null);
        spyOn(collateralService, 'getDocumentForm').and.returnValue(null);
        spyOn(collateralService, 'getOwnershipForm').and.returnValue(null);
        spyOn(collateralService, 'getParticularsForm').and.returnValue(null);
        spyOn(collateralService, 'getInspectionForm').and.returnValue(null);
        spyOn(collateralService, 'getInsuranceForm').and.returnValue(null);
        collateralService.createCollateralForm();
        expect(collateralService.formCreated).toBe(true);
    });

    it('should successfully submit a collateral', () => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({ body: JSON.stringify(mockResponseBody) });
            connection.mockRespond(new Response(response));
        });

        collateralService.selectedCollateralType = 'GUARN';
        collateralService.collateralConfig = collateralConfig;
        collateralService.submitCollateral().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'DEPOS';
        collateralService.submitCollateral().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'AIRCF';
        collateralService.submitCollateral().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'VEHIC';
        collateralService.submitCollateral().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'BOATS';
        collateralService.submitCollateral().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
    });

    it('should successfully get collateral from BE', () => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({ body: JSON.stringify(mockResponseBody) });
            connection.mockRespond(new Response(response));
        });

        const filter = {
            include: ''
        };

        collateralService.selectedCollateralType = 'GUARN';
        collateralService.collateralConfig = collateralConfig;
        collateralService.getCollaterals(filter).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'DEPOS';
        collateralService.getCollaterals(filter).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.selectedCollateralType = 'AIRCF';
        collateralService.getCollaterals(filter).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
    });

    it('should cover miscellaneous methods from collateral service', () => {
        collateralService.getDisabledTab();
        expect(collateralService.disableTab).toBe(false);
        collateralService.getDisabledButton();
        expect(collateralService.disabltButton).toBe(false);
        const mockLimitDataBeneficiary = {};
        expect(collateralService.getLimitData()).toEqual(mockLimitDataBeneficiary);
        const mockErrors = [];
        collateralService.setErrors(mockErrors);
        expect(collateralService.errors.length).toEqual(mockErrors.length);

    });

    it('should check for ownership validation when collateral type is selected as DEPOS and ownership list has data', () => {
        const formBuilder: FormBuilder = new FormBuilder;
        const ownershipForm: FormGroup = formBuilder.group({});
        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral();
        const mockOwnershipList: OwnerShipList = new OwnerShipList();
        collateral.ownershipDetails = [mockOwnershipList];
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);
        collateralService_1.selectedCollateralType = 'DEPOS';
        collateralService_1.addOwnershipVallidation(ownershipForm);
        expect(ownershipForm.get('totalPercentageSum').value).toBe(100);
        collateralService_1.validateOwnershipDetails(ownershipForm);
        expect(ownershipForm.get('totalPercentageSum').value).toBe(100);
    });

    it('should check for ownership validation when collateral type is selected as DEPOS and ownership list has no data', () => {
        const formBuilder: FormBuilder = new FormBuilder;
        const ownershipForm: FormGroup = formBuilder.group({});
        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral();
        const mockOwnershipList: OwnerShipList = new OwnerShipList();
        collateral.ownershipDetails = [];
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);
        collateralService_1.selectedCollateralType = 'DEPOS';
        collateralService_1.addOwnershipVallidation(ownershipForm);
        expect(ownershipForm.get('totalPercentageSum').value).toBe(null);
        collateralService_1.validateOwnershipDetails(ownershipForm);
        expect(ownershipForm.get('totalPercentageSum').value).toBe(null);
    });

    it('should check for ownership validation when collateral type is selected as GUARN and ownership list has data', () => {
        const formBuilder: FormBuilder = new FormBuilder;
        const ownershipForm: FormGroup = formBuilder.group({
            minGridLengthCheck: [],
            minGridLengthCheckForJOINT: [],
            totalPercentageSum: []
        });
        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral();
        const mockOwnershipList: OwnerShipList = new OwnerShipList();
        collateral.ownershipDetails = [mockOwnershipList];
        const guarnSpecificDetailObj = new GuarnLodgeCollateralTypeSpecificDetail();
        guarnSpecificDetailObj.guaranteeType = 'JOINT';
        collateral.LodgeCollateralTypeSpecificDetail = guarnSpecificDetailObj;
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);
        collateralService_1.selectedCollateralType = 'GUARN';
        collateralService_1.validateOwnershipDetails(ownershipForm);
        expect(ownershipForm.get('minGridLengthCheck').value).toBe(true);
        expect(ownershipForm.get('minGridLengthCheckForJOINT').value).toBe(false);
        expect(ownershipForm.get('totalPercentageSum').value).toBe(null);
        collateralService_1.guarantorGridLengthValidation(ownershipForm);
        expect(ownershipForm.get('minGridLengthCheck').value).toBe(true);
        expect(ownershipForm.get('minGridLengthCheckForJOINT').value).toBe(false);
        expect(ownershipForm.get('totalPercentageSum').value).toBe(null);
    });

    it('should check for ownership validation when collateral type is selected as GUARN and ownership list has no data', () => {
        const formBuilder: FormBuilder = new FormBuilder;
        const ownershipForm: FormGroup = formBuilder.group({
            minGridLengthCheck: [],
            minGridLengthCheckForJOINT: [],
            totalPercentageSum: []
        });
        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral();
        const mockOwnershipList: OwnerShipList = new OwnerShipList();
        collateral.ownershipDetails = [];
        const guarnSpecificDetailObj = new GuarnLodgeCollateralTypeSpecificDetail();
        guarnSpecificDetailObj.guaranteeType = 'JOINT';
        collateral.LodgeCollateralTypeSpecificDetail = guarnSpecificDetailObj;
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);
        collateralService_1.selectedCollateralType = 'GUARN';
        collateralService_1.validateOwnershipDetails(ownershipForm);
        expect(ownershipForm.get('minGridLengthCheck').value).toBe(false);
        expect(ownershipForm.get('minGridLengthCheckForJOINT').value).toBe(true);
        expect(ownershipForm.get('totalPercentageSum').value).toBe(null);
        collateralService_1.guarantorGridLengthValidation(ownershipForm);
        expect(ownershipForm.get('minGridLengthCheck').value).toBe(false);
        expect(ownershipForm.get('minGridLengthCheckForJOINT').value).toBe(true);
        expect(ownershipForm.get('totalPercentageSum').value).toBe(null);
    });

    it('should successfully get data from service methods', () => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({ body: JSON.stringify(mockResponseBody) });
            connection.mockRespond(new Response(response));
        });

        const filter = {
            include: ''
        };

        collateralService.getCollateralFullForm('GUARN', 'COLL1234').subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.postELC().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getCollateralTypes().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getCollateralTypes(filter).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getCollateralCodes().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getCollateralCodes(filter, true).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getCollateralCodes(filter, false).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.searchOnTypeAndFilter().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getLocations().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getDbsSharingBasis().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getMaxCondition().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getSolicitorAgencys().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getLimitsByLimitTypeId(filter).subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
        collateralService.getData('fake_path').subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.getConfigurationsForCollaterals().subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.selectedCollateralType = 'GUARN';
        collateralService.getLinkagesByCollateral('COLL1234').subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });

        collateralService.selectedCollateralType = 'DEPOS';
        collateralService.getLinkagesByCollateral('COLL1234').subscribe((response_1: Response) => {
            expect(response_1).toEqual(dataValue);
        });
    });

    it('should throw error when exception is thrown by service methods', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        spyOn(collateralService, 'errorResponseFunction').and.returnValue(Observable.of({}));
        collateralService.collateralConfig = collateralConfig;

        const collateral: Collateral = new Collateral;
        collateralService.selectedCollateralType = 'GUARN';
        collateralService.postCollateral(collateral).subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.submitCollateral().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getCollaterals().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.postELC().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getCollateralTypes().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getCollateralCodes().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.searchOnTypeAndFilter().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getLocations().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getDbsSharingBasis().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getMaxCondition().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getSolicitorAgencys().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getLimitsByLimitTypeId().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getData('').subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.getConfigurationsForCollaterals().subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.selectedCollateralType = 'GUARN';
        collateralService.getLinkagesByCollateral('COLL1234').subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

        collateralService.selectedCollateralType = 'DEPOS';
        collateralService.getLinkagesByCollateral('COLL1234').subscribe((error) => {
            expect(error).toEqual({});
            done();
        });

    });

    it('should get component forms when invoked', () => {
        const colDetails = collateralService.getDetailsForm();
        expect(colDetails.get('collateralid').value).toEqual('');

        const particularsDetails = collateralService.getParticularsForm();
        expect(particularsDetails.get('particularsList').value).toEqual('');

        const insuranceDetails = collateralService.getInsuranceForm();
        expect(insuranceDetails.get('insuranceList').value).toEqual('');

        const beneficiaryDetails = collateralService.getBeneficiaryForm();
        expect(beneficiaryDetails.get('beneficiaryList').value).toEqual(null);

        const inspectionDetails = collateralService.getInspectionForm();
        expect(inspectionDetails.get('inspectionAppraisalList').value).toEqual(null);

        const documentDetails = collateralService.getDocumentForm();
        expect(documentDetails.get('documentidList').value).toEqual(null);

        const chargeDetails = collateralService.getChargeForm();
        expect(chargeDetails.get('chargeList').value).toEqual('');

        const apportionDetails = collateralService.getApportionForm();
        collateralService.selectedCollateralType = 'AIRCF';
        expect(apportionDetails.get('justificationRemark').value).toEqual('');

        let collateralService_1: CollateralService;
        collateralService_1 = TestBed.get(CollateralService);
        const collateral: Collateral = new Collateral();
        const mockOwnershipList: OwnerShipList = new OwnerShipList();
        collateral.ownershipDetails = [mockOwnershipList];
        spyOn(collateralService_1, 'getCollateral').and.returnValue(collateral);
        const ownershipDetails = collateralService.getOwnershipForm();
        expect(ownershipDetails.get('ownershipid').value).toEqual(null);
    });

    it('should compare and return false if collateral locked by same user ', () => {
        const mainCollateral = draftCollateralData[0].modelData;
        const draftCollateral = draftCollateralData[0];
        expect(collateralService.compareCollaterals(mainCollateral, draftCollateral)).toBe(false);
    });
    it('should compare and return false if collateral modified date is greater than 30 mins', () => {
        const mainCollateral = draftCollateralData[0].modelData;
        const draftCollateral = draftCollateralData[0];
        draftCollateral._modifiedBy = 'cls-user';
        expect(collateralService.compareCollaterals(mainCollateral, draftCollateral)).toBe(false);
        expect(collateralService.lockStatus).toBe(false);
    });
    it('should compare and return false if collateral date is greater than draft collatral date', () => {
        const mainCollateral = draftCollateralData[0].modelData;
        const draftCollateral = draftCollateralData[0];
        mainCollateral._modifiedOn = '2017-11-22T10:40:36.158Z';
        expect(collateralService.compareCollaterals(mainCollateral, draftCollateral)).toBe(false);
        expect(collateralService.draftNeeded).toBe(true);
    });
    it('should clear all collateral config', () => {
        collateralService.draftNeeded = true;
        collateralService.clearCollateral();
        expect(collateralService.draftNeeded).toBe(false);
    });
    it('should get both draft and mai collateral', fakeAsync(() => {
        collateralService.selectedCollateralType = 'GUARN';
        collateralService.collateralConfig = collateralConfig;
        expect(collateralService.getCollateralsAndCompareData('COLL01', 'GUARN')).toBeTruthy();
    }));

});
