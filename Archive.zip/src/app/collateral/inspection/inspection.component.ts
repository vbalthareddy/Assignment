import {ChangeDetectorRef, Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {InspectionService} from './inspection.service';
import {InspectionAndAppraisals} from '../model/collateral';
import {CollateralService} from '../collateral.service';
import {ToastsComponent} from '../../shared/toasts/toasts.component';
import {CommonUtil} from '../../common/utils/common.util';

@Component({
    selector: 'app-inspection',
    templateUrl: './inspection.component.html',
    styleUrls: ['./inspection.component.scss']
})
export class InspectionComponent implements OnInit {
    public showPopupDialog: boolean = false;
    public dialogTitleName: string = 'Add Inspection Details';
    public inspectionTypeList: any;
    public inspectionFrequencyList: any;
    public divForNormalGrid: boolean = true;
    public AddInspectionForm: FormGroup;
    public inspectionGridData: any[] = [];
    noRecordsFlag: boolean = false;
    public rowIndex: number;
    saveData: boolean = true;
    argToastMessageObject: any;
    toastsComponent: ToastsComponent = new ToastsComponent();
    inspectionTypeInvalid: boolean = false;
    employeeIdInvalid: boolean = false;
    firstInspectionDateInvalid: boolean = false;
    latestInspectionDateInvalid: boolean = false;
    frequencyInvalid: boolean = false;
    nextInspectionDateInvalid: boolean = false;
    events: any;
    inspectionGridDataForHtml: any = [];
    validDateFlagForFirstInspectionDate: boolean = false;
    validDateFlagForLatestInspectionDate: boolean = false;
    validDateFlagForNextInspectionDate: boolean = false;
    first_inspec_date_Error: string;
    latest_inspec_date_Error: string;
    next_inspec_date_Error: string;
    frequencyError: string;
    showYesNoPrompt: boolean = false;
    dataforDelete: any = [];
    inspectionTypeData: any = [];
    inspectionFrequencyData: any = [];
    @Input() public inspectionForm: FormGroup;
    @Input() showAddInspectionBtn: boolean = true;
    @Input() showSummaryGrid: boolean = false;

    constructor(private inspectionService: InspectionService, private _fb: FormBuilder, private collateralService: CollateralService, private cd: ChangeDetectorRef) {
    }

    ngOnInit() {
        this.setUpInspectionTab();

    }

    setUpInspectionTab() {
        this.divForNormalGrid = !this.showSummaryGrid;
        this.getInspectionListDetails();
        this.getInspectionType();
        this.getInspectionFrequency();
        this.processFormItems();
        this.initialiseInspectionForm();
    }

    private getInspectionListDetails() {
        if (this.collateralService.getCollateral().inspectionAndAppraisals) {
            this.inspectionGridData = this.collateralService.getCollateral().inspectionAndAppraisals;
            setTimeout(() => this.getGridDataForHTML(JSON.parse(JSON.stringify(this.inspectionGridData))), 300);
            // this.inspectionGridDataForHtml = this.collateralService.getCollateral().inspectionAndAppraisals.filter(Data => Data.processIdentifier === 'I');
        }
    }

    private initialiseInspectionForm() {
        this.AddInspectionForm = this._fb.group({
                inspectionAppraisalType: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                inspectionEmployeeId: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
                firstInspectionAppraisalDate: [null, [Validators.required]],
                latestInspectionAppraisalDate: [null, [Validators.required]],
                frequencyToSubmit: [''],
                nextInspectionAppraisalDate: [null, [Validators.required]],
                inspectionRowStatus: [''],
                inspectionId: [''],
                inspectionVersion: ['']
            },
            {
                validator: Validators.compose([
                    this.checkDate('firstInspectionAppraisalDate', 'today'),
                    this.checkDate('firstInspectionAppraisalDate', 'latestInspectionAppraisalDate'),
                    this.checkDate('latestInspectionAppraisalDate', 'nextInspectionAppraisalDate'),
                ])
            });
        this.first_inspec_date_Error = 'Please make a selection';
        this.latest_inspec_date_Error = 'Please make a selection';
        this.next_inspec_date_Error = 'Please make a selection';
        this.frequencyError = 'Please make a selection';
        this.subscribeToFormChanges();
    }

    private subscribeToFormChanges() {
        this.AddInspectionForm.valueChanges.subscribe(data => this.onInspectionFormChanged(data));
    }

    private onInspectionFormChanged(data: any) {
        if (data.inspectionEmployeeId !== null && data.inspectionEmployeeId.length > 0) {
            this.employeeIdInvalid = false;
        }
    }

    private processFormItems() {
        if (this.inspectionGridDataForHtml.length > 0) {
            this.noRecordsFlag = false;
        } else {
            this.noRecordsFlag = true;
        }
    }

    private getInspectionType() {
        this.inspectionService.getInspectionTypeService().subscribe(
            response => {
                this.inspectionTypeList = response;
                this.inspectionTypeData = this.inspectionTypeList;
            },
            error => {
            },
            () => {
                this.getGridDataForHTML(JSON.parse(JSON.stringify(this.inspectionGridData)));
            }
        );

    }

    private getInspectionFrequency() {
        this.inspectionService.getInspectionFrequencyService().subscribe(
            response => {
                this.inspectionFrequencyList = response;
                this.inspectionFrequencyData = this.inspectionFrequencyList;
                this.cd.detectChanges();
            },
            error => {
            },
            () => {
                this.getGridDataForHTML(JSON.parse(JSON.stringify(this.inspectionGridData)));
            }
        );
    }

    addInspection() {
        this.dialogTitleName = 'Add Inspection Details';
        this.showPopupDialog = true;
        this.validationReset();
    }

    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.showPopupDialog = showPopupDialog;
        this.saveData = true;
        this.AddInspectionForm.reset();
        this.validationReset();
    }

    addInspectionClickedInNoData(e?: Event) {
        this.addInspection();
    }

    addInspectionData(data: any) {
        const flagValue = this.validationCheck(data);
        if (flagValue) {
            this.updateGridValueFunction(data, 'ADD');
        } else {
            setTimeout(() => CommonUtil.recursiveFocus(), 300);
        }
    }

    inspectionEditFunc(item: InspectionAndAppraisals, index: number) {
        this.dialogTitleName = 'Update Inspection';
        this.rowIndex = index;
        this.saveData = false;
        this.showPopupDialog = true;
        this.AddInspectionForm = this._fb.group({
                inspectionAppraisalType: [this.inspectionTypeList.find(data => data.description === item.inspectionAppraisalType).code, [<any>Validators.required, <any>Validators.minLength(0)]],
                inspectionEmployeeId: [item.inspectionEmployeeId, [<any>Validators.required, <any>Validators.minLength(0)]],
                firstInspectionAppraisalDate: [item.firstInspectionAppraisalDate, [Validators.required]],
                latestInspectionAppraisalDate: [item.latestInspectionAppraisalDate, [Validators.required]],
                frequencyToSubmit: [this.inspectionFrequencyList.find(data => data.freqDesc === item.frequencyMonths), [<any>Validators.required, <any>Validators.minLength(0)]],
                nextInspectionAppraisalDate: [item.nextInspectionAppraisalDate, [Validators.required]],
                inspectionRowStatus: [item.__row_status],
                inspectionId: [item.id],
                inspectionVersion: [item._version]
            },
            {
                validator: Validators.compose([
                    this.checkDate('firstInspectionAppraisalDate', 'today'),
                    this.checkDate('firstInspectionAppraisalDate', 'latestInspectionAppraisalDate'),
                    this.checkDate('latestInspectionAppraisalDate', 'nextInspectionAppraisalDate'),
                ])
            });
        this.first_inspec_date_Error = 'Please make a selection';
        this.latest_inspec_date_Error = 'Please make a selection';
        this.next_inspec_date_Error = 'Please make a selection';
        this.frequencyError = 'Please make a selection';
        this.subscribeToFormChanges();
    }

    updateInspectionGridList(data: any) {
        const flagValue = this.validationCheck(data);
        if (flagValue) {
            this.saveData = true;
            this.updateGridValueFunction(data, 'UPDATE');
        } else {
            setTimeout(() => CommonUtil.recursiveFocus(), 300);
        }
    }

    private updateGridValueFunction(data: any, flag: string) {
        let toastMsg: string;
        this.validationReset();
        this.AddInspectionForm.reset();
        this.showPopupDialog = false;
        const tempInspectionItem = new InspectionAndAppraisals();
        tempInspectionItem.inspectionAppraisalType = data.inspectionAppraisalType;
        tempInspectionItem.inspectionEmployeeId = data.inspectionEmployeeId;
        tempInspectionItem.firstInspectionAppraisalDate = data.firstInspectionAppraisalDate;
        tempInspectionItem.latestInspectionAppraisalDate = data.latestInspectionAppraisalDate;
        tempInspectionItem.frequencyMonths = data.frequencyToSubmit;
        tempInspectionItem.nextInspectionAppraisalDate = data.nextInspectionAppraisalDate;
        tempInspectionItem.processIdentifier = 'I';
        tempInspectionItem.inspectionAppraisalAgency = 'I';
        if (data.inspectionRowStatus !== '' && data.inspectionRowStatus !== undefined) {
            tempInspectionItem.__row_status = data.inspectionRowStatus;
        }
        const dataObj = this.inspectionGridData.find(item => item.id === data.inspectionId);
        if (dataObj !== undefined && dataObj.processIdentifier === 'I') {
            const index = this.inspectionGridData.indexOf(dataObj);
            if (tempInspectionItem.__row_status === 'modified' || tempInspectionItem.__row_status === null || tempInspectionItem.__row_status === 'deleted') {
                tempInspectionItem.__row_status = 'modified';
            } else if (tempInspectionItem.__row_status === 'added') {
                tempInspectionItem.__row_status = 'added';
            }
            tempInspectionItem.id = data.inspectionId;
            tempInspectionItem._version = data.inspectionVersion;
            this.inspectionGridData[index] = tempInspectionItem;
        } else {
            tempInspectionItem.id = 'inspec' + Math.random().toString(36).substr(2, 5) + Math.random().toString(36).substr(2, 5);
            tempInspectionItem.__row_status = 'added';
            tempInspectionItem._version = '';
            this.inspectionGridData.push(tempInspectionItem);
        }
        if (flag === 'ADD') {
            toastMsg = 'A new record of inspection details has been successfully added.';
        } else if (flag === 'UPDATE') {
            toastMsg = 'A record of inspection details has been successfully updated.';
        }
        const tmpArray = JSON.parse(JSON.stringify(this.inspectionGridData));
        this.getGridDataForHTML(tmpArray);
        this.inspectionForm.controls['inspectionAppraisalList'].setValue(this.inspectionGridData);
        this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success', toastMsg, '', '');
    }

    inspectionRemoveItemFunc(data) {
        this.showYesNoPrompt = true;
        this.dataforDelete = data;
    }

    inspectionDelete() {
        this.dataforDelete.inspectionAppraisalType = this.inspectionTypeList.find(item => item.description === this.dataforDelete.inspectionAppraisalType).code;
        const dataObj = this.inspectionGridData.find(item => item.id === this.dataforDelete.id);
        if (dataObj !== undefined && dataObj.processIdentifier === 'I') {
            const index = this.inspectionGridData.indexOf(dataObj);
            const tempInspectionItem = new InspectionAndAppraisals();
            tempInspectionItem.inspectionAppraisalType = this.dataforDelete.inspectionAppraisalType;
            tempInspectionItem.inspectionEmployeeId = this.dataforDelete.inspectionEmployeeId;
            tempInspectionItem.firstInspectionAppraisalDate = this.dataforDelete.firstInspectionAppraisalDate;
            tempInspectionItem.latestInspectionAppraisalDate = this.dataforDelete.latestInspectionAppraisalDate;
            tempInspectionItem.frequencyMonths = this.inspectionFrequencyList.find(temp => temp.freqDesc === this.dataforDelete.frequencyMonths).freq;
            tempInspectionItem.nextInspectionAppraisalDate = this.dataforDelete.nextInspectionAppraisalDate;
            tempInspectionItem.__row_status = this.dataforDelete.__row_status;
            tempInspectionItem.processIdentifier = 'I';
            tempInspectionItem.inspectionAppraisalAgency = 'I';
            tempInspectionItem.id = this.dataforDelete.id;
            tempInspectionItem._version = this.dataforDelete.inspectionVersion;
            if (tempInspectionItem.__row_status === 'added') {
                this.inspectionGridData.splice(index, 1);
            } else if (tempInspectionItem.__row_status === 'modified' || tempInspectionItem.__row_status === undefined) {
                tempInspectionItem.__row_status = 'deleted';
                this.inspectionGridData[index] = tempInspectionItem;
            }
        }
        const tmpArray = JSON.parse(JSON.stringify(this.inspectionGridData));
        this.getGridDataForHTML(tmpArray);
        this.inspectionForm.controls['inspectionAppraisalList'].setValue(this.inspectionGridData);
        this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success', 'A record of inspection details has been successfully deleted.', '', '');
    }

    getGridDataForHTML(data: any) {
        let tempArray: any = [];
        if ((this.inspectionTypeList) && (this.inspectionFrequencyList)) {
            tempArray = data.map(item => {
                if (this.inspectionTypeList.length > 0) {
                    item['inspectionAppraisalType'] = this.inspectionTypeList.find(temp => temp.code === item.inspectionAppraisalType).description;
                }
                if (this.inspectionFrequencyList.length > 0) {
                    item['frequencyMonths'] = this.inspectionFrequencyList.find(temp => temp.freq === item.frequencyMonths).freqDesc;
                }
                return item;
            });
        }
        this.inspectionGridDataForHtml = tempArray;
        this.inspectionGridDataForHtml = this.inspectionGridDataForHtml.filter(Data => Data.processIdentifier === 'I');
        this.inspectionGridDataForHtml = this.inspectionGridDataForHtml.filter(Data => Data.__row_status !== 'deleted');
        this.processFormItems();
    }

    onFrequencySelect(selectedFrequency: number) {
        const frequencyObj = this.inspectionFrequencyList.find(item => item.freq === selectedFrequency);
        if (frequencyObj) {
            if (this.AddInspectionForm.get('latestInspectionAppraisalDate').value !== undefined && this.AddInspectionForm.get('latestInspectionAppraisalDate').value !== '' && this.AddInspectionForm.get('latestInspectionAppraisalDate').value !== null) {
                this.frequencyInvalid = false;
                this.frequencyError = 'Please make a selection';
                const dt = this.AddInspectionForm.get('latestInspectionAppraisalDate').value;
                let newModifiedDate = new Date(dt);
                newModifiedDate = this.getNextDate(newModifiedDate, frequencyObj.freq);
                this.AddInspectionForm.controls['nextInspectionAppraisalDate'].setValue(new Date(newModifiedDate));
                this.nextInspectionDateInvalid = false;
            } else {
                this.frequencyError = 'Please enter the \'Latest Inspection Date\' first ';
                this.frequencyInvalid = true;
            }
        }
    }

    getNextDate(date: Date, months: number): any {
        const newD = date;
        return new Date(newD.setMonth(date.getMonth() + months));
    }

    onInspectionTypeSelect(selectedType: string) {
        const inspectionTypeObj = this.inspectionTypeList.find(item => item.code === selectedType);
        if (inspectionTypeObj) {
            this.inspectionTypeInvalid = false;
        }
    }

    private validationReset() {
        this.inspectionTypeInvalid = false;
        this.employeeIdInvalid = false;
        this.firstInspectionDateInvalid = false;
        this.latestInspectionDateInvalid = false;
        this.frequencyInvalid = false;
        this.nextInspectionDateInvalid = false;
        this.validDateFlagForFirstInspectionDate = false;
        this.validDateFlagForLatestInspectionDate = false;
        this.validDateFlagForNextInspectionDate = false;
        this.frequencyError = 'Please make a selection';
    }

    private validationCheck(data?: any) {
        let valid = true;
        const dataObj = this.inspectionTypeList.find(item => item.code === data.inspectionAppraisalType);
        if (dataObj === undefined) {
            this.inspectionTypeInvalid = true;
            valid = false;
        }
        if (!data.inspectionEmployeeId) {
            this.employeeIdInvalid = true;
            valid = false;
        }
        const frequencyObj = this.inspectionFrequencyList.find(item => item.freq === data.frequencyToSubmit);
        if (frequencyObj === undefined) {
            this.frequencyInvalid = true;
            valid = false;
        }
        if (data.firstInspectionAppraisalDate === undefined || data.firstInspectionAppraisalDate === '' || data.firstInspectionAppraisalDate === null) {
            this.firstInspectionDateInvalid = true;
            valid = false;
        }
        if (data.latestInspectionAppraisalDate === undefined || data.latestInspectionAppraisalDate === '' || data.latestInspectionAppraisalDate === null) {
            this.latestInspectionDateInvalid = true;
            valid = false;
        }
        if (data.nextInspectionAppraisalDate === undefined || data.nextInspectionAppraisalDate === '' || data.nextInspectionAppraisalDate === null) {
            this.nextInspectionDateInvalid = true;
            valid = false;
        }
        if (this.validDateFlagForFirstInspectionDate === true || this.validDateFlagForLatestInspectionDate === true || this.validDateFlagForNextInspectionDate === true) {
            valid = false;
        }
        if (this.AddInspectionForm.errors) {
            valid = false;
        }
        return valid;
    }
    onDateChange(value: string, flag: string): void {
        if (value) {
            if (flag === 'FIRST') {
                this.firstInspectionDateInvalid = false;
            }
            if (flag === 'LATEST') {
                this.latestInspectionDateInvalid = false;
                const frequencySelect = this.AddInspectionForm.get('frequencyToSubmit').value;
                if (frequencySelect !== '' || frequencySelect !== null || frequencySelect !== undefined) {
                    this.onFrequencySelect(frequencySelect);
                }
            }
            if (flag === 'NEXT') {
                this.nextInspectionDateInvalid = false;
                this.AddInspectionForm.controls['frequencyToSubmit'].setValue(0);
                this.frequencyInvalid = false;
            }
        }
    }

    checkDate(from: string, to: string) {
        return (group: FormGroup): {[key: string]: any} => {
            const f = group.controls[from];
            let t = group.controls[to];
            if (to === 'today') {
                t = new FormControl(new Date());
            }
            const mp = {
                'today': 'Today',
                'firstInspectionAppraisalDate': 'First Inspection Date',
                'latestInspectionAppraisalDate': 'Latest Inspection Date',
                'nextInspectionAppraisalDate': 'Next Inspection Date'
            };
            if ((f && t) && (f.value && t.value) && (f.value > t.value)) {
                const msg = mp[to] + ' should be greater than ' + mp[from];
                return {
                    firstInspecDateErr: from === 'firstInspectionAppraisalDate' && to === 'today' ? mp[from] + ' cannot be greater than ' + mp[to] : null,
                    latestInspecDateErr: from === 'firstInspectionAppraisalDate' && to !== 'today' ? msg : null,
                    nextInspecDateErr: from === 'latestInspectionAppraisalDate' ? msg : null,
                };

            }
            return null;
        };
    }

    confirmationFromYesNo(dlgPayload: any[]) {
        this.showYesNoPrompt = false;
        if (dlgPayload[0] === 'yes') {
            this.inspectionDelete();
        }
    }

    typeFilterChange(typeInput: string) {
        if (typeInput.length === 0) {
            this.inspectionTypeInvalid = false;
        }
        this.inspectionTypeData = this.inspectionTypeList.filter((s) => s.description.toLowerCase().indexOf(typeInput.toLowerCase()) !== -1);
    }

    frequencyFilterChange(filterInput: string) {
        if (filterInput.length === 0) {
            this.frequencyInvalid = false;
        }
        this.inspectionFrequencyData = this.inspectionFrequencyList.filter((s) => s.freqDesc.toLowerCase().indexOf(filterInput.toLowerCase()) !== -1);
    }
}
