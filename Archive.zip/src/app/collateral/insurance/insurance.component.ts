// import 'zone.js/lib/browser/zone-microtask';

import {AfterViewInit, ChangeDetectorRef, Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import {ClaimDetails, InsuranceCompanyDetails, InsuranceDetails, PolicyDetails} from '../model/collateral';
import {CollateralService} from '../collateral.service';
import {CollateralSummaryService} from 'app/collateral/collateral-summary/collateral-summary.service';

import {InsuranceService} from '../insurance/insurance.component.service';
import {ToastsComponent} from '../../shared/toasts/toasts.component';
import {Observable} from 'rxjs/Observable';
import {ErrorResponse} from '../../shared';
import {ActivatedRoute, NavigationExtras, Params, Router} from '@angular/router';

@Component({
    selector: 'collateral-insurance',
    templateUrl: './insurance.component.html',
    styleUrls: ['./insurance.component.scss']
})
export class InsuranceComponent implements OnInit, AfterViewInit {
    [name: string]: any;
    @Input() insuranceForm: FormGroup;
    public addInsuranceForm: FormGroup;
    public showPopupDialog: boolean = false;
    errorResponse: ErrorResponse = null;
    showSpecificDetailsField: boolean = false;
    public saveInsuranceData: boolean = true;
    public updateInsuranceData: boolean = false;
    selectedValueMethod: string = 'Customer';
    private selectedMethod: string = 'value1';
    insuranceDetailsDialogTitle: string;
    public addInsuranceDetailsForm: FormGroup;
    submitted: boolean;
    argToastMessageObject: any;
    public policyNumber: any;
    public insuranceType: any;
    public insuranceTypeNew: any;
    disablePolicy: boolean;
    policyNumberInvalid: boolean;
    insuranceTypeInvalid: boolean;
    divForData: boolean = true;
    selectedCollateralType: string = '';
    divForNormalGrid: boolean = true;
    public gridData: any[] = [];
    newGridData: any[] = [];
    insuranceLinkageData: any = [];
    showEdit: boolean;
    public idList: any[] = [];
    refBankIdObj: any = [];
    bankIdValue: string = '';
    refDepositObj: any = [];
    insuranceTypes: any = [];
    insuranceGridDataForView: any[] = [];
    public rowIndex: number;
    public insuranceGridData: any[] = [];
    public duplicateValueErrDiv: boolean;
    toastsComponent: ToastsComponent = new ToastsComponent();
    @Input() showAddInsuranceBtn: boolean = true;
    @Input() showSummaryGrid: boolean = false;
    gcinCpValue: string;
    gcinDesc: string;
    ctype: string;
    showYesNoPrompt: boolean = false;
    dataItemDelete: any;

    constructor(private _fb: FormBuilder, private collateralService: CollateralService, private collateralSummaryService: CollateralSummaryService,
                private router: Router, private insuranceService: InsuranceService,
                private cdr: ChangeDetectorRef, private route: ActivatedRoute) {
        this.route.queryParams.subscribe((params: Params) => {
            this.gcinCpValue = params['gcin'];
            this.gcinDesc = params['label'];
            this.ctype = params['ctype'];
        });
    }

    ngOnInit() {
        this.getInsuranceTypes();
        this.initializeFormGroup();
        this.intializeGridData();
        this.selectedCollateralType = this.collateralService.selectedCollateralType;
        if (this.selectedValueMethod === 'Customer') {
            this.selectedMethod = 'value1';
        } else {
            this.selectedMethod = 'value2';
        }
        // this.setUpInsuranceData();
        // this.processMessageToken();
    }

    ngAfterViewInit(): void {
        this.cdr.detectChanges();
        this.processMessageToken();
    }

    intializeGridData() {
        if (this.collateralService.getCollateral().insuranceDetails) {
            this.gridData = this.collateralService.getCollateral().insuranceDetails;
            setTimeout(() => this.populateAllValues(this.gridData), 1000);
            this.insuranceLinkageData = this.gridData;
            this.insuranceGridDataForView = this.gridData.filter(Data => Data.__row_status !== 'deleted');
        }
    }

    populateAllValues(data) {
        for (let i = 0; i < data.length; i++) {
            this.gridData[i]['insuranceTypeNew'] = this.getInsuranceTypeDescription(data[i].insuranceType);
            this.gridData[i]['insuranceCharge'] = this.getInsurancePurchaserForView(data[i].insurancePurchaser);
        }
        ;
        return this.gridData;
    }

    getInsuranceTypeDescription(data) {
        let description = '';
        this.refDepositObj.forEach(function (value) {
            if (value.code === data) {
                description = value.description;
            }
        });
        return description;

    }

    getInsurancePurchaserForView(iPurchaser) {
        if (iPurchaser !== null) {
            if (iPurchaser === 'C') {
                return 'Customer';
        } else {
                return 'Bank';
            }
        } else {
            return iPurchaser;
        }
    }

    // setUpInsuranceData() {
    // 	if (this.collateralService.getCollateral().insuranceDetails) {
    // 		this.insuranceLinkageData = this.collateralService.getCollateral().insuranceDetails;
    // 		//this.populateAllValues(this.insuranceLinkageData);
    // 	}
    // }

    initializeFormGroup() {

        this.addInsuranceDetailsForm = this._fb.group({
            insuranceType: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            insuranceTypeNew: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            insurancePurchaser: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            policyNumber: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            policyDetails: [],
            claimDetails: [],
            insuranceCompanyDetails: []

        });

    }

    onLabelClicked($event) {
        this.openPopDialog();
    }

    openPopDialog() {

        this.submitted = false;
        this.showPopupDialog = true;
        this.saveInsuranceData = true;
        this.insuranceDetailsDialogTitle = 'Add Insurance Details';
        this.insuranceTypeInvalid = false;
        // this.validationReset();
    }

    getInsuranceTypes() {
        this.insuranceService.getInsuranceTypesfromService().subscribe(
            response => {
                this.refDepositObj = response;
                this.insuranceTypes = this.refDepositObj;
            },
            error => {
                this.errorReturn(error);
            },
            () => {
            }
        );
    }


    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.disablePolicy = false;
        this.updateInsuranceData = false;
        this.duplicateValueErrDiv = false;
        this.showPopupDialog = showPopupDialog;
        this.addInsuranceDetailsForm.reset();
    }

    methodEvent(selectedValueMethod: any) {
        this.selectedValueMethod = selectedValueMethod;
    }


    /*Function on insurance type value change and to validate forinsurance type Selected Value*/
    onInsuranceTypeSelect(selectedInsuranceType) {
        let valid: boolean = false;
        const dataObj = this.refDepositObj.find(item => item.description === selectedInsuranceType);
        if (((dataObj !== 'undefined') || (dataObj !== '')) && (dataObj !== undefined)) {
            this.insuranceTypeInvalid = false;
            valid = true;
            const valueToSubmit = dataObj.description;
            this.addInsuranceDetailsForm.controls['insuranceTypeNew'].setValue(valueToSubmit);
        } else {
            this.insuranceTypeInvalid = true;
            valid = false;
        }
        return valid;
    }


    public filterType(filter: any): void {
        this.insuranceTypes = this.refDepositObj.filter((s) => s.description.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
    }

    getInsurancePurchaserForModel(iPurchaser) {
        if (iPurchaser !== null) {
            if (iPurchaser === 'Customer') {
                return 'C';
            } else {
                return 'B';
            }
        } else {
            return iPurchaser;
        }
    }

    getInsuranceTypeCode(desc) {
        let iCode = '';
        this.refDepositObj.forEach(function (value) {
            if (value.description === desc) {
                iCode = value.code;
            }
        });
        return iCode;
    }

    /*Function to add insurance data*/

    addInsuranceDetailsData(data: any) {
        this.disablePolicy = false;
        this.updateInsuranceData = false;
        this.validationReset();
        this.saveInsuranceData = true;
        this.submitted = true;
        const flagValue = this.validationCheck(data);
        const isInsuranceTypeValid = this.onInsuranceTypeSelect(data['insuranceTypeNew']);
        if (flagValue === true) {
            this.showPopupDialog = false;
            const policyDetails = new PolicyDetails();
            policyDetails.policyNo = this.addInsuranceDetailsForm.get('policyNumber').value;
            const claimDetails = new ClaimDetails();
            const insuranceCompanyDetails = new InsuranceCompanyDetails();
            const dataForAddInsurance = {
                'insuranceTypeNew': this.addInsuranceDetailsForm.get('insuranceTypeNew').value,
                'insuranceType': this.getInsuranceTypeCode(this.addInsuranceDetailsForm.get('insuranceTypeNew').value),
                'insuranceCharge': this.selectedValueMethod,
                'insurancePurchaser': this.getInsurancePurchaserForModel(this.selectedValueMethod),
                'policyDetails': policyDetails,
                'claimDetails': claimDetails,
                'insuranceCompanyDetails': insuranceCompanyDetails,
                '__row_status': 'added',
                'delete': false,
                'reqSent': false,
                'id': Math.random().toString(36).substr(2, 5)
            };
            this.gridData.push(dataForAddInsurance);
            if (this.gridData.length === 0) {
                this.divForData = true;
            } else {
                this.divForData = false;
                this.insuranceForm.controls['insuranceList'].setValue(this.gridData);
            }
            this.insuranceGridDataForView = this.gridData.filter(Data => Data.__row_status !== 'deleted');
            this.addInsuranceDetailsForm.reset();
            this.showPopupDialog = false;
            this.duplicateValueErrDiv = false;
            this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                'A record of Insurance details has been successfully Added.',
                '', '');

        }
    }

    insuranceRemoveItemFunc(dataItem: InsuranceDetails, itemIndex: number) {
        this.showYesNoPrompt = true;
        this.dataItemDelete = dataItem;
    }

    insuranceDelete() {
        const tempPolicyNo = this.dataItemDelete.policyDetails.policyNo;
        const dataObj = this.insuranceLinkageData.find(item => item.policyDetails.policyNo === tempPolicyNo);
        this.rowIndex = this.insuranceLinkageData.indexOf(dataObj);
        if (this.gridData[this.rowIndex].__row_status === undefined || this.gridData[this.rowIndex].__row_status === 'modified') {
            this.gridData[this.rowIndex].__row_status = 'deleted';
        } else if (this.gridData[this.rowIndex].__row_status === 'added') {
            this.gridData.splice(this.rowIndex, 1);
        }
        this.insuranceGridDataForView = this.gridData.filter(Data => Data.__row_status !== 'deleted');
        this.insuranceForm.controls['insuranceList'].setValue(this.gridData);
        this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
            'A record of Insurance details has been successfully deleted.',
            '', '');
    }

    /***Function to edit each grid data ***/
    public insuranceEditFunc(item: InsuranceDetails, index: number): void {
        this.validationReset();
        this.disablePolicy = true;
        this.insuranceDetailsDialogTitle = 'Update Insurance Details';
        this.rowIndex = index;
        this.showPopupDialog = true;
        this.saveInsuranceData = false;
        this.updateInsuranceData = true;
        if (item['insuranceCharge'] === 'Customer') {
            this.selectedMethod = 'value1';
        } else {
            this.selectedMethod = 'value2';
        }

        const tempType = this.getInsuranceTypeCode(item['insuranceTypeNew']);

        this.addInsuranceDetailsForm = this._fb.group({
            insuranceTypeNew: [item['insuranceTypeNew'], [<any>Validators.required, <any>Validators.minLength(0)]],
            insuranceType: [tempType, [<any>Validators.required, <any>Validators.minLength(0)]],
            insurancePurchaser: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            policyNumber: [item['policyDetails']['policyNo'], [<any>Validators.required, <any>Validators.minLength(0)]],
            policyDetails: [],
            claimDetails: [],
            insuranceCompanyDetails: [],
            __row_status: item.__row_status,
            delete: item.delete,
            reqSent: item.reqSent,
            id: item.id,
        });
    }

    /*Function when update button is clicked*/
    updateInsuranceDetailsData(data: any) {
        this.validationReset();
        let dataObj = this.insuranceLinkageData.find(item => (item.policyDetails.policyNo === data.policyNumber) && (item.__row_status !== 'deleted'));
        this.rowIndex = this.insuranceLinkageData.indexOf(dataObj);
        const tempCode = this.getInsuranceTypeCode(this.addInsuranceDetailsForm.get('insuranceTypeNew').value);
        const dataForUpdateInsurance = {
            'insuranceTypeNew': this.addInsuranceDetailsForm.get('insuranceTypeNew').value,
            'insuranceType': tempCode,
            'insuranceCharge': this.selectedValueMethod,
            'insurancePurchaser': this.getInsurancePurchaserForModel(this.selectedValueMethod),
            'policyDetails': this.insuranceLinkageData[this.rowIndex].policyDetails,
            'claimDetails': this.insuranceLinkageData[this.rowIndex].claimDetails,
            '__row_status': 'modified',
            'delete': this.insuranceLinkageData[this.rowIndex].delete,
            'reqSent': this.insuranceLinkageData[this.rowIndex].reqSent,
            'id': this.insuranceLinkageData[this.rowIndex].id,
            'collateralId': this.insuranceLinkageData[this.rowIndex].collateralId,
        };
        dataObj = this.gridData.find(item => item.policyDetails.policyNo === dataForUpdateInsurance.policyDetails.policyNo);
        if (dataObj) {
            this.rowIndex = this.gridData.indexOf(dataObj);
            this.gridData[this.rowIndex] = dataForUpdateInsurance;
            this.insuranceGridDataForView[this.rowIndex] = dataForUpdateInsurance;
        } else {
            this.gridData.push(dataForUpdateInsurance);
            this.insuranceGridDataForView.push(dataForUpdateInsurance);
        }
        if (this.insuranceLinkageData[this.rowIndex].collateralId === undefined) {
            dataForUpdateInsurance.__row_status = 'added';
        } else {
            dataForUpdateInsurance.__row_status = 'modified';
        }

        // this.gridData[this.rowIndex] = dataForUpdateInsurance;
        // this.insuranceGridDataForView[this.rowIndex] = dataForUpdateInsurance;

        this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
            'A record of charge details has been successfully updated.',
            '', '');
        this.insuranceForm.controls['insuranceList'].setValue(this.gridData);
        this.addInsuranceDetailsForm.reset();
        this.showPopupDialog = false;

    }


    validationCheck(data?: any) {
        let valid: boolean = true;
        let duplicateCheck: boolean = false;
        if (data.insuranceTypeNew === '' || data.policyNumber === '' || data.insuranceTypeNew === null || data.policyNumber === null || data.insuranceTypeNew === undefined || data.policyNumber === undefined) {
            this.insuranceTypeInvalid = true;
            this.policyNumberInvalid = true;
            valid = false;
        }
        this.gridData.forEach(function (item) {
            if (item.policyDetails.policyNo === data.policyNumber && item.__row_status !== 'deleted') {
                duplicateCheck = true;
                valid = false;
            }
        });
        this.duplicateValueErrDiv = duplicateCheck;
        if (this.insuranceTypeNew !== undefined) {
            const insuranceTypeInList = this.insuranceTypeNew.find(item => (item.insuranceTypeNew) === data.insuranceTypeNew);
            if (((data.insuranceTypeNew === '') || (data.insuranceTypeNew == null) || (data.insuranceTypeNew === undefined)) || (insuranceTypeInList === undefined)) {
                this.insuranceTypeInvalid = true;
                valid = false;
            }
        }
        if (this.policyNumber !== undefined) {
            const policyNumberInList = this.policyNumber.find(item => (item.policyNumber) === data.policyNumber);
            if (((data.policyNumber === '') || (data.policyNumber == null) || (data.policyNumber === undefined)) || (policyNumberInList === undefined)) {
                this.policyNumberInvalid = true;
                valid = false;
            }
        }
        return valid;
    }

    validationReset() {
        this.policyNumberInvalid = false;
        this.insuranceTypeInvalid = false;
        this.duplicateValueErrDiv = false;
    }

    errorReturn(error: any) {
        return Observable.throw(new Error(error.status));
    }

    getPolicyDetails(data: any, flag: string) {
    this.collateralService.checkPopupDialogBox = true;
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'policyNo': data.policyDetails.policyNo,
                'functionFlag': flag,
                'ctype': this.ctype,
                'gcin': this.gcinCpValue,
                'label': this.gcinDesc
            }
        };
        this.router.navigate(['./insurance/policyDetails'], navigationExtras);
    }

    getClaimDetails(data: any, flag: string) {
        this.collateralService.checkPopupDialogBox = true;
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'policyNumber': data.policyDetails.policyNo,
                'functionFlag': flag,
                'ctype': this.ctype,
                'gcin': this.gcinCpValue,
                'label': this.gcinDesc
            }
        };
        this.router.navigate(['./insurance/claimDetails'], navigationExtras);
    }

    // getCompanyDetails(data: any, flag: string) {
    // }

    processMessageToken() {
        const msg = this.collateralSummaryService.getMessageToken();
        if (!msg) {
            return;
        }

        if ((msg['raisedFor'] === 'INSURANCE_MAIN') && (msg['actionCode'] === 'SHOW_TOAST')) {
            this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                msg['message'], '', '');
            this.collateralSummaryService.resetMessageToken();
        }

    }

    confirmationFromYesNo(dlgPayload: any[]) {
        this.showYesNoPrompt = false;
        if (dlgPayload[0] === 'yes') {
            this.insuranceDelete();
        }
    }
}
