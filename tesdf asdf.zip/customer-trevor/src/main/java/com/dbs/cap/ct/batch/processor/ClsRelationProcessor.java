package com.dbs.cap.ct.batch.processor;

import com.dbs.cap.ct.batch.model.CorpRelationship;
import com.dbs.cap.ct.batch.model.RelationCustomer;
import org.springframework.batch.item.ItemProcessor;

public class ClsRelationProcessor implements ItemProcessor<CorpRelationship, RelationCustomer> {
    @Override
    public RelationCustomer process(CorpRelationship cr) throws Exception {
        RelationCustomer rc = new RelationCustomer();
        rc.setChildCorpKey(cr.getChildCorpKey());
        rc.setLinkages(cr.getLinkages());
        return rc;
    }
}
