package com.dbs.cap.cls.common.configuration;

import com.dbs.cap.cls.utility.Endpoint;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@ConfigurationProperties("endpoints")
@Getter
public class EndpointConfiguration {
    private final List<Endpoint> list = new ArrayList<>();
}
