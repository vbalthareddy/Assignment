package com.dbs.cap.ct.batch.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Slf4j
public class JobCompletionNotificationListener extends JobExecutionListenerSupport {
    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info(jobExecution.toString());
        if(jobExecution.getStatus() == BatchStatus.COMPLETED) {
            jobExecution.setExitStatus(new ExitStatus("TREVOR DONE"));
        } else {
            jobExecution.setExitStatus(new ExitStatus("TREVOR FAILED"));
        }
        log.info("***************************" + (new Date()).toString() + "**********************");
        log.info("cron ${cron.value}");
    }
}
