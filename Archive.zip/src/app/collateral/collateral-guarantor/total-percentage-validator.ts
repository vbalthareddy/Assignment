import {AbstractControl} from '@angular/forms';
export class TotalPercentageValidator {
    private static message: string = 'Make sure that total sum of guarantee percentage should be 100';

    static required(c: AbstractControl, typeGuarantee?: string) {
        return c.value ? TotalPercentageValidator.checkTotal(c.value) ? null : {
            required: TotalPercentageValidator.getMessage(c) // the custom message you wish to display
        } : {
            required: 'cannot be null'
        };
    }

    static getMessage(c: AbstractControl): string {
        return this.message;
    }

    static checkTotal(val): boolean {
        if (val === 100) {
            return true;
        } else if (val === null) {
            return true;
        }
        return false;
    }
}

export class GuarantorGridValidator {
    private static message: string = 'Please add at least one Guarantee record';

    static required(c: AbstractControl, typeGuarantee?: string) {
        return c.value ? GuarantorGridValidator.checkValidation(c.value) ? null : {
            required: GuarantorGridValidator.getMessage(c)
        } : {
            required: 'Please add at least one Guarantee record'
        };
    }

    static getMessage(c: AbstractControl): string {
        return this.message;
    }

    static checkValidation(val): boolean {
        return val;
    }
}

export class GuarantorGridValidatorForJOINT {
    private static message: string = 'Please add more than one  Guarantee record for JOINT & (JOINT&SEVERAL) types';

    static required(c: AbstractControl, typeGuarantee?: string) {
        return c.value ? GuarantorGridValidator.checkValidation(c.value) ? null : {
            required: GuarantorGridValidator.getMessage(c) // the custom message you wish to display
        } : {
            required: 'Please add more than one  Guarantee record for JOINT & (JOINT&SEVERAL) types'
        };
    }

    static getMessage(c: AbstractControl): string {
        return this.message;
    }

    static checkValidation(val): boolean {
        return val;
    }
}
