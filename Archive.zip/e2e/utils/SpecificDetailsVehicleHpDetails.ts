import {$, protractor} from 'protractor';
import {E2eSpecHelper} from './E2eSpecHelper';
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const hpDetails: any = {
    addHpdetails: $('#addHpDetailsLink'),
    editHpdetails: $('#editHpDetailsLink'),
    specificDetailsIdOnTab: $('#specific_details_tab'),
    saveFormBtn: $('#hpDetailsSaveBtn'),
    backBtn: $('#hpDetailsBackBtn'),
    hpDetailsTextId: $('#hpDetailsTextId'),
    financeAmountInput: $('#finance-amount'),
    financeAmtInputValue: (financeAmtValue: string): any => $('#finance-amount input.cls-text').sendKeys(financeAmtValue),
    viewMoreDetails: $('#viewMoreDetails'),
    loanType: $('#loanTypeId'),
    loanTypeInputValue: (inputTerm: string): any => $('#loanType input.cls-text').sendKeys(inputTerm),
    groupCodeId: $('#groupCodeId'),
    groupCodeIdValue: (inputTerm: string): any => $('#groupCode input.cls-text').sendKeys(inputTerm),
    locationOfAssets: $('#coll-location-dropdown'),
    locationOfAssetSelect: (searchTerm: string): any => $('#coll-location-dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
    dealerCodeId: $('#dealerCodeId'),
    dealerCodeIdValue: (inputTerm: string): any => $('#dealerCode input.cls-text').sendKeys(inputTerm),
    deposeAmountInput: $('#deposit-amount'),
    deposeAmtInputValue: (deposeAmtValue: string): any => $('#deposit-amount input.cls-text').sendKeys(deposeAmtValue),
    yearOfRegistrationId: $('#yearOfRegistrationId'),
    yearOfRegisrationIcon: $('#yearOfRegistrationId .input-group-addon'),
    yearSelect: $('datepicker .btn-default.active'),
    location: $('.selected-list button'),
    locationSelect: $('.dropdown-list ul li:first-child'),
    removeIconMultiSelect: $('#angular2-multi-select > div > div.selected-list > button > div > div:nth-child(1) > span.fa.fa-remove')
};

exports.specificHpDetailsTestSuite = function () {
    describe('Hp Details Page', function () {
        it('should redirect to hpdetails page on click of hpdetails link ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.addHpdetails.click();
            e2eSpecHelper.sleepBrowser(3000);
            e2eSpecHelper.verifyTextContains('#hpDetailsTextId', 'HP Details');
        });
        it('should check HP details text ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#hpDetailsTextId', 'HP Details');
        });
        it('should Vehicle more show onclick of show more details ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.viewMoreDetails.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#viewMoreDetails', 'Show Less');
            hpDetails.viewMoreDetails.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#viewMoreDetails', 'View More');
        });
        it('should check HP details FormControl validations ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.verifyTextContains('#errorFinanceAmount', 'Finance Amount is required');
            e2eSpecHelper.verifyTextContains('#errorLoanType', 'Please Enter Loan Type');
            e2eSpecHelper.verifyTextContains('#errorGroupCodeId', 'Please Enter Group Code');
            e2eSpecHelper.verifyTextContains('#errorDealerCode', 'Please Enter Dealer Code');
            e2eSpecHelper.verifyTextContains('#errorDeposit', 'Deposit Payable Amount is required');
            e2eSpecHelper.verifyTextContains('#errorYearOfRegistration', 'Please Make a Selection');
        });
        it('should check HP details FormControl validations for individual inputs ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.financeAmountInput.click();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.financeAmtInputValue('');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.verifyTextContains('#errorFinanceAmount', 'Finance Amount is required');
            hpDetails.groupCodeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.groupCodeIdValue('');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.verifyTextContains('#errorGroupCodeId', 'Please Enter Group Code');
            hpDetails.dealerCodeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.dealerCodeIdValue('');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.verifyTextContains('#errorDealerCode', 'Please Enter Dealer Code');
        });
        it('should save data for valid entries ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.financeAmountInput.click();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.financeAmtInputValue('12');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.loanType.click();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.loanTypeInputValue('loan1');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.groupCodeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.groupCodeIdValue('GroupCode');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.dealerCodeId.click();
            hpDetails.dealerCodeIdValue('DealerCode');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.deposeAmountInput.click();
            hpDetails.deposeAmtInputValue('12');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.location.click();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.locationSelect.click();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.yearOfRegistrationId.click();
            hpDetails.yearOfRegisrationIcon.click();
            e2eSpecHelper.sleepBrowser(5000);
            hpDetails.yearSelect.click();
            e2eSpecHelper.sleepBrowser(5000);
            hpDetails.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(6000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'HP details have been succesfully added.');
            e2eSpecHelper.sleepBrowser(3000);
        });
        it('should update hp details data on click of edit hpdetails', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.editHpdetails.click();
            e2eSpecHelper.sleepBrowser(3000);
            e2eSpecHelper.verifyTextContains('#hpDetailsTextId', 'HP Details');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.dealerCodeId.click();
            e2eSpecHelper.sleepBrowser(1000);
            hpDetails.dealerCodeId.clear();
            hpDetails.dealerCodeIdValue('DealerCode Updated');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(6000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'HP details has been succesfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });
        it('should navigate to specific details page on click of back button', () => {
            hpDetails.backBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            expect(e2eSpecHelper.verifyTextContains('#hpDetailsTextId', 'HP Details')).toBe(false);
        });
    });
};
exports.HpDetailsTestSuiteForEditFlow = function () {
    describe('Hp Details Page', function () {
        it('should redirect to hpdetails page on click of hpdetails link ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.editHpdetails.click();
            e2eSpecHelper.sleepBrowser(3000);
            e2eSpecHelper.verifyTextContains('#hpDetailsTextId', 'HP Details');
        });
        it('should Vehicle more show onclick of show more details ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.viewMoreDetails.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#viewMoreDetails', 'Show Less');
            hpDetails.viewMoreDetails.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#viewMoreDetails', 'View More');
        });
        it('should update data for valid entries ', () => {
            hpDetails.dealerCodeId.click();
            e2eSpecHelper.sleepBrowser(1000);
            hpDetails.dealerCodeId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.saveFormBtn.click();
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.verifyTextContains('#errorDealerCode', 'Please Enter Dealer Code');

        });
        it('should update hp details data on click of edit hpdetails', () => {
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.editHpdetails.click();
            e2eSpecHelper.sleepBrowser(3000);
            e2eSpecHelper.verifyTextContains('#hpDetailsTextId', 'HP Details');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.dealerCodeId.click();
            e2eSpecHelper.sleepBrowser(1000);
            hpDetails.dealerCodeId.clear();
            hpDetails.dealerCodeIdValue('DealerCode Updated');
            e2eSpecHelper.sleepBrowser(2000);
            hpDetails.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(3000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'HP details has been succesfully updated.');
            e2eSpecHelper.sleepBrowser(3000);
        });

        it('should navigate to specific details page on click of back button', () => {
            hpDetails.backBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            expect(e2eSpecHelper.verifyTextContains('#hpDetailsTextId', 'HP Details')).toBe(false);
        });
    });
};
