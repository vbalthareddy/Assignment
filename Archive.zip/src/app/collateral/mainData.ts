export const evJson =
    {
        "collateralId": "lodge03",
        "collateralCode": "code03",
        "draft": false,
        "collateralType": "GUARN",
        "generalDetail": {
            "collateralDesc": "Lodgement for guarantee",
            "collateralClass": "COLTRLCLS1",
            "collateralGrp": "COLTRLGRP1",
            "collateralCreationDate": "2017-05-07T12:40:36.355Z",
            "collateralExpiryDate": "2017-12-07T12:40:36.355Z",
            "currencyCode": "SGD",
            "collateralStatus": "",
            "applicationDetail": {
                "formNo": "B234323",
                "receivedDate": "2017-05-25T12:40:36.355Z",
                "reviewDate": "2017-06-25T12:40:36.355Z",
                "nextReviewDate": "2017-08-07T12:40:36.355Z",
                "signingDate": "2017-05-25T12:40:36.355Z",
                "executionDate": "2017-05-25T12:40:36.355Z",
                "comments": ""
            }
        },
        "withdrawalDetail": {
            "withdraw": false,
            "reasonCode": "",
            "withdrawalDate": "2017-05-31T12:01:56.464Z"
        },
        "GUARN": {
            "LodgeReceiptAndPayment": {
                "receiptAndPayment": [
                    {
                        "receiptType": "General",
                        "receiptAmt": {
                            "value": 1000,
                            "ccy": "SGD"
                        },
                        "paymentType": "",
                        "paymentAmt": {
                            "value": 0,
                            "ccy": "SGD"
                        },
                        "dueDate": "2017-05-27T12:40:36.355Z",
                        "paidOrReceivedDate": "2017-05-27T12:40:36.355Z",
                        "dateRange": "",
                        "proofVerifiedDate": "2017-05-27T12:40:36.355Z",
                        "paymentMode": "",
                        "notes": "",
                        "name": "",
                        "freeCode1": "",
                        "freeCode2": "",
                        "freeText": "",
                        "delete": false
                    }
                ]
            },
            "LodgeDocumentationDetail": {
                "document": [
                    {
                        "documentCode": "DOCCODE2",
                        "documentDate": "2017-05-27T12:40:36.355Z",
                        "documentId": "",
                        "dueDate": "2017-06-07T12:40:36.355Z",
                        "documentReceivedDate": "2017-06-07T12:40:36.355Z",
                        "documentExpirationDate": "2017-06-27T12:40:36.355Z",
                        "comments": "TEST",
                        "delete": false
                    }
                ]
            },
            // "LodgeBeneficiaryDetail": {
            //     "beneficiaryList": [
            //         {
            //             "beneficiaryName": "",
            //             "cifId": "",
            //             "beneficiaryIdType": "",
            //             "beneficiaryId": "",
            //             "addressLine1": "",
            //             "addressLine2": "",
            //             "addressLine3": "",
            //             "city": "",
            //             "state": "",
            //             "country": "",
            //             "postalCode": "",
            //             "phoneNo": "",
            //             "emailAddress": "",
            //             "telexNo": "",
            //             "faxNo": "",
            //             "delete": false
            //         },
            //           {
            //             "beneficiaryName": "",
            //             "cifId": "",
            //             "beneficiaryIdType": "",
            //             "beneficiaryId": "",
            //             "addressLine1": "",
            //             "addressLine2": "",
            //             "addressLine3": "",
            //             "city": "",
            //             "state": "",
            //             "country": "",
            //             "postalCode": "",
            //             "phoneNo": "",
            //             "emailAddress": "",
            //             "telexNo": "",
            //             "faxNo": "",
            //             "delete": false
            //         }
            //     ]
            // },
            "CollateralValuationDetail": {
                "loanToValuePcnt": 40,
                "externalChargeAmt": {
                    "value": 0,
                    "ccy": "SGD"
                },
                "collateralValue": {
                    "value": 100000,
                    "ccy": "SGD"
                },
                "finalCollateralValue": {
                    "value": 0,
                    "ccy": "SGD"
                },
                "apportioningMethod": "P",
                "totalApportionedValue": {
                    "value": 0,
                    "ccy": "SGD"
                },
                "balanceApportionableAmt": {
                    "value": 0,
                    "ccy": "SGD"
                }
            },
            "LodgeOwnerShipDetail": {
                "collateralOwnerShipType": "",
                "ownerShipList": [
                    {
                        "cifId": "",
                        "idType": "IDTYPE1",
                        "idNo": 0,
                        "name": "",
                        "collateralOwnerShipPcnt": 0,
                        "addressLine1": "",
                        "addressLine2": "",
                        "addressLine3": "",
                        "city": "",
                        "state": "",
                        "country": "",
                        "postalCode": "",
                        "phoneNo": "",
                        "emailAddress": "",
                        "telexNo": "",
                        "faxNo": "",
                        "delete": false
                    }
                ]
            },
            "LodgeCollateralTypeSpecificDetail": {
                "guaranteeType": "GUARNCODE1",
                "guarantorName": "Guarantor1",
                "guarantorCifId": "",
                "idType": "",
                "idNo": "",
                "guarantorType": "GUARNTYPE2",
                "supportingCollateralsHeld": false,
                "guaranteePcnt": 10,
                "guaranteeAmt": {
                    "value": 0,
                    "ccy": "SGD"
                },
                "addressLine1": "",
                "addressLine2": "",
                "addressLine3": "",
                "city": "",
                "state": "",
                "country": "",
                "postalCode": ""
            },
            "FeeDetail": {
                "feeDetailList": [
                    {
                        "feeType": "FEE2",
                        "feeCode": "FEECODE",
                        "overrideFeeSetup": false,
                        "feeDistributable": false,
                        "multiple": false,
                        "frequency": "",
                        "nextAssessmentDate": "2017-05-27T12:40:36.356Z",
                        "maxNumberOfAssessements": 0,
                        "amortize": false,
                        "amortizationTerm": 0,
                        "method": "",
                        "scriptName": "",
                        "userEnteredAmt": {
                            "value": 0,
                            "ccy": "SGD"
                        },
                        "userEnteredPcnt": 0,
                        "remarks": "",
                        "delete": false
                    }
                ],
                "feeCollectionAccount": "",
                "computedAmount": {
                    "value": 0,
                    "ccy": "SGD"
                },
                "collectableAmountPcnt": 0,
                "collectableAmount": {
                    "value": 0,
                    "ccy": "SGD"
                }
            },
            "CollateralValueDetail": {
                "unitValueMethod": false,
                "directValueMethod": false,
                "netValueMethod": false,
                "derivedValueMethod": false,
                "itemBasedMethod": false,
                "customerDerivationMethod": false,
                "defaultValueMethod": false,
                "childCollateralMethod": false
            }
        }
    }
