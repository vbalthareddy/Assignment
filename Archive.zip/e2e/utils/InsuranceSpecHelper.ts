import {E2eSpecHelper} from './E2eSpecHelper';
import {$, browser, by, element, protractor} from 'protractor';

const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const insurance: any = {
    policyDetailsLink: $('#insuranceAddPolicyLink'),
    policyDetailsBackLink: $('#policyBackButton'),
    saveFormBtn: $('#save-form-btn'),
    updateFormBtn: $('#update-form-btn'),
    addDetailsBtn: $('#add-details-btn'),
    closeDialogIcon: $('.k-dialog-close'),
    noRecordLink: $('#no-records-label a'),
    deleteIcon: $('#insuranceDeleteIcon-0'),
    insuranceIdOnTab: $('#insurance_tab'),
    insuranceTypeId: $('#fcfd-dropdwon'),
    insuranceBtnForPopDialog: $('.clsBtnSecondary'),
    insuranceLabel: $('#insuranceLable'),
    insuranceCodeId: $('#fcfd-dropdwon'),
    insurancePolicyId: $('#policyNumber'),
    insuranceSearchId: $('#insuranceSearchId'),
    insuranceCodeErrorMessage: $('#insuranceCodeErrorMessage'),
    insuranceEditIcon: $('#insuranceEditIcon-0'),
    insuranceDropDownResult: $('.k-animation-container .k-list .k-item:first-child'),
    insuranceDropDownResult1: $('.k-animation-container .k-list .k-item:last-child'),
    insuranceCustodianSearch: (searchTerm: string): any => $('#insuranceSearchId .k-searchbar .k-input').sendKeys(searchTerm),
    insuranceCodeSearch: (searchTerm: string): any => $('#fcfd-dropdwon .k-searchbar .k-input').sendKeys(searchTerm),
    selectinsuredDropdownList: $('.k-animation-container .k-list .k-item:first-child'),
    insuredValueSearch: (searchTerm: string): any => $('#itemsInsured .k-searchbar .k-input').sendKeys(searchTerm),
    selectDropdownList: $('.k-animation-container .k-list .k-item:first-child'),
    selectDropdownListLast: $('.k-animation-container .k-list .k-item:last-child'),
    insurancePolicyNoInputValue: (inputTerm: string): any => $('#policyNumber').sendKeys(inputTerm),
    insuranceDateIcon: $('#insuranceDate .k-select'),
    insuranceDueDate: $('#insuranceDueDate .k-select'),
    insuranceReceivedDate: $('#insuranceReceivedDate .k-select'),
    insuranceExpirationDate: $('#insuranceExpirationDate .k-select'),
    insurancePolicyNo: $('#policyNumber'),
    insurancePemiumPaidDate: $('#premiumPaidDate .k-select'),
    insuranceCollectionDate: $('#premiumCollectionDate .k-select'),
    insuranceCancellationDate: $('#cancellationDate .k-select'),
    insuranceCoverStartDate: $('#coverStartDate .k-select'),
    insuranceCoverEndDate: $('#coverEndDate .k-select'),
    dateToday: $('.k-today '),
    dateWeekend: $('.k-weekend')
};

exports.InsuranceTestSuite = function () {
    describe('insurance Page', function () {
        it('should display insurance Tab on click', function () {
            e2eSpecHelper.sleepBrowser(1000);
            element(by.css('#insurance_tab')).click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.insuranceIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#insurance_tab', 'Insurance');
            e2eSpecHelper.sleepBrowser(1000);
        });

        it('should check for no records found for insurance', function () {
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Insurance Details Found');
            e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding insurance details');
            insurance.noRecordLink.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.closeDialogIcon.click();

        });

        it('should not validate insurance Details if fields are empty', function () {
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            insurance.closeDialogIcon.click();
        });

        it('should validate and save details for insurance', function () {
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceTypeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceCodeSearch('M');
            e2eSpecHelper.sleepBrowser(2000);
            insurance.selectDropdownList.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insurancePolicyNoInputValue('XYZ1');
            e2eSpecHelper.sleepBrowser(2000);
            insurance.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(5000);
        });

        xit('should validate and save details for insurance', function () {
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceTypeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceCodeSearch('M');
            e2eSpecHelper.sleepBrowser(5000);
            insurance.selectDropdownListLast.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insurancePolicyNoInputValue('XYZ2');
            e2eSpecHelper.sleepBrowser(2000);
            insurance.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(5000);
        });

        it('should  navigate to policy Details Page', () => {
            e2eSpecHelper.sleepBrowser(2000);
            insurance.policyDetailsLink.click();
            e2eSpecHelper.verifyTextContains('#add_policy_details', 'Add Policy Details');
        });

        it('should navigate to insurance page on click of back button.', () => {
            e2eSpecHelper.sleepBrowser(2000);
            insurance.policyDetailsBackLink.click();
            e2eSpecHelper.verifyTextContains('#insurance_tab', 'Insurance');
            insurance.policyDetailsLink.click();
        });

        it('should validate the Amount fields', () => {
            e2eSpecHelper.sleepBrowser(2000);
            element(by.css('[placeholder="Enter Policy amount"]')).sendKeys('jhjj');
            element(by.id('policy-amount')).click();
            expect(element.all(by.id('currencyAmounterror')).getText()).toContain('Please enter amount.');

        });

        it('should fill the appropriate data and click on submit button.', () => {
            e2eSpecHelper.sleepBrowser(2000);
            element(by.css('[placeholder="Enter Policy amount"]')).sendKeys('12');
            element(by.css('[placeholder="Enter Premium amount"]')).sendKeys('33');
            element(by.css('[placeholder="Enter policy holder name"]')).sendKeys('policy holder name');
            element(by.css('[placeholder="Search premium collection A/C ID"]')).sendKeys('Search premium collection A/C ID');
            element(by.css('[placeholder="Enter policy no."]')).sendKeys('Enter policy no.');
            ($('#itemsInsured')).click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.insuredValueSearch('1');
            e2eSpecHelper.sleepBrowser(1000);
            insurance.selectinsuredDropdownList.click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
            $('#frequency').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
            $('#paymentMethod').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();

            $('#insuranceAction').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
            $('#coverType').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();

            e2eSpecHelper.sleepBrowser(3000);
            insurance.insurancePemiumPaidDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.dateWeekend.click();
            e2eSpecHelper.sleepBrowser(3000);
            insurance.insuranceCollectionDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.dateToday.click();
            $('#insuranceAction').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
            $('#coverType').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();

            e2eSpecHelper.sleepBrowser(9000);
            insurance.insuranceCoverStartDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.dateWeekend.click();
            e2eSpecHelper.sleepBrowser(6000);
            insurance.insuranceCoverEndDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.dateWeekend.click();

            $('#bankID').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
            $('#branchID').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();

            e2eSpecHelper.sleepBrowser(6000);
            insurance.insuranceCancellationDate.click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.dateWeekend.click();
            e2eSpecHelper.sleepBrowser(2000);
            $('#insuranceAction').click();
            browser.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
            const submitButton = element.all(by.id('policySubmitButton'));
            submitButton.click();
        });

        it('should update insurance details', function () {
            insurance.insuranceEditIcon.click();
            //	e2eSpecHelper.sleepBrowser(2000);
            //	insurance.insuranceCodeId.clear();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceTypeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceCodeSearch('d');
            e2eSpecHelper.sleepBrowser(5000);
            insurance.selectDropdownListLast.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.updateFormBtn.click();
            e2eSpecHelper.sleepBrowser(5000);
        });

        it('should remove insurance details on click of delete button', function () {
            e2eSpecHelper.verifyPresence('#insuranceDeleteIcon-0');
            insurance.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            //	e2eSpecHelper.verifyPresence('#no-records-div');
            e2eSpecHelper.sleepBrowser(2000);
        });

    });
};

exports.InsuranceTestSuiteForEditFlow = function () {
    describe('insurance Page for Edit Flow', function () {
        it('should display insurance Tab on click', function () {
            e2eSpecHelper.sleepBrowser(1000);
            insurance.insuranceIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#insurance_tab', 'insurance');
            e2eSpecHelper.sleepBrowser(1000);
        });
        it('should not validate insurance Details if fields are empty', function () {
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
        });

        it('should validate and save details for insurance', function () {
            e2eSpecHelper.sleepBrowser(1000);
            insurance.insuranceCodeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.dateToday.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceDueDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.dateToday.click();
            insurance.insuranceExpirationDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.dateWeekend.click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.insuranceCodeSearch('d');
            insurance.insuranceDropDownResult.click();
            e2eSpecHelper.sleepBrowser(1000);
            insurance.insuranceCustodianSearch('s');
            insurance.insuranceDropDownResult.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of insurance details has been successfully Added.');
        });

        it('should update insurance details', function () {
            insurance.insuranceEditIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            insurance.insuranceRemark.clear();
            insurance.insuranceRemarkInput('Test Remarks');
            insurance.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should remove insurance details on click of delete button', function () {
            e2eSpecHelper.verifyPresence('#insuranceDeleteIcon-0');
            insurance.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('#no-records-div');
            e2eSpecHelper.sleepBrowser(2000);
        });

    });
};