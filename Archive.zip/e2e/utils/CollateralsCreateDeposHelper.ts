import {E2eSpecHelper} from './E2eSpecHelper';

const collateralSpecSuite = require('./CollateralSpecHelper');
const summarySpecSuite = require('./SummarySpecHelper');
const valuationSpecSuite = require('./ValuationSpecHelper');
const documentSpecSuite = require('./DocumentSpecHelper');
const beneficiarySpecSuite = require('./BeneficiarySpecHelper');
const collateralDetailSpecSuite = require('./CollateralDetailSpecHelper');
const specificDetailSpecSuite = require('./SpecificDetailsSpecHelper');
const ownershipSpecSuite = require('./OwnershipSpecHelper');
const chargeSpecSuite = require('./ChargeSpecHelper');
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

exports.CreateCollateralDeposTestSuite = function () {
    describe('should create collateral of deposit type', () => {
        /*E2E for setting up add collateral Page*/
        const processCollateralPage = () => {
            collateralSpecSuite.CollateralTestSuite('DEPOSIT');
        };

        /*E2E for Collateral Details Page*/
        const processCollateralDetailsPage = () => {
            collateralDetailSpecSuite.CollateralDetailsTestSuite();
        };

        /*E2E for Collateral Details Page*/
        const processSpecificDetailsPage = () => {
            specificDetailSpecSuite.SpecificDetailsTestSuite();
        };

        /*E2E for Beneficiary Page*/
        const processBeneficiaryDetailsPage = () => {
            beneficiarySpecSuite.BeneficiaryTestSuite();
        };

        /*E2E for Ownership Page*/
        const processOwnershipDetailsPage = () => {
            ownershipSpecSuite.OwnershipTestSuite();
        };

        /*E2E for Document Page*/
        const processDocumentDetailsPage = () => {
            documentSpecSuite.DocumentTestSuite();
        };

        /*E2E for Valuation Page*/
        const processValuationDetailsPage = () => {
            valuationSpecSuite.ValuationTestSuite();
        };

        /*E2E for Summary Page*/
        const processSummaryPage = () => {
            summarySpecSuite.SummaryTestSuite('Deposit');
        };

        describe('should set up add collateral page', () => {
            processCollateralPage();
        });

        describe('should verify details on collateral-details page', () => {
            processCollateralDetailsPage();
        });

        describe('should verify details on specific-details page', () => {
            processSpecificDetailsPage();
        });

        describe('should verify details on beneficiary-details page', () => {
            processBeneficiaryDetailsPage();
        });

        xdescribe('should verify details on ownership-details page', () => {
            processOwnershipDetailsPage();
        });

        describe('should verify details on document-details page', () => {
            processDocumentDetailsPage();
        });

        describe('should verify details on valuation tab page', () => {
            processValuationDetailsPage();
        });

        describe('should verify data from summary page', () => {
            processSummaryPage();
        });

        it('should click on Submit button to submit guarantee type collateral', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.buttonClick('#final_submit_btn');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('#gblMsgId');
        });
    });
};
