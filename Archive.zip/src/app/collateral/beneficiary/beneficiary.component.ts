import {ChangeDetectorRef, Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Http} from '@angular/http';
import {BeneficiaryList} from '../model/collateral';
import {BeneficiaryService} from './beneficiary.component.service';
import {CollateralService} from '../collateral.service';
import {CounterPartyDetailsService} from '../../common/counterparty-details/counterparty.service';
import {ErrorResponse} from '../../shared';
import {ToastsComponent} from '../../shared/toasts/toasts.component';
import {ActivatedRoute, NavigationExtras, Params, Router} from '@angular/router';
import * as _ from 'underscore';
import {CurrencyFormatPipe} from '../../shared/currency-pipe/currency-pipe';
import {CommonUtil} from '../../common/utils/common.util';

@Component({
    selector: 'collateral-beneficiary',
    templateUrl: './beneficiary.component.html',
    styleUrls: ['./beneficiary.component.scss']
})
export class BeneficiaryComponent implements OnInit {
    public beneficiaryGridData: any[] = [];
    public beneficiaryGridDataForHtml: any[] = [];
    successMsg: boolean = false;
    errMsg: boolean = false;
    errorMessage: string;
    showLoader = false;
    errorResponse: ErrorResponse = null;
    public beneficiaryAddDialogBox: boolean = false;
    beneficiaryIdInvalid: boolean = false;
    public events: any[] = [];
    public AddBeneficiaryForm: FormGroup;
    divForNormalGrid: boolean = true;
    public saveData: boolean = true;
    public showPopupDialog: boolean = false;
    public dialogTitleName: string = 'Add Beneficiary Details';
    noRecordsFlag: boolean = true;
    public counterPartyDetails: any;
    public rowIndex: number;
    public idList = [];
    argToastSelfTimeout: number;
    public duplicateValueErrDiv: boolean = false;
    argToastMessageObject: any;
    private divForServiceError: boolean;
    beneficiaryRankList: any;
    toastsComponent: ToastsComponent = new ToastsComponent();
    duplicateValueCheck: any;
    beneficiaryLinkageData: any = [];
    keyArrayFromLimit: string[] = [];
    rankData: any = [];
    beneficiaryIdDisableFlag: boolean = false;
    selectedRankCode: string;
    gcinCpValue: string;
    gcinDesc: string;
    ctype: string;
    showYesNoPrompt: boolean = false;
    beneficiaryDataForDelete: any;
    @Input() iscollapsible: boolean;
    @Input() public beneficiaryForm: FormGroup;
    @Input() showAddBeneficiaryBtn: boolean = true;
    @Input() showSummaryGrid: boolean = false;

    constructor(private _fb: FormBuilder, private http: Http, private router: Router, private route: ActivatedRoute, private beneficiaryservice: BeneficiaryService,
                private collateralService: CollateralService, private cd: ChangeDetectorRef,
                private counterPartyDetailsService: CounterPartyDetailsService) {
        this.route.queryParams.subscribe((params: Params) => {
            this.gcinCpValue = params['gcin'];
            this.gcinDesc = params['label'];
            this.ctype = params['ctype'];

        });
    }

    ngOnInit() {
        this.getBeneficiaryRank();
        this.subscribeCounterPartyDetail();
        this.setUpBeneficiaryComponent();
    }

    subscribeCounterPartyDetail() {
        this.counterPartyDetailsService.subscribeToCPDetails({
            next: (value) => this.counterPartyDetails = value,
            error: (value) => console.log(value),
            complete: () => {
            }
        });

    }

    setUpBeneficiaryComponent() {
        this.divForNormalGrid = !this.showSummaryGrid;
        this.getBeneficiaryListDetails();
        this.processFormItems();
        this.initialiseBeneficiaryForm();
        this.getLimitDataForBeneficiary();
    }

    private getBeneficiaryListDetails() {
        if (this.collateralService.getCollateral().beneficiaryDetails) {
            this.beneficiaryGridData = this.collateralService.getCollateral().beneficiaryDetails;
            const tmpArray = JSON.parse(JSON.stringify(this.beneficiaryGridData));
            this.getGridDataForHTML(tmpArray);
        }
    }

    private initialiseBeneficiaryForm() {
        this.AddBeneficiaryForm = this._fb.group({
            beneficiaryId: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            beneficiaryName: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            beneficiaryDescription: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
            beneficiaryRankToShow: [''],
            beneficiaryRankToSubmit: [''],
            beneficiaryCapAmount: [null],
            beneficiaryCapAmountType: [''],
            beneficiaryRowStatus: ['', [<any>Validators.required, <any>Validators.required]],
            id: [''],
            _version: ['']
        });
    }

    getBeneficiaryRank() {
        this.beneficiaryservice.getBeneficiaryRankService().subscribe(
            response => {
                this.divForServiceError = false;
                this.beneficiaryRankList = response;
                this.rankData = this.beneficiaryRankList;
                this.getBeneficiaryListDetails();
            },
            error => {
                this.divForServiceError = true;
            },
            () => {
                this.divForServiceError = false;
                this.getGridDataForHTML(JSON.parse(JSON.stringify(this.beneficiaryGridData)));
            }
        );
    }

    getLimitDataForBeneficiary() {
        if (this.collateralService.getLimitData()) {
            this.beneficiaryLinkageData = this.collateralService.getLimitData();
        }
    }

    cancelForm() {
        this.duplicateValueErrDiv = false;
        this.showPopupDialog = false;
        this.saveData = true;
        this.AddBeneficiaryForm.reset();
        this.validationReset();
    }

    addBeneficiary() {
        this.dialogTitleName = 'Add Beneficiary Details';
        this.showPopupDialog = true;
        this.beneficiaryIdDisableFlag = false;
        this.validationReset();
    }

    addBeneficiaryData(data: any) {
        const flagValue = this.validationCheck(data);
        if (flagValue === true) {
            this.validationReset();
            const dataObj = this.beneficiaryGridDataForHtml.find(item => item.beneficiaryId === data.beneficiaryId);
            if (dataObj) {
                this.duplicateValueErrDiv = true;
            } else {
                this.updateGridValueFunction(data, 'ADD');
            }
        } else {
            setTimeout(() => CommonUtil.recursiveFocus(), 300);
        }
    }

    beneficiaryEditFunc(item: BeneficiaryList): void {
        this.validationReset();
        this.dialogTitleName = 'Update Beneficiary';
        this.rowIndex = this.beneficiaryGridData.indexOf(item);
        this.searchByGCINCIF(item.beneficiaryId);
        setTimeout(() => this.dataForEdit(item), 1000);
    }

    private dataForEdit(item: any) {
        this.saveData = false;
        this.showPopupDialog = true;
        this.beneficiaryIdDisableFlag = true;
        if (item.beneficiaryCap === null) {
            item.beneficiaryCap = {
                value: 0.0,
                ccy: ''
            };
        }
        if (this.idList !== undefined && this.idList.length > 0) {
            const rankObj = this.beneficiaryRankList.find(data => data.description === item.beneficiaryRanking);
            this.AddBeneficiaryForm = this._fb.group({
                beneficiaryId: [this.idList[0].gcin, [<any>Validators.required, <any>Validators.minLength(0)]],
                beneficiaryName: [item.beneficiaryName, [<any>Validators.required, <any>Validators.minLength(0)]],
                beneficiaryDescription: [this.idList[0].description, [<any>Validators.required, <any>Validators.minLength(0)]],
                beneficiaryRankToSubmit: [rankObj ? rankObj.code : ''],
                beneficiaryRankToShow: [item.beneficiaryRanking],
                beneficiaryCapAmount: [item.beneficiaryCap.value],
                beneficiaryCapAmountType: [item.beneficiaryCap.ccy],
                beneficiaryRowStatus: [item.__row_status, [<any>Validators.required, <any>Validators.required]],
                id: [item.id, [<any>Validators.required, <any>Validators.required]],
                _version: [item._version]

            });
            this.duplicateValueCheck = this.AddBeneficiaryForm.value;
        }
    }

    updateBeneficiaryGridList(data: any) {
        const flagValue = this.validationCheck(data);
        if (flagValue === true) {
            this.validationReset();
            this.saveData = true;
            this.updateGridValueFunction(data, 'UPDATE');
        } else {
            setTimeout(() => CommonUtil.recursiveFocus(), 300);
        }
    }

    private updateGridValueFunction(data: any, flag: string) {
        this.duplicateValueErrDiv = false;
        this.AddBeneficiaryForm.reset();
        this.showPopupDialog = false;
        const tempBeneficiaryItem = new BeneficiaryList();
        tempBeneficiaryItem.beneficiaryId = data.beneficiaryId;
        tempBeneficiaryItem.beneficiaryName = data.beneficiaryName;
        if (!data.beneficiaryRankToSubmit) {
            tempBeneficiaryItem.beneficiaryRanking = '';
            tempBeneficiaryItem['beneficiaryRankingToShow'] = '';
        } else {
            tempBeneficiaryItem.beneficiaryRanking = data.beneficiaryRankToSubmit;
            tempBeneficiaryItem['beneficiaryRankingToShow'] = data.beneficiaryRankToShow;
        }
        tempBeneficiaryItem.beneficiaryCap.value = CurrencyFormatPipe.transformAsNumberFromString(data.beneficiaryCapAmount);
        if (tempBeneficiaryItem.beneficiaryCap.value === 0) {
            tempBeneficiaryItem.beneficiaryCap.ccy = '';
        } else {
            tempBeneficiaryItem.beneficiaryCap.ccy = data.beneficiaryCapAmountType;
        }

        if (data.beneficiaryRowStatus !== '' && data.beneficiaryRowStatus !== undefined) {
            tempBeneficiaryItem.__row_status = data.beneficiaryRowStatus;
        }
        let toastMsg: string;
        const dataObj = this.beneficiaryGridData.find(item => item.beneficiaryId === tempBeneficiaryItem.beneficiaryId);
        if (flag !== 'DELETE') {
            if (dataObj) {
                this.rowIndex = this.beneficiaryGridData.indexOf(dataObj);
                if (tempBeneficiaryItem.__row_status === 'modified' || tempBeneficiaryItem.__row_status === null) {
                    tempBeneficiaryItem.__row_status = 'modified';
                } else if (tempBeneficiaryItem.__row_status === 'added') {
                    tempBeneficiaryItem.__row_status = 'added';
                }
                tempBeneficiaryItem.id = dataObj.id;
                tempBeneficiaryItem._version = dataObj._version;
                this.beneficiaryGridData[this.rowIndex] = tempBeneficiaryItem;
            } else {
                tempBeneficiaryItem.__row_status = 'added';
                tempBeneficiaryItem.id = 'benefiary' + Math.random().toString(36).substr(2, 5) + Math.random().toString(36).substr(2, 5);
                this.beneficiaryGridData.push(tempBeneficiaryItem);
            }
        }
        if (flag === 'ADD') {
            this.beneficiaryservice.addBeneficiary(tempBeneficiaryItem).subscribe(temp => {
            }, error => {
                this.errorResponse = <ErrorResponse>error;
            });
            toastMsg = 'A new record of beneficiary details has been successfully added.';
        } else if (flag === 'UPDATE') {
            toastMsg = 'A record of beneficiary details has been successfully updated.';
        } else if (flag === 'DELETE') {
            this.rowIndex = this.beneficiaryGridData.indexOf(dataObj);
            tempBeneficiaryItem.__row_status = data.__row_status;
            tempBeneficiaryItem.id = data.id;
            tempBeneficiaryItem._version = dataObj._version;
            if (tempBeneficiaryItem.__row_status === 'added') {
                this.beneficiaryGridData.splice(this.rowIndex, 1);
            } else if (tempBeneficiaryItem.__row_status === 'modified' || tempBeneficiaryItem.__row_status === undefined) {
                tempBeneficiaryItem.__row_status = 'deleted';
                this.beneficiaryGridData[this.rowIndex] = tempBeneficiaryItem;
            }
            toastMsg = 'A record of beneficiary details has been successfully deleted.';
            this.updateLinkageStatus(data.beneficiaryId);
        }
        const tmpArray = JSON.parse(JSON.stringify(this.beneficiaryGridData));
        this.getGridDataForHTML(tmpArray);
        this.beneficiaryForm.get('beneficiaryList').setValue(this.beneficiaryGridData);
        this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success', toastMsg, '', '');
    }

    private getGridDataForHTML(data: any) {
        if (this.beneficiaryRankList) {
            const dataForMap = data.map(item => {
                if (this.beneficiaryRankList.length > 0) {
                    if (item && item.beneficiaryRanking !== '') {
                        item['beneficiaryRanking'] = this.beneficiaryRankList.find(temp => temp.code === item.beneficiaryRanking).description;
                    }
                }
                return item;
            });
            this.beneficiaryGridDataForHtml = dataForMap.filter(Data => {
                if (Data && Data.__row_status !== 'deleted') {
                    return Data;
                }
            });
            this.processFormItems();
        }
    }

    updateLinkageStatus(beneficiaryId?: string) {
        if (this.collateralService.limitDataBeneficiary[beneficiaryId]) {
            this.collateralService.limitDataBeneficiary[beneficiaryId].forEach(element => {
                const collateralIndex = _.findIndex(this.collateralService.collateral.linkageDetails, {entityId: element.limitId});
                if (collateralIndex !== -1 && this.collateralService.collateral.linkageDetails[collateralIndex] &&
                    this.collateralService.collateral.linkageDetails[collateralIndex].__row_status !== 'added') {
                    this.collateralService.collateral.linkageDetails[collateralIndex].__row_status = 'deleted';
                } else if (collateralIndex !== -1 && this.collateralService.collateral.linkageDetails[collateralIndex] &&
                    this.collateralService.collateral.linkageDetails[collateralIndex].__row_status === 'added') {
                    this.collateralService.collateral.linkageDetails.splice(collateralIndex, 1);
                }
            });
            delete this.collateralService.limitDataBeneficiary[beneficiaryId];
        }
    }

    beneficiaryRemoveItemFunc(data: any) {
        this.showYesNoPrompt = true;
        this.beneficiaryDataForDelete = data;
    }

    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.duplicateValueErrDiv = false;
        this.showPopupDialog = showPopupDialog;
        this.saveData = true;
        this.AddBeneficiaryForm.reset();
        this.validationReset();
    }

    searchByGCINCIF(searchValue: string) {
        if (searchValue.length === 0) {
            this.beneficiaryIdInvalid = false;
            this.duplicateValueErrDiv = false;
        }
        const bodyData = {'searchKeyword': searchValue};
        if (searchValue.length > 2) {
            this.idList = [];
            this.showLoader = true;
            this.beneficiaryservice.getBeneficiaryIdDataService(bodyData).subscribe(
                response => {
                    this.successMsg = true;
                    this.errMsg = false;
                    this.idList = response.map(function (item) {
                        return ({
                            'gcin': item.gcin,
                            'description': item.gcin + '   ' + this.modifiedNameFunc(item.description, item.gcin),
                            'type': item.type,
                            'name': this.modifiedNameFunc(item.description, item.gcin)
                        });

                    }, this);
                },
                error => {
                    this.showLoader = false;
                    this.successMsg = false;
                    this.errMsg = true;
                    this.errorMessage = 'Oops! something went wrong.    ' + error._body;
                },
                () => {
                }
            );
        }
    }

    onSearchGCIDCIFSelect(event) {
        const dataObj = this.idList.find(item => item.description === this.AddBeneficiaryForm.value.beneficiaryDescription);
        if (!(dataObj === undefined)) {
            this.beneficiaryIdInvalid = false;
            this.AddBeneficiaryForm.controls['beneficiaryId'].setValue(dataObj.gcin);
            this.AddBeneficiaryForm.controls['beneficiaryName'].setValue(dataObj.name);
        } else {
            this.beneficiaryIdInvalid = true;
        }
        const beneficiaryObj = this.beneficiaryGridDataForHtml.find(item => item.beneficiaryId === this.AddBeneficiaryForm.value.beneficiaryDescription);
        if (!beneficiaryObj) {
            this.duplicateValueErrDiv = false;
        }
    }

    private processFormItems() {
        if (this.beneficiaryGridDataForHtml.length > 0) {
            this.noRecordsFlag = false;
        } else {
            this.noRecordsFlag = true;
        }
    }

    private validationReset() {
        this.beneficiaryIdInvalid = false;
    }

    private validationCheck(data?: any) {
        let valid = false;
        const dataObj = this.idList.find(item => item.description === data.beneficiaryDescription);
        if (((data.beneficiaryDescription === '') || (data.beneficiaryDescription === null)) || (dataObj === undefined)) {
            this.beneficiaryIdInvalid = true;
            this.duplicateValueErrDiv = false;
            valid = false;
        } else {
            this.beneficiaryIdInvalid = false;
            valid = true;
        }
        return valid;
    }

    private modifiedNameFunc(description: string, gcin: string): string {
        let tempName = description.replace(gcin, '');
        tempName = tempName.replace('()', '');
        return tempName;
    }

    onRankSelect(selectedRank: number) {
        const i = this.beneficiaryRankList.find(item => item.code === selectedRank);
        if (((i !== '') || (i !== null)) && (i !== undefined)) {
            this.AddBeneficiaryForm.controls['beneficiaryRankToSubmit'].setValue(i.code);
            this.AddBeneficiaryForm.controls['beneficiaryRankToShow'].setValue(i.description);
        }
    }

    rankValidation(rankInput: string) {
        this.rankData = this.beneficiaryRankList.filter((s) => s.description.toLowerCase().indexOf(rankInput.toLowerCase()) !== -1);
        if (rankInput === '') {
            this.AddBeneficiaryForm.controls['beneficiaryRankToSubmit'].setValue(null);
        }
    }

    getLinkage(data: any, flag: string) {
        this.collateralService.checkPopupDialogBox = true;
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'gcinLabel': data.beneficiaryName,
                'gcinValue': data.beneficiaryId,
                'functionFlag': flag,
                'ctype': this.ctype,
                'gcin': this.gcinCpValue,
                'label': this.gcinDesc
            }
        };
        this.router.navigate(['./facilityLinkage'], navigationExtras);

    }

    confirmationFromYesNo(dlgPayload: any[]) {
        this.showYesNoPrompt = false;
        if (dlgPayload[0] === 'yes') {
            this.updateGridValueFunction(this.beneficiaryDataForDelete, 'DELETE');
        }
    }

}
