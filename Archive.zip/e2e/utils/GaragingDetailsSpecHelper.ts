import {E2eSpecHelper} from './E2eSpecHelper';
import {$, by, element, protractor} from 'protractor';

exports.GaragingDetailsSpecSuite = function () {
    const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
    describe('Garage Address Page', function () {
        it('should  navigate to garage address Page', function () {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#sub-hirer-details-panel', 'Add Garage Address');
        });

        it('should fill the appropriate data and click on submit button.', () => {
            e2eSpecHelper.sleepBrowser(2000);
            element(by.css('[placeholder="Enter address line 1"]')).sendKeys('122242');
            element(by.css('[placeholder="Enter address line 2"]')).sendKeys('kondapur');
            element(by.css('[placeholder="Enter address line 3"]')).sendKeys('shilpa park');
            $('#city').click();
            $('#city .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            $('#state').click();
            $('#state .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            $('#countryDropDownId').click();
            $('#countryDropDownId .k-searchbar > .k-input').sendKeys('', protractor.Key.ENTER);
            element(by.css('[placeholder="Please enter postal code"]')).sendKeys('postalCode');
            const submitButton = element.all(by.id('subHirerSubmitButton'));
            submitButton.click();

        });
    });
}