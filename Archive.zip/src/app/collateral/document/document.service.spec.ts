import {fakeAsync, inject, TestBed} from '@angular/core/testing';
import {MockBackend, MockConnection} from '@angular/http/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {DocRefValues, documentCodes, documentStatus} from './document_data';
import {DocumentService} from './document.service';
import {Observable} from 'rxjs/Rx';

class MockDocumentService {
    getData() {
        return [];
    }

    getDocumentCodes() {
        return Observable.of(documentCodes);
    }

    getDocumentStatus() {
        return Observable.of(documentStatus);
    }
}

describe('DocumentService', () => {
    let documentService: DocumentService;
    let mockBackend: MockBackend;
    const data = DocRefValues;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                DocumentService
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([DocumentService, MockBackend], (service: DocumentService, backend: MockBackend) => {
            documentService = service;
            mockBackend = backend;
        })
    );

    it('should ...', inject([DocumentService], (service: DocumentService) => {
        expect(service).toBeTruthy();
    }));
    it('service should be defined', () => {
        expect(DocumentService).toBeDefined();
    });
    it('should get response from mock server for document codes ', fakeAsync(() => {
        const mockResponseBody = documentCodes;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        documentService.getDocumentCodes().subscribe((response: Response) => {
            expect(response).toEqual(documentCodes);
        });
    }));
    it('should get response from mock server for document status codes ', fakeAsync(() => {
        const mockResponseBody = documentStatus;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        documentService.getDocumentStatus().subscribe((response: Response) => {
            expect(response).toEqual(documentStatus);
        });
    }));

    it('getDocumentStatus service should call endpoint and return error', (() => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
            documentService.getDocumentStatus()
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
            documentService.getDocumentCodes()
            .subscribe((error) => {
                expect(error).toEqual('r');
            });
    }));

});
