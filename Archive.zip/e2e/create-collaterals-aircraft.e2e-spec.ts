describe('should complete add,edit,delete journey for collateral of aircraft Type', () => {

    const createCollateralAirCraftTestSuite = require('./utils/CollateralsCreateAirCraftHelper');
    const editCollateralAirCraftTestSuite = require('./utils/CollateralsEditAirCraftHelper');
    const withdrawCollateralAirCraftTestSuite = require('./utils/CollateralsWithdrawAirCraftHelper');

    const processCreateCollateralAirCraft = () => {
        createCollateralAirCraftTestSuite.CreateCollateralAirCraftTestSuite();
    };

    const processEditCollateralAirCraft = () => {
        editCollateralAirCraftTestSuite.EditCollateralAirCraftTestSuite();
    };

    const processWithdrawCollateralAirCraft = () => {
        withdrawCollateralAirCraftTestSuite.WithdrawCollateralAirCraftTestSuite();
    };

    describe('should create a collateral of AirCraft type', () => {
        processCreateCollateralAirCraft();
    });

    describe('should edit already created collateral of AirCraft type', () => {
        processEditCollateralAirCraft();
    });

    describe('should withdraw existing collateral of AirCraft type ', () => {
        processWithdrawCollateralAirCraft();
    });

});
