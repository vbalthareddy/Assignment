import { FacilityGuardService } from 'app/collateral/facility-linkage-data/facility-guard.service';
import { MockBackend } from '@angular/http/testing';
import { TestBed } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { inject } from '@angular/core/testing';
import { collateralData } from 'app/collateral/new-collateral/new-collateral.data';
import { CollateralService } from 'app/collateral/collateral.service';
import { Router, ActivatedRoute, RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

class MockCollateralService {
    collateral = this.getCollateral();
    getCollateral()
    {
        return collateralData;
    }
}
describe('Facility Linkage guard service Test Cases', () => {
    let facilityGuardService: FacilityGuardService = null;
    let mockBackend: MockBackend = null;
    let mockCollateralService: MockCollateralService;
    const router = {
        navigate: jasmine.createSpy('navigate')
    };
    const MockActivatedRoute = {
        queryParams: Observable.of({
            'gcinLabel': '16R2A GCIN4NF CN002 ',
            'gcinValue': 'GC0001045990',
            'functionFlag': 'EDIT'
        })
    };
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [FacilityGuardService, MockBackend, { provide: CollateralService, useClass: MockCollateralService },
                {provide: Router, useValue: router},
                {provide: ActivatedRoute, useValue: MockActivatedRoute}],
            imports: [HttpModule]
        });
    });
    beforeEach(
        inject([FacilityGuardService, MockBackend, CollateralService], (service: FacilityGuardService, backend: MockBackend, collateralService: CollateralService) => {
            facilityGuardService = service;
            mockBackend = backend;
            mockCollateralService = collateralService;
        })
    );

    it('should Create Facility Linkage guard Service', inject([FacilityGuardService], (service: FacilityGuardService) => {
        expect(service).toBeTruthy();
    }));

    it('should verify collateral data and return true', inject([FacilityGuardService], (service: FacilityGuardService) => {
        const route: ActivatedRouteSnapshot = null;
        const state: RouterStateSnapshot = null;
        expect(facilityGuardService.canActivate(route, state)).toBe(true);
    }));

    it('should verify collateral data and navigate back if it is empty ', inject([FacilityGuardService], (service: FacilityGuardService) => {
        const route: ActivatedRouteSnapshot = null;
        const state: RouterStateSnapshot = null;
        mockCollateralService.collateral = null;
        spyOn(mockCollateralService, 'getCollateral').and.returnValue(null);
        facilityGuardService.canActivate(route, state);
        expect(router.navigate).toHaveBeenCalledWith(['./']);
    }));
});