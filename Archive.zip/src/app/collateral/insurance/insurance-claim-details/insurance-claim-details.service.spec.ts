import {inject, TestBed} from '@angular/core/testing';
import {MockBackend, MockConnection} from '@angular/http/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {InsuranceClaimsDetailsService} from './insurance-claim-details.service';

describe('InsuranceClaimService', () => {
    let insuranceClaimsDetailsService: InsuranceClaimsDetailsService;
    let mockBackend: MockBackend;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                }, InsuranceClaimsDetailsService
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([InsuranceClaimsDetailsService, MockBackend], (service: InsuranceClaimsDetailsService, backend: MockBackend) => {
            insuranceClaimsDetailsService = service;
            mockBackend = backend;
        })
    );
    it('insuranceClaimsDetails service should be defined', () => {
        expect(InsuranceClaimsDetailsService).toBeDefined();
    });
    it('insuranceClaimsDetails service should call endpoint and return it\'s result', (done) => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const options = new ResponseOptions({
                body: JSON.stringify({status: 'Ok'})
            });
            connection.mockRespond(new Response(options));
        });
        insuranceClaimsDetailsService.getInsuranceClaimStatus()
            .subscribe((response) => {
                expect(response).toEqual({status: 'Ok'});
                done();
            });
    });
    it('insuranceClaimsDetails service should call endpoint and return error', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });
        insuranceClaimsDetailsService.getInsuranceClaimStatus()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });
});
