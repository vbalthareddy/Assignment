import {Component, ElementRef, HostListener, OnInit} from '@angular/core';
import {CollateralsListService} from './collaterals-list.component.service';
import {ActivatedRoute, NavigationExtras, Params, Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {ToastsComponent} from '../../shared/toasts/toasts.component';
import {CollateralSummaryService} from '../collateral-summary/collateral-summary.service';
import {_} from 'underscore';
import {Collateral} from 'app/collateral/model/collateral';
import {JsonConvert} from 'json2typescript';
import {CollateralService} from 'app/collateral/collateral.service';
import {CounterPartyDetailsService} from 'app/common/counterparty-details/counterparty.service';
import {CurrencyFormatPipe} from '../../shared/currency-pipe/currency-pipe';
import {PlatformLocation} from '@angular/common';
import {FormBuilder, FormGroup} from '@angular/forms';

@Component({
    selector: 'app-collaterals-list',
    templateUrl: './collaterals-list.component.html',
    styleUrls: ['./collaterals-list.component.scss']
})
export class CollateralsListComponent implements OnInit {
    popUpShow: any;
    backBtnPress: boolean;
    public currencyValues: any = [];
    private errorMsg: boolean;
    public setPresentCurrencyFormat: any = {
        code: 'SGD'
    };
    public presentCurrencyFormat: string = 'SGD';
    public presentCurrencyUnit: string = 'Unit';
    public listItems: any[] = ['Unit', 'Thousand', 'Million'];
    private counterpartyGCID: string;
    public argToastMessageObject: any;
    showPopupDialogForRemoveConfirmation: boolean = false;
    private dialogTitleNameConfirmation: string = '';
    selectedCollateral: any;
    selectedCollateralIndex: number;
    private errMsg: boolean = false;
    private errorMessage: string;
    private toastsComponent: ToastsComponent = new ToastsComponent();
    private selectedCollateralType: string;
    public withdrawReason: any = 'Not Applicable';
    public withdrawReasons: any[] = ['Not Applicable', 'Form B delink'];
    COLLATERAL_CONFIG: any;
    keys: any = [];
    masterCollateralList: any;
    collateralDataFromMastersInq: any;
    collateralsDataToShowList: any = {};
    public showLoader: boolean = false;
    public summaryRowAddFlag: boolean = false;
    public checkBoxSelectedAll: any = [];
    public checkAllBox: any = [];
    currencyFormatValue: number = 2;
    currencyDivider: number = 1;
    errorMsgText: string = 'Errors found while converting Rate values (The collaterals with below currencies as collateral currency are  excluding from total Amount)';
    createCollateral: boolean = false;
    ratesErrorMsgsList: any = [];
    showHeadErrorPanel: boolean = false;
    public disableTab: boolean = false;
    gcinCpValue: string;
    gcinDesc: string;
    sumKeys: any = {};
    showPopupDialog: boolean = false;
    titleDialogBox: string = 'Leaving Form';
    actionTypeDialogBox: string = 'leaveForm';
    collateralListForm: FormGroup;
    collateralIndexValue: any;

    constructor(public collateralsListService: CollateralsListService, private route: ActivatedRoute,
                private collateralService: CollateralService, private router: Router,
                public collateralSummaryService: CollateralSummaryService,
                private _displayContent: ElementRef,
                private counterPartyDetailsService: CounterPartyDetailsService, location: PlatformLocation, private _fb: FormBuilder) {
        this.route.queryParams.subscribe((params: Params) => {
            this.gcinCpValue = params['gcin'];
            this.gcinDesc = params['label'];
        });
        location.onPopState(() => {
            this.backBtnPress = true;
            location.pushState(null, null, window.location.pathname);
        });
    }

    ngOnInit() {
        this.initCustomForms();
        this.getRateValuesFromService();
        this.setUpCollateralsListPage();

    }

    @HostListener('window:onbeforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        if (this.popUpShow) {
            return this.popUpShow;
        } else {
            if (this.backBtnPress) {
                this.titleDialogBox = 'Warning';
                this.actionTypeDialogBox = 'warning';
                this.backBtnPress = false;
                this.showPopupDialog = true;
            } else {
                this.showPopupDialog = false;
                this.popUpShow = true;
            }
            return this.popUpShow;
        }
    }

    initCustomForms() {
        this.collateralListForm = this._fb.group({
            currencyFormat: [this.presentCurrencyFormat],
            amountFormat: [this.presentCurrencyUnit]
        });
    }

    setUpCollateralsListPage() {
        this.showLoader = true;
        this.masterCollateralList = this.collateralSummaryService.masterCollateralListFromService;
        this.COLLATERAL_CONFIG = this.collateralSummaryService.collateralConfigListFromService;
        if (this.collateralSummaryService.collateralOperation && this.collateralSummaryService.collateralOperation === 'COLLATERSL_SUCCESS') {
            this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                this.collateralService.getCollateral().collateralId + ' Collateral submitted succesfully',
                '', '');
            this.collateralSummaryService.collateralOperation = null;
            this.masterCollateralList = null;
        } else if (this.collateralSummaryService.collateralOperation && (this.collateralSummaryService.collateralOperation === 'FACILITY LINKAGE' || this.collateralSummaryService.collateralOperation === 'ADD')) {
            this.collateralSummaryService.collateralOperation = null;
            this.masterCollateralList = null;
        }
        this.getCurrencyList();
        /*Get data (if available) from collateral summary*/

        if (this.COLLATERAL_CONFIG && this.masterCollateralList) {
            this.collateralsListService.configurationForCollaterals = this.COLLATERAL_CONFIG;
            this.extractCollateralTypeFromConfig();
            this.getCollateralDataToShowInGrids();
            this.selectionCurrencyChange(this.presentCurrencyFormat);
            this.showLoader = false;
        } else {
            /*Load Configurations from Service*/
            this.getConfigurations();
            setTimeout(() => {
                this.extractCollateralTypeFromConfig();
                this.masterCollateralList = {};
                this.initializeGridsWithBlankDataForMasterCollaterals();
                this.extractMasterCollateralList();
            }, 500);
        }
        // this.showLoader = false;
    }

    getConfigurations() {
        this.collateralsListService.getConfigurationsForCollaterals().subscribe(
            data => {
                this.COLLATERAL_CONFIG = data;
                /*setting up variable in service file to serve purpose in service file*/
                this.collateralsListService.configurationForCollaterals = data;
            }, error => {
                this.errorMsg = true;
                this.returnError(error);
            });
    }

    getCurrencyList() {
        this.collateralsListService.getCurrency().subscribe(data => {
            this.currencyValues = data;
        }, error => {
            this.errorMsg = true;
            this.returnError(error);
        });
    }

    /*TODO when batch currency API will be ready */
    /*getStoredCurrencyRate(argFrom: string, argTo: string) {
     const tempRate = this.collateralSummaryService.rateConversionArray.find(item => item.from === argFrom && item.to === argTo);
     if (tempRate !== undefined) {
     return tempRate['rate'];
     } else {
     return undefined;
     }
     }*/

    returnError(error: any) {
        if (error.status === 500) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 400) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 409) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 404) {
            return Observable.throw(new Error(error.status));
        }
    }

    /*Function to Add New Collateral*/
    redirectToAddNewCollateral() {
        this.createCollateral = true;
        this.collateralSummaryService.breadCrumbClickFlag = false;
        // this.router.navigate(['/newcollateral']);
    }

    onCancel(createCollateral: boolean) {
        this.createCollateral = createCollateral;
    }

    private getUsableCollateralsData(fullJSONOfCollaterals: any, collateralType: string) {
        const list = [];
        if (fullJSONOfCollaterals !== undefined) {
            for (const key in fullJSONOfCollaterals) {
                /* TODO Logic to map json to Object using JSON deserialize */
                if (fullJSONOfCollaterals[key].withdrawalDetail === null || !(fullJSONOfCollaterals[key].withdrawalDetail.withdraw)) {
                    const temporaryJSONObj = {
                        'collateralId': (fullJSONOfCollaterals[key].collateralId === undefined) ? '-' : fullJSONOfCollaterals[key].collateralId,
                        'collateralCode': (fullJSONOfCollaterals[key].collateralCode === undefined) ? '-' : fullJSONOfCollaterals[key].collateralCode,
                        'owner': ((this.getFilteredBeneficiaryAndOwnershipList(fullJSONOfCollaterals[key].ownershipDetails, '__row_status', 'ownership')).length !== 0) ?
                            this.getFilteredBeneficiaryAndOwnershipList(fullJSONOfCollaterals[key].ownershipDetails, '__row_status', 'ownership') : ['-'],
                        'originalCurrency': (fullJSONOfCollaterals[key].CollateralValuationDetail.finalCollateralValue.ccy === undefined || fullJSONOfCollaterals[key].CollateralValuationDetail.finalCollateralValue.ccy === '') ? 'SGD' :
                            fullJSONOfCollaterals[key].CollateralValuationDetail.finalCollateralValue.ccy,
                        'originalCollateralValue': fullJSONOfCollaterals[key].CollateralValuationDetail.finalCollateralValue.value,
                        'displayOriginalCollateralValue': fullJSONOfCollaterals[key].CollateralValuationDetail.finalCollateralValue.value,
                        'convertedCollateralValue': fullJSONOfCollaterals[key].CollateralValuationDetail.finalCollateralValue.value,
                        'beneficiaryID': ((this.getFilteredBeneficiaryAndOwnershipList(fullJSONOfCollaterals[key].beneficiaryDetails, '__row_status', 'beneficiary')).length !== 0) ?
                            this.getFilteredBeneficiaryAndOwnershipList(fullJSONOfCollaterals[key].beneficiaryDetails, '__row_status', 'beneficiary') : ['-'],
                        'linkages': '',
                        'remarks': (fullJSONOfCollaterals[key].generalDetail.remarks === undefined || fullJSONOfCollaterals[key].generalDetail.remarks === '') ? '-' : fullJSONOfCollaterals[key].generalDetail.remarks
                    };
                    list.push(temporaryJSONObj);
                    if (fullJSONOfCollaterals[key].linkageDetails && fullJSONOfCollaterals[key].linkageDetails.length > 0) {
                        this.getLimitsBeneficiaryMap(fullJSONOfCollaterals[key].linkageDetails, temporaryJSONObj);
                    }
                }
            }
            if (list.length !== 0) {
                this.addSummaryRowToCollateralData(list, collateralType);
            }
        }
        return list;
    }

    getLimitsBeneficiaryMap(linkages: any, obj: any): any {
        const entityData = linkages;
        const limits = _.map(entityData, function (element, index, list) {
            return element.entityId;
        });
        const filter = {where: {limitId: {inq: limits}}, fields: ['limitId', 'limitTypeId']};
        this.collateralService.getLimitsByLimitTypeId(filter).subscribe(_limits => {
                obj.linkages = _.groupBy(_.map(entityData, function (element, index, list) {
                    const linkage = _.where(_limits, {limitId: element.entityId});
                    return {
                        limitId: element.entityId,
                        collateralId: element.collateralId,
                        gcin: linkage[0].limitTypeId
                    };
                }), function (_obj) {
                    return _obj.gcin;
                });
            },
            error => {
            }
        );
    }

    /*Extract keys on which kendo grid(s) will be generated*/
    extractCollateralTypeFromConfig() {
        const configList = this.COLLATERAL_CONFIG;
        for (const key in configList) {
            this.keys[(configList[key].sequencePos) - 1] = {
                type: key,
                apiToHit: (configList[key].apiToHit),
                label: (configList[key].label),
                include: (configList[key].include)
            };
            this.checkBoxSelectedAll[key] = false;
            this.checkAllBox[key] = false;
        }
    }

    extractMasterCollateralList() {
        /*GET collateral master data from GCIN Id*/
        /*TODO get Collateral master Data from API*/

        this.counterPartyDetailsService.subscribeToCPDetails({
            next: (value) => {
                this.collateralSummaryService.getCollateralInqRes(value.value).subscribe(data => {
                        this.collateralDataFromMastersInq = data;
                        this.fetchCollateralDetails(this.collateralDataFromMastersInq);
                        setTimeout(() => {
                            this.collateralSummaryService.masterCollateralListFromService = this.masterCollateralList;
                            this.getCollateralDataToShowInGrids();
                            this.selectionCurrencyChange(this.presentCurrencyFormat);
                            this.showLoader = false;
                        }, 10000);
                    },
                    error => {

                    });
            },
            error: (value) => this.returnError(value),
            complete: () => {
            }
        });
    }

    fetchCollateralDetails(collateralsMasterData) {
        collateralsMasterData = _.groupBy(collateralsMasterData, function (obj) {
            return obj.collateralType;
        });

        this.keys.forEach(element => {
            const collateralIds = _.map(collateralsMasterData[element.type], function (value, index, list) {
                return value.collateralId;
            });
            const filter = {
                where: {'withdrawalDetail.withdraw': false, collateralId: {inq: collateralIds}},
                order: '_createdOn desc',
                include: element.include
            };
            this.collateralsListService.getCollateralsList(element.type, element.apiToHit, filter).subscribe(data => {
                this.masterCollateralList[element.type] = data;
            }, error => {
                this.masterCollateralList[element.type] = [];
            }, () => {
            });
        });
    }

    getCollateralDataToShowInGrids() {
        this.keys.forEach(element => {
            this.collateralsDataToShowList[element.type] =
                this.getUsableCollateralsData(this.masterCollateralList[element.type], element.type);
        });
    }

    colPositionFun(position: number, collateralType: string, returnVal: string) {
        if (this.COLLATERAL_CONFIG.hasOwnProperty(collateralType)) {
            for (let i = 0; i < this.COLLATERAL_CONFIG[collateralType]['columnsToShow'].length; i++) {
                if (position === this.COLLATERAL_CONFIG[collateralType]['columnsToShow'][i]['position']) {
                    if (returnVal === 'colHeader') {
                        return this.COLLATERAL_CONFIG[collateralType]['columnsToShow'][i]['colHeader'];
                    }
                    if (returnVal === 'fieldName') {
                        return this.COLLATERAL_CONFIG[collateralType]['columnsToShow'][i]['fieldName'];
                    }
                }
            }
        }
    }

    checkForCollateralListData(list: any) {
        return list.length !== 0;
    }

    addSummaryRowToCollateralData(list: any, collateralType: string) {
        if (list.length !== 0) {
            /* this.summaryRowJSON = {
             'checkboxId': 'Total',
             'collateralId': '',
             'collateralCode': '',
             'owner': '',
             'originalCurrency': '',
             'beneficiaryID': '',
             'remarks': ''
             };*/
            let localSumValue: number = 0;
            for (const listRow in list) {
                localSumValue = localSumValue + CurrencyFormatPipe.transformAsNumberFromString(list[listRow]['convertedCollateralValue']);
            }
            // this.summaryRowJSON['convertedCollateralValue'] = localSumValue;
            this.sumKeys[collateralType] = localSumValue;

            // list.push(this.summaryRowJSON);
        }
        // return list;
    }

    unitConverter(amountFormat: any) {
        this.showLoader = true;
        this.currencyFormatValue = 3;
        this.presentCurrencyUnit = amountFormat;
        const currencyDivider: any = 1;
        if (this.presentCurrencyUnit === 'Million') {
            this.currencyDivider = 1.0e+6;
        } else if (this.presentCurrencyUnit === 'Thousand') {
            this.currencyDivider = 1.0e+3;
        } else if (this.presentCurrencyUnit === 'Unit') {
            this.currencyDivider = 1;
            this.currencyFormatValue = 2;
        }
        this.getRateValuesFromService();
    }

    getRateValuesFromService() {
        const toCurrencyValue = this.collateralSummaryService.rateConversionArray.map(item => {
            return item['toCurrency'];
        });
        const findIndexForCurrency = toCurrencyValue.findIndex(item => item === this.presentCurrencyFormat);
        if (findIndexForCurrency === undefined || findIndexForCurrency === -1) {
            this.collateralSummaryService.getRateValues('', this.presentCurrencyFormat).subscribe(data => {
                this.collateralSummaryService.rateConversionArray = this.collateralSummaryService.rateConversionArray.concat(data);
                this.sumAmountValuesForCollaterals();
            }, error => {
                this.errorMsgShow(error);
                this.sumAmountValuesForCollaterals();

            }, () => {

            });
        } else {
            this.sumAmountValuesForCollaterals();
        }
    }

    errorMsgShow(error?: any) {
        if (error) {
            this.errorMsgText = 'Service not available';
            this.ratesErrorMsgsList.push(error._body);

        } else {
            const msg = 'Rates are not available from service for ' + this.presentCurrencyFormat;
            const findIndexValue = this.ratesErrorMsgsList.findIndex(item => item === msg);
            if (findIndexValue === undefined || findIndexValue === -1) {
                this.ratesErrorMsgsList.push(msg);
                this.showHeadErrorPanel = true;
            }
        }
    }

    selectionCurrencyChange(currencyFormat: any) {
        this.summaryRowAddFlag = false;
        this.currencyFormatValue = 3;
        this.ratesErrorMsgsList = [];
        this.showHeadErrorPanel = false;
        if (currencyFormat) {
            this.showLoader = true;
            this.presentCurrencyFormat = currencyFormat;
            this.getRateValuesFromService();
            if (this.presentCurrencyUnit === 'Million') {
                this.currencyDivider = 1.0e+6;
                this.currencyFormatValue = 3;
            }
            if (this.presentCurrencyUnit === 'Thousand') {
                this.currencyDivider = 1.0e+3;
                this.currencyFormatValue = 3;
            }
            if (this.presentCurrencyUnit === 'Unit') {
                this.currencyFormatValue = 2;
                this.currencyDivider = 1;
            }
        }

    }

    sumAmountValuesForCollaterals() {
        this.keys.forEach(element => {
            let tempDataArrayOfCollaterals = [];
            let counterForAPICompletion = 0;
            tempDataArrayOfCollaterals = this.collateralsDataToShowList[element.type];
            if (tempDataArrayOfCollaterals && tempDataArrayOfCollaterals.length !== 0) {
                for (const key in tempDataArrayOfCollaterals) {
                    let newRate;
                    if (this.collateralSummaryService.rateConversionArray.length > 0) {
                        const indexOfRate = this.collateralSummaryService.rateConversionArray.findIndex(item => item['fromCurrency'] === tempDataArrayOfCollaterals[key]['originalCurrency'] && item['toCurrency'] === this.presentCurrencyFormat);
                        if (indexOfRate !== undefined && (indexOfRate !== -1)) {
                            newRate = this.collateralSummaryService.rateConversionArray[indexOfRate]['rate'];
                            tempDataArrayOfCollaterals[key]['convertedCollateralValue'] =
                                (Math.abs(Number((tempDataArrayOfCollaterals[key]['originalCollateralValue'])) * newRate) / this.currencyDivider);
                            tempDataArrayOfCollaterals[key]['displayOriginalCollateralValue'] =
                                (Math.abs(Number((tempDataArrayOfCollaterals[key]['originalCollateralValue']))) / this.currencyDivider);
                            counterForAPICompletion++;

                        } else {
                            const msg = 'Rate Values for ' + tempDataArrayOfCollaterals[key]['originalCurrency'] + ' currency to ' + this.presentCurrencyFormat + ' not available form service';
                            const findIndexValue = this.ratesErrorMsgsList.findIndex(item => item === msg);
                            if (findIndexValue === undefined || findIndexValue === -1) {
                                this.ratesErrorMsgsList.push(msg);
                                this.showHeadErrorPanel = true;
                            }
                            newRate = 0;
                            tempDataArrayOfCollaterals[key]['convertedCollateralValue'] =
                                (Math.abs(Number((tempDataArrayOfCollaterals[key]['originalCollateralValue'])) * newRate) / this.currencyDivider);
                            tempDataArrayOfCollaterals[key]['displayOriginalCollateralValue'] =
                                (Math.abs(Number((tempDataArrayOfCollaterals[key]['originalCollateralValue']))) / this.currencyDivider);
                            counterForAPICompletion++;

                        }
                        if (counterForAPICompletion === tempDataArrayOfCollaterals.length) {
                            /*Adding Summary Row again after calculating new values*/
                            this.addSummaryRowToCollateralData(tempDataArrayOfCollaterals, element.type);
                            this.collateralsDataToShowList[element.type] = tempDataArrayOfCollaterals;
                            this.showLoader = false;
                        }
                    }
                }
            }
        });
    }

    removeCollateralItem(indexValue, selectedCollateral: any, index: number, collateralType: string) {
        this.collateralIndexValue = indexValue;
        if (!selectedCollateral) {
            return;
        }

        if (!this.collateralsListService.configurationForCollaterals) {
            this.getConfigurations();
        }

        const collateralIdFilter = {
            where: {collateralId: selectedCollateral.collateralId},
            include: this.collateralsListService.configurationForCollaterals[collateralType].include
        };
        this.collateralsListService.getCollateralsList(collateralType,
            this.collateralsListService.configurationForCollaterals[collateralType].apiToHit, collateralIdFilter).subscribe(data => {
                if (data.length > 0) {
                    this.selectedCollateral = JsonConvert.deserializeString(JSON.stringify(data[0]), Collateral);
                    this.selectedCollateral.generalDetail.businessEntity = ['ALL'];
                    this.selectedCollateral.generalDetail.globalCollateral = true;
                    this.selectedCollateralIndex = index;
                    this.selectedCollateralType = collateralType;
                    this.showPopupDialogForRemoveConfirmation = true;
                    this.dialogTitleNameConfirmation = 'Confirm Collateral Withdrawal';
                }
            },
            error => {
            });

    }

    closeEventFromRemoveCollateralPopupDialog() {
        this.showPopupDialogForRemoveConfirmation = false;
    }

    confirmCollateralRemoval() {
        //  call service to  remove item
        const collateralCode = this.selectedCollateral['collateralCode'];
        const collateralType = this.selectedCollateralType;
        if (this.withdrawReason !== undefined) {
            let reasonCode = '';
            if (this.withdrawReason === 'Not Applicable') {
                reasonCode = '01';
            } else {
                reasonCode = '03';
            }

            if (this.selectedCollateral.linkageDetails && this.selectedCollateral.linkageDetails.length > 0) {
                this.selectedCollateral.linkageDetails.forEach(element => {
                    element.__row_status = 'deleted';
                });
            }
            this.collateralsListService.withdrawCollateral(this.selectedCollateral, reasonCode, collateralType).subscribe(data => {
                    if (data) {
                        // if we get success remove from Grids
                        this.removeCollateralFromGrid(this.selectedCollateralIndex, collateralType);
                        this.closeEventFromRemoveCollateralPopupDialog();   // uncomment later when service works
                    }
                },
                error => {
                    this.closeEventFromRemoveCollateralPopupDialog();
                    this.errMsg = true;
                    this.errorMessage = 'Oops! something went wrong.    ' + error._body;
                }
            );
            this.closeEventFromRemoveCollateralPopupDialog();    // TBD remove later
        } else {
            return;
        }
    }


    removeCollateralFromGrid(selectedCollateralIndex: number, collateralType: string) {
        // based on the  Collateral Type remove teh record from Grid
        //  TBD change the Collateraltype as per Actual JSON from Service <OTHER_TANGBLE> to be changed
        let toastLocMsg = '';
        if (this.collateralsDataToShowList.hasOwnProperty(collateralType)) {
            this.changeBackGroundColor(collateralType, this.selectedCollateralIndex, this.collateralIndexValue)
            if (this.collateralsDataToShowList[collateralType].length === 0) {
                this.extractMasterCollateralList();
                return;
            }
            this.addSummaryRowToCollateralData(this.collateralsDataToShowList[collateralType], collateralType);
            for (let i = 0; i < this.keys.length; i++) {
                if (this.keys[i]['type'] === collateralType) {
                    toastLocMsg = 'A record of ' + this.keys[i]['label'] + ' Collateral has been successfully withdrawn.';
                    break;
                }
            }
            this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                toastLocMsg,
                '', '');
        }
    }

    selectionChangeEventForWithdrawSelect(reason: any) {
        this.withdrawReason = reason;
    }

    editSummaryCollateralItemOld(selectedCollateral: any, index: number, collateralType: string) {
        this.collateralService.isCollateralLocked(selectedCollateral.collateralId, collateralType).subscribe(isLocked => {
            console.log(isLocked);
        });

        /* this.collateralService.disableTab = true;
         this.clearCollateral();

         if (!selectedCollateral) {
         return;
         }

         if (!this.collateralsListService.configurationForCollaterals) {
         this.getConfigurations();
         }

         const tabSections = [];
         const collateralIdFilter = {
         where: {collateralId: selectedCollateral.collateralId},
         include: this.COLLATERAL_CONFIG[collateralType].include
         };
         this.collateralService.selectedCollateralType = collateralType;
         this.collateralsListService.getCollateralsList(collateralType,
         this.collateralsListService.configurationForCollaterals[collateralType].apiToHit, collateralIdFilter).subscribe(data => {
         if (data.length > 0) {
         this.collateralService.collateral = JsonConvert.deserializeString(JSON.stringify(data[0]), Collateral);
         const filter = {where: {collateralType: collateralType}};
         this.collateralsListService.getCollateralTypes(filter).subscribe(response => {
         if (response) {
         populateTabSections(_.pick(response[0], 'sections'));
         this.collateralService.tabSections = tabSections;
         this.collateralService.selectedTab = 'Summary';
         this.collateralSummaryService.collateralOperation = 'VIEW COLLATERAL';
         this.collateralService.getLinkages();
         let navigationExtras: NavigationExtras;
         navigationExtras = {
         queryParams: {
         'cid': selectedCollateral.collateralId,
         'ctype': collateralType,
         'gcin': this.gcinCpValue,
         'label': this.gcinDesc
         }
         };
         this.router.navigate(['/collateral'], navigationExtras);
         }
         },
         error => {
         });
         }

         },
         error => {

         });

         function populateTabSections(obj) {
         _.each(obj, function (element, indx, list) {
         if (_.isObject(element)) {
         populateTabSections(element);
         } else {
         if (element) {
         tabSections.push(indx);
         }
         }
         });
         } */
    }

    editSummaryCollateralItem(selectedCollateral: any, index: number, collateralType: string) {
        this.collateralService.disableTab = true;
        this.collateralService.checkPopupDialogBox = false;
        this.collateralSummaryService.breadcrumbvalue = false;
        this.collateralSummaryService.breadCrumbClickFlag = false;
        this.collateralService.clearCollateral();
        if (!selectedCollateral) {
            return;
        }
        this.collateralService.isCollateralLocked(selectedCollateral.collateralId, collateralType).subscribe(isLocked => {
            let navigationExtras: NavigationExtras;
            navigationExtras = {
                queryParams: {
                    'cid': selectedCollateral.collateralId,
                    'ctype': collateralType,
                    'gcin': this.gcinCpValue,
                    'label': this.gcinDesc
                }
            };
            this.collateralSummaryService.collateralOperation = 'VIEW COLLATERAL';
            this.collateralService.selectedTab = 'Summary';
            this.router.navigate(['./collateral'], navigationExtras);
        });
    }

    editCollateralItem(selectedCollateral: any, index: number, collateralType: string) {
        this.collateralService.checkPopupDialogBox = false;
        this.collateralSummaryService.breadcrumbvalue = false;
        this.collateralSummaryService.breadCrumbClickFlag = false;
        this.collateralService.disableTab = false;
        this.collateralService.clearCollateral();
        if (!selectedCollateral) {
            return;
        }

        this.collateralService.isCollateralLocked(selectedCollateral.collateralId, collateralType).subscribe(isLocked => {
            console.log(isLocked);
            let navigationExtras: NavigationExtras;
            navigationExtras = {
                queryParams: {
                    'cid': selectedCollateral.collateralId,
                    'ctype': collateralType,
                    'gcin': this.gcinCpValue,
                    'label': this.gcinDesc
                }
            };

            if (!isLocked) {
                this.collateralSummaryService.collateralOperation = 'EDIT';
            } else {
                this.collateralSummaryService.collateralOperation = 'VIEW COLLATERAL';
                this.collateralService.selectedTab = 'Summary';
                this.collateralService.disableTab = true;
            }
            this.router.navigate(['./collateral'], navigationExtras);

        });


    }

    toggleCheckBox(indexValue: any, typeOfCollateral: string, $event: any) {
        this.checkBoxSelectedAll[typeOfCollateral] = {};
        if ($event.target.checked) {
            const collateralLength = this.collateralsDataToShowList[typeOfCollateral].length;
            for (let i = 0; i < collateralLength; i++) {
                this.checkBoxSelectedAll[typeOfCollateral][i] = true;
                this.checkedBgColorChange(collateralLength, indexValue, true);
            }
        } else {
            const collateralLength = this.collateralsDataToShowList[typeOfCollateral].length;
            for (let i = 0; i < collateralLength; i++) {
                this.checkBoxSelectedAll[typeOfCollateral][i] = false;
                this.checkedBgColorChange(collateralLength, indexValue, false);
            }
        }
    }

    checkedEvent(indexValue: any, event: any, collateralType: string, rowIndex?: any) {
        let count = 0;
        this.checkAllBox[collateralType] = false;
        const collateralLength = this.collateralsDataToShowList[collateralType].length;
        for (let i = 0; i < collateralLength - 1; i++) {
            if (this.checkBoxSelectedAll[collateralType][i] === true) {
                count = count + 1;
                if (count === collateralLength - 1) {
                    this.checkAllBox[collateralType] = true;
                }
            }
        }
        if (event.target.checked) {
            const action = {
                type: 'single',
                targetValue: true,
                rowIndex: rowIndex
            };
            this.checkedBgColorChange(collateralLength, indexValue, '', action);
        } else {
            const action = {
                type: 'single',
                targetValue: false,
                rowIndex: rowIndex
            };
            this.checkedBgColorChange(collateralLength, indexValue, '', action);
        }
    }

    checkedBgColorChange(collateralLength: any, indexValue: any, status: any, action?: any) {
        if (action) {
            const selectedGridValue = this._displayContent.nativeElement.querySelectorAll('.k-grid')[indexValue].querySelectorAll('tbody')[1];
            const colorCode = (action.targetValue) ? 'rgba(117, 203, 255, 0.24)' : 'white';
            this._displayContent.nativeElement.querySelectorAll('.k-grid')[indexValue].querySelectorAll('tbody tr')[action.rowIndex].style.background = colorCode;
            selectedGridValue.children[action.rowIndex].style.background = colorCode;
        } else {
            const colorCode = status ? 'rgba(117, 203, 255, 0.24)' : 'white';
            for (let i = 0; i < collateralLength; i++) {
                this._displayContent.nativeElement.querySelectorAll('.k-grid')[indexValue].querySelectorAll('tbody tr')[i].style.background = colorCode;
                const selectedGridValue = this._displayContent.nativeElement.querySelectorAll('.k-grid')[indexValue].querySelectorAll('tbody')[1];
                const children = selectedGridValue.children[i].style.background = colorCode;
            }
        }
    }

    changeBackGroundColor(collateralType, rowIndex, colIndex) {
        const selectedGridValue = this._displayContent.nativeElement.querySelectorAll('.k-grid')[colIndex];
        const SelectedRowValue = selectedGridValue.querySelectorAll('tbody')[1];
        this._displayContent.nativeElement.querySelectorAll('.k-grid')[colIndex].querySelectorAll('tbody tr')[rowIndex].style.background = '#eeeeee';
        this._displayContent.nativeElement.querySelectorAll('.k-grid')[colIndex].querySelectorAll('tbody tr')[rowIndex].style.pointerEvents = 'none';
        SelectedRowValue.children[rowIndex].style.background = '#eeeeee';
        SelectedRowValue.children[rowIndex].style.pointerEvents = 'none';
    }

    highlight(index, type, event, rowIndex) {
    }

    getData(i: any, data: any, event: any, rowIndex: number, collateralType: any) {
        /*TODO Click event when user clicks on checkbox - design and functionality not yet defined*/
    }

    initializeGridsWithBlankDataForMasterCollaterals() {
        this.keys.forEach(element => {
            this.masterCollateralList[element.type] = [];
        });
    }

    private getFilteredBeneficiaryAndOwnershipList(list: any, type?: string, typeOfTab?: string) {
        let usableList = [];
        const listToReturn = [];
        if (list !== undefined && list.length !== 0) {
            if (type === '__row_status') {
                usableList = list.filter(Data => Data.__row_status !== 'deleted');
                if (typeOfTab === 'beneficiary') {
                    for (let i = 0; i < usableList.length; i++) {
                        const beneficiary = {};
                        beneficiary['key'] = usableList[i].beneficiaryId;
                        beneficiary['value'] = usableList[i].beneficiaryName;

                        listToReturn.push(beneficiary);
                    }
                    return listToReturn;
                } else {
                    for (let i = 0; i < usableList.length; i++) {
                        listToReturn.push(usableList[i].name);
                    }
                    return listToReturn;
                }
            }
        } else {
            return listToReturn;
        }
    }

    getLinkage(beneficiary: any, linkages: any, selectedCollateral: any, collateralType: string, flag: string) {

        if (flag === 'EDIT') {
            this.collateralService.limitDataBeneficiary = linkages;
        } else {
            this.collateralService.limitDataBeneficiary = {};
        }

        const collateralIdFilter = {
            where: {collateralId: selectedCollateral.collateralId},
            include: this.COLLATERAL_CONFIG[collateralType].include
        };
        this.collateralsListService.getCollateralsList(collateralType,
            this.collateralsListService.configurationForCollaterals[collateralType].apiToHit, collateralIdFilter).subscribe(data => {
                if (data.length > 0) {
                    this.collateralService.collateral = JsonConvert.deserializeString(JSON.stringify(data[0]), Collateral);
                    let navigationExtras: NavigationExtras;
                    navigationExtras = {
                        queryParams: {
                            'gcinLabel': beneficiary.value,
                            'gcinValue': beneficiary.key,
                            'functionFlag': flag,
                            'source': 'CollateralList',
                            'gcin': this.gcinCpValue,
                            'label': this.gcinDesc
                        }
                    };
                    this.collateralService.selectedCollateralType = collateralType;
                    this.router.navigate(['./facilityLinkage'], navigationExtras);
                }
            },
            error => {

            });
    }

    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.showPopupDialog = showPopupDialog;
    }

}
