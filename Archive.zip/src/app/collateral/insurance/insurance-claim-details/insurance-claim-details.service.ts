import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import {Observable} from 'rxjs';
import {AppSettings} from './../../../common/config/appsettings';


@Injectable()
export class InsuranceClaimsDetailsService {

    constructor(private http: Http) {
    }

    public getInsuranceClaimStatus(): Observable<any> {

        const url = AppSettings.apiBaseUrl + AppSettings.apiToGetInsuranceClaimsStatus;
        return this.http.get(url)
            .map(this.extractData)
            .catch(error => error.message || error);
    }
    private extractData(res: Response) {
        const body = res.json();
        return body;
    }
}
