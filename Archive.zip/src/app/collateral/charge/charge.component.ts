import {AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ChargeService} from './charge.component.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ChargeDataModel} from './charge.model';
import {Observable} from 'rxjs/Rx';
import {CollateralService} from '../collateral.service';
import {CurrencyFormatPipe} from '../../shared/currency-pipe/currency-pipe';
import {ToastsComponent} from '../../shared/toasts/toasts.component';
import {ChargeAmt, ChargeDetailList} from '../model/collateral';
import {CollateralSummaryService} from '../collateral-summary/collateral-summary.service';
import {CommonUtil} from '../../common/utils/common.util';
@Component({
    selector: 'collateral-charge',
    templateUrl: './charge.component.html',
    styleUrls: ['./charge.component.scss']
})
export class ChargeComponent implements OnInit, AfterViewInit {

    addChargeDetailsDialogBox: boolean = false;
    public addChargeForm: FormGroup;
    divForNoData: boolean;
    sumOfChargeAmount: number = 0;
    submitted: boolean = false;

    @Input() showAddChargeBtn: boolean = true;

    @Input() showSummaryGrid: boolean = false;

    @Input() chargeForm: FormGroup;

    @Output() dataFromChargeComponent: EventEmitter<any> = new EventEmitter<string>();

    @Input() show: boolean = true;

    valueFromSelectedButton: string = 'No';
    private selectedBtn: string = 'value2';

    public saveData: boolean = true;
    public rowIndex: number;
    public chargeDialogTitleName: string = 'Add Charge Details';
    natureOfCharges: any;
    argToastMessageObject: any;
    private divForServiceError: boolean;
    chargeAmountValidate: boolean = false;
    natureOfChargeDivError: boolean = false;
    chargeRankDivError: boolean = false;
    maxChargeAmountReachedDivError: boolean = false;
    maxChargeAmount: number = 0.0;
    maxChargeAmountErrMsg = '';
    pipe: CurrencyFormatPipe = new CurrencyFormatPipe();
    toastsComponent: ToastsComponent = new ToastsComponent();
    chargeRankList: any;
    chargeRankResponse: any = [];
    natureOfChargeVal: string = '';
    chargeGridDataForHTML: any = [];
    operationForNatureOfCharge: boolean;
    natureOfDataToShow: any;
    public showYesNoPrompt: boolean = false;
    collateralCurrency: string;
    collateralValue: number = 0.0;
    selectedCollateralType: string;
    currencyNotAvailable: boolean;
    regAuthorityObj: any;
    regAuthorityDataForFilter: any;
    regAuthDivError: boolean = false;

    constructor(private _fb: FormBuilder, private chargeService: ChargeService, private collateralService: CollateralService, private cdr: ChangeDetectorRef, public collateralSummaryService: CollateralSummaryService) {

    }

    ngOnInit() {
        this.setUpChargeComponent();
    }

    /*Function to set up charge component*/
    setUpChargeComponent() {
        /*Get collateral object details for currency*/
        this.getGeneralDetails();
        this.getRegistrationAuthInfo();
        /*Getting Nature of charge data and Charge rank i.e. require for component setup*/
        this.getNatureOfChargesData();
        if (!this.chargeForm) {
            this.chargeForm = this._fb.group({
                chargeList: [[]]
            });
        }
        this.initiateAddChargeForm();
        this.getChargeRankData();

    }

    private initiateAddChargeForm() {
        this.addChargeForm = this._fb.group({
            natureOfCharge: ['', [<any>Validators.required, <any>Validators.required]],
            chargeRankToShow: ['', [<any>Validators.required, <any>Validators.required]],
            chargeRankToSubmit: ['', [<any>Validators.required, <any>Validators.required]],
            chargeAmount: ['', [<any>Validators.required, <any>Validators.required]],
            filingDate: [null, [<any>Validators.required, <any>Validators.required]],
            receiptDate: [null, [<any>Validators.required, <any>Validators.required]],
            registrationAuthInfo: [],
            currencyType: ['', [<any>Validators.required, <any>Validators.required]]
        });
        this.subscribeToFormChanges();
    }

    /*Function to manually call view Init for updating charge*/
    ngAfterViewInit() {
        this.cdr.detectChanges();
    }

    /*Function to check for form changes that will be reflected in apportion*/
    private subscribeToFormChanges() {
        this.chargeForm.valueChanges.subscribe(data => this.onChargeFormChanged(data));
    }

    /*Function to show Add Charge Dialog Box*/
    showAddChargeDialog() {
        this.setNatureOfChargeVal('ADD');
        this.saveData = true;
        this.submitted = false;
        this.chargeAmountValidate = false;
        this.chargeDialogTitleName = 'Add Charge Details';
        this.addChargeDetailsDialogBox = true;
        this.getChargeRankData();
        this.validationReset();
        if (this.chargeGridDataForHTML.length !== 0) {
            this.addChargeForm.controls['natureOfCharge'].setValue(this.natureOfChargeVal);
        }
    }

    /*Function to close Add Charge Dialog Box from dialog cross button and emit close event for cls-popup-component*/
    closeAddChargeDetailsDialogBox(addChargeDetailsDialogBox?: boolean) {
        this.addChargeDetailsDialogBox = false;
        this.addChargeForm.reset();
        this.validationReset();
    }

    /*Function to add Charge data*/
    addChargeData(data: any) {
        this.submitted = true;
        if (data['chargeAmount'] === null || data['chargeAmount'] === undefined || data['chargeAmount'] === '') {
            this.chargeAmountValidate = true;
            this.maxChargeAmountReachedDivError = false;
        }

        const isNatureOfChargeValid = this.validationCheckForNatureOfCharge(data['natureOfCharge']);
        const isChargeRankValid = this.validationCheckForChargeRank(data['chargeRankToShow']);
        if (!this.maxChargeAmountReachedDivError) {
            if (isNatureOfChargeValid && isChargeRankValid) {
                if (this.addChargeForm.valid) {
                    this.addChargeDetailsDialogBox = false;
                    if (this.chargeGridDataForHTML.length === 0) {
                        this.natureOfChargeVal = data['natureOfCharge'];
                        this.collateralService.getCollateral().LodgeChargeDetail.natureOfCharge = this.getNatureOfChargeVal(this.natureOfChargeVal, 'code');
                        this.addDataToChargeFormAndGrid(data);
                    } else {
                        this.addDataToChargeFormAndGrid(data);
                    }
                } else {
                    setTimeout(() => CommonUtil.recursiveFocus(), 300);
                }
            } else {
                setTimeout(() => CommonUtil.recursiveFocus(), 300);
            }
        } else {
            setTimeout(() => CommonUtil.recursiveFocus(), 300);
        }
    }

    private addDataToChargeFormAndGrid(data: any) {

        const chargeDetailList = new ChargeDetailList();
        chargeDetailList.chargePriority = data['chargeRankToSubmit'];
        chargeDetailList.externalCharge = (this.valueFromSelectedButton === 'Yes');
        chargeDetailList.filingDate = data['filingDate'];
        chargeDetailList.receiptDate = data['receiptDate'];
        const chargeAmtObj = new ChargeAmt();
        chargeAmtObj.value = CurrencyFormatPipe.transformAsNumberFromString(data['chargeAmount']);
        chargeAmtObj.ccy = data['currencyType'];
        chargeDetailList.chargeAmt = chargeAmtObj;
        chargeDetailList.registrationAuthorityInfo.registrationAuthority = this.getRegAuthValue(data['registrationAuthInfo'], 'get_code');
        data['registrationAuthInfo'] = this.checkForRegAuthValue(data['registrationAuthInfo']);
        const dataForAddCharge = {
            'chargeAmount': CurrencyFormatPipe.transformAsNumberFromString(data['chargeAmount']),
            'chargeRank': data['chargeRankToSubmit'],
            'externalCharge': this.valueFromSelectedButton,
            'filingDate': data['filingDate'],
            'natureOfCharge': this.natureOfChargeVal,
            'receiptDate': data['receiptDate'],
            'registrationAuthority': data['registrationAuthInfo'],
            'currencyType': data['currencyType']
        };
        this.chargeGridDataForHTML.push(dataForAddCharge);

        this.divForNoData = false;
        this.chargeForm.controls['chargeList'].setValue(this.chargeGridDataForHTML);
        this.collateralService.getCollateral().LodgeChargeDetail.chargeDetailList.push(chargeDetailList);
        this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
            'A new record of charge details has been successfully added.',
            '', '');
        this.processChargeAmtWithCurrency(this.chargeGridDataForHTML);
        // this.populateTotalChargeAmountValue();
        this.submitted = false;
        this.chargeAmountValidate = false;
        this.addChargeForm.reset();
        this.validationReset();
    }

    /*Function to emit event for toggle button and setting up the value to be saved*/
    eventFromToggleButton(valueFromSelectedButton: any) {
        this.valueFromSelectedButton = valueFromSelectedButton;
    }

    /*Function to call when edit icon is clicked from charge grid*/
    chargeEditFunc(item: any, index: number): void {
        this.setNatureOfChargeVal('EDIT');
        this.addChargeForm.reset();
        this.chargeDialogTitleName = 'Update Charge Details';
        this.rowIndex = index;
        this.saveData = false;
        this.addChargeDetailsDialogBox = true;
        this.valueFromSelectedButton = (item['externalCharge']);
        if (this.valueFromSelectedButton === 'Yes') {
            this.selectedBtn = 'value1';
        } else {
            this.selectedBtn = 'value2';
        }
        this.getChargeRankData();
        const dataForEditCharge = {
            'chargeAmount': item['chargeAmount'],
            'chargeRank': item['chargeRankToShow'],
            'externalCharge': item['externalCharge'],
            'filingDate': item['filingDate'],
            'natureOfCharge': item['natureOfCharge'],
            'receiptDate': item['receiptDate'],
            'registrationAuthInfo': item['registrationAuthority'],
            'currencyType': item['currencyType']
        };
        const currentChargeConvertedAmt = CurrencyFormatPipe.transformAsNumberFromString(item['chargeAmount']) * this.getRateForCurrency(this.collateralCurrency, item['currencyType']);
        // get Current row Charge Amount converted in to CCY currency
        this.maxChargeAmount = this.maxChargeAmount + currentChargeConvertedAmt;

        if (dataForEditCharge !== undefined) {
            this.addChargeForm = this._fb.group({
                natureOfCharge: [item['natureOfCharge'], [<any>Validators.required, <any>Validators.required]],
                chargeRankToShow: [this.chargeRankResponse[item['chargeRank']], [<any>Validators.required, <any>Validators.required]],
                chargeRankToSubmit: [item['chargeRank'], [<any>Validators.required, <any>Validators.required]],
                chargeAmount: [item['chargeAmount'], [<any>Validators.required, <any>Validators.required]],
                filingDate: [item['filingDate'], [<any>Validators.required, <any>Validators.required]],
                receiptDate: [item['receiptDate'], [<any>Validators.required, <any>Validators.required]],
                registrationAuthInfo: item['registrationAuthority'],
                currencyType: [item['currencyType'], [<any>Validators.required, <any>Validators.required]]
            });
            this.chargeAmountValidate = false;
            this.subscribeToFormChanges();
            this.ngAfterViewInit();
        }
    }

    /*Function when update button is clicked*/
    updateChargeData(data: ChargeDataModel) {
        this.ngAfterViewInit();
        if (data['chargeAmount'] === null || data['chargeAmount'] === undefined || data['chargeAmount'].toString() === '') {
            this.chargeAmountValidate = true;
            this.maxChargeAmountReachedDivError = false;
        }
        const isNatureOfChargeValid = this.validationCheckForNatureOfCharge(data['natureOfCharge']);
        const isChargeRankValid = this.validationCheckForChargeRank(data['chargeRankToShow']);

        if (!this.maxChargeAmountReachedDivError) {
            if (isNatureOfChargeValid && isChargeRankValid) {
                if (this.addChargeForm.valid) {
                    if (this.chargeGridDataForHTML.length === 1) {
                        this.natureOfChargeVal = data['natureOfCharge'];
                    }
                    this.addChargeDetailsDialogBox = false;
                    data['registrationAuthInfo'] = this.checkForRegAuthValue(data['registrationAuthInfo']);
                    const dataForUpdateCharge = {
                        'chargeAmount': CurrencyFormatPipe.transformAsNumberFromString(data['chargeAmount'].toString()),
                        'chargeRank': data['chargeRankToSubmit'],
                        'externalCharge': this.valueFromSelectedButton,
                        'filingDate': data['filingDate'],
                        'natureOfCharge': data['natureOfCharge'],
                        'receiptDate': data['receiptDate'],
                        'registrationAuthority': data['registrationAuthInfo'],
                        'currencyType': data['currencyType']
                    };
                    this.chargeGridDataForHTML[this.rowIndex] = dataForUpdateCharge;
                    this.updateGblChargeDetailList(data, this.rowIndex);
                    this.processChargeAmtWithCurrency(this.chargeGridDataForHTML);
                    // this.populateTotalChargeAmountValue();
                    this.emitChargeDataValueFromChargeComp();
                    this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
                        'A record of charge details has been successfully updated.',
                        '', '');
                    this.chargeForm.controls['chargeList'].setValue(this.chargeGridDataForHTML);
                    this.addChargeForm.reset();
                    this.validationReset();
                    this.collateralService.getCollateral().LodgeChargeDetail.natureOfCharge = this.getNatureOfChargeVal(this.natureOfChargeVal, 'code');
                } else {
                    setTimeout(() => CommonUtil.recursiveFocus(), 300);
                }
            } else {
                setTimeout(() => CommonUtil.recursiveFocus(), 300);
            }
        } else {
            setTimeout(() => CommonUtil.recursiveFocus(), 300);
        }
    }

    updateGblChargeDetailList(data: any, rowIndex: number) {
        const chargeDetailList = new ChargeDetailList();
        chargeDetailList.chargePriority = data['chargeRankToSubmit'];
        chargeDetailList.externalCharge = (this.valueFromSelectedButton === 'Yes');
        chargeDetailList.filingDate = data['filingDate'];
        chargeDetailList.receiptDate = data['receiptDate'];
        const chargeAmtObj = new ChargeAmt();
        chargeAmtObj.value = CurrencyFormatPipe.transformAsNumberFromString(data['chargeAmount'].toString());
        chargeAmtObj.ccy = data['currencyType'];
        chargeDetailList.chargeAmt = chargeAmtObj;
        chargeDetailList.registrationAuthorityInfo.registrationAuthority = this.getRegAuthValue(data['registrationAuthInfo'], 'get_code');
        this.collateralService.getCollateral().LodgeChargeDetail.chargeDetailList[rowIndex] = chargeDetailList;
    }

    /*Function to call when remove icon is clicked from charge grid*/
    removeClickedChargeData(itemIndex: number) {
        this.chargeGridDataForHTML.splice(itemIndex, 1);
        this.collateralService.getCollateral().LodgeChargeDetail.chargeDetailList.splice(itemIndex, 1);
        if (this.chargeGridDataForHTML.length === 0) {
            this.divForNoData = true;
        } else {
            this.divForNoData = false;
            this.processChargeAmtWithCurrency(this.chargeGridDataForHTML);
            // this.populateTotalChargeAmountValue();
        }
        this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
            'A record of charge details has been successfully deleted.',
            '', '');
        this.chargeForm.controls['chargeList'].setValue(this.chargeGridDataForHTML);
        if (this.chargeGridDataForHTML.length === 0) {
            this.collateralService.getCollateral().LodgeChargeDetail.natureOfCharge = '';
        }
    }

    /*Function to emit Total Charge Amount (if required)*/
    emitChargeDataValueFromChargeComp() {
        this.dataFromChargeComponent
            .emit({'chargedGridData': this.chargeGridDataForHTML, 'sumValue': this.sumOfChargeAmount});
    }

    /*Function to get Nature of Charges Data from Service*/
    private getNatureOfChargesData() {
        this.chargeService.getNatureOfCharges().subscribe(
            response => {
                this.divForServiceError = false;
                this.natureOfCharges = response;
                this.natureOfDataToShow = this.natureOfCharges.map(item => {
                    return item['description'];
                });
            },
            error => {
                this.divForServiceError = true;
                this.handleErrorResponse(error);
            },
            () => {
                this.divForServiceError = false;
                this.getRegistrationAuthInfo();
                this.checkForChargeData();
                this.getRateValues();
                this.divForNoData = (this.chargeGridDataForHTML.length === 0);
            }
        );
    }

    /*Function to get Charge Rank Data*/
    private getChargeRankData() {
        this.chargeService.getChargeRank().subscribe(
            response => {
                this.divForServiceError = false;
                this.chargeRankList = response;
                this.chargeRankResponse = this.formChargeRanksForGridDisplay(response);
            },
            error => {
                this.divForServiceError = true;
                this.handleErrorResponse(error);
            },
            () => {
                this.divForServiceError = false;
                this.checkForChargeData();
            }
        );
    }

    formChargeRanksForGridDisplay(response: any) {
        const chargeRanksArray = [];
        if (response) {
            response.forEach(item => chargeRanksArray.push(item.rankDesc));
        }
        return chargeRanksArray;
    }

    /*Function to validate charge amount (because using Currency Component)*/
    validateChargeAmount($event) {
        if ($event.amount) {
            this.chargeAmountValidate = false;
        } else {
            this.chargeAmountValidate = true;
            this.maxChargeAmountReachedDivError = false;
        }
    }

    /*Function to be called when Registration Authority Value is not set*/
    checkForRegAuthValue(data: string) {
        if (data === '' || data === null || data === 'undefined') {
            return '';
        } else {
            return data;
        }
    }

    /*Function to be called when there is a change in the Charge Form to be reflected in Apportion Tab*/
    onChargeFormChanged(data?: any) {
        let amt = 0;
        let arr: any[] = [];
        if (data && data.chargeList) {
            arr = data.chargeList;
        }
        arr.forEach(ch => {
            if (ch.externalCharge && ch.externalCharge.toString().toUpperCase() === 'YES') {
                amt += ch.chargeAmount;
            }
        });
        const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
        collateralObj.externalChargeAmt.value = amt;
        collateralObj.finalCollateralValue.value =
            collateralObj.collateralValue.value - collateralObj.externalChargeAmt.value;
    }

    /*Function on Nature of Charge value change and to validate for Nature of Charge Selected Value*/
    validationCheckForNatureOfCharge(data?: any) {
        let valid: boolean = false;
        const dataObj = this.natureOfCharges.find(item => item.description === data);

        if (((dataObj !== 'undefined') || (dataObj !== '')) && (dataObj !== undefined)) {
            this.natureOfChargeDivError = false;
            valid = true;
        } else {
            this.natureOfChargeDivError = true;
            valid = false;
        }
        return valid;
    }

    /*Function on Charge Rank value change and to validate for Charge Rank Selected Value*/
    validationCheckForChargeRank(data?: any) {
        let valid: boolean = false;
        const dataObj = this.chargeRankList.find(item => item.rankDesc === data);
        if (((dataObj !== null) || (dataObj !== '')) && (dataObj !== undefined)) {
            this.chargeRankDivError = false;
            valid = true;
            const valueToSubmit = dataObj.rank;
            this.addChargeForm.controls['chargeRankToSubmit'].setValue(valueToSubmit);
        } else {
            this.chargeRankDivError = true;
            valid = false;
        }
        return valid;
    }

    /*Function to Reset validations*/
    private validationReset() {
        this.natureOfChargeDivError = false;
        this.chargeRankDivError = false;
        this.maxChargeAmountReachedDivError = false;
    }

    /*Function to validate charge amount with Valuation Details*/
    validateChargeAmountWithValuationDetail(data?: any, caller?: any, rowIndex?: any) {
        if (this.valueFromSelectedButton === 'Yes') {
            const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
            let localConvertedChargeAmt = 0.00;
            localConvertedChargeAmt = CurrencyFormatPipe.transformAsNumberFromString(this.addChargeForm.get('chargeAmount').value) * this.getRateForCurrency(this.collateralCurrency, this.addChargeForm.get('currencyType').value);
            if (this.maxChargeAmount < localConvertedChargeAmt) {
                this.maxChargeAmountErrMsg = 'Charge amount should be less than or equal to calculated Collateral Value amount (' + this.pipe.transform(this.maxChargeAmount, 2, collateralObj.finalCollateralValue.ccy) + ') as External Charge is applied.';
                this.maxChargeAmountReachedDivError = true;
            } else {
                this.maxChargeAmountReachedDivError = false;
            }
        } else {
            this.maxChargeAmountReachedDivError = false;
        }
    }

    setNatureOfChargeVal(typeOfOperation: string) {
        if (typeOfOperation === 'EDIT' && this.chargeGridDataForHTML.length === 1) {
            this.operationForNatureOfCharge = false;
        } else {
            return this.operationForNatureOfCharge = (this.chargeGridDataForHTML.length !== 0);
        }
    }

    private checkForChargeData() {
        if (this.natureOfCharges && this.regAuthorityObj) {
            this.chargeGridDataForHTML = [];
            if (this.collateralService.getCollateral().LodgeChargeDetail && (this.collateralService.getCollateral().LodgeChargeDetail.chargeDetailList && this.collateralService.getCollateral().LodgeChargeDetail.chargeDetailList.length !== 0)) {
                for (let i = 0; i < this.collateralService.getCollateral().LodgeChargeDetail.chargeDetailList.length; i++) {
                    this.chargeGridDataForHTML.push(this.createJSONForHTMLGrid(this.collateralService.getCollateral().LodgeChargeDetail.chargeDetailList[i],
                        this.collateralService.getCollateral().LodgeChargeDetail.natureOfCharge));
                    this.divForNoData = !(this.chargeGridDataForHTML.length);
                }
                this.natureOfChargeVal = this.getNatureOfChargeVal(this.collateralService.getCollateral().LodgeChargeDetail.natureOfCharge, 'description');
            } else {
                this.chargeGridDataForHTML = [];
            }
        } else {
            this.divForNoData = true;
        }
    }

    private createJSONForHTMLGrid(_value: any, _natureOfCharge: string) {
        const tempChargeListObj = {
            'chargeRank': _value['chargePriority'],
            'externalCharge': (_value['externalCharge']) ? 'Yes' : 'No',
            'filingDate': _value['filingDate'],
            'receiptDate': _value['receiptDate'],
            'registrationAuthority': this.getRegAuthValue(_value['registrationAuthorityInfo']['registrationAuthority'], 'get_desc'),
            'chargeAmount': _value['chargeAmt']['value'],
            'currencyType': _value['chargeAmt']['ccy'],
            'natureOfCharge': this.getNatureOfChargeVal(_natureOfCharge, 'description')
        };
        return tempChargeListObj;
    }

    getNatureOfChargeVal(_val: any, _type: any) {
        if (_type === 'code') {
            return this.natureOfCharges.find(item => item.description === _val).code;
        } else {
            return this.natureOfCharges.find(item => item.code === _val).description;
        }

    }

    public filterNatureOfCharge(filter: any): void {
        if (this.natureOfCharges) {
            const tempArr = this.natureOfCharges.map(function (item) {
                return item['description'];
            });
            this.natureOfDataToShow = tempArr.filter((s) => s.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
        }
    }

    deleteChargeData(itemIndex: number) {
        this.showYesNoPrompt = true;
        this.rowIndex = itemIndex;
    }

    confirmationFromYesNo(dlgPayload: any[]) {
        this.showYesNoPrompt = false;
        if (dlgPayload[0] === 'yes') {
            this.removeClickedChargeData(this.rowIndex);
        }
    }

    getGeneralDetails() {
        const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
        const generalDetailObj = this.collateralService.getCollateral().generalDetail;
        this.collateralCurrency = generalDetailObj.currencyCode;
        this.collateralValue = collateralObj.collateralValue.value;
        this.selectedCollateralType = this.collateralService.selectedCollateralType;
    }

    getRateValues() {
        const indexOfRate = this.collateralSummaryService.rateConversionArray.findIndex(item => item['toCurrency'] === this.collateralCurrency);
        if (indexOfRate === undefined || (indexOfRate === -1)) {
            this.collateralSummaryService.getRateValues('', this.collateralCurrency).subscribe(response => {
                this.collateralSummaryService.rateConversionArray = this.collateralSummaryService.rateConversionArray.concat(response);
                const index = this.collateralSummaryService.rateConversionArray.findIndex(data => data.toCurrency === this.collateralCurrency);
                if (index !== undefined && (index !== -1)) {
                    this.currencyNotAvailable = false;
                } else {
                    this.currencyNotAvailable = true;
                }
                this.processChargeAmtWithCurrency(this.chargeGridDataForHTML, '');
            }, error => {
                this.processChargeAmtWithCurrency(this.chargeGridDataForHTML, '');
                this.currencyNotAvailable = true;
            });
        } else {
            this.processChargeAmtWithCurrency(this.chargeGridDataForHTML);
            this.currencyNotAvailable = false;
        }
    }

    getRateForCurrency(collateralCcy, amountCcy) {
        if (amountCcy === collateralCcy) {
            return 1;
        } else {
            if (this.collateralSummaryService.rateConversionArray.length > 0) {
                const indexOfRate = this.collateralSummaryService.rateConversionArray.findIndex(data => data.fromCurrency === amountCcy && data.toCurrency === collateralCcy);
                if (indexOfRate !== undefined && (indexOfRate !== -1)) {
                    return this.collateralSummaryService.rateConversionArray[indexOfRate]['rate'];
                } else {
                    return 0;
                }
            } else {
                return 0;
            }
        }
    }

    processChargeAmtWithCurrency(gridElement?: any, calling?: string, from?: any, to?: any) {
        let counter = 0;
        let chargeAmountCounter = 0;
        const gridDataObj = JSON.parse(JSON.stringify(gridElement));
        for (let i = 0; i < gridElement.length; i++) {
            if (gridDataObj[i].externalCharge === 'Yes') {
                const externalChargeRate = this.getRateForCurrency(this.collateralCurrency, gridElement[i].currencyType);
                gridDataObj[i].chargeAmount = gridDataObj[i].chargeAmount * externalChargeRate;
                chargeAmountCounter = chargeAmountCounter + CurrencyFormatPipe.transformAsNumberFromString(gridDataObj[i].chargeAmount);
                counter++;
            }
        }
        this.sumOfChargeAmount = chargeAmountCounter;
        this.calculateFinalCollateralValueFromCharge();
    }

    calculateFinalCollateralValueFromCharge() {
        const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
        collateralObj.externalChargeAmt.value = this.sumOfChargeAmount;
        collateralObj.externalChargeAmt.ccy = this.collateralCurrency;
        collateralObj.finalCollateralValue.value = collateralObj.collateralValue.value - collateralObj.externalChargeAmt.value;
        collateralObj.finalCollateralValue.ccy = this.collateralCurrency;
        this.maxChargeAmount = collateralObj.collateralValue.value - (collateralObj.externalChargeAmt.value);
        if (collateralObj.finalCollateralValue.value < 0.0) {
            this.collateralService.chargeCompErrors = [];
            this.collateralService.chargeCompErrors.push('Total External charge should not exceed the collateral value.');
        } else {
            this.collateralService.chargeCompErrors = [];
        }
    }
    handleErrorResponse(error: any) {
        /*Do whatever with the error on the basis of error code*/
        if (error.status === 500) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 400) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 409) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 404) {
            return Observable.throw(new Error(error.status));
        }
    }

    getRegistrationAuthInfo() {
        this.chargeService.getRegistrationAuthorityDetails().subscribe(
            response => {
                this.divForServiceError = false;
                this.regAuthorityObj = response;
                this.regAuthorityDataForFilter = this.regAuthorityObj.map(item => {
                    return item['description'];
                });
            },
            error => {
                this.divForServiceError = true;
                this.handleErrorResponse(error);
            },
            () => {
                this.divForServiceError = false;
                this.checkForChargeData();
            }
        );
    }

    getRegAuthValue(_value: any, caller?: string) {
        if (caller === 'get_code') {
            return (_value === '' || _value === null || _value === undefined) ? ''
                : this.regAuthorityObj.find(temp => temp.description === _value).code;
        } else {
            return (_value === '' || _value === null || _value === undefined) ? ''
                : this.regAuthorityObj.find(temp => temp.code === _value).description;
        }

    }

    filterChangeRegAuthority(filter: any): void {
        if (this.regAuthorityObj) {
            const tempArr = this.regAuthorityObj.map(function (item) {
                return item['description'];
            });
            this.regAuthorityDataForFilter = tempArr.filter((s) => s.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
        }
    }

    validationCheckForRegistrationAuth(data?: any) {
        let valid: boolean = false;
        const dataObj = this.regAuthorityObj.find(item => item.description === data);
        if (((dataObj !== 'undefined') || (dataObj !== '')) && (dataObj !== undefined)) {
            this.regAuthDivError = false;
            valid = true;
        } else {
            this.regAuthDivError = true;
            valid = false;
        }
        return valid;
    }
}
