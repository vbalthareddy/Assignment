package com.dbs.cap.cls.common.configuration;

import com.dbs.cap.cls.common.constants.ClsConstants;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.*;

@Component
@Slf4j
public class FeignRequestInterceptor implements RequestInterceptor {
    @Autowired
    private UAA3Configuration uaa3Configuration;

    @Override
    public void apply(RequestTemplate template) {
        try {
            Map<String, Collection<String>> headersMap = new HashMap<>();
            headersMap.put(ClsConstants.CONTENT_TYPE, Collections.singletonList(MediaType.APPLICATION_JSON_VALUE));
            headersMap.put(ClsConstants.X_REQUEST_ID, Collections.singletonList(UUID.randomUUID().toString()));
            headersMap.put(ClsConstants.USER_NAME, Collections.singletonList(ClsConstants.CLS_USER));
            headersMap.put(ClsConstants.EMAIL, Collections.singletonList(ClsConstants.CLS_USER_EMAIL));
            headersMap.put(ClsConstants.ROLES, Collections.singletonList(ClsConstants.ADMIN));
            headersMap.put(ClsConstants.CHANNEL_ID, Collections.singletonList(ClsConstants.CLS_SERVICE));
            headersMap.put(ClsConstants.TIMESTAMP, Collections.singletonList(
                    new SimpleDateFormat(ClsConstants.TIMESTAMP_FORMAT).format(new java.util.Date())));
            headersMap.put(ClsConstants.X_JWT_ASSERTION, Collections.singletonList(
                    uaa3Configuration.uaa2RestTemplate().getAccessToken().getValue()));
            template.headers(headersMap);
        } catch (Exception e) {
            log.error("Exception while calling EV Service", e);
        }
    }
}
