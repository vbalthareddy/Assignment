import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {Http, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {AppSettings} from './../../common/config/appsettings';

@Injectable()
export class InspectionService {
    public params: any;

    constructor(private http: Http) {

    }

    public getInspectionTypeService(): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const filter = {'fields': ['code', 'description'], 'order': 'description'};
        params.set('filter', JSON.stringify(filter));
        const urlToGetInspectionType = AppSettings.apiBaseUrl + AppSettings.apiToGetInspectionType;
        return this.http.get(urlToGetInspectionType, {search: params})
            .map(res => res.json())
            .catch(error => error.message || error);
    }

    public getInspectionFrequencyService(): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        const filter = {'order': 'freq'};
        params.set('filter', JSON.stringify(filter));
        const urlToGetInspectionFrequency = AppSettings.apiBaseUrl + AppSettings.apiToGetFrequency;
        return this.http.get(urlToGetInspectionFrequency, {search: params})
            .map(res => res.json())
            .catch(error => error.message || error);
    }

}
