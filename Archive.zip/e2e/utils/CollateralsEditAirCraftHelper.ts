import {E2eSpecHelper} from './E2eSpecHelper';

const collateralSpecSuite = require('./CollateralSpecHelper');
const summarySpecSuite = require('./SummarySpecHelper');
const valuationSpecSuite = require('./ValuationSpecHelper');
const documentSpecSuite = require('./DocumentSpecHelper');
const beneficiarySpecSuite = require('./BeneficiarySpecHelper');
const collateralDetailSpecSuite = require('./CollateralDetailSpecHelper');
const specificDetailSpecSuite = require('./SpecificDetailsSpecHelper');
const ownershipSpecSuite = require('./OwnershipSpecHelper');
const chargeSpecSuite = require('./ChargeSpecHelper');
const inspectionSpecSuite = require('./InspectionSpecHelper');
const insuranceSpecSuite = require('./InsuranceSpecHelper');

const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

exports.CreateCollateralAirCraftTestSuite = function () {
    describe('should edit collateral of aircraft type', () => {
        /*E2E for setting up add collateral Page*/
        const processCollateralPage = () => {
            collateralSpecSuite.CollateralTestSuite('Aircraft');
        };

        /*E2E for Specific Details Page*/
        const processSpecificDetailsPage = () => {
            specificDetailSpecSuite.SpecificDetailsTestSuiteForAircraftEditFlow();
        };

        /*E2E for Beneficiary Page*/
        const processBeneficiaryDetailsPage = () => {
            beneficiarySpecSuite.BeneficiaryTestForAircraftEditSuite();
        };

        /*E2E for Ownership Page*/
        const processOwnershipDetailsPage = () => {
            ownershipSpecSuite.OwnershipTestForAircraftEditSuite();
        };

        /*E2E for Charge Page*/
        const processChargePage = () => {
            chargeSpecSuite.ChargeTestSuiteForEditFlow();
        };

        /*E2E for Inspection Page*/
        const processInspectionPage = () => {
            inspectionSpecSuite.InspectionTestForAircraftEditSuite();
        };

        /*E2E for Insurance Page*/
        const processInsurancePage = () => {
            insuranceSpecSuite.InsuranceTestForAircraftEditSuite();
        };

        /*E2E for Document Page*/
        const processDocumentDetailsPage = () => {
            documentSpecSuite.DocumentTestForAircraftEditSuite();
        };

        /*E2E for Valuation Page*/
        const processValuationDetailsPage = () => {
            valuationSpecSuite.ValuationTestForAircraftEditSuite();
        };

        /*E2E for Summary Page*/
        const processSummaryPage = () => {
            summarySpecSuite.SummaryTestSuite('Aircraft');
        };

        describe('should set up add collateral page', () => {
            processCollateralPage();
        });

        describe('should verify specific-details page', () => {
            processSpecificDetailsPage();
        });

        describe('should verify beneficiary & linkage  page', () => {
            processBeneficiaryDetailsPage();
        });

        describe('should verify ownership page', () => {
            processOwnershipDetailsPage();
        });

        describe('should verify charge page', () => {
            processChargePage();
        });

        describe('should verify inspection page', () => {
            processInspectionPage();
        });

        describe('should verify insurance page', () => {
            processInsurancePage();
        });

        describe('should verify  document page', () => {
            processDocumentDetailsPage();
        });

        describe('should verify  valuation tab page', () => {
            processValuationDetailsPage();
        });

        describe('should verify data from summary page', () => {
            processSummaryPage();
        });

        it('should click on Submit button to submit aircraft type collateral', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.buttonClick('#final_submit_btn');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('#gblMsgId');
        });
    });
};

exports.InspectionTestForAircraftEditSuite = function () {

};
