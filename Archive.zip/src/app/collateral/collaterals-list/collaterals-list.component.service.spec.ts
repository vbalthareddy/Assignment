import {DEPOS_TYPE_COLLATERALS, GUARN_TYPE_COLLATERALS} from './collaterals-list.data';
import {Observable} from 'rxjs/Rx';
import {CollateralsListService} from './collaterals-list.component.service';
import {AppSettings} from './../../common/config/appsettings';
import {MockCollateralData} from '../collateral-summary/collateral-summary-mock-data';
import {MockBackend, MockConnection} from '@angular/http/testing';
import {BaseRequestOptions, Http, HttpModule, Response, ResponseOptions} from '@angular/http';
import {fakeAsync, inject, TestBed} from '@angular/core/testing';
import {AppConfigData} from './../../common/config/app-config.data';
import {Collateral} from '../model/collateral';
class MockCollateralsListService {

    getRateValues(from: string, to: string) {
        if (from === '' && to === '') {
            return Observable.throw({status: 404});
        } else {
            const data = [{'rate': 1}];
            return Observable.of(data);
        }
    }

    getStoredCurrencyRate(argFrom: string, argTo: string) {
        if (argFrom === '' && argTo === '') {
            return Observable.throw({status: 404});

        } else {
            const tempRate = [{'rate': 1}];
            return Observable.of(tempRate);
        }
    }

    getCurrency() {
        const data = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        return Observable.of(data);
    }

    getCollateralsInfo(collateralType: string, collateralId?: string): Observable<any> {
        switch (collateralType) {
            case 'GUARN':
                return Observable.of(GUARN_TYPE_COLLATERALS);
            case 'DEPOS':
                return Observable.throw(DEPOS_TYPE_COLLATERALS);
            default:
                return Observable.throw('Invalid Collateral Type');
        }
    }

    withdrawCollateral(collateralID: string, reasonCode: string, collateralType: string) {
        // return Observable.of('success');
    }

    getCollateralTypes() {
        // return Observable.of(COLLATERAL_CODES_TYPES_DATA);
    }

    getConfigurationsForCollaterals() {
        // return Observable.of(MOCK_COLLATERAL_CONFIG);
    }

    getCollateralsList() {
        // return Observable.of(GUARN_TYPE_COLLATERALS);
    }
}

describe('Collaterals List Service Test Cases', () => {
    let collateralsListService: CollateralsListService = null;
    const ratesUrl = AppConfigData.apiBaseUrl + 'fakeRatesURL';
    const currencyUrl = AppConfigData.apiBaseUrl + 'fakeCurrecyRatesURL';
    let mockBackend: MockBackend = null;
    const data = MockCollateralData;
    const currencyDropdownList = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
    const mockRateValues = [{rate: 10}, {rate: 17}, {rate: 18}];
    const currencyRateValue = AppConfigData.apiBaseUrl + 'rate';
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                {provide: CollateralsListService, useClass: MockCollateralsListService},
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                CollateralsListService
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([CollateralsListService, MockBackend], (service: CollateralsListService, backend: MockBackend) => {
            collateralsListService = service;
            mockBackend = backend;
        })
    );

    it('should Create Collaterals List service ', inject([CollateralsListService], (service: CollateralsListService) => {
        expect(service).toBeTruthy();
    }));

    it('should get response for currency list ', fakeAsync(() => {
        const dataValues = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
        const mockResponseBody = dataValues;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralsListService.getCurrency().subscribe((response: Response) => {
            expect(response).toEqual(dataValues);
        });
    }));

    it('should throw error when getCurrency function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        collateralsListService.getCurrency()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

    it('should get response for Rate Values', fakeAsync(() => {
        const dataValue = [{'rate': 10}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralsListService.getRateValues('', '').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
    }));

    it('should throw error when getRateValues function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        collateralsListService.getRateValues('', '')
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

    it('should get response for getCollateralsByCounterPartyGCID', fakeAsync(() => {
        const dataValue = [{'rate': 10}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralsListService.getCollateralsByCounterPartyGCID('CPI23').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
    }));

    it('should throw error when getCollateralsByCounterPartyGCID function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        collateralsListService.getCollateralsByCounterPartyGCID('CPI23')
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

    it('should get response for getCollateralsInfo', fakeAsync(() => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralsListService.getCollateralsInfo('GUARN', 'COL1ID').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
        collateralsListService.getCollateralsInfo('DEPOS').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
    }));

    it('should throw error when getCollateralsInfo function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        collateralsListService.getCollateralsInfo('GUARN', 'COL1ID')
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

    it('should get response for getCollateralTypes', fakeAsync(() => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralsListService.getCollateralTypes('xyz').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
    }));

    it('should throw error when getCollateralTypes function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        collateralsListService.getCollateralTypes('xyz')
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

    it('should get response for getCollateralsList', fakeAsync(() => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralsListService.getCollateralsList('', '', 'xyz').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
    }));

    it('should throw error when getCollateralsList function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        collateralsListService.getCollateralsList('', '', 'xyz')
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

    it('should get response for getConfigurationsForCollaterals', fakeAsync(() => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });
        collateralsListService.getConfigurationsForCollaterals().subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
    }));

    it('should throw error when getConfigurationsForCollaterals function throw exception', (done) => {
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        collateralsListService.getConfigurationsForCollaterals()
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });

    it('should test error function', () => {
        const error = {
            status: 500
        };
        expect(collateralsListService.errorReturn(error)).toEqual(Observable.throw(new Error('500')));
        error['status'] = 404;
        expect(collateralsListService.errorReturn(error)).toEqual(Observable.throw(new Error('404')));
        error['status'] = 400;
        expect(collateralsListService.errorReturn(error)).toEqual(Observable.throw(new Error('400')));
        error['status'] = 409;
        expect(collateralsListService.errorReturn(error)).toEqual(Observable.throw(new Error('409')));

    });

    it('should withdraw collateral of any type', () => {
        const dataValue = [{}];
        const mockResponseBody = dataValue;
        mockBackend.connections.subscribe((connection: MockConnection) => {
            const response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
            connection.mockRespond(new Response(response));
        });

        const collateral: Collateral = new Collateral;
        collateralsListService.withdrawCollateral(collateral, '', 'GUARN').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
        collateralsListService.withdrawCollateral(collateral, '', 'DEPOS').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
        collateralsListService.withdrawCollateral(collateral, '', 'AIRCF').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
        collateralsListService.withdrawCollateral(collateral, '', 'VEHIC').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
        collateralsListService.withdrawCollateral(collateral, '', 'BOATS').subscribe((response: Response) => {
            expect(response).toEqual(dataValue);
        });
    });

    it('should throw error when getConfigurationsForCollaterals function throw exception', (done) => {
        const collateral: Collateral = new Collateral;
        mockBackend.connections.subscribe(
            (connection: MockConnection) => {
                connection.mockError(new Error('r'));
            });

        collateralsListService.withdrawCollateral(collateral, '', 'GUARN')
            .subscribe((error) => {
                expect(error).toEqual('r');
                done();
            });
    });
});
