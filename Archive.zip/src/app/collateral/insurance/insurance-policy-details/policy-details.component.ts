import {PlatformLocation} from '@angular/common';
import {DraftRecordService} from '../../../draftrecord/draft-record.service';
import {ChangeDetectorRef, Component, HostListener, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {CollateralService} from '../../collateral.service';
import {ErrorResponse} from '../../../shared';
import {ActivatedRoute, NavigationExtras, Params, Router} from '@angular/router';
import {PolicyAmt, PremiumAmt} from '../../model/collateral';
import * as _ from 'underscore';
import {AppSettings} from '../../../common/config/appsettings';
import {CollateralSummaryService} from '../../collateral-summary/collateral-summary.service';
import {isNullOrUndefined} from 'util';
import {CurrencyFormatPipe} from '../../../shared/currency-pipe/currency-pipe';
import {Observable} from 'rxjs/Observable';

@Component({
    moduleId: (module.id.toString()),
    selector: 'policy-details',
    templateUrl: './policy-details.html',
    styleUrls: ['./policy-details.scss']
})
export class PolicyDetailsComponent implements OnInit {
    backBtnPress: boolean;
    popUpShow: boolean = false;
    showPopupDialog: boolean = false;
    titleDialogBox: string = 'Leave Form';
    actionTypeDialogBox: string = 'leaveForm';

    errorResponse: ErrorResponse = null;
    policyHolderNameValidate: boolean;
    collectionIDValidate: boolean;
    policyNumberValidate: boolean;
    ccyAmountValidate: boolean;
    riskEndDateValidate: boolean;
    premiumCollectionDateValidate: boolean;
    premiumAmountValidate: boolean;
    premiumPaidValidate: boolean;
    premiumCollectionValidate: boolean;
    premiumCollectionValidateRange: boolean;
    coverStartDateValidate: boolean;
    riskCoverEndValidate: boolean;
    riskCoverValidateRange: boolean;
    argToastMessageObject: any;
    cancellationDateValidate: boolean;
    baseData: Array<any> = [];
    valueFromSelectedButton: string = 'Waived';
    public selectedBtn: string = 'value2';
    private selectedMethod: string = 'value1';
    policyNumber: string = '';
    functionType: string = '';
    insuranceType: string = '';
    insurancePurchaser: string = '';
    insuredItems: Array<any> = [];
    frequency: Array<any> = [];
    paymentMethod: Array<any> = [];
    bankIdList: any[] = [];
    branchId: Array<any> = [];
    insuranceAction: Array<any> = [];
    typeOfCover: Array<any> = [];
    insuranceDetails: any = {};
    heading: string = '';
    gcinCpValue: string = '';
    gcinDesc: string = '';
    ctype: string = '';
    todaysDateValid: boolean = false;

    policyDetailsForm: FormGroup = new FormGroup({});

    formTouched = {
        'policyHolderName': false,
        'policyNumber': false,
        'policyAmount': false,
        'coverStartDate': false,
        'coverEndDate': false,
        'frequency': false,
        'paymentMethod': false,
        'premiumPaidDate': false,
        'premiumCollectionDate': false,
        'cancellationDate': false,
        'collectionID': false,
        'bankID': false,
        'branchID': false,
        'insuranceAction': false,
        'coverType': false,
        'itemsInsured': false,
        'method': false

    };

    constructor(private collateralService: CollateralService, private _changeDetectionRef: ChangeDetectorRef, private router: Router, private route: ActivatedRoute, private collateralSummaryService: CollateralSummaryService, private draftRecordService: DraftRecordService, location: PlatformLocation) {
        this.policyHolderNameValidate = false;
        this.collectionIDValidate = false;
        this.policyNumberValidate = false;
        this.ccyAmountValidate = false;
        this.riskEndDateValidate = false;
        this.premiumCollectionDateValidate = false;
        this.premiumPaidValidate = false;
        this.premiumCollectionValidate = false;
        this.premiumCollectionValidateRange = false;
        this.premiumAmountValidate = false;
        this.cancellationDateValidate = false;
        this.coverStartDateValidate = false;
        this.riskCoverEndValidate = false;
        this.riskCoverValidateRange = false;
        this.getParameterisedData();
        this.collateralService.checkPopupDialogBox = false;
        location.onPopState(() => {
            this.backBtnPress = true;
            location.pushState('', '', '');
        });

    }

    private getParameterisedData() {
        this.route.queryParams.subscribe((params: Params) => {
            this.policyNumber = params['policyNo'];
            this.functionType = params['functionFlag'];
            this.gcinCpValue = params['gcin'];
            this.gcinDesc = params['label'];
            this.ctype = params['ctype'];
        });
    }

    ngOnInit() {
        this.setHeading();
        this.addFormControls();
        this.clearControls();
        this.initItemsInsured();
        this.initBankId();
        this.initFrequency();
        this.initBranchId();
        this.initInsuranceAction();
        this.initTypeOfCover();
        this.setBasicDetails();
        this.initPaymentMethod();
        this.setPolicyDetails();
    }

    @HostListener('window:onbeforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        if (this.popUpShow) {
            return this.popUpShow;
        } else {
            if (this.backBtnPress) {
                this.titleDialogBox = 'Warning';
                this.actionTypeDialogBox = 'warning';
                this.backBtnPress = false;
            } else {
                this.titleDialogBox = 'Leave Form';
                this.actionTypeDialogBox = 'leaveForm';
            }
            this.showPopupDialog = true;
            return this.popUpShow;
        }
    }

    setHeading() {
        if (this.functionType === 'ADD') {
            this.heading = 'Add Policy Details';
        }
        if (this.functionType === 'EDIT') {
            this.heading = 'Edit Policy Details';
        }
    }

    setPolicyDetails() {
        if (this.functionType === 'EDIT' && !isNullOrUndefined(this.insuranceDetails) && !isNullOrUndefined(this.insuranceDetails.policyDetails)) {
            const bankIdCode = this.insuranceDetails.policyDetails.bankId;
            const branchIdCode = this.insuranceDetails.policyDetails.branchId;
            const frequencyCode = this.insuranceDetails.policyDetails.frequency;
            const insuranceActionCode = this.insuranceDetails.policyDetails.insuranceAction;
            const itemInsuredCode = this.insuranceDetails.policyDetails.itemsInsured;
            const paymentMethodCode = this.insuranceDetails.policyDetails.paymentMethod;
            const coverTypeCode = this.insuranceDetails.policyDetails.typeOfCover;
            if ((this.bankIdList) && (this.bankIdList.length > 0)) {
                this.policyDetailsForm.get('bankID').setValue({
                    code: bankIdCode,
                    description: this.bankIdList.find(item => item.code === bankIdCode).description
                });
            }
            if ((this.branchId) && (this.branchId.length > 0)) {
                this.policyDetailsForm.get('branchID').setValue({
                    code: branchIdCode,
                    description: this.branchId.find(item => item.code === branchIdCode).description
                });
            }
            if ((this.insuranceAction) && (this.insuranceAction.length > 0)) {
                if (insuranceActionCode) {
                    this.policyDetailsForm.get('insuranceAction').setValue({
                        code: insuranceActionCode,
                        description: this.insuranceAction.find(item => item.code === insuranceActionCode).description
                    });
                }
            }
            if ((this.frequency) && (this.frequency.length > 0)) {
                this.policyDetailsForm.get('frequency').setValue({
                    code: frequencyCode,
                    description: this.frequency.find(item => item.code === frequencyCode).description
                });
            }
            if ((this.insuredItems) && (this.insuredItems.length > 0)) {
                this.policyDetailsForm.get('itemsInsured').setValue({
                    code: itemInsuredCode
                });
            }
            if ((this.paymentMethod) && (this.paymentMethod.length > 0)) {
                this.policyDetailsForm.get('paymentMethod').setValue({
                    code: paymentMethodCode,
                    description: this.paymentMethod.find(item => item.code === paymentMethodCode).description
                });
            }
            if ((this.typeOfCover) && (this.typeOfCover.length > 0)) {
                this.policyDetailsForm.get('coverType').setValue({
                    code: coverTypeCode,
                    description: this.typeOfCover.find(item => item.code === coverTypeCode).description
                });
            }
            this.policyDetailsForm.get('collectionID').setValue(this.insuranceDetails.policyDetails.accountId);
            this.policyDetailsForm.get('premiumCollectionDate').setValue(this.insuranceDetails.policyDetails.lastPremiumCollectionDate);
            this.policyDetailsForm.get('premiumPaidDate').setValue(this.insuranceDetails.policyDetails.lastPremiumPaidDate);
            this.policyDetailsForm.get('cancellationDate').setValue(this.insuranceDetails.policyDetails.cancellationDate);
            this.policyDetailsForm.get('policyHolderName').setValue(this.insuranceDetails.policyDetails.policyHolderName);
            this.policyDetailsForm.get('coverStartDate').setValue(this.insuranceDetails.policyDetails.riskCoverStartDate);
            this.policyDetailsForm.get('coverEndDate').setValue(this.insuranceDetails.policyDetails.riskCoverEndDate);
            if (this.insuranceDetails.policyDetails.premiumAmt) {
                this.policyDetailsForm.get('premiumCurrencyType').setValue(this.insuranceDetails.policyDetails.premiumAmt.ccy);
                this.policyDetailsForm.get('premiumAmount').setValue(this.insuranceDetails.policyDetails.premiumAmt.value);
            }
            if (this.insuranceDetails.policyDetails.policyAmt) {
                this.policyDetailsForm.get('policyCurrencyType').setValue(this.insuranceDetails.policyDetails.policyAmt.ccy);
                this.policyDetailsForm.get('policyAmount').setValue(this.insuranceDetails.policyDetails.policyAmt.value);
            }
            if (this.insuranceDetails.policyDetails.premiumStatus === 'W') {
                this.selectedBtn = 'value2';
            } else {
                this.selectedBtn = 'value1';
            }
        }

    }

    clearControls() {
        this.policyDetailsForm.clearValidators();
        this.policyDetailsForm.reset();
    }

    setBasicDetails() {
        let insuranceList;
        if (this.collateralService.getCollateral() && this.collateralService.getCollateral().insuranceDetails) {
            insuranceList = this.collateralService.getCollateral().insuranceDetails;
        }
        const policyNumber = this.policyNumber;

        this.insuranceDetails = _.find(insuranceList, function (o) {
            return o.policyDetails.policyNo === policyNumber;
        });
        if (this.insuranceDetails) {
            this.insuranceType = this.insuranceDetails.insuranceTypeNew;
            this.insurancePurchaser = this.insuranceDetails.insuranceCharge;
        }
        if (this.policyNumber) {
            this.policyDetailsForm.get('policyNumber').setValue(this.policyNumber);
        }
    }

    private initItemsInsured() {
        this.collateralService.getData(AppSettings.apiToGetItemsInsured).subscribe(data => {
            this.insuredItems = data;
        }, error => {
        }, () => {
            this.setPolicyDetails();
        });
    }

    private initBankId() {
        this.collateralService.getData(AppSettings.apiToGetBankId).subscribe(data => {
            this.bankIdList = data;
        }, error => {
        }, () => {
            this.setPolicyDetails();
        });
    }

    private initFrequency() {
        this.collateralService.getData(AppSettings.apiToGetInsuranceFrequencys).subscribe(data => {
            this.frequency = data;
        }, error => {
        }, () => {
            this.setPolicyDetails();
        });
    }

    private initBranchId() {
        this.collateralService.getData(AppSettings.apiToGetBranchId).subscribe(data => {
            this.branchId = data;
        }, error => {
        }, () => {
            this.setPolicyDetails();
        });
    }

    private initInsuranceAction() {
        this.collateralService.getData(AppSettings.apiToGetInsuranceAction).subscribe(data => {
            this.insuranceAction = data;
        }, error => {
        }, () => {
            this.setPolicyDetails();
        });
    }

    private initTypeOfCover() {
        this.collateralService.getData(AppSettings.apiToGetTypeCover).subscribe(data => {
            this.typeOfCover = data;
        }, error => {
        }, () => {
            this.setPolicyDetails();
        });
    }

    private initPaymentMethod() {
        this.collateralService.getData(AppSettings.apiToGetPaymentMethod).subscribe(data => {
            this.paymentMethod = data;
        }, error => {
        }, () => {
            this.setPolicyDetails();
        });
    }

    addFormControls() {
        const emptyControls = ['policyHolderName', 'policyNumber', 'policyAmount',
            'policyCurrencyType', 'premiumAmount', 'premiumCurrencyType',
            'collectionID'];
        for (const emptyControl of emptyControls) {
            this.addEmptyControls(emptyControl);
        }
        const nullControls = ['coverStartDate', 'coverEndDate',
            'premiumPaidDate', 'premiumCollectionDate'

        ];
        for (const nullControl of nullControls) {
            this.addNullControls(nullControl);
        }
        this.policyDetailsForm.addControl('bankID', new FormControl({
            code: '',
            description: ''
        }, [Validators.required]));
        this.policyDetailsForm.addControl('itemsInsured', new FormControl({code: ''}, [Validators.required]));
        this.policyDetailsForm.addControl('frequency', new FormControl({
            code: '',
            description: ''
        }, [Validators.required]));
        this.policyDetailsForm.addControl('cancellationDate', new FormControl(null));
        this.policyDetailsForm.addControl('branchID', new FormControl({
            code: '',
            description: ''
        }, [Validators.required]));
        this.policyDetailsForm.addControl('insuranceAction', new FormControl({
            code: '',
            description: ''
        }));
        this.policyDetailsForm.addControl('coverType', new FormControl({
            code: '',
            description: ''
        }, [Validators.required]));
        this.policyDetailsForm.addControl('paymentMethod', new FormControl({
            code: '',
            description: ''
        }, [Validators.required]));
    }

    addEmptyControls(control: string) {
        this.policyDetailsForm.addControl(control, new FormControl('', [Validators.required]));
    }

    private addNullControls(control: string) {
        this.policyDetailsForm.addControl(control, new FormControl(null, [Validators.required]));
    }

    onTouched(element) {
        if (!this.policyDetailsForm) {
            return;
        }
        this.formTouched[element] = true;
    }

    onFocusHasError(element: string) {
        if (this.collateralService.formSubmitClicked && this.policyDetailsForm.controls[element] && this.policyDetailsForm.controls[element]['invalid']) {
            return true;
        }
        return false;
    }

    validateAmount(ccy) {
        this.ccyAmountValidate = !(ccy.amount);
    }

    validatePolicyHolder(policyHolderName) {
        this.policyHolderNameValidate = !(policyHolderName.value);
    }

    validateCollectionID(collectionID) {
        this.collectionIDValidate = !(collectionID.value);
    }

    validatePremiumAmount(ccy) {
        this.premiumAmountValidate = !(ccy.amount);
    }

    validatePolicyNumber(policyNumber) {
        this.policyNumberValidate = !(policyNumber.value);
    }

    riskCoverDateValidator() {
        const coverEndDate = this.policyDetailsForm.get('coverEndDate').value;
        const coverStartDate = this.policyDetailsForm.controls['coverStartDate'].value;
        if (coverStartDate > coverEndDate) {
            this.riskEndDateValidate = true;
        } else {
            this.riskEndDateValidate = false;
        }
    }

    premiumPaidDateValidator() {
        const premiumPaidDate = this.policyDetailsForm.controls['premiumPaidDate'].value;
        const todaysDate = new Date(Date.now());

        if (!(premiumPaidDate instanceof Date)) {
            this.premiumPaidValidate = true;

        } else {
            this.premiumPaidValidate = false;
            if (premiumPaidDate >= todaysDate) {
                this.todaysDateValid = true;
            }
            else {
                this.todaysDateValid = false;
            }
        }
    }

    premiumCollectionDateValidator() {
        const premiumCollectionDate = this.policyDetailsForm.controls['premiumCollectionDate'].value;
        const premiumPaidDate = this.policyDetailsForm.controls['premiumPaidDate'].value;
        if ((premiumCollectionDate instanceof Date)) {
            this.premiumCollectionValidate = false;
            if (premiumCollectionDate < premiumPaidDate) {
                this.premiumCollectionValidateRange = true;
            } else {
                this.premiumCollectionValidateRange = false;
            }
        } else {
            this.premiumCollectionValidate = true;
            this.premiumCollectionValidateRange = false;
        }
    }

    riskCoverStartDateValidator() {
        const coverStartDate = this.policyDetailsForm.controls['coverStartDate'].value;
        if (!(coverStartDate instanceof Date)) {
            this.coverStartDateValidate = true;
        } else {
            this.coverStartDateValidate = false;
        }
        this.riskCoverEndDateValidator();
    }

    riskCoverEndDateValidator() {
        const coverStartDate = this.policyDetailsForm.controls['coverStartDate'].value;
        const coverEndDate = this.policyDetailsForm.controls['coverEndDate'].value;
        const todaysDate = new Date(Date.now());
        if ((coverEndDate instanceof Date)) {
            this.riskCoverEndValidate = false;
            if (coverEndDate <= coverStartDate || coverEndDate <= todaysDate) {
                this.riskCoverValidateRange = true;
            } else {
                this.riskCoverValidateRange = false;
            }
        } else {
            this.riskCoverEndValidate = true;
            this.riskCoverValidateRange = false;
        }
    }

    navigateBack() {
        this.popUpShow = true;
        this.canDeactivate();
        this.collateralSummaryService.collateralOperation = 'POLICY_DETAILS';
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'cid': this.collateralService.collateral.collateralId,
                'ctype': this.ctype,
                'gcin': this.gcinCpValue,
                'label': this.gcinDesc
            }
        };
        this.router.navigate(['./collateral'], navigationExtras);
    }

    submitPolicyDetails(flag?: any) {
        if (this.policyDetailsForm.valid && this.isPremiumDatesValid() && this.isCoverDatesValid()) {
            if ((this.policyDetailsForm.controls['insuranceAction'].value) && (this.policyDetailsForm.controls['insuranceAction'].value.description === 'Cancel Policy & Eff Under BK MSTR' || this.policyDetailsForm.controls['insuranceAction'].value.description === 'Cancel Policy') && (this.policyDetailsForm.controls['cancellationDate'].value === null || this.policyDetailsForm.controls['cancellationDate'].value === '' || this.policyDetailsForm.controls['cancellationDate'].value === undefined)) {
                this.cancellationDateValidate = true;
                setTimeout(() => this.recursiveFocus(), 300);
            } else {
                this.savePolicyDetails(flag);
                this.popUpShow = true;
                this.canDeactivate();
            }
        } else {
            this.validateAllFormFields(this.policyDetailsForm);
            setTimeout(() => this.recursiveFocus(), 300);
        }
    }

    isPremiumDatesValid() {
        const premiumCollectionDate = this.checkDateValue(this.policyDetailsForm.controls['premiumCollectionDate'].value);
        const premiumPaidDate = this.checkDateValue(this.policyDetailsForm.controls['premiumPaidDate'].value);
        if ((premiumCollectionDate instanceof Date) && (premiumPaidDate instanceof Date)) {
            if (premiumCollectionDate < premiumPaidDate) {
                return false;
            } else {
                return true;
            }
        }
    }

    isCoverDatesValid() {
        const coverStartDate = this.checkDateValue(this.policyDetailsForm.controls['coverStartDate'].value);
        const coverEndDate = this.checkDateValue(this.policyDetailsForm.controls['coverEndDate'].value);
        if ((coverStartDate instanceof Date) && (coverEndDate instanceof Date)) {
            if (coverEndDate < coverStartDate) {
                return false;
            } else {
                return true;
            }
        }
    }

    savePolicyDetails(flag?: any) {
        if (this.policyDetailsForm.get('bankID').value) {
            this.insuranceDetails.policyDetails.bankId = this.policyDetailsForm.get('bankID').value.code;
        }
        if (this.policyDetailsForm.get('branchID').value) {
            this.insuranceDetails.policyDetails.branchId = this.policyDetailsForm.get('branchID').value.code;
        }
        if (this.policyDetailsForm.get('frequency').value) {
            this.insuranceDetails.policyDetails.frequency = this.policyDetailsForm.get('frequency').value.code;
        }
        if (this.policyDetailsForm.get('insuranceAction').value) {
            this.insuranceDetails.policyDetails.insuranceAction = this.policyDetailsForm.get('insuranceAction').value.code;
        }
        if (this.policyDetailsForm.get('itemsInsured').value) {
            this.insuranceDetails.policyDetails.itemsInsured = this.policyDetailsForm.get('itemsInsured').value.code;
        }
        if (this.policyDetailsForm.get('collectionID')) {
            this.insuranceDetails.policyDetails.accountId = this.policyDetailsForm.get('collectionID').value;
        }
        if (this.policyDetailsForm.get('paymentMethod').value) {
            this.insuranceDetails.policyDetails.paymentMethod = this.policyDetailsForm.get('paymentMethod').value.code;
        }
        if (this.policyDetailsForm.get('cancellationDate').value) {
            this.insuranceDetails.policyDetails.cancellationDate = this.checkDateValue(this.policyDetailsForm.get('cancellationDate').value);
        }
        this.insuranceDetails.policyDetails.lastPremiumCollectionDate = this.checkDateValue(this.policyDetailsForm.get('premiumCollectionDate').value);
        this.insuranceDetails.policyDetails.lastPremiumPaidDate = this.checkDateValue(this.policyDetailsForm.get('premiumPaidDate').value);
        this.insuranceDetails.policyDetails.premiumAmt = new PremiumAmt();
        this.insuranceDetails.policyDetails.premiumAmt.ccy = this.policyDetailsForm.get('premiumCurrencyType').value;
        this.insuranceDetails.policyDetails.premiumAmt.value = CurrencyFormatPipe.transformAsNumberFromString(this.policyDetailsForm.get('premiumAmount').value);
        this.insuranceDetails.policyDetails.premiumStatus = this.valueFromSelectedButton === 'Waived' ? 'W' : 'P';
        this.insuranceDetails.policyDetails.policyHolderName = this.policyDetailsForm.get('policyHolderName').value;
        this.insuranceDetails.policyDetails.riskCoverEndDate = this.checkDateValue(this.policyDetailsForm.get('coverEndDate').value);
        this.insuranceDetails.policyDetails.riskCoverStartDate = this.checkDateValue(this.policyDetailsForm.get('coverStartDate').value);
        this.insuranceDetails.policyDetails.policyAmt = new PolicyAmt();
        this.insuranceDetails.policyDetails.policyAmt.ccy = this.policyDetailsForm.get('policyCurrencyType').value;
        this.insuranceDetails.policyDetails.policyAmt.value = CurrencyFormatPipe.transformAsNumberFromString(this.policyDetailsForm.get('policyAmount').value);
        this.insuranceDetails.policyDetails.typeOfCover = this.policyDetailsForm.get('coverType').value.code;
        this.collateralSummaryService.collateralOperation = 'POLICY_DETAILS';
        if (flag !== 'save') {
            this.navigateBack();
        }
    }

    validateAllFormFields(formGroup: FormGroup) {

        const premiumCollectionDate = this.policyDetailsForm.get('premiumCollectionDate').value;
        const premiumPaidDate = this.policyDetailsForm.get('premiumPaidDate').value;
        const coverStartDate = this.policyDetailsForm.get('coverStartDate').value;
        const coverEndDate = this.policyDetailsForm.get('coverEndDate').value;

        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {

                if (!control.valid) {
                    control.markAsTouched({onlySelf: true});
                    control.markAsDirty({onlySelf: true});
                }
            } else if (control instanceof FormGroup) {
                this.validateAllFormFields(control);
            }
            if (!formGroup.get('policyHolderName').valid) {
                this.policyHolderNameValidate = true;

            }
            if (!formGroup.get('policyNumber').valid) {
                this.policyNumberValidate = true;

            }
            if (!formGroup.get('collectionID').valid) {
                this.collectionIDValidate = true;

            }

            if (!formGroup.get('policyAmount').valid) {
                this.ccyAmountValidate = true;

            }
            if (!formGroup.get('premiumAmount').valid) {
                this.premiumAmountValidate = true;

            }
            if (!formGroup.get('premiumPaidDate').valid) {
                this.premiumPaidValidate = true;

            }

            if (!formGroup.get('premiumCollectionDate').valid) {
                this.premiumCollectionValidate = true;

            }

            if (!formGroup.get('coverStartDate').valid) {
                this.coverStartDateValidate = true;

            }

            if (!formGroup.get('coverEndDate').valid) {
                this.riskCoverEndValidate = true;

            }

            if (formGroup.get('premiumPaidDate').valid && formGroup.get('premiumCollectionDate').valid) {
                if (premiumCollectionDate < premiumPaidDate) {
                    this.premiumCollectionValidateRange = true;
                } else {
                    this.premiumCollectionValidateRange = false;
                }
            }

            if (formGroup.get('coverStartDate').valid && formGroup.get('coverEndDate').valid) {
                if (coverEndDate < coverStartDate) {
                    this.riskCoverValidateRange = true;
                } else {
                    this.riskCoverValidateRange = false;
                }
            }

        });
    }

    onDateChange(value: string): void {
        if (value) {
            this.cancellationDateValidate = false;
        }
    }

    onInsuranceActionSelect(selectedValue: any) {
        if (selectedValue) {
            if (selectedValue.description !== 'Cancel Policy & Eff Under BK MSTR' || selectedValue.description !== 'Cancel Policy') {
                this.cancellationDateValidate = false;
            }
        }
    }

    eventFromToggleButton(valueFromSelectedButton: any) {
        this.valueFromSelectedButton = valueFromSelectedButton;
    }

    // focus any child that is focusable
    private recursiveFocus(root?: HTMLElement) {
        const ele = <HTMLSelectElement>document.querySelectorAll('.has-error');
        if (ele[0]) {
            root = ele[0];
            const x = root.focus();
            if (!x) {
                let y = <HTMLSelectElement>root.getElementsByTagName('input');
                if (y.length > 0) {
                    y[0].focus();
                } else {
                    y = <HTMLSelectElement>root.getElementsByClassName('k-button');
                    if (y.length > 0) {
                        y[0].focus();
                    }
                }
            }
        }
    }

    closeEventFromPopupDialog(showPopupDialog: boolean) {
        this.showPopupDialog = showPopupDialog;
    }

    navigateToColl(value?: any) {
        this.showPopupDialog = false;
        this.popUpShow = true;
        let navigationExtras: NavigationExtras;
        navigationExtras = {
            queryParams: {
                'gcin': this.gcinCpValue,
                'label': this.gcinDesc
            }
        };
        if (value === 'save') {
            this.savePolicyDetails('save');
            this.draftRecordService.saveCollateralAsDraft();
        }
        this.canDeactivate();
        if (this.collateralSummaryService.breadcrumbvalue) {
            this.router.navigate(['/collateralSummary'], navigationExtras);
        } else {
            this.router.navigate(['./collateralList'], navigationExtras);
        }
    }

    checkDateValue(dateValue: any) {
        return typeof dateValue === 'string' ? new Date(dateValue) : dateValue;
    }
}
