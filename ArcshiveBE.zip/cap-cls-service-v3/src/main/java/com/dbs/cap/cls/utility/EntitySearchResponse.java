package com.dbs.cap.cls.utility;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class EntitySearchResponse {
    private EntitySearchHeader header;
    private String error;
    private SearchResult searchResult;

    @Getter
    @AllArgsConstructor
    @ToString
    public static class EntityResult {
        private String value;
        private String label;
    }

    @Getter
    @ToString
    @AllArgsConstructor
    public static class GroupResult {
        private String groupName;
        private String groupLabel;
        private int totalCount;
        @JsonProperty("topSearchResult")
        private List<EntityResult> entities;
    }

    @Getter
    @ToString
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SearchResult {
        @JsonProperty("searchResults")
        private List<GroupResult> groupResults;
    }
}
