package com.dbs.cap.cls.common.exception;

public class EntityLinkageException extends RuntimeException {
    public EntityLinkageException(String message) {
        super(message);
    }
}
