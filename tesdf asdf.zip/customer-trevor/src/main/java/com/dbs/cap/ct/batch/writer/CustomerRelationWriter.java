package com.dbs.cap.ct.batch.writer;

import com.dbs.cap.ct.batch.config.UAA3Configuration;
import com.dbs.cap.ct.batch.exception.RestTemplateErrorHandler;
import com.dbs.cap.ct.batch.model.RelationCustomer;
import com.dbs.cap.ct.batch.utils.TrevorConstants;
import lombok.extern.slf4j.Slf4j;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.batch.item.ItemWriter;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

@Slf4j
public class CustomerRelationWriter implements ItemWriter<RelationCustomer> {
    private static String clsServiceUrl;
    private RestTemplate restTemplate;
    private UAA3Configuration uaa3Configuration;

    public CustomerRelationWriter(RestTemplate restTemplate, String clsServiceUrl,
                                  UAA3Configuration uaa3Configuration) {
        this.restTemplate = restTemplate;
        this.restTemplate.setErrorHandler(new RestTemplateErrorHandler());
        this.clsServiceUrl = clsServiceUrl;
        this.uaa3Configuration = uaa3Configuration;
    }

    @Override
    public void write(List<? extends RelationCustomer> relatedCustomers) throws Exception {
        ObjectMapper ow = new ObjectMapper();
        MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<String, String>();
        headersMap.set("Authorization", OAuth2AccessToken.BEARER_TYPE + " "
                + uaa3Configuration.uaa3RestTemplate().getAccessToken().getValue());
        headersMap.set("Content-Type", "application/json");
        relatedCustomers.stream().forEach(rc -> {
            try {
                restTemplate.exchange(new URI(clsServiceUrl + TrevorConstants.CUSTOMER_RELATION_API),
                        HttpMethod.PUT, new HttpEntity<>(ow.writeValueAsString(rc), headersMap),
                        Object.class);
            } catch(RestClientException | URISyntaxException | IOException e) {
                log.error(e.getMessage());
            }
        });
    }
}
