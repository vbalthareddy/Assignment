import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {InspectionComponent} from './inspection.component';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {CommonUIModule} from '../../common/commonUI.module';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';

import {
    AutoCompleteModule,
    ComboBoxModule,
    DropDownListModule,
    DropDownsModule
} from '@progress/kendo-angular-dropdowns';
import {DateInputsModule} from '@progress/kendo-angular-dateinputs';
import {InspectionService} from './inspection.service';

@NgModule({
    imports: [CommonModule, BrowserModule, LoaderModule, ButtonsModule, CommonUIModule, ClsSharedCommonModule, PopupDialogModule, AutoCompleteModule, DateInputsModule,
        ComboBoxModule, DropDownListModule, DropDownsModule],
    declarations: [InspectionComponent],
    providers: [InspectionService],
    exports: [InspectionComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class InspectionModule {
    // public static forRoot(): ModuleWithProviders {
    // 	return {ngModule: InspectionModule, providers: []};
    // }
}
