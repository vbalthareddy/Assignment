// Required Parameters
// BRANCH_NAME


final APP_NAME = <REPLACE WITH YOUR APPLICATION NAME>
final GIT_REPO = "https://gitlab.dev.apps.cs.sgp.dbs.com/cap/${APP_NAME}.git"

node {

    sh 'curl https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/raw/master/jenkins.groovy -o jenkins.groovy'
    jenkins = load 'jenkins.groovy'

    stage 'Checkout'
    git branch: BRANCH_NAME, url: GIT_REPO
    
    jenkins.maven()
    jenkins.checkSonar("com.dbs.cap:$APP_NAME")
    jenkins.fortify('CST_CAP', APP_NAME, BRANCH_NAME)
    jenkins.uploadArtifact(APP_NAME, "${APP_NAME}.jar", "target/${APP_NAME}.jar")

    jenkins.tag()
    jenkins.runDeployJob(BRANCH_NAME: BRANCH_NAME)

}
