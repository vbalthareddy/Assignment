import {E2eSpecHelper} from './E2eSpecHelper';
import {$} from 'protractor';
const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
const document: any = {
    saveFormBtn: $('#save-form-btn'),
    addDetailsBtn: $('#add-details-btn'),
    closeDialogIcon: $('.k-dialog-close'),
    noRecordLink: $('#no-records-label a'),
    deleteIcon: $('#documentDeleteIcon-0'),
    documentIdOnTab: $('#document_tab'),
    documentBtnForPopDialog: $('.clsBtnSecondary'),
    documentLabel: $('#documentLable'),
    documentCodeId: $('#doccumentCodeId'),
    documentSearchId: $('#documentSearchId'),
    documentCodeErrorMessage: $('#documentCodeErrorMessage'),
    documentEditIcon: $('#documentEditIcon-0'),
    documentDropDownResult: $('.k-animation-container .k-list .k-item:first-child'),
    documentDropDownResult1: $('.k-animation-container .k-list .k-item:last-child'),
    documentCodeSearch: (searchTerm: string): any => $('#doccumentCodeId .k-searchbar .k-input').sendKeys(searchTerm),
    documentCustodianSearch: (searchTerm: string): any => $('#documentSearchId .k-searchbar .k-input').sendKeys(searchTerm),
    documentRemark: $('.commentTextArea__input'),
    documentRemarkInput: (documentRemarkInput: string): any => $('.commentTextArea__input').sendKeys(documentRemarkInput),
    documentDateIcon: $('#documentDate .input-group-addon'),
    documentDueDate: $('#documentDueDate .input-group-addon'),
    documentReceivedDate: $('#documentReceivedDate ..input-group-addon'),
    documentExpirationDate: $('#documentExpirationDate .input-group-addon'),
    dateToday: $('.btn.active '),
    dateWeekend: $('.btn.active'),
    yesOptionId: $('#yesOptionId .clsBtn'),
    noOptionId: $('#noOptionId .clsBtnCancel')
};

exports.DocumentTestSuite = function () {
    describe('Document Page', function () {
        it('should display Document Tab on click', function () {
            e2eSpecHelper.sleepBrowser(1000);
            document.documentIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#document_tab', 'Document');
            e2eSpecHelper.sleepBrowser(1000);
        });

        it('should check for no records found for document', function () {
            e2eSpecHelper.verifyTextContains('#no-records-header', 'No Document Details Found');
            e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding document details');
            document.noRecordLink.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.closeDialogIcon.click();

        });

        it('should not validate Document Details if fields are empty', function () {
            e2eSpecHelper.sleepBrowser(2000);
            document.documentBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
        });

        it('should validate and save details for document', function () {
            e2eSpecHelper.sleepBrowser(1000);
            document.documentCodeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.documentDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.dateToday.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.documentDueDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.dateToday.click();
            document.documentExpirationDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.dateWeekend.click();
            e2eSpecHelper.sleepBrowser(1000);
            document.documentCodeId.click();
            document.documentCodeSearch('d');
            document.documentDropDownResult.click();
            e2eSpecHelper.sleepBrowser(1000);
            document.documentCustodianSearch('s');
            document.documentDropDownResult.click();
            document.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.k-grid');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully Added.');
        });

        it('should show error if invalid entries are given', function () {
            document.documentBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(1000);
            document.documentCodeSearch('aaaaa');
            document.documentCustodianSearch('aaaaa');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('.k-dialog-close');
            document.closeDialogIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should update document details', function () {
            document.documentEditIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.documentRemark.clear();
            document.documentRemarkInput('Test Remarks');
            document.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully Updated.');
            e2eSpecHelper.verifyPresence('.k-grid');

        });
        it('should not remove document details on click of delte button if selected option no', function () {
            e2eSpecHelper.verifyPresence('#documentDeleteIcon-0');
            document.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.noOptionId.click();
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should remove document details on click of delte button if selected option yes', function () {
            e2eSpecHelper.verifyPresence('#documentDeleteIcon-0');
            document.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.yesOptionId.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('#no-records-div');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully deleted.');
            e2eSpecHelper.sleepBrowser(2000);
        });

    });
};

exports.DocumentTestSuiteForEditFlow = function () {
    describe('Document Page for Edit Flow', function () {
        it('should display Document Tab on click', function () {
            e2eSpecHelper.sleepBrowser(1000);
            document.documentIdOnTab.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyTextContains('#document_tab', 'Document');
            e2eSpecHelper.sleepBrowser(1000);
        });
        it('should not validate Document Details if fields are empty', function () {
            e2eSpecHelper.sleepBrowser(2000);
            document.documentBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
        });

        it('should validate and save details for document', function () {
            e2eSpecHelper.sleepBrowser(1000);
            document.documentCodeId.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.documentDateIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.dateToday.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.documentDueDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.dateToday.click();
            document.documentExpirationDate.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.dateWeekend.click();
            e2eSpecHelper.sleepBrowser(1000);
            document.documentCodeSearch('d');
            document.documentDropDownResult.click();
            e2eSpecHelper.sleepBrowser(1000);
            document.documentCustodianSearch('s');
            document.documentDropDownResult.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully Added.');
        });

        it('should show error if invalid entries are given', function () {
            document.documentBtnForPopDialog.click();
            e2eSpecHelper.sleepBrowser(1000);
            document.documentCodeSearch('aaaaa');
            document.documentCustodianSearch('aaaaa');
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyPresence('.has-error');
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('.k-dialog-close');
            document.closeDialogIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should update document details', function () {
            document.documentEditIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.documentRemark.clear();
            document.documentRemarkInput('Test Remarks');
            document.saveFormBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully Updated.');
            e2eSpecHelper.verifyPresence('.k-grid');

        });
        it('should not remove document details on click of delte button if selected option no', function () {
            e2eSpecHelper.verifyPresence('#documentDeleteIcon-0');
            document.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(2000);
            document.noOptionId.click();
            e2eSpecHelper.sleepBrowser(2000);
        });

        it('should remove document details on click of delte button', function () {
            e2eSpecHelper.verifyPresence('#documentDeleteIcon-0');
            document.deleteIcon.click();
            e2eSpecHelper.sleepBrowser(1000);
            e2eSpecHelper.verifyPresence('#no-records-div');
            e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully deleted.');
            e2eSpecHelper.sleepBrowser(2000);
        });

    });
};

exports.DocumentTestForAircraftEditSuite = function () {

};
