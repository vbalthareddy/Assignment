package com.dbs.cap.cls.service;

import com.dbs.cap.cls.client.CustomerClient;
import com.dbs.cap.cls.common.exception.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Service
@Slf4j
public class CustomerService {
    private static final String CUSTOMER_FILTER = "{\"where\":{\"entityId\":\"gcin\"}}";
    private static final String ID = "id";
    private static final String VERSION = "_version";
    @Autowired
    private CustomerClient customerClient;

    public HashMap<String, Object> updateCustomer(HashMap<String, Object> customer) throws EntityNotFoundException {
        log.debug("Processing entity: {}" + customer.get("entityId"));
        List<HashMap<String, Object>> getCustomer = getCustomerDataByEntityId((String) customer.get("entityId"));
        if (CollectionUtils.isEmpty(getCustomer)) {
            return customerClient.createCustomer(customer);
        } else {
            customer.put(ID, getCustomer.get(0).get(ID));
            customer.put(VERSION, getCustomer.get(0).get(VERSION));
            return customerClient.updateCustomer(customer);
        }
    }

    private List<HashMap<String, Object>> getCustomerDataByEntityId(String entityId) {
        return customerClient.getCustomer(CUSTOMER_FILTER.replace("gcin", entityId));
    }

    public HashMap<String, Object> updateCustomerRelationship(HashMap<String, Object> customerRelationShip) {
        log.debug("Processing relationship: {}" + customerRelationShip.get("childCorpKey"));
        List<HashMap<String, Object>> getCustomer = getCustomerDataByEntityId(
                (String) customerRelationShip.get("childCorpKey"));
        if (CollectionUtils.isNotEmpty(getCustomer)) {
            getCustomer.get(0).remove("otherGroups");
            if (!StringUtils.isEmpty(customerRelationShip.get("linkages"))) {
                getCustomer.get(0).put("otherGroups",
                        new ArrayList<>(Arrays.asList(customerRelationShip.get("linkages").toString().split(","))));
            } else {
                getCustomer.get(0).put("otherGroups", null);
            }
            return customerClient.updateCustomer(getCustomer.get(0));
        } else {
            throw new EntityNotFoundException("This customer does not exist in CLS, hence skipping.");
        }
    }
}
