package com.dbs.cap.cls.service;

import com.dbs.cap.cls.common.configuration.CurrentUser;
import com.dbs.cap.cls.common.configuration.EndpointConfiguration;
import com.dbs.cap.cls.common.configuration.UAA3Configuration;
import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.common.exception.ApiNotFoundException;
import com.dbs.cap.cls.utility.Endpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.UUID;

@Service
@Slf4j
public class GatewayService {
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private UAA3Configuration uaa3Configuration;
    @Autowired
    private EndpointConfiguration endpointConfiguration;
    @Autowired
    private CurrentUser currentUser;

    public String execute(URI uri, HttpMethod method,
                          Object body, MultiValueMap<String, String> headers) {
        HttpEntity<?> httpEntity = new HttpEntity<>(body, getHeaders(headers));
        ResponseEntity<String> response =
                restTemplate.exchange(uri, method, httpEntity, String.class);
        return response.getBody();
    }

    public URI getServiceUri(RequestEntity<Object> request)
            throws ApiNotFoundException, UnsupportedEncodingException, URISyntaxException {
        log.debug("getServiceUri request URL -{}", request.getUrl());
        String path = request.getUrl().getPath();
        String query = request.getUrl().getQuery();
        Endpoint endpoint = endpointConfiguration.getList().stream()
                .filter(e -> e.getPath().equals(path))
                .findFirst()
                .orElseThrow(() -> new ApiNotFoundException(path));
        String url = endpoint.getUrl();
        UriComponentsBuilder builder;
        if (url.contains(ClsConstants.PATH_PARAM) && query.contains(ClsConstants.EQUAL_DELIMITER)) {
            builder = UriComponentsBuilder.fromUriString(
                    url.replace(ClsConstants.PATH_PARAM, query.substring(query.lastIndexOf(ClsConstants.EQUAL_DELIMITER) + 1)));
        } else {
            builder = UriComponentsBuilder.fromUriString(url);
            builder.query(query);
        }
        log.debug("getServiceUri Resolved URI -{}", builder.toUriString());
        return builder.build().toUri();
    }

    private MultiValueMap<String, String> getHeaders(MultiValueMap<String, String> headers) {
        MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
        if (!CollectionUtils.isEmpty(headers)) {
            headers.forEach((k, v) -> {
                if (!k.matches("(?i)host|(?i)connection|(?i)cache-control|" +
                        "(?i)user-agent|(?i)postman-token|(?i)accept|(?i)accept-encoding|(?i)accept-language")) {
                    headersMap.set(k, v.get(0));
                }
            });
        }
        String userName = ClsConstants.CLS_USER;
        try {
            userName = currentUser.getOnebankId();
        } catch (NullPointerException e) {
            log.error(e.getMessage(), e);
        }
        log.debug("User Name: {}", currentUser.getOnebankId());
        headersMap.set(ClsConstants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headersMap.set(ClsConstants.X_REQUEST_ID, UUID.randomUUID().toString());
        headersMap.set(ClsConstants.USER_NAME, userName);
        headersMap.set(ClsConstants.EMAIL, userName + "@dbs.com");
        headersMap.set(ClsConstants.ROLES, ClsConstants.ADMIN);
        headersMap.set(ClsConstants.CHANNEL_ID, ClsConstants.CLS_SERVICE);
        headersMap.set(ClsConstants.TIMESTAMP, new SimpleDateFormat(ClsConstants.TIMESTAMP_FORMAT)
                .format(new java.util.Date()));
        headersMap.set(ClsConstants.X_JWT_ASSERTION, uaa3Configuration.uaa2RestTemplate().getAccessToken().getValue());
        return headersMap;
    }
}