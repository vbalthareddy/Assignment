package com.dbs.cap.cls.common.test;

public interface SystemIntegrationTest {
}
