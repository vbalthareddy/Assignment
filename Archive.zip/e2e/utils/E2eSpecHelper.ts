import {$, browser, by, element, protractor} from 'protractor';

export class E2eSpecHelper {
    sideNav = element(by.css('div.sidenav'));
    homeLink = element(by.cssContainingText('span', 'Home'));
    hamburgerIcon = element(by.css('span.hamburgerIcon'));
    collateralLink = element(by.cssContainingText('span', 'Collateral'));
    refDataLink = element(by.cssContainingText('span', 'Reference Data'));
    path = require('path');

    dropDownSearchKeys(searchString: string, selector: string): any {
        return $(selector).sendKeys(searchString, protractor.Key.ENTER);
    }

    inputSearchKeys(searchString: string, selector: string): any {
        return $(selector).sendKeys(searchString);
    }

    verifyPresence(selector: string, expectation = true, errorMsg?: string) {
        expect($(selector).isPresent())
            .toBe(expectation, errorMsg || `Expected '${selector}' to${expectation ? '' : ' not'} be present`);
    }

    verifyContentOf(selector: string, content: string, failMessage = `Expected '${selector}' to have '${content}'`) {
        this.verifyPresence(selector);

        expect($(selector).getText())
            .toBe(content, failMessage);
    }

    verifyTextContains(selector: string, expectedContainedValue: string) {
        this.verifyPresence(selector);
        expect($(selector).getText())
            .toContain(expectedContainedValue, selector + ' did not match');
    }

    sleepBrowser(value: number) {
        browser.sleep(value);
    }

    enterValueByName(property: string, searchTerm: string) {
        element(by.css('[name=' + property + ']')).sendKeys(searchTerm);
    }

    buttonClick(selector: string) {
        return $(selector).click();
    }

    /*waitForAndClickButton(buttonSelector: string, buttonName: string) {
     return browser.wait(until.elementLocated(By.css(buttonSelector)), 5000, buttonName + ' button not found after 5 seconds').then(button => button.click());
     }*/

    scrollToTheTop() {
        browser.executeScriptWithDescription('window.scrollTo(0,0)', 'Scroll to the top!');
    }

    scrollToElement(selector: string) {
        browser.executeScript(`return ({
            scrollLeft: window.pageXOffset || document.documentElement.scrollLeft,
            scrollTop: window.pageYOffset || document.documentElement.scrollTop
        })`).then((windowBox: any) => {
            browser.executeScript(`
            return document.querySelector('${selector}').getBoundingClientRect();
        `).then((elementBox: any) => {
                browser.executeScriptWithDescription(`window.scrollTo(${elementBox.top + windowBox.scrollTop}, ${elementBox.left + windowBox.scrollLeft})`, 'Scroll to the top!');
            });
        });
    }

    scrollToTheBottom(scrollBottom: string) {
        const getWindowsScreenSize = 'window.scrollTo(0,' + scrollBottom + ')';
        browser.executeScriptWithDescription(getWindowsScreenSize, 'Scroll to the Bottom!');
    }

}