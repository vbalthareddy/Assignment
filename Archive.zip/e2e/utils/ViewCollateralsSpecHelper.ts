import {$, browser} from 'protractor';
import {E2eSpecHelper} from './E2eSpecHelper';

exports.ViewCollateralsTestSuite = function (collateralType: string) {
    const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

    const viewCollaterals: any = {
        collateralCurrencyFormatter: $('.currencyFormatter .k-select'),
        collateralCurrencyFormatterValueSelect: $('.k-animation-container .k-list .k-item:nth-child(39)'),
        collateralamountFormatter: $('.amountFormatter .k-select'),
        collateralamountFormatterValueSelect: $('.k-animation-container .k-list .k-item:nth-child(2)'),
        cashCollateralPanelID: '#DEPOS-collaterals-panel',
        guaranteeCollateralPanelID: '#GUARN-collaterals-panel',
        aircraftCollateralPanelID: '#AIRCF-collaterals-panel',
        otherIntangibleCollateralPanelID: '#OTHERS-collaterals-panel',
        spanLabel: 'span.panel-label',
        spanKArrowIcon: 'span.k-icon-arrow'
    };
    describe('View_Collaterals_Page', function () {
        browser.ignoreSynchronization = true;

        it('should verify view collaterals page', function () {
            e2eSpecHelper.sleepBrowser(4000);
            e2eSpecHelper.verifyTextContains('.view-collateral-text', 'View Collaterals');
            e2eSpecHelper.verifyPresence('#add_new_collateral_btn');
            e2eSpecHelper.verifyPresence('#next_btn');
            viewCollaterals.collateralCurrencyFormatter.click();
            e2eSpecHelper.sleepBrowser(2000);
            viewCollaterals.collateralCurrencyFormatterValueSelect.click();
            e2eSpecHelper.sleepBrowser(1000);
            viewCollaterals.collateralamountFormatter.click();
            e2eSpecHelper.sleepBrowser(2000);
            viewCollaterals.collateralamountFormatterValueSelect.click();
        });

        it('should show cash, guarantee and other tangible panels on view collaterals page', function () {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains(viewCollaterals.cashCollateralPanelID + ' ' + viewCollaterals.spanLabel, 'Cash');
            e2eSpecHelper.verifyTextContains(viewCollaterals.guaranteeCollateralPanelID + ' ' + viewCollaterals.spanLabel, 'Guarantee');
            e2eSpecHelper.verifyTextContains(viewCollaterals.aircraftCollateralPanelID + ' ' + viewCollaterals.spanLabel, 'Aircraft');
            e2eSpecHelper.verifyTextContains(viewCollaterals.otherIntangibleCollateralPanelID + ' ' + viewCollaterals.spanLabel, 'Other Intangible');
        });

        it('should open-close panels on view collaterals page', function () {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.buttonClick(viewCollaterals.cashCollateralPanelID + ' ' + viewCollaterals.spanKArrowIcon);
            e2eSpecHelper.buttonClick(viewCollaterals.guaranteeCollateralPanelID + ' ' + viewCollaterals.spanKArrowIcon);
            e2eSpecHelper.buttonClick(viewCollaterals.aircraftCollateralPanelID + ' ' + viewCollaterals.spanKArrowIcon);
            e2eSpecHelper.buttonClick(viewCollaterals.otherIntangibleCollateralPanelID + ' ' + viewCollaterals.spanKArrowIcon);
            browser.sleep(3000);
            e2eSpecHelper.buttonClick(viewCollaterals.cashCollateralPanelID + ' ' + viewCollaterals.spanKArrowIcon);
            e2eSpecHelper.buttonClick(viewCollaterals.guaranteeCollateralPanelID + ' ' + viewCollaterals.spanKArrowIcon);
            e2eSpecHelper.buttonClick(viewCollaterals.aircraftCollateralPanelID + ' ' + viewCollaterals.spanKArrowIcon);
            e2eSpecHelper.buttonClick(viewCollaterals.otherIntangibleCollateralPanelID + ' ' + viewCollaterals.spanKArrowIcon);
            e2eSpecHelper.scrollToTheTop();
            browser.sleep(1000);
        });
    });
};
