describe('should complete add,edit,delete journey for collateral of vehicle Type', () => {

    const createCollateralVehicleTestSuite = require('./utils/CollateralsCreateVehicleHelper');
    const editCollateralVehicleTestSuite = require('./utils/CollateralsEditVehicleHelper');
    const withdrawCollateralVehicleTestSuite = require('./utils/CollateralsWithdrawVehicleHelper');

    const processCreateCollateralVehicle = () => {
        createCollateralVehicleTestSuite.CreateCollateralVehicleTestSuite();
    };

    const processEditCollateralVehicle = () => {
        editCollateralVehicleTestSuite.EditCollateralVehicleTestSuite();
    };

    const processWithdrawCollateralVehicle = () => {
        withdrawCollateralVehicleTestSuite.WithdrawCollateralVehicleTestSuite();
    };

    describe('should create a collateral of Vehicle type', () => {
        processCreateCollateralVehicle();
    });

    describe('should edit already created collateral of Vehicle type', () => {
        processEditCollateralVehicle();
    });

    describe('should withdraw existing collateral of Vehicle type ', () => {
        processWithdrawCollateralVehicle();
    });

});
