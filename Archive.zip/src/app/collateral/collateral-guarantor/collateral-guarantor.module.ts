import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {AutoCompleteModule, ComboBoxModule} from '@progress/kendo-angular-dropdowns';
import {GridModule} from '@progress/kendo-angular-grid';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import {IntlModule} from '@progress/kendo-angular-intl';
import {PopupDialogModule} from '../../common/popup-dialog/popup-dialog.module';
import {CommonUIModule} from '../../common/commonUI.module';
import {CollateralGuarantorComponent} from './collateral-guarantor.component';
import {CollateralGuarantorService} from './collateral-guarantor.service';

@NgModule({
    imports: [
        CommonModule,
        BrowserModule, FormsModule, ReactiveFormsModule,
        ButtonsModule, BrowserAnimationsModule,
        LoaderModule, GridModule, ClsSharedCommonModule, IntlModule, AutoCompleteModule
        , PopupDialogModule, CommonUIModule, ComboBoxModule
    ],
    declarations: [CollateralGuarantorComponent],
    exports: [CollateralGuarantorComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers: [CollateralGuarantorService]
})
export class CollateralGuarantorModule {
}
