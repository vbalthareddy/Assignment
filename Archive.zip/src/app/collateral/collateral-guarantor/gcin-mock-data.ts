export const GcinData = [
    {
        'description': '16R2A GCIN4NF CN002 (GC0001045990)',
        'cifId': 'GC0001045990',
        'idType': 'COUNTERPARTY1',
        'typeDescription': 'COUNTERPARTY',
        'collateralOwnerShipPcnt': 12
    },
    {
        'description': '16R2A GCIN4NF CN004 (GC0001045991)',
        'cifId': 'GC0001045991',
        'idType': 'COUNTERPARTY2',
        'typeDescription': 'COUNTERPARTY',
        'collateralOwnerShipPcnt': 12
    },
    {
        'description': '16R2A GCIN4NF CN002 (GC0001045992)',
        'cifId': 'GC0001045992',
        'idType': 'COUNTERPARTY2',
        'typeDescription': 'COUNTERPARTY',
        'collateralOwnerShipPcnt': 12
    },
    {
        'description': '16R2A GCIN4NF CN004 (GC0001045994)',
        'cifId': 'GC0001045994',
        'idType': 'COUNTERPARTY4',
        'typeDescription': 'COUNTERPARTY',
        'collateralOwnerShipPcnt': 12
    }

];

export const GuarantorData = [
    {
        'guarantorId': 'GC0001045991',
        'guarantorDescription': '16R2A GCIN4NF CN004 (GC0001045991)',
        'guarantorType': 'COUNTERPARTY',
        'gurantorName': null,
        'guaranteePercentage': '12'
    },
    {
        'guarantorId': 'GC0001045992',
        'guarantorDescription': '16R2A GCIN4NF CN004 (GC0001045992)',
        'guarantorType': 'COUNTERPARTY',
        'gurantorName': null,
        'guaranteePercentage': '12'
    },
    {
        'guarantorId': 'GC0001045993',
        'guarantorDescription': '16R2A GCIN4NF CN004 (GC0001045993)',
        'guarantorType': 'COUNTERPARTY',
        'gurantorName': null,
        'guaranteePercentage': '12'
    }
];
