import {$, by, element, protractor} from 'protractor';
import {E2eSpecHelper} from './E2eSpecHelper';

exports.SpecificDetailsAirCraftCreateSubHirerTestSuite_BKP = function () {
    const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
    const subHirer: any = {
        subHirerDetailspanel: $('#sub-hirer-details-panel'),

        agreementNoID: $('#agreementNoId'),
        agreementNoIDValue: (arg: string): any => $('#agreementNoId input.cls-text').sendKeys(arg),

        agreementTypeDropDownId: $('#agreementTypeDropDownId'),
        agreementTypeDropDownValue: (searchTerm: string): any => $('#agreementTypeDropDownId .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

        hirerNameId: $('#hirerNameId'),
        hirerNameIdValue: (arg: string): any => $('#hirerNameId input.cls-text').sendKeys(arg),

        companyRegNoId: $('#companyRegNoId'),
        companyRegNoIdValue: (arg: string): any => $('#companyRegNoId input.cls-text').sendKeys(arg),

        addressId: $('#addressId'),
        addressIdValue: (arg: string): any => $('#addressId input.cls-text').sendKeys(arg),

        countryDropDownId: $('#countryDropDownId'),
        countryDropDownValue: (searchTerm: string): any => $('#countryDropDownId .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

        monthlyInstallmentInputId: $('#monthlyInstallmentInputId'),
        monthlyInstallmentInputValue: (monthlyInstallmentInputVal: string): any => $('#monthlyInstallmentInputId input.cls-text').sendKeys(monthlyInstallmentInputVal),

        amountFinancedInputId: $('#amountFinancedInputId'),
        amountFinancedInputValue: (amountFinancedInputVal: string): any => $('#amountFinancedInputId input.cls-text').sendKeys(amountFinancedInputVal),

        agreementTenorId: $('#agreementTenorId'),
        agreementTenorIdValue: (arg: string): any => $('#hirerNameId input.cls-text').sendKeys(arg),

        maturityDateId: $('#maturityDateId .input-group-addon'),
        currentDate: $('.btn.active'),

        subHirerRemarksId: $('#subHirerRemarksId'),
        subHirerRemarksIdValue: (arg: string): any => $('#subHirerRemarksId textarea.commentTextArea__input').sendKeys(arg),
        selectDropdownList: $('.k-animation-container .k-list .k-item:last-child'),
        subHirerSubmitBtn: $('#subHirerSubmitButton')

    };
    describe('SpecificDetails_Sub_Hirer_Page Create Flow', function () {
        it('should  navigate to Sub Hirer Page', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#sub-hirer-details-panel', 'Add Sub-Hirer Details');
        });

        it('should show validations for all Mandatory fields in Sub Hirer Page', () => {

            subHirer.subHirerSubmitBtn.click();
            e2eSpecHelper.sleepBrowser(2000);

            // make sure all alerts are shown and visible

            expect(element(by.id('alert_1')).isDisplayed()).toBeTruthy();
            expect(element(by.id('alert_2')).isDisplayed()).toBeTruthy();
            expect(element(by.id('alert_3')).isDisplayed()).toBeTruthy();
            expect(element(by.id('alert_4')).isDisplayed()).toBeTruthy();
            expect(element(by.id('alert_5')).isDisplayed()).toBeTruthy();
            expect(element(by.id('alert_6')).isDisplayed()).toBeTruthy();
            // expect(element(by.id('alert_7')).isDisplayed()).toBeTruthy();
            expect(element(by.id('alert_8')).isDisplayed()).toBeTruthy();
            expect(element(by.id('alert_9')).isDisplayed()).toBeTruthy();
            expect(element(by.id('alert_10')).isDisplayed()).toBeTruthy();
            // expect(element(by.id('alert_11')).isDisplayed()).toBeTruthy();

            expect(element(by.id('alert_1')).getText()).toContain('Please enter agreement number');
            expect(element(by.id('alert_2')).getText()).toContain('Please select a agreement type.');
            expect(element(by.id('alert_3')).getText()).toContain('Please enter sub-hirer name.');
            expect(element(by.id('alert_4')).getText()).toContain('Please enter company registration number.');
            expect(element(by.id('alert_5')).getText()).toContain('Please enter address.');
            expect(element(by.id('alert_6')).getText()).toContain('Please select a country.');
            // expect(element(by.id('alert_7')).getText()).toContain('Please enter agreement telephone Info.');
            expect(element(by.id('alert_8')).getText()).toContain('Please enter agreement monthly installment.');
            expect(element(by.id('alert_9')).getText()).toContain('Please enter agreement amount financed.');
            expect(element(by.id('alert_10')).getText()).toContain('Please enter tenor.');
            // expect(element(by.id('alert_11')).getText()).toContain('Please select agreement maturity date.');

        });

        it('should add sub Hirer data with valid values, submit successfully and navigate to main page ', function () {

            subHirer.agreementNoID.click();
            subHirer.agreementNoID.sendKeys('SH12345');

            subHirer.agreementTypeDropDownId.click();
            subHirer.agreementTypeDropDownValue('sub');
            e2eSpecHelper.sleepBrowser(1000);

            subHirer.hirerNameId.click();
            subHirer.hirerNameId.sendKeys('Hirer Name');

            subHirer.companyRegNoId.click();
            subHirer.companyRegNoId.sendKeys('Company Registration Name');

            subHirer.addressId.click();
            subHirer.addressId.sendKeys('Address string goes here ');

            subHirer.countryDropDownId.click();
            subHirer.countryDropDownValue('India');

            subHirer.monthlyInstallmentInputId.click();
            subHirer.monthlyInstallmentInputValue('12345');

            subHirer.amountFinancedInputId.click();
            subHirer.amountFinancedInputValue('54321');

            subHirer.agreementTenorId.click();
            subHirer.agreementTenorId.sendKeys('tenor 123456');

            subHirer.maturityDateId.click();
            e2eSpecHelper.sleepBrowser(2000);
            subHirer.currentDate.click();
            e2eSpecHelper.sleepBrowser(1000);

            subHirer.subHirerRemarksId.click();
            subHirer.subHirerRemarksIdValue('Sub Hirer remarks to go in here');

            // No vlaidations messages shown
            expect(element(by.id('alert_1')).isDisplayed()).toBeFalsy();
            expect(element(by.id('alert_2')).isDisplayed()).toBeFalsy();
            expect(element(by.id('alert_3')).isDisplayed()).toBeFalsy();
            expect(element(by.id('alert_4')).isDisplayed()).toBeFalsy();
            expect(element(by.id('alert_5')).isDisplayed()).toBeFalsy();
            expect(element(by.id('alert_6')).isDisplayed()).toBeFalsy();

            // expect(element(by.id('alert_7')).isDisplayed()).toBeFalsy();

            // expect(element(by.id('alert_8')).isDisplayed()).toBeFalsy();
            // expect(element(by.id('alert_9')).isDisplayed()).toBeFalsy();
            expect(element(by.id('alert_10')).isDisplayed()).toBeFalsy();
            expect(element(by.id('alert_11')).isDisplayed()).toBeFalsy();

            subHirer.subHirerSubmitBtn.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('.toast__msg', 'successfully added.');
            e2eSpecHelper.sleepBrowser(3000);
        });
    });

    // it('should navigate to Specifric Details  page on click of back button.', () => {
    //     e2eSpecHelper.waitForAndClickButton('#claimDetailsBackButton', 'Back');
    //     expect(e2eSpecHelper.verifyTextContains('#claim-details-panel', 'Add Claim Details')).toBeFalsy();
    // });

};

exports.SpecificDetailsAirCraftCreateSubHirerTestSuite = function () {    // SpecificDetailsAirCraftEditSubHirerTestSuite
    const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

    const subHirer: any = {
        subHirerDetailspanel: $('#sub-hirer-details-panel'),

        agreementNoID: $('#agreementNoId'),
        agreementNoIDValue: (arg: string): any => $('#agreementNoId input.cls-text').sendKeys(arg),

        agreementTypeDropDownId: $('#agreementTypeDropDownId'),
        agreementTypeDropDownValue: (searchTerm: string): any => $('#agreementTypeDropDownId .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

        hirerNameId: $('#hirerNameId'),
        hirerNameIdValue: (arg: string): any => $('#hirerNameId input.cls-text').sendKeys(arg),

        companyRegNoId: $('#companyRegNoId'),
        companyRegNoIdValue: (arg: string): any => $('#companyRegNoId input.cls-text').sendKeys(arg),

        addressId: $('#addressId'),
        addressIdValue: (arg: string): any => $('#addressId input.cls-text').sendKeys(arg),

        countryDropDownId: $('#countryDropDownId'),
        countryDropDownValue: (searchTerm: string): any => $('#countryDropDownId .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),

        monthlyInstallmentInputId: $('#monthlyInstallmentInputId'),
        monthlyInstallmentInputValue: (monthlyInstallmentInputVal: string): any => $('#monthlyInstallmentInputId input.cls-text').sendKeys(monthlyInstallmentInputVal),

        amountFinancedInputId: $('#amountFinancedInputId'),
        amountFinancedInputValue: (amountFinancedInputVal: string): any => $('#amountFinancedInputId input.cls-text').sendKeys(amountFinancedInputVal),

        agreementTenorId: $('#agreementTenorId'),
        agreementTenorIdValue: (arg: string): any => $('#hirerNameId input.cls-text').sendKeys(arg),

        maturityDateId: $('#maturityDateId .input-group-addon'),
        currentDate: $('.btn.active'),

        subHirerRemarksId: $('#subHirerRemarksId'),
        subHirerRemarksIdValue: (arg: string): any => $('#subHirerRemarksId textarea.commentTextArea__input').sendKeys(arg),
        selectDropdownList: $('.k-animation-container .k-list .k-item:last-child'),
        subHirerSubmitBtn: $('#subHirerSubmitButton'),
        viewMoreDetails: $('#viewMoreDetails')

    };

    describe('SpecificDetails_Sub_Hirer_Page_Edit', function () {

        xit('should  navigate to Sub Hirer Page Edit', () => {
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#sub-hirer-details-panel', 'Update Sub-Hirer Details');
            e2eSpecHelper.sleepBrowser(2000);
        });

        xit('should Vehicle more show onclick of show more details ', () => {
            e2eSpecHelper.sleepBrowser(2000);
            subHirer.viewMoreDetails.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#viewMoreDetails', 'Show Less');
            subHirer.viewMoreDetails.click();
            e2eSpecHelper.sleepBrowser(2000);
            e2eSpecHelper.verifyTextContains('#viewMoreDetails', 'View More');
        });

        it('should Clear Fields of  sub Hirer and repopulate  data with valid values and submit it ', () => {

            subHirer.agreementNoID.click();
            subHirer.agreementNoID.clear();
            e2eSpecHelper.sleepBrowser(1000);
            // expect(element(by.id('alert_1')).getText()).toContain('Please enter agreement number');
            subHirer.agreementNoID.sendKeys('SH67890 Edited');

            subHirer.agreementTypeDropDownId.selectedIndex = -1;
            e2eSpecHelper.sleepBrowser(1000);
            // expect(element(by.id('alert_2')).getText()).toContain('Please select a agreement type.');
            subHirer.agreementTypeDropDownValue('sub');

            subHirer.hirerNameId.click();
            subHirer.hirerNameId.clear();
            e2eSpecHelper.sleepBrowser(1000);
            // expect(element(by.id('alert_3')).getText()).toContain('Please enter sub-hirer name.');
            subHirer.hirerNameIdValue('Hirer Name Edited');

            // subHirer.companyRegNoId.click();
            // subHirer.companyRegNoId.clear();
            // e2eSpecHelper.sleepBrowser(1000);
            // expect(element(by.id('alert_4')).getText()).toContain('Please enter company registration number.');
            // subHirer.companyRegNoIdValue('Company Registration Name Edited');

            // subHirer.addressId.click();
            // subHirer.addressId.clear();
            // e2eSpecHelper.sleepBrowser(1000);
            // expect(element(by.id('alert_5')).getText()).toContain('Please enter address.');
            // subHirer.addressIdValue('Address string goes here Edited');

            // subHirer.countryDropDownId.click();
            // subHirer.countryDropDownId.clear();
            // e2eSpecHelper.sleepBrowser(1000);
            // expect(element(by.id('alert_6')).getText()).toContain('Please select a country.');
            // subHirer.countryDropDownValue('China');

            // subHirer.monthlyInstallmentInputId.click();
            // subHirer.monthlyInstallmentInputId.clear();
            // e2eSpecHelper.sleepBrowser(1000);
            // expect(element(by.id('alert_8')).getText()).toContain('Please enter agreement monthly installment.');
            // subHirer.monthlyInstallmentInputValue('67890');

            // subHirer.amountFinancedInputId.click();
            // subHirer.amountFinancedInputId.clear();
            // expect(element(by.id('alert_9')).getText()).toContain('Please enter agreement amount financed.');
            // subHirer.amountFinancedInputValue('12345');

            // subHirer.agreementTenorId.click();
            // subHirer.agreementTenorId.clear();
            // e2eSpecHelper.sleepBrowser(1000);
            //  expect(element(by.id('alert_10')).getText()).toContain('Please enter tenor.');
            // subHirer.agreementTenorIdValue('tenor 123456 Edited');

            // subHirer.maturityDateId.clear();
            // e2eSpecHelper.sleepBrowser(1000);
            // expect(element(by.id('alert_11')).getText()).toContain('Please select agreement maturity date.');
            // subHirer.maturityDateId.click();
            // e2eSpecHelper.sleepBrowser(1000);
            // subHirer.currentDate.click();

            // subHirer.subHirerRemarksId.click();
            // subHirer.agreementTenorIdValue('Sub Hirer remarks to go in here Edited');

            // // No vlaidations messages shown
            // expect(element(by.id('alert_1')).isDisplayed()).toBeFalsy();
            // expect(element(by.id('alert_2')).isDisplayed()).toBeFalsy();
            // expect(element(by.id('alert_3')).isDisplayed()).toBeFalsy();
            // expect(element(by.id('alert_4')).isDisplayed()).toBeFalsy();
            // expect(element(by.id('alert_5')).isDisplayed()).toBeFalsy();
            // expect(element(by.id('alert_6')).isDisplayed()).toBeFalsy();
            // // expect(element(by.id('alert_7')).isDisplayed()).toBeFalsy();
            // // expect(element(by.id('alert_8')).isDisplayed()).toBeFalsy();
            // // expect(element(by.id('alert_9')).isDisplayed()).toBeFalsy();
            // expect(element(by.id('alert_10')).isDisplayed()).toBeFalsy();
            // expect(element(by.id('alert_11')).isDisplayed()).toBeFalsy();

            // e2eSpecHelper.waitForAndClickButton('#subHirerSubmitButton', 'Save');
            // e2eSpecHelper.sleepBrowser(1000);
            // e2eSpecHelper.verifyTextContains('.toast__msg', 'successfully updated.');
            // e2eSpecHelper.sleepBrowser(3000);
        });
    });

};
