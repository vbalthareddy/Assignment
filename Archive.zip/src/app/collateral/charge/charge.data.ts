export const ChargeListResponse = [{
    'natureOfCharge': 'Dummy',
    'chargeRank': '1ST',
    'externalCharge': 'No',
    'chargeAmount': '200,000.08',
    'filingDate': '21 Apr 2017',
    'receiptDate': '20 Apr 2017',
    'registrationAuthority': '-'
}, {
    'natureOfCharge': 'Dummy',
    'chargeRank': '1DBS',
    'externalCharge': 'No',
    'chargeAmount': '40,000.01',
    'filingDate': '21 Apr 2017',
    'receiptDate': '20 Apr 2017',
    'registrationAuthority': '-'
}];

export const ChargeRankList = ['1DBS', '1ST', '2ND', '3RD', '4TH', '5TH', '6TH', '7TH', '8TH', '9TH'];

export const MOCK_NATURE_OF_CHARGES = [
    {
        'code': 'CHARGENAT1',
        'description': 'Nature of charge code1',
        'id': '59155ee950c8b30600c7949c',
        '_type': 'NatureOfCharge',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload',
        '_createdOn': '2017-05-12T07:06:17.255Z',
        '_modifiedOn': '2017-05-12T07:06:17.255Z',
        '_version': '003f258d-e68b-4882-b747-940a6a7bf893',
        '_isDeleted': false
    },
    {
        'code': 'CHARGENAT2',
        'description': 'Nature of charge code1',
        'id': '59155ee950c8b30600c7949d',
        '_type': 'NatureOfCharge',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload',
        '_createdOn': '2017-05-12T07:06:17.302Z',
        '_modifiedOn': '2017-05-12T07:06:17.302Z',
        '_version': '302fa2b8-e5fa-4a69-bd68-dafe47fa549c',
        '_isDeleted': false
    }
];

export const MOCK_REGISTRATION_AUTHOURITY = [
    {
        'code': 'ICAR',
        'description': 'International Council Of Aircraft Registration',
        'agencyName': 'DUMMY',
        'agencyNature': null,
        'agencySubType': null,
        'cifId': null,
        'regNo': null,
        'regValidUptoDate': null,
        'premCollAcctId': null,
        'bankId': null,
        'bankIdentifierCode': null,
        'branchId': null,
        'address': null,
        'id': '8c20877a-ee7d-49a5-b7b0-d80ab63b7287',
        '_type': 'RegistrationAuthority',
        '_createdBy': 'upload',
        '_modifiedBy': 'admin',
        '_createdOn': '2017-10-02T03:49:19.619Z',
        '_modifiedOn': '2017-10-02T03:49:24.110Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': '002a2bd6-1172-40f9-8437-932df2010d4f',
        '_version': '7f7666d2-fe94-41c1-8738-d0cf11131458',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'code': 'Registration1',
        'description': 'Registration authority agency details',
        'agencyName': 'REGIS',
        'agencyNature': null,
        'agencySubType': null,
        'cifId': null,
        'regNo': null,
        'regValidUptoDate': null,
        'premCollAcctId': null,
        'bankId': null,
        'bankIdentifierCode': null,
        'branchId': null,
        'address': null,
        'id': '6fc0c03b-a536-4367-9bfe-79635a2b2d7a',
        '_type': 'RegistrationAuthority',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload',
        '_createdOn': '2017-10-02T03:49:21.763Z',
        '_modifiedOn': '2017-10-02T03:49:21.763Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': 'afb343ab-0fd7-4530-956a-88fda2b10d7a',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'code': 'SG01',
        'description': 'ACRA',
        'agencyName': 'DUMMY',
        'agencyNature': null,
        'agencySubType': null,
        'cifId': null,
        'regNo': null,
        'regValidUptoDate': null,
        'premCollAcctId': null,
        'bankId': null,
        'bankIdentifierCode': null,
        'branchId': null,
        'address': null,
        'id': '725c7ec8-e26c-48d1-93e9-20376c691ab1',
        '_type': 'RegistrationAuthority',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'admin',
        '_createdOn': '2017-08-14T03:43:38.130Z',
        '_modifiedOn': '2017-10-02T03:49:24.109Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': 'e38fe472-b863-403c-85aa-586f98b73081',
        '_version': 'c95e28ad-dfde-44db-9e97-1b5fb27e46d1',
        '_requestId': null,
        '_newVersion': null
    }
];

export const ChargeRankJSON =
    [{'rank': 0, 'rankDesc': '1DBS'},
        {'rank': 1, 'rankDesc': '1ST'},
        {'rank': 2, 'rankDesc': '2ND'},
        {'rank': 3, 'rankDesc': '3RD'},
        {'rank': 4, 'rankDesc': '4TH'},
        {'rank': 5, 'rankDesc': '5TH'},
        {'rank': 6, 'rankDesc': '6TH'},
        {'rank': 7, 'rankDesc': '7TH'},
        {'rank': 8, 'rankDesc': '8TH'},
        {'rank': 9, 'rankDesc': '9TH'}];

export const MOCK_CHARGE_DETAILS_LIST = [{
    'externalCharge': false,
    'chargeInstrumentNo': '',
    'filingDate': new Date('2017-09-26T18:30:00.000Z'),
    'receiptDate': new Date('2017-09-29T18:30:00.000Z'),
    'mortgageName': '',
    'registrationAuthorityInfo': {
        'registrationAuthority': 'SG01',
        'registrationDate': null,
        'titleNo': '',
        'addressLine1': '',
        'addressLine2': '',
        'addressLine3': '',
        'city': '',
        'state': '',
        'country': '',
        'postalCode': '',
        'phoneNo': '',
        'emailAddress': '',
        'telexNo': '',
        'faxNo': '',
        'comments': '',
        'id': ''
    },
    'delete': false,
    'id': '',
    'chargePriority': 2,
    'chargeAmt': {
        'ccy': 'SGD',
        'id': '',
        '_type': '',
        '_createdBy': '',
        '_modifiedBy': '',
        '_createdOn': null,
        '_modifiedOn': null,
        '_isDeleted': false,
        '_oldVersion': '',
        '_version': '',
        '_requestId': '',
        '_newVersion': '',
        'value': 12345
    }
}];

export const MOCK_LODGE_CHARGE_DETAIL = {
    'natureOfCharge': 'CHARGENAT1',
    'chargeDetailList': MOCK_CHARGE_DETAILS_LIST,
    'id': ''
};

export const MOCK_CHARGE_DATA = {
    'natureOfCharge': 'Nature of charge code1',
    'chargeRankToShow': '1DBS',
    'chargeRankToSubmit': 0,
    'externalCharge': 'No',
    'chargeAmount': 200000.08,
    'filingDate': '21 Apr 2017',
    'receiptDate': '20 Apr 2017',
    'registrationAuthInfo': 'ACRA',
    'currencyType': 'SGD'
};

export const MOCK_COLLATERAL_VALUATION_DATA = {
    derivedValuationDetail: [
        {
            'collValueType': 'A',
            'collValue': {
                'value': 0,
                'ccy': 'SGD',
                'id': '',
                '_type': '',
                '_createdBy': '',
                '_modifiedBy': '',
                '_createdOn': null,
                '_modifiedOn': null,
                '_isDeleted': false,
                '_oldVersion': '',
                '_version': '',
                '_requestId': '',
                '_newVersion': ''
            },
            'derivedFrom': false,
            'id': ''
        }

    ],
    'collValueType': 'A',
    'collValue': {
        'value': 0,
        'ccy': 'SGD',
        'id': '',
        '_type': '',
        '_createdBy': '',
        '_modifiedBy': '',
        '_createdOn': null,
        '_modifiedOn': null,
        '_isDeleted': false,
        '_oldVersion': '',
        '_version': '',
        '_requestId': '',
        '_newVersion': ''
    },
    'externalChargeAmt': {
        'value': 0,
        'ccy': 'SGD'
    },
    'collateralValue': {
        'value': 0,
        'ccy': 'SGD'
    },
    'finalCollateralValue': {
        'value': 0,
        'ccy': 'SGD'
    },
    'apportioningMethod': 'A',
    'totalApportionedValue': {
        'value': 0,
        'ccy': 'SGD'
    },
    'balanceApportionableAmt': {
        'value': 0,
        'ccy': 'SGD'
    },
    'justificationRemark': 'Remarks',
    'valRepRequired': 'na',
    'loanToValuePcnt': 0
};
