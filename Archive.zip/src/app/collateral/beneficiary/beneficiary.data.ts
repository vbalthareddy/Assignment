export const BeneficiaryListResponse = [{
    'cif_id': 'A',
    'beneficiary_id': 'B',
    'beneficiary_type': 'C',
    'testing1': '123',
    'testing2': '123'

}, {
    'cif_id': 'A',
    'beneficiary_id': 'B',
    'beneficiary_type': 'C',
    'testing1': '123A',
    'testing2': '123B'

}, {
    'cif_id': 'A',
    'beneficiary_id': 'B',
    'beneficiary_type': 'C',
    'testing1': '123A1',
    'testing2': '123A2'

}, {
    'cif_id': 'A',
    'beneficiary_id': 'B',
    'beneficiary_type': 'C',
    'testing1': '123A3',
    'testing2': '123A4'

}];

export const BeneficiaryIdList = [
    {
        'description': '16R2A GCIN4NF CN002 (GC0001045990)',
        'gcin': 'GC0001045990',
        'type': 'COUNTERPARTY1',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN004 (GC0001045991)',
        'gcin': 'GC0001045991',
        'type': 'COUNTERPARTY2',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN006 (GC0001045992)',
        'gcin': 'GC0001045992',
        'type': 'COUNTERPARTY3',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN008 (GC0001045993)',
        'gcin': 'GC0001045993',
        'type': 'COUNTERPARTY4',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN010 (GC0001045995)',
        'gcin': 'GC0001045995',
        'type': 'COUNTERPARTY5',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': '16R2A GCIN4NF CN011 (GC0000190330)',
        'gcin': 'GC0000190330',
        'type': 'COUNTERPARTY6',
        'typeDescription': 'COUNTERPARTY'
    }
];
export const BeneficiaryIdListSorting = [
    {
        'description': 'Ajkdfhkjdsfhjsd (GC0001045990)',
        'gcin': 'GC0001045990',
        'type': 'COUNTERPARTY1',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': 'Abiksjdief (GC0001045991)',
        'gcin': 'GC0001045991',
        'type': 'COUNTERPARTY2',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': 'zjhfdsfhjfs (GC0001045992)',
        'gcin': 'GC0001045992',
        'type': 'COUNTERPARTY3',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': 'hdiwqdhhd (GC0001045993)',
        'gcin': 'GC0001045993',
        'type': 'COUNTERPARTY4',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': 'hqwiqiukjk (GC0001045995)',
        'gcin': 'GC0001045995',
        'type': 'COUNTERPARTY5',
        'typeDescription': 'COUNTERPARTY'
    },
    {
        'description': 'fewfewfw (GC0000190330)',
        'gcin': 'GC0000190330',
        'type': 'COUNTERPARTY6',
        'typeDescription': 'COUNTERPARTY'
    }
];
export const BeneficiaryIdModifiedList = [
    {
        'description': 'GC0001045990   16R2A GCIN4NF CN002 ',
        'gcin': 'GC0001045990',
        'type': 'COUNTERPARTY1',
        'name': '16R2A GCIN4NF CN002 '
    },
    {
        'description': 'GC0001045991   16R2A GCIN4NF CN004 ',
        'gcin': 'GC0001045991',
        'type': 'COUNTERPARTY2',
        'name': '16R2A GCIN4NF CN004 '
    },
    {
        'description': 'GC0001045992   16R2A GCIN4NF CN006 ',
        'gcin': 'GC0001045992',
        'type': 'COUNTERPARTY3',
        'name': '16R2A GCIN4NF CN006 '
    },
    {
        'description': 'GC0001045993   16R2A GCIN4NF CN008 ',
        'gcin': 'GC0001045993',
        'type': 'COUNTERPARTY4',
        'name': '16R2A GCIN4NF CN008 '
    },
    {
        'description': 'GC0001045995   16R2A GCIN4NF CN010 ',
        'gcin': 'GC0001045995',
        'type': 'COUNTERPARTY5',
        'name': '16R2A GCIN4NF CN010 '
    },
    {
        'description': 'GC0000190330   16R2A GCIN4NF CN011 ',
        'gcin': 'GC0000190330',
        'type': 'COUNTERPARTY5',
        'name': '16R2A GCIN4NF CN011 '
    }
];
export const BeneficiaryRankJson =
    [{'code': 0, 'description': '1DBS'},
        {'code': 1, 'description': '1ST'},
        {'code': 2, 'description': '2ND'},
        {'code': 3, 'description': '3RD'},
        {'code': 4, 'description': '4TH'},
        {'code': 5, 'description': '5TH'},
        {'code': 6, 'description': '6TH'},
        {'code': 7, 'description': '7TH'},
        {'code': 8, 'description': '8TH'},
        {'code': 9, 'description': '9TH'}];
export const BeneficiaryRankList = ['1DBS', '1ST', '2ND', '3RD', '4TH', '5TH', '6TH', '7TH', '8TH', '9TH'];
export const beneficiaryLimitData = {
        'GC0001045990': [
            {
                'limitId': 'LIM179',
                'collateralId': 'aaaaaaa'
            },
            {
                'limitId': 'LIM178',
                'collateralId': 'aaaaaaa'
            }
        ],
        'GC0001045992': [
            {
                'limitId': 'LIM177',
                'collateralId': 'aaaaaaa'
            }
        ]
    };
export const BeneficiaryGridData = [{
    'beneficiaryName': '16R2A GCIN4NF CN002 ',
    'beneficiaryId': 'GC0001045990',
    'beneficiaryCap': {
        value: 123,
        ccy: 'INR'
    },
    'beneficiaryRanking': '30 Apr 2017'
}
];
