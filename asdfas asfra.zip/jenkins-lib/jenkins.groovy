LINKS = [
    FORTIFY_SSCTOKEN: '3f34aefc-e5b4-488b-a3af-1d744c1c9a01', 
    FORTIFY_UPTOKEN: '134a1c1c-2845-4ba4-b68c-0f0018bdc8eb',
    SONAR: "http://sonar.dev.sys.cs.sgp.dbs.com",
    ARTIFACTORY_REPO: 'http://artifactory.dev.sys.cs.sgp.dbs.com/artifactory/libs-release-final-local'
]

def login(api, username, password, org, space) {
    stage "login"
    sh "set +x && cf login -a $api -u $username -p '$password' -o '$org' -s '$space'"
}

def loginWithCred(api, credentialsId) {
    stage 'Login to CF'

    withCredentials([[$class: 'UsernamePasswordMultiBinding',
                      credentialsId: "$credentialsId",
                      usernameVariable: 'USERNAME',
                      passwordVariable: 'PASSWORD']]) {
        echo "Credential used: $credentialsId"
        sh "set +x && cf login -a $api -u $env.USERNAME -p '$env.PASSWORD'"
    }
}

def target(args) {
    sh "cf target $args"
}

def push(app, args) {
    sh "cf push $app $args"
}

def deploy(app, args) {
    // blue green 
    stage "Deploy"

    sh "cf delete -f $app-blue || true"
    sh "cf rename $app $app-blue || true"
    sh "cf push $app $args"
    sh "cf stop $app-blue || true"
    //TODO check if the blue application has been stopped
}

def checkSonar(projectKey, failFast=true) {
    stage "Check Sonar Status"
    // very crude way to check sonar status, hardcoded to look for the ERROR status string
    boss {
        try {
            sh "curl $LINKS.SONAR/api/qualitygates/project_status?projectKey=$projectKey | \
                grep -v '^{\"projectStatus\":{\"status\":\"ERROR\"' > /dev/null"
        } catch (e)  {
            message = "Failed to pass sonar! $LINKS.SONAR/dashboard?id=$projectKey"
            if (failFast == true || failFast == "true") {
                error message
            } else {
                echo message
            }
        }
    }
}

/**
You need a sonar-project.properties file to push to DBS sonar 

Sample file can be found here:https://gitlab.dev.apps.cs.sgp.dbs.com/cap/wb-counterparty-profile-ui/blob/master/sonar-project.properties
*/
def sonarScanner(args) {
    def scannerHome = tool 'CST-SonarScanner'
    env.PATH = "${scannerHome}/bin:${env.PATH}"
    sh "sonar-scanner $args"
}

def uploadArtifact(projectName, filename, path) {
    stage 'Upload to Artifacts'
    url = "$LINKS.ARTIFACTORY_REPO/$projectName/b$env.BUILD_NUMBER/$filename"
    sh "curl -X PUT $url -T $path"
    echo "file is uploaded to $url"
}


def downloadArtifactory(projectName, buildNumber, filename) {
    stage 'Download Artifacts'
    url = "$LINKS.ARTIFACTORY_REPO/$projectName/b$buildNumber/$filename"
    sh "curl $url -o $filename"
    echo "file is downloaded from $url"
}

def downloadManifest(String url) {
    stage 'Download Manifest'
    sh "curl $url -o manifest.yml"
    echo 'Manifest file is downloaded'
}

def fortify(project, versionname, branch='master') {
    stage "Fortify Scan"

    def fortifyhome = tool name: 'fortify', type: 'com.cloudbees.jenkins.plugins.customtools.CustomTool'
    env.PATH = "${fortifyhome}/:${env.PATH}"
    
    sh "sourceanalyzer -b $env.BUILD_NUMBER -clean"
    sh "sourceanalyzer -b $env.BUILD_NUMBER -source 1.8 mvn com.hpe.security.fortify.maven.plugin:sca-maven-plugin:17.10:translate -DskipTests"
    // when we upgrade the git cli, it will be nice to use 'git remote get-url origin' to get the git repo
    sh 'GIT_REPO=$(git remote -v | head -n 1 | grep -o \'http.*.git\') \
            && GIT_COMMIT=$(git rev-parse HEAD) \
            && ' + "cloudscan -sscurl 'https://x01chpfoapp01a.sgp.dbs.com:8443/ssc' \
            -ssctoken '$LINKS.FORTIFY_SSCTOKEN' \
            start -upload -project $project -versionname $versionname -b $env.BUILD_NUMBER \
            -uptoken '$LINKS.FORTIFY_UPTOKEN' -scan -build-label 'b$env.BUILD_NUMBER' "
}

def maven(deploy=false) {
    stage 'Maven Build'
    boss {
        // spring boot specific, please add spring boot actuator 
        sh 'mkdir -p src/main/resources/META-INF'
        writeFile file: "src/main/resources/META-INF/build-info.properties", text: "build.build_number=$env.BUILD_NUMBER"

        def deployParameter = deploy ? 'deploy': ''

        sh "mvn clean git-commit-id:revision ${deployParameter}\
            org.jacoco:jacoco-maven-plugin:prepare-agent \
            package \
            sonar:sonar \
            -Dmaven.repo.local=.maven \
            -Dsonar.projectVersion=$env.BUILD_NUMBER \
            -Dsonar.host.url=$LINKS.SONAR"
    }
}

/*
    tag the current repo with build number 
*/
def tag() {
    stage "Tag"
    sh "git remote -v | grep push | cut -f2 | cut -f1 -d ' ' > .git_push_url"
    url = readFile ".git_push_url"
    url = url.replace("https://gitlab.dev.apps.cs.sgp.dbs.com/", "ssh://git@gitlab.dev.apps.cs.sgp.dbs.com:2222/")
    
    sshagent (credentials: ['c8546f37-e7aa-4259-801a-629974978f77']) {
        sh "git remote set-url origin ${url}"
        sh "git tag ${env.BUILD_NUMBER}"
        sh "git push origin ${env.BUILD_NUMBER}"
    }
}

/*
    BRANCH_NAME
*/
def runDeployJob(params = [:]) {

    if (!params.containsKey("BRANCH_NAME")) {
        params.put "BRANCH_NAME", "master"
    }

    params.put "BUILD_NUMBER", env.BUILD_NUMBER

    def args = []
    for (Map.Entry e : params.entrySet()) {
        args.add([$class: 'StringParameterValue', name: e.getKey(), value: e.getValue()])
    }

    stage "Deploy${params.DEPLOY_TO ? (' to ' + params.DEPLOY_TO) : '' }"
    build job: 'deploy', propagate: false, parameters: args

}



/*
Send email in case anything went wrong
*/
def boss(run) {
    try {
        return run()
    } catch (Throwable t) {
        sh 'git log --pretty=format:"%ae" --since="3am" | sort | uniq | tr "\n" "," > email'
        def email = readFile('email')
        if (email != '') {
            echo "Sending mail to: $email"
            mail(
                body: generateFailureEmailBody(), 
                from: 'boss@dbs.com', 
                subject: "[Build Failure] $env.JOB_NAME", 
                mimeType: 'text/html', 
                to: email
            )
        } else {
            echo "Can't find who broke the build!"
        }
        throw t;
    }
}

def generateFailureEmailBody() {
    return """
    <p>Go fix your build, the big boss is watching you!</p>

    <p>You better click the "Download Pictures" button in your outlook</p>

    <img src='https://gitlab.dev.apps.cs.sgp.dbs.com/cap/jenkins-lib/uploads/28de34d462678cae97af234f5a54577e/34774655.jpg'>

    <p>
        <a href='$env.BUILD_URL'>$env.BUILD_URL</a>
    </p>
    """
}

env.CF_HOME = '.'

return this