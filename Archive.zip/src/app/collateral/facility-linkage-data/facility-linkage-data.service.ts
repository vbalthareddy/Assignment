import {Injectable} from '@angular/core';

@Injectable()
export class FacilityLinkageDataService {

    private linkages: any = [];
    linkageData: any;

    setLinkages(linkageData: any) {
        this.linkages = [];
        this.linkages = linkageData;
    }

    getLinkages(): any {
        return this.linkages;
    }
}
